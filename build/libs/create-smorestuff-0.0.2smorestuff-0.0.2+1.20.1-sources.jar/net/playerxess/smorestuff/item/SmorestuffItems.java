package net.playerxess.smorestuff.item;

import net.fabricmc.fabric.api.item.v1.FabricItemSettings;
import net.playerxess.smorestuff.Smorestuff;
import net.minecraft.class_1792;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_7923;
import net.minecraft.item.*;
import net.playerxess.smorestuff.item.custom.TraditionalSmoreItem;

public class SmorestuffItems {
    public static final class_1792 MARSHMALLOW = registerItem("marshmallow", new class_1792(new FabricItemSettings()));

    public static final class_1792 PRESSED_DOUGH = registerItem("pressed_dough", new class_1792(new FabricItemSettings()));
    public static final class_1792 CRACKER = registerItem("cracker", new class_1792(new FabricItemSettings().method_19265(SmorestuffFoodComponents.CRACKERFOOD)));
    public static final class_1792 GRAHAMCRACKER = registerItem("graham_cracker", new class_1792(new FabricItemSettings()));

    public static final class_1792 RAWSMORE = registerItem("raw_smore", new class_1792(new FabricItemSettings()));
    public static final class_1792 TRADITIONALSMORE = registerItem("traditional_smore", new TraditionalSmoreItem(new FabricItemSettings().method_19265(SmorestuffFoodComponents.TRADITIONALSMOREFOOD)));

    public static final class_1792 MARSHMALLOWEYSMORE = registerItem("marshmallowey_smore", new class_1792(new FabricItemSettings().method_19265(SmorestuffFoodComponents.MARSHMALLOWEYSMOREFOOD)));
    public static final class_1792 CHOCOLATEYSMORE = registerItem("chocolatey_smore", new class_1792(new FabricItemSettings().method_19265(SmorestuffFoodComponents.CHOCOLATEYSMOREFOOD)));


    private static class_1792 registerItem(String name, class_1792 item) {
        return class_2378.method_10230(class_7923.field_41178, new class_2960(Smorestuff.MOD_ID, name), item);
    }

    public static void registerSmorestuffItems() {
        Smorestuff.LOGGER.info(("Registering Items For Mod Create: Smorestuff"));

    }
}

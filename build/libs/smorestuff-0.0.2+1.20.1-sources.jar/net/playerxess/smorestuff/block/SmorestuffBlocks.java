package net.playerxess.smorestuff.block;

import net.minecraft.class_1747;
import net.minecraft.class_1792;
import net.minecraft.class_2248;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_7923;
import net.playerxess.smorestuff.Smorestuff;

public class SmorestuffBlocks {

	public static class_2248 register(class_2248 block, String name, boolean shouldRegisterItem) {

		class_2960 id = new class_2960(Smorestuff.MOD_ID, name);

		if (shouldRegisterItem) {
			class_1747 blockItem = new class_1747(block, new class_1792.class_1793());
			class_2378.method_10230(class_7923.field_41178, id, blockItem);
		}

		return class_2378.method_10230(class_7923.field_41175, id, block);
	}

	public static void registerModBlocks() {
        Smorestuff.LOGGER.info(("Registering Blocks For Mod Create: Smorestuff"));

    }

}

package net.playerxess.smorestuff.item.custom;

import org.jetbrains.annotations.Nullable;
import java.util.List;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_1937;
import net.minecraft.class_2561;

public class TraditionalSmoreItem extends class_1792{
	public TraditionalSmoreItem(class_1793 settings) {
		super(settings);
	}

	@Override
    public void method_7851(class_1799 stack, @Nullable class_1937 world, List<class_2561> tooltip, class_1836 context) {
        tooltip.add(class_2561.method_43471("tooltip.smorestuff.traditional_smore_tooltip.tooltip"));
        super.method_7851(stack, world, tooltip, context);
    }

}

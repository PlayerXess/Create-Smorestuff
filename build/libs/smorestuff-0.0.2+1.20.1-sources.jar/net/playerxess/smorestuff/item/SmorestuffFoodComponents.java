package net.playerxess.smorestuff.item;

import java.util.Random;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_4174;

public class SmorestuffFoodComponents {

	public static final class_4174 CRACKERFOOD = new class_4174.class_4175().method_19238(3).method_19237(0.2f).method_19242();
	public static final class_4174 TRADITIONALSMOREFOOD = new class_4174.class_4175().method_19238(10).method_19237(0.5f).method_19239(new class_1293(class_1294.field_5922, 600, 1), 1.0F).method_19242();
	public static final class_4174 CHOCOLATEYSMOREFOOD = new class_4174.class_4175().method_19238(10).method_19237(0.5f).method_19239(new class_1293(class_1294.field_5922, 1200, 1), 1.0F).method_19239(new class_1293(class_1294.field_5904, 2400, 1), 1.0F).method_19242();
	public static final class_4174 MARSHMALLOWEYSMOREFOOD = new class_4174.class_4175().method_19238(10).method_19237(0.5f).method_19239(new class_1293(class_1294.field_5922, 1200, 1), 1.0F).method_19239(new class_1293(class_1294.field_5901, 600, 1), 1.0F).method_19242();

}

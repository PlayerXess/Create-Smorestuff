package net.playerxess.smorestuff.item;

import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.minecraft.class_1761;
import net.minecraft.class_1799;
import net.minecraft.class_2378;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_7923;
import net.playerxess.smorestuff.Smorestuff;
import net.playerxess.smorestuff.fluid.SmorestuffFluids;
import net.playerxess.smorestuff.block.SmorestuffBlocks;

public class SmorestuffItemGroups {
    public static final class_1761 SMORE_STUFF = class_2378.method_10230(class_7923.field_44687,
            new class_2960(Smorestuff.MOD_ID, "smore"),
            FabricItemGroup.builder().method_47321(class_2561.method_43471("itemgroup.smore"))
                    .method_47320(() -> new class_1799(SmorestuffItems.TRADITIONALSMORE)). method_47317((displayContext, entries) -> {
                        entries.method_45421(SmorestuffItems.MARSHMALLOW);
						entries.method_45421(SmorestuffItems.PRESSED_DOUGH);
						entries.method_45421(SmorestuffItems.CRACKER);
						entries.method_45421(SmorestuffItems.GRAHAMCRACKER);
						entries.method_45421(SmorestuffItems.RAWSMORE);
						entries.method_45421(SmorestuffItems.TRADITIONALSMORE);
						entries.method_45421(SmorestuffItems.CHOCOLATEYSMORE);
						entries.method_45421(SmorestuffItems.MARSHMALLOWEYSMORE);
						entries.method_45421(SmorestuffFluids.MARSHMALLOW_BUCKET);

                    }).method_47324());

    public static void registerItemGroups() {
        Smorestuff.LOGGER.info("Registering Item Groups For Mod Create: Smorestuff");
    }
}

package net.playerxess.smorestuff.fluid;

import net.fabricmc.fabric.api.item.v1.FabricItemSettings;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.fabricmc.fabric.api.object.builder.v1.block.FabricBlockSettings;
import net.minecraft.class_1755;
import net.minecraft.class_1792;
import net.minecraft.class_1802;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2378;
import net.minecraft.class_2404;
import net.minecraft.class_2960;
import net.minecraft.class_3609;
import net.minecraft.class_7923;
import net.playerxess.smorestuff.Smorestuff;
import net.playerxess.smorestuff.item.SmorestuffItemGroups;

public class SmorestuffFluids {

    public static class_3609 MARSHMALLOW_STILL;
    public static class_3609 MARSHMALLOW_FLOWING;
    public static class_2248 FLUID_MARSHMALLOW_BLOCK;
    public static class_1792 MARSHMALLOW_BUCKET;

    public static void registerModFluids() {
        MARSHMALLOW_STILL = class_2378.method_10230(class_7923.field_41173,
                new class_2960(Smorestuff.MOD_ID, "marshmallow_still"), new MarshmallowFluid.Still());
        MARSHMALLOW_FLOWING = class_2378.method_10230(class_7923.field_41173,
                new class_2960(Smorestuff.MOD_ID, "marshmallow_flow"), new MarshmallowFluid.Flowing());

        FLUID_MARSHMALLOW_BLOCK = class_2378.method_10230(class_7923.field_41175, new class_2960(Smorestuff.MOD_ID, "fluid_marshmallow_block"),
                new class_2404(SmorestuffFluids.MARSHMALLOW_STILL, FabricBlockSettings.copyOf(class_2246.field_10382)){ });
        MARSHMALLOW_BUCKET = class_2378.method_10230(class_7923.field_41178, new class_2960(Smorestuff.MOD_ID, "marshmallow_bucket"),
                new class_1755(SmorestuffFluids.MARSHMALLOW_STILL, new FabricItemSettings().method_7896(class_1802.field_8550).method_7889(1)));
    }

}

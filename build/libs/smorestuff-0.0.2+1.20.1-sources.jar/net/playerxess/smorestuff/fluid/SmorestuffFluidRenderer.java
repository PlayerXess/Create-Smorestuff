package net.playerxess.smorestuff.fluid;

import net.fabricmc.fabric.api.blockrenderlayer.v1.BlockRenderLayerMap;
import net.fabricmc.fabric.api.client.render.fluid.v1.FluidRenderHandler;
import net.fabricmc.fabric.api.client.render.fluid.v1.SimpleFluidRenderHandler;
import net.fabricmc.fabric.api.client.render.fluid.v1.FluidRenderHandlerRegistry;
import net.fabricmc.fabric.impl.client.rendering.fluid.FluidRenderHandlerRegistryImpl;
import net.minecraft.class_1921;
import net.minecraft.class_2960;
import net.playerxess.smorestuff.Smorestuff;
import net.playerxess.smorestuff.fluid.SmorestuffFluids;

public class SmorestuffFluidRenderer {
    static FluidRenderHandler MarshmallowFluidRenderHandler = new SimpleFluidRenderHandler(new class_2960("smorestuff", "fluid/marshmallow_still"), new class_2960("smorestuff", "texture/fluid/marshmallow_flow"));
    FluidRenderHandlerRegistry fluidRegistry = new FluidRenderHandlerRegistryImpl();

    public static void setupFluidRendering() {
        Smorestuff.LOGGER.info("Loading Fluid Rendering For Create: Smorestuff");

        FluidRenderHandlerRegistry.INSTANCE.register(SmorestuffFluids.MARSHMALLOW_STILL, SmorestuffFluids.MARSHMALLOW_FLOWING, MarshmallowFluidRenderHandler);

        BlockRenderLayerMap.INSTANCE.putFluids(class_1921.method_23577(), SmorestuffFluids.MARSHMALLOW_STILL, SmorestuffFluids.MARSHMALLOW_FLOWING);


    }

    public static void registerFluidRenderer() {
        Smorestuff.LOGGER.info("Loading Fluid Rendering For Create: Smorestuff");
        setupFluidRendering();
    }

}

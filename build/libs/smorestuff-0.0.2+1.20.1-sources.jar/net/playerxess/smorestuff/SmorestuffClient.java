package net.playerxess.smorestuff;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.render.fluid.v1.FluidRenderHandlerRegistry;
import net.fabricmc.fabric.api.client.render.fluid.v1.SimpleFluidRenderHandler;
import net.minecraft.class_2960;
import net.playerxess.smorestuff.fluid.SmorestuffFluids;

public class SmorestuffClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
FluidRenderHandlerRegistry.INSTANCE.register(SmorestuffFluids.MARSHMALLOW_STILL, SmorestuffFluids.MARSHMALLOW_FLOWING,
                new SimpleFluidRenderHandler(
                        new class_2960("minecraft:block/water_still"),
                        new class_2960("minecraft:block/water_flow"),
                        0xFFFFFF
                ));
    }
}

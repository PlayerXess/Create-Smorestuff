package net.playerxess.smorestuff;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.render.fluid.v1.FluidRenderHandlerRegistry;
import net.fabricmc.fabric.api.client.render.fluid.v1.SimpleFluidRenderHandler;
import net.minecraft.class_2960;
import net.minecraft.class_3611;
import net.playerxess.smorestuff.fluid.SmorestuffFluids;
import net.fabricmc.fabric.api.client.render.fluid.v1.FluidRenderHandler;import org.slf4j.Logger;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class SmorestuffClient implements ClientModInitializer {

    public static void setupFluidRendering(final class_3611 still, final class_3611 flowing, final class_2960 textureBase) {
        final class_2960 stillTexture = new class_2960(textureBase.method_12836(), "fluid/marshmallow_still");
        Smorestuff.LOGGER.info("Attempted To Load Marshmallow Still Texture");

        final class_2960 flowingTexture = new class_2960(textureBase.method_12836(), "texture/fluid/marshmallow_flow");
        Smorestuff.LOGGER.info("Attempted To Load Marshmallow Flowing Texture");

        FluidRenderHandler handler = new SimpleFluidRenderHandler(stillTexture, flowingTexture);
        FluidRenderHandlerRegistry.INSTANCE.register(still, handler);
        FluidRenderHandlerRegistry.INSTANCE.register(flowing, handler);
    }

    @Override
    public void onInitializeClient() {
        setupFluidRendering(SmorestuffFluids.MARSHMALLOW_STILL, SmorestuffFluids.MARSHMALLOW_FLOWING, new class_2960(Smorestuff.MOD_ID, "marshmallow"));
    }
}

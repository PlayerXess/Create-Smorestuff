package net.playerxess.smorestuff;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.blockrenderlayer.v1.BlockRenderLayerMap;
import net.fabricmc.fabric.api.client.render.fluid.v1.FluidRenderHandler;
import net.fabricmc.fabric.api.client.render.fluid.v1.SimpleFluidRenderHandler;
import net.minecraft.class_1921;
import net.minecraft.class_2960;
import net.minecraft.class_3611;
import net.fabricmc.fabric.api.client.render.fluid.v1.FluidRenderHandlerRegistry;
import net.playerxess.smorestuff.Smorestuff;
import net.playerxess.smorestuff.fluid.SmorestuffFluids;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class SmorestuffClient implements ClientModInitializer {
    public static void setupFluidRendering(final class_3611 still, final class_3611 flowing, final String textureBase) {
        final class_2960 stillTexture = new class_2960(textureBase, "block/marshmallow_still");
            Smorestuff.LOGGER.info("Grabbing Still Texture from: " + stillTexture.toString());
        final class_2960 flowingTexture = new class_2960(textureBase, "block/marshmallow_flow");
            Smorestuff.LOGGER.info("Grabbing Flowing Texture from: " + flowingTexture.toString());

        FluidRenderHandler handler = new SimpleFluidRenderHandler(stillTexture, flowingTexture);
        FluidRenderHandlerRegistry.INSTANCE.register(still, handler);
        FluidRenderHandlerRegistry.INSTANCE.register(flowing, handler);
    }
    @Override
    public void onInitializeClient() {
        setupFluidRendering(SmorestuffFluids.MARSHMALLOW_STILL, SmorestuffFluids.MARSHMALLOW_FLOWING, "smorestuff");
        BlockRenderLayerMap.INSTANCE.putFluids(class_1921.method_23583(), SmorestuffFluids.MARSHMALLOW_STILL, SmorestuffFluids.MARSHMALLOW_FLOWING);
    }
}

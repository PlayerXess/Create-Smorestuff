package net.playerxess.smorestuff.datagen;

import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricRecipeProvider;
import net.minecraft.class_2444;
import java.util.List;
import java.util.function.Consumer;

public class SmorestuffRecipeProvider extends FabricRecipeProvider {

    public SmorestuffRecipeProvider(FabricDataOutput output) {
        super(output);
    }

    @Override
    public void method_10419(Consumer<class_2444> exporter) {
            }
}



package net.playerxess.smorestuff.datagen;

import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricTagProvider;
import net.minecraft.class_7225;
import net.playerxess.smorestuff.item.SmorestuffItems;
import java.util.concurrent.CompletableFuture;

public class SmorestuffBlockTagProvider extends FabricTagProvider.BlockTagProvider {

	public SmorestuffBlockTagProvider(FabricDataOutput output, CompletableFuture<class_7225.class_7874> registriesFuture) {
        super(output, registriesFuture);
    }

    @Override
    protected void method_10514(class_7225.class_7874 arg) {

    }
}


package net.playerxess.smorestuff.datagen;

import net.fabricmc.fabric.api.datagen.v1.DataGeneratorEntrypoint;
import net.fabricmc.fabric.api.datagen.v1.FabricDataGenerator;
import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricAdvancementProvider;
import net.minecraft.advancement.*;
import net.minecraft.class_161;
import net.minecraft.class_189;
import net.minecraft.class_2066;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import java.util.function.Consumer;
import net.playerxess.smorestuff.item.SmorestuffItems;

public class SmorestuffAdvancementsProvider extends FabricAdvancementProvider {

	public SmorestuffAdvancementsProvider(FabricDataOutput dataGenerator) {
		super(dataGenerator);
	}

	@Override
    public void generateAdvancement(Consumer<class_161> consumer) {
        class_161 rootAdvancement = class_161.class_162.method_707()
                .method_697(
                        SmorestuffItems.TRADITIONALSMORE, // The display icon
                        class_2561.method_43470("A Taste Of Tradition"), // The title
                        class_2561.method_43470("Make Your First Traditional S'more"), // The description
                        new class_2960("src/main/resources/assets/smorestuff/textures/item/traditional_smore.png"), // Background image used
                        class_189.field_1254, // Options: TASK(field_1254), CHALLENGE(field_1250), GOAL(field_1249)
                        true, // Show toast top right
                        true, // Announce to chat
                        false // Hidden in the advancement tab
                )
                // The first string used in criterion is the name referenced by other advancements when they want to have 'requirements'
                .method_709("got_s'more", class_2066.class_2068.method_8959(SmorestuffItems.TRADITIONALSMORE))
                .method_694(consumer, "smorestuff" + "/root");
    }
}


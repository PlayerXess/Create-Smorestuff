package net.playerxess.smorestuff.datagen;

import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricModelProvider;
import net.minecraft.class_4910;
import net.minecraft.class_4915;
import net.playerxess.smorestuff.item.SmorestuffItems;

public class SmorestuffModelProvider extends FabricModelProvider {
    public SmorestuffModelProvider(FabricDataOutput output) {
        super(output);
    }

    @Override
    public void generateBlockStateModels(class_4910 blockStateModelGenerator) {

    }

    @Override
    public void generateItemModels(class_4915 itemModelGenerator) {

    }
}

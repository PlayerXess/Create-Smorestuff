package net.playerxess.smorestuff.datagen;

import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricBlockLootTableProvider;
import net.minecraft.class_141;
import net.minecraft.class_1792;
import net.minecraft.class_1893;
import net.minecraft.class_2248;
import net.minecraft.class_52;
import net.minecraft.class_5662;
import net.minecraft.class_77;
import net.minecraft.class_7788;
import net.minecraft.class_79;
import net.minecraft.class_85;
import net.minecraft.class_94;
import net.playerxess.smorestuff.item.SmorestuffItems;

public class SmorestuffLootTableProvider extends FabricBlockLootTableProvider {
    public SmorestuffLootTableProvider(FabricDataOutput dataOutput) {
        super(dataOutput);
    }

    @Override
    public void method_10379() {

    }

    public class_52.class_53 copperLikeOreDrops(class_2248 drop, class_1792 item) {
        return class_7788.method_45989(drop, (class_79.class_80)this.method_45977(drop,
                ((class_85.class_86)
                        class_77.method_411(item)
                                .method_438(class_141
                                        .method_621(class_5662
                                                .method_32462(2.0f, 5.0f))))
                        .method_438(class_94.method_455(class_1893.field_9130))));
    }
}


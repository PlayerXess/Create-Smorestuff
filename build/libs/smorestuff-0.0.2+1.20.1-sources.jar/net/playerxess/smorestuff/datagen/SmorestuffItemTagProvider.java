package net.playerxess.smorestuff.datagen;

import java.util.concurrent.CompletableFuture;

import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricTagProvider;
import net.minecraft.class_7225;

public class SmorestuffItemTagProvider extends FabricTagProvider.ItemTagProvider {
    public SmorestuffItemTagProvider(FabricDataOutput output, CompletableFuture<class_7225.class_7874> completableFuture) {
        super(output, completableFuture);
    }

    @Override
    protected void method_10514(class_7225.class_7874 arg) {

    }
}

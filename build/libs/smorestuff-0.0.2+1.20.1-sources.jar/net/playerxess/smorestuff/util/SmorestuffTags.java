package net.playerxess.smorestuff.util;

import net.minecraft.class_1792;
import net.minecraft.class_2248;
import net.minecraft.class_2960;
import net.minecraft.class_6862;
import net.minecraft.class_7924;
import net.playerxess.smorestuff.Smorestuff;

public class SmorestuffTags {

	public static class Blocks {



		private static class_6862<class_2248> createTag(String name) {
            return class_6862.method_40092(class_7924.field_41254, new class_2960(Smorestuff.MOD_ID, name));
        }

	}

	public static class Items {

		private static class_6862<class_1792> createTag(String name) {
            return class_6862.method_40092(class_7924.field_41197, new class_2960(Smorestuff.MOD_ID, name));
        }

	}
}

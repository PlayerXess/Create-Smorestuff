/*
 * This file is licensed under the MIT License, part of Roughly Enough Items.
 * Copyright (c) 2018, 2019, 2020, 2021, 2022, 2023 shedaniel
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */

package me.shedaniel.rei.plugin.autocrafting.recipebook;

import me.shedaniel.rei.api.client.ClientHelper;
import me.shedaniel.rei.api.client.registry.transfer.TransferHandler;
import me.shedaniel.rei.api.common.display.Display;
import me.shedaniel.rei.api.common.display.SimpleGridMenuDisplay;
import me.shedaniel.rei.api.common.transfer.info.MenuTransferException;
import me.shedaniel.rei.plugin.common.displays.cooking.DefaultCookingDisplay;
import me.shedaniel.rei.plugin.common.displays.crafting.DefaultCraftingDisplay;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.gui.screen.recipebook.RecipeBookProvider;
import net.minecraft.recipe.Recipe;
import net.minecraft.screen.AbstractRecipeScreenHandler;
import net.minecraft.screen.CraftingScreenHandler;
import net.minecraft.screen.PlayerScreenHandler;
import net.minecraft.text.Text;
import ApplicabilityResult;
import Result;
import java.util.Optional;

@Environment(EnvType.CLIENT)
public class DefaultRecipeBookHandler implements TransferHandler {
    @Override
    public me.shedaniel.rei.api.client.registry.transfer.TransferHandler.ApplicabilityResult checkApplicable(Context context) {
        if (context.getDisplay() instanceof SimpleGridMenuDisplay && ClientHelper.getInstance().canUseMovePackets())
            return me.shedaniel.rei.api.client.registry.transfer.TransferHandler.ApplicabilityResult.createNotApplicable();
        Display display = context.getDisplay();
        if (!(context.getMenu() instanceof AbstractRecipeScreenHandler<?> container))
            return me.shedaniel.rei.api.client.registry.transfer.TransferHandler.ApplicabilityResult.createNotApplicable();
        if (container == null)
            return me.shedaniel.rei.api.client.registry.transfer.TransferHandler.ApplicabilityResult.createNotApplicable();
        return me.shedaniel.rei.api.client.registry.transfer.TransferHandler.ApplicabilityResult.createApplicable();
    }
    
    @Override
    public me.shedaniel.rei.api.client.registry.transfer.TransferHandler.Result handle(Context context) {
        AbstractRecipeScreenHandler<?> container = (AbstractRecipeScreenHandler<?>) context.getMenu();
        Display display = context.getDisplay();
        if (display instanceof DefaultCraftingDisplay<?> craftingDisplay) {
            if (craftingDisplay.getOptionalRecipe().isPresent()) {
                int h = -1, w = -1;
                if (container instanceof CraftingScreenHandler) {
                    h = 3;
                    w = 3;
                } else if (container instanceof PlayerScreenHandler) {
                    h = 2;
                    w = 2;
                }
                if (h == -1 || w == -1)
                    return me.shedaniel.rei.api.client.registry.transfer.TransferHandler.Result.createNotApplicable();
                Recipe<?> recipe = craftingDisplay.getOptionalRecipe().get();
                if (craftingDisplay.getHeight() > h || craftingDisplay.getWidth() > w)
                    return me.shedaniel.rei.api.client.registry.transfer.TransferHandler.Result.createFailed(Text.translatable("error.rei.transfer.too_small", h, w));
                if (!context.getMinecraft().player.getRecipeBook().contains(recipe))
                    return me.shedaniel.rei.api.client.registry.transfer.TransferHandler.Result.createNotApplicable();
                if (!context.isActuallyCrafting())
                    return me.shedaniel.rei.api.client.registry.transfer.TransferHandler.Result.createSuccessful();
                context.getMinecraft().setScreen(context.getContainerScreen());
                if (context.getContainerScreen() instanceof RecipeBookProvider)
                    ((RecipeBookProvider) context.getContainerScreen()).getRecipeBookWidget().ghostSlots.reset();
                context.getMinecraft().gameMode.handlePlaceRecipe(container.syncId, recipe, context.isStackedCrafting());
                return me.shedaniel.rei.api.client.registry.transfer.TransferHandler.Result.createSuccessful();
            }
        } else if (display instanceof DefaultCookingDisplay defaultDisplay) {
            if (defaultDisplay.getOptionalRecipe().isPresent()) {
                Recipe<?> recipe = (defaultDisplay).getOptionalRecipe().get();
                if (!context.getMinecraft().player.getRecipeBook().contains(recipe))
                    return me.shedaniel.rei.api.client.registry.transfer.TransferHandler.Result.createNotApplicable();
                if (!context.isActuallyCrafting())
                    return me.shedaniel.rei.api.client.registry.transfer.TransferHandler.Result.createSuccessful();
                context.getMinecraft().setScreen(context.getContainerScreen());
                if (context.getContainerScreen() instanceof RecipeBookProvider)
                    ((RecipeBookProvider) context.getContainerScreen()).getRecipeBookWidget().ghostSlots.reset();
                context.getMinecraft().gameMode.handlePlaceRecipe(container.syncId, recipe, context.isStackedCrafting());
                return me.shedaniel.rei.api.client.registry.transfer.TransferHandler.Result.createSuccessful();
            }
        }
        return me.shedaniel.rei.api.client.registry.transfer.TransferHandler.Result.createNotApplicable();
    }
    
    @Override
    public double getPriority() {
        return -20;
    }
}

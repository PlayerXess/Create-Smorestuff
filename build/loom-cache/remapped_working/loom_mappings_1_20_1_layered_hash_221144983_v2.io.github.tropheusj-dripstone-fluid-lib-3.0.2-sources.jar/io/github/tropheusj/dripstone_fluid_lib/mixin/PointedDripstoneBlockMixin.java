package io.github.tropheusj.dripstone_fluid_lib.mixin;

import java.util.Optional;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.PointedDripstoneBlock;
import net.minecraft.fluid.Fluid;
import net.minecraft.fluid.Fluids;
import net.minecraft.particle.ParticleEffect;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.registry.tag.FluidTags;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;
import net.minecraft.world.WorldAccess;
import net.minecraft.world.WorldEvents;
import net.minecraft.world.WorldView;
import net.minecraft.world.event.GameEvent;
import io.github.tropheusj.dripstone_fluid_lib.Constants;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Overwrite;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;

import com.google.common.annotations.VisibleForTesting;

import io.github.tropheusj.dripstone_fluid_lib.DripstoneInteractingFluid;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(value = PointedDripstoneBlock.class, priority = 429) // random number to apply overwrites early, let other mods inject
public abstract class PointedDripstoneBlockMixin {

	@Shadow
	private static boolean isHeldByPointedDripstone(BlockState state, WorldView world, BlockPos pos) {
		throw new RuntimeException("Mixin application failed!");
	}

	@Shadow
	@Nullable
	private static BlockPos getTipPos(BlockState state, WorldAccess world, BlockPos pos, int range, boolean allowMerged) {
		throw new RuntimeException("Mixin application failed!");
	}

	@Shadow
	private static Fluid getDripFluid(World world, Fluid fluid) {
		throw new RuntimeException("Mixin application failed!");
	}

	@Shadow
	@Nullable
	private static BlockPos getCauldronPos(World world, BlockPos pos, Fluid fluid) {
		throw new RuntimeException("Mixin application failed!");
	}

	@Shadow
	private static Optional<class_7381> getFluid(World world, BlockPos pos, BlockState state) {
		throw new RuntimeException("Mixin application failed!");
	}

	/**
	 * @author Tropheus Jay
	 * @reason to properly handle custom fluid drip chances, requires access to multiple variables
	 */
	@VisibleForTesting
	@Overwrite
	public static void dripTick(BlockState state, ServerWorld world, BlockPos pos, float dripChance) {
		// removed outside if statement to handle custom fluid chances
		if (isHeldByPointedDripstone(state, world, pos)) {
			Optional<PointedDripstoneBlock.DrippingFluid> optional = getFluid(world, pos, state);
			if (!optional.isEmpty()) {
				Fluid fluid = optional.get().comp_710();
				float f;
				if (fluid == Fluids.WATER) {
					f = 0.17578125F;
				} else {
					if (fluid != Fluids.LAVA) {
						// custom fluid chance
						if (fluid instanceof DripstoneInteractingFluid customFluid) {
							f = customFluid.getFluidDripChance(world, optional.get());
						} else return;
					}

					f = 0.05859375F;
				}

				if (!(dripChance >= f)) {
					BlockPos blockPos = getTipPos(state, world, pos, 11, false);
					if (blockPos != null) {
						if (optional.get().comp_711().method_27852(Blocks.field_37576) && fluid == Fluids.WATER) {
							BlockState blockState = Blocks.field_10460.getDefaultState();
							world.setBlockState(optional.get().comp_709(), blockState);
							Block.pushEntitiesUpBeforeBlockChange(
									optional.get().comp_711(), blockState, world, optional.get().comp_709()
							);
							world.emitGameEvent(GameEvent.field_28733, optional.get().comp_709(), GameEvent.Emitter.of(blockState));
							world.syncWorldEvent(WorldEvents.POINTED_DRIPSTONE_DRIPS, blockPos, 0);
						} else {
							BlockPos blockPos2 = getCauldronPos(world, blockPos, fluid);
							if (blockPos2 != null) {
								world.syncWorldEvent(WorldEvents.POINTED_DRIPSTONE_DRIPS, blockPos, 0);
								int i = blockPos.getY() - blockPos2.getY();
								int j = 50 + i;
								BlockState blockState2 = world.getBlockState(blockPos2);
								world.scheduleBlockTick(blockPos2, blockState2.getBlock(), j);
							}
						}
					}
				}
			}
		}
	}

	/**
	 * @reason get particle effect for other fluids, requires access to the fluid gotten from getDripFluid
	 * @author Tropheus Jay
	 */
	@Overwrite
	private static void createParticle(World world, BlockPos pos, BlockState state, Fluid fluid) {
		Vec3d modelOffset = state.getModelOffset(world, pos);
		double x = pos.getX() + 0.5 + modelOffset.x;
		double y = ((pos.getY() + 1) - 0.6875F) - 0.0625;
		double z = pos.getZ() + 0.5 + modelOffset.z;
		Fluid dripFluid = getDripFluid(world, fluid);
		ParticleEffect particleEffect;
		if (dripFluid instanceof DripstoneInteractingFluid interactingFluid) {
			particleEffect = Constants.FLUIDS_TO_PARTICLES.get(interactingFluid).hang();
		} else {
			particleEffect = dripFluid.isIn(FluidTags.field_15518) ? ParticleTypes.field_28076 : ParticleTypes.field_28078;
		}
		world.addParticle(particleEffect, x, y, z, 0.0, 0.0, 0.0);
	}

	/**
	 * @reason allow fluids other than water to grow dripstone
	 * @author Tropheus Jay
	 */
	@Overwrite
	private static boolean canGrow(BlockState dripstoneBlockState, BlockState fluidState) {
		Fluid fluid = fluidState.getFluidState().getFluid();
		boolean growsDripstone = fluidState.isOf(Blocks.field_10382);
		if (fluid instanceof DripstoneInteractingFluid interactingFluid) {
			growsDripstone = interactingFluid.growsDripstone(fluidState);
		}

		return dripstoneBlockState.isOf(Blocks.field_28049) && growsDripstone && fluidState.getFluidState().isStill();
	}

	@Inject(method = "isFluidLiquid", at = @At("HEAD"), cancellable = true)
	private static void dripstone_fluid_lib$makeCustomFluidsValid(Fluid fluid, CallbackInfoReturnable<Boolean> cir) {
		if (fluid instanceof DripstoneInteractingFluid) {
			cir.setReturnValue(true);
		}
	}
}

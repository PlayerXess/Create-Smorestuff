package io.github.fabricators_of_create.porting_lib.mixin.accessors.common.accessor;

import net.minecraft.entity.decoration.painting.PaintingEntity;
import net.minecraft.entity.decoration.painting.PaintingVariant;
import net.minecraft.registry.entry.RegistryEntry;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(PaintingEntity.class)
public interface PaintingAccessor {
	@Invoker("setVariant")
	void porting_lib$setVariant(RegistryEntry<PaintingVariant> variant);
}

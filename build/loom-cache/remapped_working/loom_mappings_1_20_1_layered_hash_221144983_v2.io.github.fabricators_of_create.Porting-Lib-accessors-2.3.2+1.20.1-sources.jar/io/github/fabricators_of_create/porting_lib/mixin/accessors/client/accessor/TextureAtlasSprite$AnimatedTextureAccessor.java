package io.github.fabricators_of_create.porting_lib.mixin.accessors.client.accessor;

import net.minecraft.client.texture.SpriteContents;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(SpriteContents.Animation.class)
public interface AnimatedTextureAccessor {
	@Invoker("getFrameX")
	int port_lib$getFrameX(int frameIndex);

	@Invoker("getFrameY")
	int port_lib$getFrameY(int frameIndex);
}

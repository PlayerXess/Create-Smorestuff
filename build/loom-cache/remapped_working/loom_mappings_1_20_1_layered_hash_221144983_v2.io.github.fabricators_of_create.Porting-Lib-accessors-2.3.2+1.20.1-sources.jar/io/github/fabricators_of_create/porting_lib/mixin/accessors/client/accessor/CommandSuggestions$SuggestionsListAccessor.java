package io.github.fabricators_of_create.porting_lib.mixin.accessors.client.accessor;

import com.mojang.brigadier.suggestion.Suggestion;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

import java.util.List;
import net.minecraft.client.gui.screen.ChatInputSuggestor;

@Mixin(ChatInputSuggestor.SuggestionWindow.class)
public interface SuggestionsListAccessor {
	@Invoker("<init>")
	static ChatInputSuggestor.SuggestionWindow port_lib$create(ChatInputSuggestor suggestions, int i, int j, int k, List<Suggestion> list, boolean bl) {
		throw new RuntimeException("mixin failed");
	}
}

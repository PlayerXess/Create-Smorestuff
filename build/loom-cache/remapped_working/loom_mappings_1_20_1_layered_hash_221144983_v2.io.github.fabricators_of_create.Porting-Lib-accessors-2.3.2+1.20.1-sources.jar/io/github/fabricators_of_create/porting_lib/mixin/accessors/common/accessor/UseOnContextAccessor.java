package io.github.fabricators_of_create.porting_lib.mixin.accessors.common.accessor;

import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemUsageContext;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.world.World;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(ItemUsageContext.class)
public interface UseOnContextAccessor {
	@Invoker("<init>")
	static ItemUsageContext createUseOnContext(World level, @Nullable PlayerEntity player, Hand interactionHand, ItemStack itemStack, BlockHitResult blockHitResult) {
		throw new UnsupportedOperationException();
	}
}

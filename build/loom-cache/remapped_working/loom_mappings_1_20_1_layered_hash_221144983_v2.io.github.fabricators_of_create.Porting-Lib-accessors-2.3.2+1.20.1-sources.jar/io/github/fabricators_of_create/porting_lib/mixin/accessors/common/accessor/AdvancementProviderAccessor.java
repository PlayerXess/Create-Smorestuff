package io.github.fabricators_of_create.porting_lib.mixin.accessors.common.accessor;

import java.util.List;
import net.minecraft.data.DataOutput;
import net.minecraft.data.server.advancement.AdvancementProvider;
import net.minecraft.data.server.advancement.AdvancementTabGenerator;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(AdvancementProvider.class)
public interface AdvancementProviderAccessor {
	@Accessor
	DataOutput.PathResolver getPathProvider();

	@Accessor
	List<AdvancementTabGenerator> getSubProviders();
}

package io.github.fabricators_of_create.porting_lib.transfer.item;

import org.jetbrains.annotations.NotNull;

import io.github.fabricators_of_create.porting_lib.transfer.TransferUtil;
import net.fabricmc.fabric.api.transfer.v1.item.ItemVariant;
import net.fabricmc.fabric.api.transfer.v1.storage.SlottedStorage;
import net.fabricmc.fabric.api.transfer.v1.storage.base.SingleSlotStorage;
import net.fabricmc.fabric.api.transfer.v1.transaction.Transaction;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.inventory.Inventory;
import net.minecraft.inventory.SimpleInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.screen.slot.Slot;

public class SlotItemHandler extends Slot {
	private static final Inventory emptyInventory = new SimpleInventory(0);
	private final SlottedStorage<ItemVariant> storage;
	private final int index;

	public SlotItemHandler(SlottedStackStorage storage, int index, int xPosition, int yPosition) {
		super(emptyInventory, index, xPosition, yPosition);
		this.storage = storage;
		this.id = index;
	}

	public SlotItemHandler(SlottedStorage<ItemVariant> storage, int index, int xPosition, int yPosition) {
		super(emptyInventory, index, xPosition, yPosition);
		this.storage = storage;
		this.id = index;
	}

	@Override
	public boolean canInsert(ItemStack stack) {
		if (stack.isEmpty())
			return false;
		if (storage instanceof SlottedStackStorage slottedStorage)
			return slottedStorage.isItemValid(id, ItemVariant.of(stack), stack.getCount());
		return true;
	}

	@Override
	@NotNull
	public ItemStack getStack() {
		if (storage instanceof SlottedStackStorage slottedStorage)
			return slottedStorage.getStackInSlot(id);
		var slot = storage.getSlot(id);
		return slot.getResource().toStack((int) slot.getAmount());
	}

	// Override if your IItemHandler does not implement IItemHandlerModifiable
	@Override
	public void setStackNoCallbacks(@NotNull ItemStack stack) {
		if (storage instanceof SlottedStackStorage slottedStorage)
			slottedStorage.setStackInSlot(id, stack);
		else {
			var slot = storage.getSlot(id);
			if (!slot.isResourceBlank()) {
				try (Transaction t = TransferUtil.getTransaction()) {
					slot.extract(slot.getResource(), slot.getAmount(), t);
					t.commit();
				}
			}
			var variant = ItemVariant.of(stack);
			if (!variant.isBlank()) {
				try (Transaction t = TransferUtil.getTransaction()) {
					slot.insert(variant, stack.getCount(), t);
					t.commit();
				}
			}
		}
		this.markDirty();
	}

	@Override
	public void onQuickTransfer(@NotNull ItemStack oldStackIn, @NotNull ItemStack newStackIn) {
	}

	@Override
	public int getMaxItemCount() {
		if (storage instanceof SlottedStackStorage slottedStorage)
			return slottedStorage.getSlotLimit(this.id);
		return (int) storage.getSlot(id).getCapacity();
	}

	@Override
	public int getMaxItemCount(@NotNull ItemStack stack) {
		if (storage instanceof SlottedStackStorage slottedStorage)
			return slottedStorage.getSlotLimit(id);
		return (int) storage.getSlot(id).getCapacity();
	}

	@Override
	public boolean canTakeItems(@NotNull PlayerEntity playerIn) {
		if (storage instanceof SlottedStackStorage slottedStorage)
			return !slottedStorage.getStackInSlot(id).isEmpty();
		return !storage.getSlot(id).isResourceBlank();
	}

	@Override
	@NotNull
	public ItemStack takeStack(int amount) {
		if (storage instanceof SlottedStackStorage slottedStorage) {
			ItemStack held = slottedStorage.getStackInSlot(id).copy();
			ItemStack removed = held.split(amount);
			slottedStorage.setStackInSlot(id, held);
			return removed;
		}
		try (Transaction t = TransferUtil.getTransaction()) {
			var slot = storage.getSlot(id);
			ItemStack lastResource = slot.getResource().toStack();
			long extraced = slot.extract(slot.getResource(), amount, t);
			t.commit();
			return lastResource.copyWithCount((int) extraced);
		}
	}

	public SlottedStorage<ItemVariant> getItemHandler() {
		return storage;
	}
}

package io.github.fabricators_of_create.porting_lib.transfer.fluid.block;

import io.github.fabricators_of_create.porting_lib.transfer.callbacks.TransactionSuccessCallback;
import net.fabricmc.fabric.api.transfer.v1.fluid.FluidConstants;
import net.fabricmc.fabric.api.transfer.v1.fluid.FluidVariant;
import net.fabricmc.fabric.api.transfer.v1.storage.base.ExtractionOnlyStorage;
import net.fabricmc.fabric.api.transfer.v1.storage.base.SingleSlotStorage;
import net.fabricmc.fabric.api.transfer.v1.transaction.TransactionContext;
import net.minecraft.block.FluidDrainable;
import net.minecraft.fluid.FluidState;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

public class BucketPickupHandlerWrapper implements SingleSlotStorage<FluidVariant>, ExtractionOnlyStorage<FluidVariant> {
	protected final FluidDrainable bucketPickupHandler;
	protected final World world;
	protected final BlockPos blockPos;

	public BucketPickupHandlerWrapper(FluidDrainable bucketPickupHandler, World world, BlockPos blockPos) {
		this.bucketPickupHandler = bucketPickupHandler;
		this.world = world;
		this.blockPos = blockPos;
	}

	@Override
	public long extract(FluidVariant resource, long maxAmount, TransactionContext tx) {
		if (!resource.isBlank() && FluidConstants.BUCKET <= maxAmount) {
			FluidState fluidState = world.getFluidState(blockPos);
			if (!fluidState.isEmpty() && resource.getFluid() == fluidState.getFluid()) {
				TransactionSuccessCallback.onSuccess(tx, () -> bucketPickupHandler.tryDrainFluid(world, blockPos, world.getBlockState(blockPos)));
				if (resource.equals(FluidVariant.of(fluidState.getFluid()))) {
					return FluidConstants.BUCKET;
				}
			}
		}
		return 0;
	}

	@Override
	public boolean isResourceBlank() {
		return getResource().isBlank();
	}

	@Override
	public FluidVariant getResource() {
		return FluidVariant.of(world.getFluidState(blockPos).getFluid());
	}

	@Override
	public long getAmount() {
		return !world.getFluidState(blockPos).isEmpty() ? FluidConstants.BUCKET : 0;
	}

	@Override
	public long getCapacity() {
		return FluidConstants.BUCKET;
	}
}

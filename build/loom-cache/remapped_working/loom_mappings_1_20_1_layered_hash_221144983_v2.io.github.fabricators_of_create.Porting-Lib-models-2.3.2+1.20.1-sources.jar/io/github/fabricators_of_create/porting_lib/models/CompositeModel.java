package io.github.fabricators_of_create.porting_lib.models;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.function.Function;
import java.util.function.Supplier;

import org.jetbrains.annotations.Nullable;

import com.google.common.collect.ImmutableList;
import com.google.common.collect.ImmutableMap;
import com.google.common.collect.ImmutableMap.Builder;
import io.github.fabricators_of_create.porting_lib.models.geometry.IUnbakedGeometry;
import net.fabricmc.fabric.api.renderer.v1.model.FabricBakedModel;
import net.fabricmc.fabric.api.renderer.v1.render.RenderContext;
import net.minecraft.block.BlockState;
import net.minecraft.client.render.model.BakedModel;
import net.minecraft.client.render.model.BakedQuad;
import net.minecraft.client.render.model.Baker;
import net.minecraft.client.render.model.BasicBakedModel;
import net.minecraft.client.render.model.ModelBakeSettings;
import net.minecraft.client.render.model.UnbakedModel;
import net.minecraft.client.render.model.json.JsonUnbakedModel;
import net.minecraft.client.render.model.json.ModelOverrideList;
import net.minecraft.client.render.model.json.ModelTransformation;
import net.minecraft.client.texture.Sprite;
import net.minecraft.client.util.SpriteIdentifier;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.random.Random;
import net.minecraft.world.BlockRenderView;

public class CompositeModel implements IUnbakedGeometry<CompositeModel> {
	private final ImmutableMap<String, JsonUnbakedModel> children;
	private final ImmutableList<String> itemPasses;

	public CompositeModel(ImmutableMap<String, JsonUnbakedModel> children, ImmutableList<String> itemPasses) {
		this.children = children;
		this.itemPasses = itemPasses;
	}

	@Override
	public BakedModel bake(JsonUnbakedModel context, Baker baker, Function<SpriteIdentifier, Sprite> spriteGetter, ModelBakeSettings modelState, ModelOverrideList overrides, Identifier modelLocation, boolean isGui3d) {
		SpriteIdentifier particleLocation = context.resolveSprite("particle");
		Sprite particle = spriteGetter.apply(particleLocation);

		var rootTransform = context.getRootTransform();
		if (!rootTransform.isIdentity()) {
			modelState = UnbakedGeometryHelper.composeRootTransformIntoModelState(modelState, rootTransform);
		}

		var bakedPartsBuilder = ImmutableMap.<String, BakedModel>builder();
		for (var entry : children.entrySet()) {
			var name = entry.getKey();
			if (!context.isComponentVisible(name, true)) {
				continue;
			}
			var model = entry.getValue();
			bakedPartsBuilder.put(name, model.bake(baker, model, spriteGetter, modelState, modelLocation, true));
		}
		var bakedParts = bakedPartsBuilder.build();

		var itemPassesBuilder = ImmutableList.<BakedModel>builder();
		for (String name : this.itemPasses) {
			var model = bakedParts.get(name);
			if (model == null) {
				throw new IllegalStateException("Specified \"" + name + "\" in \"item_render_order\", but that is not a child of this model.");
			}
			itemPassesBuilder.add(model);
		}

		return new Baked(true, context.getGuiLight().isSide(), context.useAmbientOcclusion(), particle, context.getTransformations(), context.compileOverrides(baker, context), bakedParts, itemPassesBuilder.build());
	}

	@Override
	public void resolveParents(Function<Identifier, UnbakedModel> modelGetter, JsonUnbakedModel context) {
		children.values().forEach(child -> child.setParents(modelGetter));
	}

	@Override
	public Set<String> getConfigurableComponentNames() {
		return children.keySet();
	}

	public static class Baked implements BakedModel, FabricBakedModel {
		private final boolean isAmbientOcclusion;
		private final boolean isGui3d;
		private final boolean isSideLit;
		private final Sprite particle;
		private final ModelOverrideList overrides;
		private final ModelTransformation transforms;
		private final ImmutableMap<String, BakedModel> children;
		private final ImmutableList<BakedModel> itemPasses;

		public Baked(boolean isGui3d, boolean isSideLit, boolean isAmbientOcclusion, Sprite particle, ModelTransformation transforms, ModelOverrideList overrides, ImmutableMap<String, BakedModel> children, ImmutableList<BakedModel> itemPasses) {
			this.children = children;
			this.isAmbientOcclusion = isAmbientOcclusion;
			this.isGui3d = isGui3d;
			this.isSideLit = isSideLit;
			this.particle = particle;
			this.overrides = overrides;
			this.transforms = transforms;
			this.itemPasses = itemPasses;
		}

		@Override
		public List<BakedQuad> getQuads(@Nullable BlockState state, @Nullable Direction side, Random rand) {
			List<List<BakedQuad>> quadLists = new ArrayList<>();
			for (Map.Entry<String, BakedModel> entry : children.entrySet()) {
				quadLists.add(entry.getValue().getQuads(state, side, rand));
			}
			return ConcatenatedListView.of(quadLists);
		}

		@Override
		public void emitBlockQuads(BlockRenderView blockView, BlockState state, BlockPos pos, Supplier<Random> randomSupplier, RenderContext context) {
			for (Map.Entry<String, BakedModel> entry : children.entrySet()) {
				((FabricBakedModel) entry.getValue()).emitBlockQuads(blockView, state, pos, randomSupplier, context);
			}
		}

		@Override
		public void emitItemQuads(ItemStack stack, Supplier<Random> randomSupplier, RenderContext context) {
			for (Map.Entry<String, BakedModel> entry : children.entrySet()) {
				((FabricBakedModel) entry.getValue()).emitItemQuads(stack, randomSupplier, context);
			}
		}

		@Override
		public boolean useAmbientOcclusion() {
			return isAmbientOcclusion;
		}

		@Override
		public boolean hasDepth() {
			return isGui3d;
		}

		@Override
		public boolean isSideLit() {
			return isSideLit;
		}

		@Override
		public boolean isBuiltin() {
			return false;
		}

		@Override
		public Sprite getParticleSprite() {
			return particle;
		}

		@Override
		public ModelOverrideList getOverrides() {
			return overrides;
		}

		@Override
		public ModelTransformation getTransformation() {
			return transforms;
		}

		@Override
		public boolean isVanillaAdapter() {
			return false;
		}

		@Nullable
		public BakedModel getPart(String name) {
			return children.get(name);
		}

		public static io.github.fabricators_of_create.porting_lib.models.CompositeModel.Baked.Builder builder(JsonUnbakedModel owner, boolean isGui3d, Sprite particle, ModelOverrideList overrides, ModelTransformation cameraTransforms) {
			return builder(owner.useAmbientOcclusion(), isGui3d, owner.getGuiLight().isSide(), particle, overrides, cameraTransforms);
		}

		public static io.github.fabricators_of_create.porting_lib.models.CompositeModel.Baked.Builder builder(boolean isAmbientOcclusion, boolean isGui3d, boolean isSideLit, Sprite particle, ModelOverrideList overrides, ModelTransformation cameraTransforms) {
			return new io.github.fabricators_of_create.porting_lib.models.CompositeModel.Baked.Builder(isAmbientOcclusion, isGui3d, isSideLit, particle, overrides, cameraTransforms);
		}

		public static class Builder {
			private final boolean isAmbientOcclusion;
			private final boolean isGui3d;
			private final boolean isSideLit;
			private final List<BakedModel> children = new ArrayList<>();
			private final List<BakedQuad> quads = new ArrayList<>();
			private final ModelOverrideList overrides;
			private final ModelTransformation transforms;
			private Sprite particle;

			private Builder(boolean isAmbientOcclusion, boolean isGui3d, boolean isSideLit, Sprite particle, ModelOverrideList overrides, ModelTransformation transforms) {
				this.isAmbientOcclusion = isAmbientOcclusion;
				this.isGui3d = isGui3d;
				this.isSideLit = isSideLit;
				this.particle = particle;
				this.overrides = overrides;
				this.transforms = transforms;
			}

			public void addLayer(BakedModel model) {
				flushQuads();
				children.add(model);
			}

			private void addLayer(List<BakedQuad> quads) {
				var modelBuilder = new BasicBakedModel.Builder(isAmbientOcclusion, isSideLit, isGui3d, transforms, overrides).setParticle(particle);
				quads.forEach(modelBuilder::addQuad);
				children.add(modelBuilder.build());
			}

			private void flushQuads() {
				if (quads.size() > 0) {
					addLayer(quads);
					quads.clear();
				}
			}

			public io.github.fabricators_of_create.porting_lib.models.CompositeModel.Baked.Builder setParticle(Sprite particleSprite) {
				this.particle = particleSprite;
				return this;
			}

			public io.github.fabricators_of_create.porting_lib.models.CompositeModel.Baked.Builder addQuads(BakedQuad... quadsToAdd) {
				flushQuads();
				Collections.addAll(quads, quadsToAdd);
				return this;
			}

			public io.github.fabricators_of_create.porting_lib.models.CompositeModel.Baked.Builder addQuads(Collection<BakedQuad> quadsToAdd) {
				flushQuads();
				quads.addAll(quadsToAdd);
				return this;
			}

			public BakedModel build() {
				if (quads.size() > 0) {
					addLayer(quads);
				}
				var childrenBuilder = ImmutableMap.<String, BakedModel>builder();
				var itemPassesBuilder = ImmutableList.<BakedModel>builder();
				int i = 0;
				for (var model : this.children) {
					childrenBuilder.put("model_" + (i++), model);
					itemPassesBuilder.add(model);
				}
				return new Baked(isGui3d, isSideLit, isAmbientOcclusion, particle, transforms, overrides, childrenBuilder.build(), itemPassesBuilder.build());
			}
		}
	}
}

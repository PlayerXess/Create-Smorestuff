package io.github.fabricators_of_create.porting_lib.models;

import com.google.gson.JsonObject;
import net.minecraft.client.render.model.UnbakedModel;
import net.minecraft.client.render.model.json.JsonUnbakedModel;

public interface ModelLoader {
	UnbakedModel readModel(JsonUnbakedModel parent, JsonObject jsonObject);
}

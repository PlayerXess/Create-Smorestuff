package io.github.fabricators_of_create.porting_lib.models;

import java.util.Collection;
import java.util.Collections;
import java.util.Map.Entry;
import java.util.function.Function;

import com.google.gson.JsonParseException;

import org.jetbrains.annotations.Nullable;

import com.google.common.collect.ImmutableList;
import com.google.gson.JsonObject;

import it.unimi.dsi.fastutil.ints.Int2ObjectArrayMap;
import it.unimi.dsi.fastutil.ints.Int2ObjectMap;
import net.fabricmc.fabric.api.renderer.v1.RendererAccess;
import net.fabricmc.fabric.api.renderer.v1.material.RenderMaterial;
import net.fabricmc.fabric.api.renderer.v1.mesh.MeshBuilder;
import net.fabricmc.fabric.api.renderer.v1.mesh.QuadEmitter;
import net.minecraft.client.render.model.BakedModel;
import net.minecraft.client.render.model.BakedQuad;
import net.minecraft.client.render.model.Baker;
import net.minecraft.client.render.model.ModelBakeSettings;
import net.minecraft.client.render.model.ModelLoader;
import net.minecraft.client.render.model.UnbakedModel;
import net.minecraft.client.render.model.json.JsonUnbakedModel;
import net.minecraft.client.texture.Sprite;
import net.minecraft.client.util.SpriteIdentifier;
import net.minecraft.util.Identifier;

public class ItemLayerModel implements UnbakedModel {
	private final JsonUnbakedModel owner;
	@Nullable
	private ImmutableList<SpriteIdentifier> textures;
	private final Int2ObjectMap<RenderMaterial> layerData;

	private ItemLayerModel(JsonUnbakedModel owner, @Nullable ImmutableList<SpriteIdentifier> textures, Int2ObjectMap<RenderMaterial> layerData) {
		this.owner = owner;
		this.textures = textures;
		this.layerData = layerData;
	}

	@Override
	public Collection<Identifier> getModelDependencies() {
		return Collections.emptyList();
	}

	@Override
	public void setParents(Function<Identifier, UnbakedModel> modelGetter) {}

	@Nullable
	@Override
	public BakedModel bake(Baker modelBaker, Function<SpriteIdentifier, Sprite> spriteGetter, ModelBakeSettings modelState, Identifier modelLocation) {
		if (textures == null) {
			ImmutableList.Builder<SpriteIdentifier> builder = ImmutableList.builder();
			if (owner.textureExists("particle"))
				builder.add(owner.resolveSprite("particle"));
			for (int i = 0; owner.textureExists("layer" + i); i++)
			{
				builder.add(owner.resolveSprite("layer" + i));
			}
			textures = builder.build();
		}

		Sprite particle = spriteGetter.apply(
				owner.textureExists("particle") ? owner.resolveSprite("particle") : textures.get(0)
		);

		MeshBuilder meshBuilder = RendererAccess.INSTANCE.getRenderer().meshBuilder();
		for (int i = 0; i < textures.size(); i++)
		{
			QuadEmitter emitter = meshBuilder.getEmitter();
			Sprite sprite = spriteGetter.apply(textures.get(i));
			var unbaked = ModelLoader.ITEM_MODEL_GENERATOR.processFrames(i, "layer" + i, sprite.getContents());
			var quads = UnbakedGeometryHelper.bakeElements(unbaked, $ -> sprite, modelState, modelLocation);
			for (BakedQuad quad : quads) {
				emitter.fromVanilla(quad, this.layerData.get(i), quad.getFace());
				emitter.emit();
			}
		}

		return new BakedMeshModel(owner, particle, meshBuilder.build());
	}

	public static final class Loader implements io.github.fabricators_of_create.porting_lib.models.ModelLoader {
		public static final Loader INSTANCE = new Loader();

		@Override
		public UnbakedModel readModel(JsonUnbakedModel parent, JsonObject jsonObject) {
			if (!RendererAccess.INSTANCE.hasRenderer())
				throw new JsonParseException("The Fabric Rendering API is not available. If you have Sodium, install Indium!");
			var emissiveLayers = new Int2ObjectArrayMap<RenderMaterial>();
			if(jsonObject.has("render_materials")) {
				JsonObject forgeData = jsonObject.get("render_materials").getAsJsonObject();
				readLayerData(forgeData, "layers", emissiveLayers);
			}
			return new ItemLayerModel(parent, null, emissiveLayers);
		}

		public void readLayerData(JsonObject jsonObject, String name, Int2ObjectMap<RenderMaterial> layerData) {
			if (!jsonObject.has(name)) {
				return;
			}
			var fullbrightLayers = jsonObject.getAsJsonObject(name);
			for (var entry : fullbrightLayers.entrySet()) {
				int layer = Integer.parseInt(entry.getKey());
				var data = PortingLibModelLoadingRegistry.GSON.fromJson(entry.getValue(), RenderMaterial.class);
				layerData.put(layer, data);
			}
		}
	}
}

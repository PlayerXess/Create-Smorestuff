package io.github.fabricators_of_create.porting_lib.models.mixin.client;

import io.github.fabricators_of_create.porting_lib.models.CustomParticleIconModel;
import io.github.fabricators_of_create.porting_lib.models.extensions.TerrainParticleExtensions;
import net.fabricmc.fabric.api.rendering.data.v1.RenderAttachedBlockView;
import net.minecraft.block.BlockState;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.particle.BlockDustParticle;
import net.minecraft.client.particle.SpriteBillboardParticle;
import net.minecraft.client.render.model.BakedModel;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.util.math.BlockPos;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(BlockDustParticle.class)
public abstract class TerrainParticleMixin extends SpriteBillboardParticle implements TerrainParticleExtensions {
	protected TerrainParticleMixin(ClientWorld clientLevel, double d, double e, double f) {
		super(clientLevel, d, e, f);
	}

	@Override
	public BlockDustParticle updateSprite(BlockState state, BlockPos pos) {
		MinecraftClient mc = MinecraftClient.getInstance();
		BakedModel model = mc.getBakedModelManager().getBlockModels().getModel(state);
		if (model instanceof CustomParticleIconModel custom && mc.world != null) {
			Object data = mc.world.getBlockEntityRenderData(pos);
			this.setSprite(custom.getParticleIcon(data));
		}
		return (BlockDustParticle) (Object) this;
	}
}

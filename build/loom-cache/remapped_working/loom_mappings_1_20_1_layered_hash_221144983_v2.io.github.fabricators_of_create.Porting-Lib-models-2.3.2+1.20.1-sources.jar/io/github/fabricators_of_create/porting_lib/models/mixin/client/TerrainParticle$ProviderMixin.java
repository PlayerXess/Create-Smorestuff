package io.github.fabricators_of_create.porting_lib.models.mixin.client;

import com.llamalad7.mixinextras.injector.ModifyReturnValue;
import net.minecraft.client.particle.BlockDustParticle;
import net.minecraft.client.particle.Particle;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.particle.BlockStateParticleEffect;
import net.minecraft.util.math.BlockPos;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(BlockDustParticle.Factory.class)
public class ProviderMixin {
	@ModifyReturnValue(
			method = "createParticle(Lnet/minecraft/core/particles/BlockParticleOption;Lnet/minecraft/client/multiplayer/ClientLevel;DDDDDD)Lnet/minecraft/client/particle/Particle;",
			at = @At("RETURN")
	)
	private Particle updateSprite(Particle particle,
								  BlockStateParticleEffect type, ClientWorld level, double x, double y, double z, double xSpeed, double ySpeed, double zSpeed) {
		BlockPos source = type.getSourcePos();
		if (source != null && particle instanceof BlockDustParticle terrainParticle) {
			terrainParticle.updateSprite(type.getBlockState(), source);
		}
		return particle;
	}
}

package io.github.fabricators_of_create.porting_lib.models;

import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParseException;

import io.github.fabricators_of_create.porting_lib.models.geometry.IGeometryLoader;
import io.github.fabricators_of_create.porting_lib.models.geometry.IUnbakedGeometry;
import net.fabricmc.fabric.api.renderer.v1.RendererAccess;
import net.fabricmc.fabric.api.renderer.v1.mesh.MeshBuilder;
import net.fabricmc.fabric.api.renderer.v1.mesh.QuadEmitter;
import net.minecraft.client.render.model.BakedModel;
import net.minecraft.client.render.model.Baker;
import net.minecraft.client.render.model.BasicBakedModel;
import net.minecraft.client.render.model.ModelBakeSettings;
import net.minecraft.client.render.model.json.JsonUnbakedModel;
import net.minecraft.client.render.model.json.ModelElement;
import net.minecraft.client.render.model.json.ModelOverrideList;
import net.minecraft.client.texture.Sprite;
import net.minecraft.client.util.SpriteIdentifier;
import net.minecraft.util.Identifier;
import net.minecraft.util.JsonHelper;
import net.minecraft.util.math.Direction;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Function;

public class ElementsModel implements IUnbakedGeometry<ElementsModel> {
	private final List<ModelElement> elements;

	public ElementsModel(List<ModelElement> elements) {
		this.elements = elements;
	}

	@Override
	public BakedModel bake(JsonUnbakedModel context, Baker baker, Function<SpriteIdentifier, Sprite> spriteGetter, ModelBakeSettings modelState, ModelOverrideList overrides, Identifier modelLocation, boolean isGui3d) {
		// If there is a root transform, undo the ModelState transform, apply it, then re-apply the ModelState transform.
		// This is necessary because of things like UV locking, which should only respond to the ModelState, and as such
		// that is the only transform that should be applied during face bake.
		Sprite particle = spriteGetter.apply(context.resolveSprite("particle"));
		BasicBakedModel.Builder modelBuilder = new BasicBakedModel.Builder(context.useAmbientOcclusion(), context.getGuiLight().isSide(), true,
				context.getTransformations(), overrides).setParticle(particle);
		MeshBuilder meshBuilder = RendererAccess.INSTANCE.getRenderer().meshBuilder();
		QuadEmitter emitter = meshBuilder.getEmitter();
		var postTransform = QuadTransformers.empty();
		var rootTransform = context.getRootTransform();
		if (!rootTransform.isIdentity())
			postTransform = UnbakedGeometryHelper.applyRootTransform(modelState, rootTransform);

		for (ModelElement element : elements) {
			for (Direction direction : element.faces.keySet()) {
				var face = element.faces.get(direction);
				var sprite = spriteGetter.apply(context.resolveSprite(face.textureId));
				var quad = JsonUnbakedModel.createQuad(element, face, sprite, direction, modelState, modelLocation);
				// Kinda hacky but should work
				emitter.fromVanilla(quad, RendererAccess.INSTANCE.getRenderer().materialFinder().find(), face.cullFace);
				postTransform.transform(emitter);
				quad = emitter.toBakedQuad(sprite);

				if (face.cullFace == null)
					modelBuilder.addQuad(quad);
				else
					modelBuilder.addQuad(modelState.getRotation().rotateTransform(face.cullFace), quad);
			}
		}
		return modelBuilder.build();
	}

	public static final class Loader implements IGeometryLoader<ElementsModel> {
		public static final Loader INSTANCE = new Loader();

		private Loader() {}

		@Override
		public ElementsModel read(JsonObject jsonObject, JsonDeserializationContext deserializationContext) throws JsonParseException {
			if (!jsonObject.has("elements"))
				throw new JsonParseException("An element model must have an \"elements\" member.");
			if (!RendererAccess.INSTANCE.hasRenderer())
				throw new JsonParseException("The Fabric Rendering API is not available. If you have Sodium, install Indium!");

			List<ModelElement> elements = new ArrayList<>();
			for (JsonElement element : JsonHelper.getArray(jsonObject, "elements")) {
				elements.add(deserializationContext.deserialize(element, ModelElement.class));
			}

			return new ElementsModel(elements);
		}
	}
}

package io.github.fabricators_of_create.porting_lib.models.virtual;

import java.util.function.Supplier;

import net.fabricmc.fabric.api.renderer.v1.model.ForwardingBakedModel;
import net.fabricmc.fabric.api.renderer.v1.render.RenderContext;
import net.minecraft.block.BlockState;
import net.minecraft.client.render.model.BakedModel;
import net.minecraft.item.ItemStack;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.random.Random;
import net.minecraft.world.BlockRenderView;

public class FixedColorTintingBakedModel extends ForwardingBakedModel {
	private static final ThreadLocal<FixedColorTintingBakedModel> THREAD_LOCAL = ThreadLocal.withInitial(FixedColorTintingBakedModel::new);

	protected int color;

	protected FixedColorTintingBakedModel() {
	}

	public static BakedModel wrap(BakedModel model, int color) {
		FixedColorTintingBakedModel wrapper = THREAD_LOCAL.get();
		wrapper.wrapped = model;
		wrapper.color = color;
		return wrapper;
	}

	@Override
	public boolean isVanillaAdapter() {
		return false;
	}

	@Override
	public void emitBlockQuads(BlockRenderView blockView, BlockState state, BlockPos pos, Supplier<Random> randomSupplier, RenderContext context) {
		context.pushTransform(quad -> {
			if (quad.colorIndex() != -1) {
				quad.color(color, color, color, color);
				quad.colorIndex(-1);
			}
			return true;
		});
		super.emitBlockQuads(blockView, state, pos, randomSupplier, context);
		context.popTransform();
	}

	@Override
	public void emitItemQuads(ItemStack stack, Supplier<Random> randomSupplier, RenderContext context) {
		context.pushTransform(quad -> {
			if (quad.colorIndex() != -1) {
				quad.color(color, color, color, color);
				quad.colorIndex(-1);
			}
			return true;
		});
		super.emitItemQuads(stack, randomSupplier, context);
		context.popTransform();
	}
}

package io.github.fabricators_of_create.porting_lib.models.util;

import com.google.common.collect.ImmutableMap;
import org.jetbrains.annotations.Nullable;

import java.util.HashMap;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.util.Identifier;

public final class RenderTypeUtil {
	private static final ImmutableMap<Identifier, RenderLayer> RENDER_TYPES;

	@Nullable
	public static RenderLayer get(Identifier name) {
		return RENDER_TYPES.getOrDefault(name, null);
	}

	static {
		var renderTypes = new HashMap<Identifier, RenderLayer>();
		renderTypes.put(new Identifier("solid"), RenderLayer.getSolid());
		renderTypes.put(new Identifier("cutout"), RenderLayer.getCutout());
		// Generally entity/item rendering shouldn't use mipmaps, so cutout_mipped has them off by default. To enforce them, use cutout_mipped_all.
		renderTypes.put(new Identifier("cutout_mipped"), RenderLayer.getCutoutMipped());
		renderTypes.put(new Identifier("cutout_mipped_all"), RenderLayer.getCutoutMipped());
		renderTypes.put(new Identifier("translucent"), RenderLayer.getTranslucent());
		renderTypes.put(new Identifier("tripwire"), RenderLayer.getTripwire());
		RENDER_TYPES = ImmutableMap.copyOf(renderTypes);
	}
}

package io.github.fabricators_of_create.porting_lib.models.mixin.client;

import java.util.function.Function;

import net.fabricmc.fabric.api.renderer.v1.material.RenderMaterial;
import net.minecraft.client.render.model.BakedModel;
import net.minecraft.client.render.model.Baker;
import net.minecraft.client.render.model.ModelBakeSettings;
import net.minecraft.client.render.model.json.JsonUnbakedModel;
import net.minecraft.client.texture.Sprite;
import net.minecraft.client.util.SpriteIdentifier;
import net.minecraft.util.Identifier;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;

import com.llamalad7.mixinextras.injector.ModifyReturnValue;

import io.github.fabricators_of_create.porting_lib.models.RenderMaterialModel;
import io.github.fabricators_of_create.porting_lib.models.extensions.BlockModelExtensions;

@Mixin(JsonUnbakedModel.class)
public class BlockModelMixin implements BlockModelExtensions {
	@Unique
	private RenderMaterial material;

	@Override
	public void port_lib$setRenderMaterial(RenderMaterial material) {
		this.material = material;
	}

	@ModifyReturnValue(method = "bake(Lnet/minecraft/client/resources/model/ModelBaker;Lnet/minecraft/client/renderer/block/model/BlockModel;Ljava/util/function/Function;Lnet/minecraft/client/resources/model/ModelState;Lnet/minecraft/resources/ResourceLocation;Z)Lnet/minecraft/client/resources/model/BakedModel;", at = @At("RETURN"))
	private BakedModel useRenderMaterial(BakedModel model, Baker modelBaker, JsonUnbakedModel blockModel,
										 Function<SpriteIdentifier, Sprite> function, ModelBakeSettings modelState,
										 Identifier resourceLocation, boolean bl) {
		if (material != null)
			return new RenderMaterialModel(model, material);
		return model;
	}
}

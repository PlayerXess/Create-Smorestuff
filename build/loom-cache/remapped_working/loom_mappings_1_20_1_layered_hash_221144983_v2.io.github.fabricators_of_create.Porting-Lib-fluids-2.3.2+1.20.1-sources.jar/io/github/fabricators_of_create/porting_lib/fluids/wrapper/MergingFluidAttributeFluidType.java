package io.github.fabricators_of_create.porting_lib.fluids.wrapper;

import io.github.fabricators_of_create.porting_lib.fluids.FluidStack;
import io.github.fabricators_of_create.porting_lib.fluids.FluidType;
import io.github.fabricators_of_create.porting_lib.fluids.sound.SoundAction;
import io.github.fabricators_of_create.porting_lib.fluids.sound.SoundActions;
import net.fabricmc.fabric.api.transfer.v1.fluid.FluidVariant;
import net.fabricmc.fabric.api.transfer.v1.fluid.FluidVariantAttributeHandler;
import net.minecraft.block.BlockState;
import net.minecraft.entity.Entity;
import net.minecraft.entity.ItemEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.ai.pathing.PathNodeType;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.vehicle.BoatEntity;
import net.minecraft.fluid.FluidState;
import net.minecraft.item.ItemStack;
import net.minecraft.sound.SoundEvent;
import net.minecraft.text.Text;
import net.minecraft.util.Rarity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.BlockRenderView;
import net.minecraft.world.BlockView;
import net.minecraft.world.World;
import net.minecraft.world.WorldView;
import org.jetbrains.annotations.Nullable;

public class MergingFluidAttributeFluidType extends FluidType {
	private final FluidVariant variant;
	private final FluidVariantAttributeHandler handler;
	private final FluidType superType;
	public MergingFluidAttributeFluidType(FluidType superType, FluidVariant variant, FluidVariantAttributeHandler handler) {
		super(Properties.create()
				.viscosity(handler.getViscosity(variant, null))
				.temperature(handler.getTemperature(variant))
				.lightLevel(handler.getLuminance(variant))
				.sound(SoundActions.BUCKET_FILL, handler.getFillSound(variant).get())
				.sound(SoundActions.BUCKET_EMPTY, handler.getEmptySound(variant).get())
				.density(handler.isLighterThanAir(variant) ? -1 : 1)
		);
		this.variant = variant;
		this.handler = handler;
		this.superType = superType;
	}

	@Override
	public Text getDescription() {
		return handler.getName(variant);
	}

	@Override
	public int getTemperature(FluidStack stack) {
		return handler.getTemperature(stack.getType());
	}

	@Override
	public int getViscosity(FluidStack stack) {
		return handler.getViscosity(stack.getType(), null);
	}

	@Override
	public int getViscosity(FluidState state, BlockRenderView getter, BlockPos pos) {
		if (getter instanceof World level)
			return handler.getViscosity(FluidVariant.of(state.getFluid()), level);
		return super.getViscosity(state, getter, pos);
	}

	@Override
	public int getLightLevel(FluidStack stack) {
		return handler.getLuminance(stack.getType());
	}

	@Override
	public int getDensity() {
		return superType.getDensity();
	}

	@Override
	public int getTemperature() {
		return superType.getTemperature();
	}

	@Override
	public int getViscosity() {
		return superType.getViscosity();
	}

	@Override
	public Rarity getRarity() {
		return superType.getRarity();
	}

	@Override
	public @Nullable SoundEvent getSound(SoundAction action) {
		return superType.getSound(action);
	}

	@Override
	public double motionScale(Entity entity) {
		return superType.motionScale(entity);
	}

	@Override
	public boolean canPushEntity(Entity entity) {
		return superType.canPushEntity(entity);
	}

	@Override
	public boolean canSwim(Entity entity) {
		return superType.canSwim(entity);
	}

	@Override
	public float getFallDistanceModifier(Entity entity) {
		return superType.getFallDistanceModifier(entity);
	}

	@Override
	public boolean canExtinguish(Entity entity) {
		return superType.canExtinguish(entity);
	}

	@Override
	public boolean move(FluidState state, LivingEntity entity, Vec3d movementVector, double gravity) {
		return superType.move(state, entity, movementVector, gravity);
	}

	@Override
	public boolean canDrownIn(LivingEntity entity) {
		return superType.canDrownIn(entity);
	}

	@Override
	public void setItemMovement(ItemEntity entity) {
		superType.setItemMovement(entity);
	}

	@Override
	public boolean supportsBoating(BoatEntity boat) {
		return superType.supportsBoating(boat);
	}

	@Override
	public boolean supportsBoating(FluidState state, BoatEntity boat) {
		return superType.supportsBoating(state, boat);
	}

	@Override
	public boolean canRideVehicleUnder(Entity vehicle, Entity rider) {
		return superType.canRideVehicleUnder(vehicle, rider);
	}

	@Override
	public boolean canHydrate(Entity entity) {
		return superType.canHydrate(entity);
	}

	@Override
	public @Nullable SoundEvent getSound(Entity entity, SoundAction action) {
		return superType.getSound(entity, action);
	}

	@Override
	public boolean canExtinguish(FluidState state, BlockView getter, BlockPos pos) {
		return superType.canExtinguish(state, getter, pos);
	}

	@Override
	public boolean canConvertToSource(FluidState state, WorldView reader, BlockPos pos) {
		return superType.canConvertToSource(state, reader, pos);
	}

	@Override
	public @Nullable PathNodeType getBlockPathType(FluidState state, BlockView level, BlockPos pos, @Nullable MobEntity mob, boolean canFluidLog) {
		return superType.getBlockPathType(state, level, pos, mob, canFluidLog);
	}

	@Override
	public @Nullable PathNodeType getAdjacentBlockPathType(FluidState state, BlockView level, BlockPos pos, @Nullable MobEntity mob, PathNodeType originalType) {
		return superType.getAdjacentBlockPathType(state, level, pos, mob, originalType);
	}

	@Override
	public @Nullable SoundEvent getSound(@Nullable PlayerEntity player, BlockView getter, BlockPos pos, SoundAction action) {
		return superType.getSound(player, getter, pos, action);
	}

	@Override
	public boolean canHydrate(FluidState state, BlockView getter, BlockPos pos, BlockState source, BlockPos sourcePos) {
		return superType.canHydrate(state, getter, pos, source, sourcePos);
	}

	@Override
	public int getLightLevel(FluidState state, BlockRenderView getter, BlockPos pos) {
		return superType.getLightLevel(state, getter, pos);
	}

	@Override
	public int getDensity(FluidState state, BlockRenderView getter, BlockPos pos) {
		return superType.getDensity(state, getter, pos);
	}

	@Override
	public int getTemperature(FluidState state, BlockRenderView getter, BlockPos pos) {
		return superType.getTemperature(state, getter, pos);
	}

	@Override
	public boolean canConvertToSource(FluidStack stack) {
		return superType.canConvertToSource(stack);
	}

	@Override
	public @Nullable SoundEvent getSound(FluidStack stack, SoundAction action) {
		return superType.getSound(stack, action);
	}

	@Override
	public boolean canHydrate(FluidStack stack) {
		return superType.canHydrate(stack);
	}

	@Override
	public int getDensity(FluidStack stack) {
		return superType.getDensity(stack);
	}

	@Override
	public Rarity getRarity(FluidStack stack) {
		return superType.getRarity(stack);
	}

	@Override
	public ItemStack getBucket(FluidStack stack) {
		return superType.getBucket(stack);
	}

	@Override
	public BlockState getBlockForFluidState(BlockRenderView getter, BlockPos pos, FluidState state) {
		return superType.getBlockForFluidState(getter, pos, state);
	}

	@Override
	public FluidState getStateForPlacement(BlockRenderView getter, BlockPos pos, FluidStack stack) {
		return superType.getStateForPlacement(getter, pos, stack);
	}

	@Override
	public boolean isVaporizedOnPlacement(World level, BlockPos pos, FluidStack stack) {
		return superType.isVaporizedOnPlacement(level, pos, stack);
	}

	@Override
	public void onVaporize(@Nullable PlayerEntity player, World level, BlockPos pos, FluidStack stack) {
		superType.onVaporize(player, level, pos, stack);
	}

	public FluidType getRegisteredWrapper() {
		return this.superType;
	}
}

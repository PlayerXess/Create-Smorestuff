package io.github.fabricators_of_create.porting_lib.fluids;

import io.github.fabricators_of_create.porting_lib.core.PortingLib;
import io.github.fabricators_of_create.porting_lib.fluids.sound.SoundActions;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.event.registry.FabricRegistryBuilder;
import net.minecraft.entity.Entity;
import net.minecraft.entity.ItemEntity;
import net.minecraft.entity.ai.pathing.PathNodeType;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.fluid.FluidState;
import net.minecraft.registry.Registry;
import net.minecraft.registry.RegistryKey;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.BlockView;
import org.jetbrains.annotations.Nullable;

public class PortingLibFluids implements ModInitializer {
	public static final RegistryKey<Registry<FluidType>> FLUID_TYPE_REGISTRY = RegistryKey.ofRegistry(PortingLib.id("fluid_type"));
	public static final Registry<FluidType> FLUID_TYPES = FabricRegistryBuilder.createDefaulted(FLUID_TYPE_REGISTRY, PortingLib.id("empty")).buildAndRegister();

	public static final FluidType EMPTY_TYPE =
			new FluidType(FluidType.Properties.create()
					.descriptionId("block.minecraft.air")
					.motionScale(1D)
					.canPushEntity(false)
					.canSwim(false)
					.canDrown(false)
					.fallDistanceModifier(1F)
					.pathType(null)
					.adjacentPathType(null)
					.density(0)
					.temperature(0)
					.viscosity(0))
			{
				@Override
				public void setItemMovement(ItemEntity entity) {
					if (!entity.hasNoGravity()) entity.setVelocity(entity.getVelocity().add(0.0D, -0.04D, 0.0D));
				}
			};
	public static final FluidType WATER_TYPE =
			new FluidType(FluidType.Properties.create()
					.descriptionId("block.minecraft.water")
					.fallDistanceModifier(0F)
					.canExtinguish(true)
					.canConvertToSource(true)
					.supportsBoating(true)
					.sound(SoundActions.BUCKET_FILL, SoundEvents.field_15126)
					.sound(SoundActions.BUCKET_EMPTY, SoundEvents.field_14834)
					.sound(SoundActions.FLUID_VAPORIZE, SoundEvents.field_15102)
					.canHydrate(true))
			{
				@Override
				public @Nullable PathNodeType getBlockPathType(FluidState state, BlockView level, BlockPos pos, @Nullable MobEntity mob, boolean canFluidLog)
				{
					return canFluidLog ? super.getBlockPathType(state, level, pos, mob, true) : null;
				}

//				@Override
//				public void initializeClient(Consumer<IClientFluidTypeExtensions> consumer)
//				{
//					consumer.accept(new IClientFluidTypeExtensions()
//					{
//						private static final ResourceLocation UNDERWATER_LOCATION = new ResourceLocation("textures/misc/underwater.png"),
//								WATER_STILL = new ResourceLocation("block/water_still"),
//								WATER_FLOW = new ResourceLocation("block/water_flow"),
//								WATER_OVERLAY = new ResourceLocation("block/water_overlay");
//
//						@Override
//						public ResourceLocation getStillTexture()
//						{
//							return WATER_STILL;
//						}
//
//						@Override
//						public ResourceLocation getFlowingTexture()
//						{
//							return WATER_FLOW;
//						}
//
//						@Nullable
//						@Override
//						public ResourceLocation getOverlayTexture()
//						{
//							return WATER_OVERLAY;
//						}
//
//						@Override
//						public ResourceLocation getRenderOverlayTexture(Minecraft mc)
//						{
//							return UNDERWATER_LOCATION;
//						}
//
//						@Override
//						public int getTintColor()
//						{
//							return 0xFF3F76E4;
//						}
//
//						@Override
//						public int getTintColor(FluidState state, BlockAndTintGetter getter, BlockPos pos)
//						{
//							return BiomeColors.getAverageWaterColor(getter, pos) | 0xFF000000;
//						}
//					});
//				}
			};
	public static final FluidType LAVA_TYPE =
			new FluidType(FluidType.Properties.create()
					.descriptionId("block.minecraft.lava")
					.canSwim(false)
					.canDrown(false)
					.pathType(PathNodeType.field_14)
					.adjacentPathType(null)
					.sound(SoundActions.BUCKET_FILL, SoundEvents.field_15202)
					.sound(SoundActions.BUCKET_EMPTY, SoundEvents.field_15010)
					.lightLevel(15)
					.density(3000)
					.viscosity(6000)
					.temperature(1300))
			{
				@Override
				public double motionScale(Entity entity)
				{
					return entity.getWorld().getDimension().ultrawarm() ? 0.007D : 0.0023333333333333335D;
				}

				@Override
				public void setItemMovement(ItemEntity entity)
				{
					Vec3d vec3 = entity.getVelocity();
					entity.setVelocity(vec3.x * (double)0.95F, vec3.y + (double)(vec3.y < (double)0.06F ? 5.0E-4F : 0.0F), vec3.z * (double)0.95F);
				}

//				@Override
//				public void initializeClient(Consumer<IClientFluidTypeExtensions> consumer)
//				{
//					consumer.accept(new IClientFluidTypeExtensions()
//					{
//						private static final ResourceLocation LAVA_STILL = new ResourceLocation("block/lava_still"),
//								LAVA_FLOW = new ResourceLocation("block/lava_flow");
//
//						@Override
//						public ResourceLocation getStillTexture()
//						{
//							return LAVA_STILL;
//						}
//
//						@Override
//						public ResourceLocation getFlowingTexture()
//						{
//							return LAVA_FLOW;
//						}
//					});
//				}
			};

	@Override
	public void onInitialize() {
		Registry.register(FLUID_TYPES, PortingLib.id("empty"), EMPTY_TYPE);
		Registry.register(FLUID_TYPES, PortingLib.id("water"), WATER_TYPE);
		Registry.register(FLUID_TYPES, PortingLib.id("lava"), LAVA_TYPE);
	}
}

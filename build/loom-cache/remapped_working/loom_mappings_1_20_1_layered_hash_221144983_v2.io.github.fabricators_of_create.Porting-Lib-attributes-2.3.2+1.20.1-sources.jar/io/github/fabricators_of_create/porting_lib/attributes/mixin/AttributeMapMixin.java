package io.github.fabricators_of_create.porting_lib.attributes.mixin;

import net.minecraft.entity.attribute.AttributeContainer;
import net.minecraft.registry.Registries;
import net.minecraft.util.Identifier;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyArg;

@Mixin(AttributeContainer.class)
public class AttributeMapMixin {
	@ModifyArg(method = "load", at = @At(value = "INVOKE", target = "Lnet/minecraft/resources/ResourceLocation;tryParse(Ljava/lang/String;)Lnet/minecraft/resources/ResourceLocation;"))
	private String port_lib$remapOldAttribute(String location) {
		if (Registries.ATTRIBUTE.getOrEmpty(Identifier.tryParse(location)).isPresent())
			return location;
		return location.replace("forge", "porting_lib");
	}
}

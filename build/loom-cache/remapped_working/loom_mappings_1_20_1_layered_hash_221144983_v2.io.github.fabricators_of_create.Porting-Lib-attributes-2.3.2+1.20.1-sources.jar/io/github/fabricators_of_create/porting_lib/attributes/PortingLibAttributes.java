package io.github.fabricators_of_create.porting_lib.attributes;

import com.jamieswhiteshirt.reachentityattributes.ReachEntityAttributes;

import io.github.fabricators_of_create.porting_lib.attributes.extensions.PlayerAttributesExtensions;
import io.github.fabricators_of_create.porting_lib.core.PortingLib;
import net.fabricmc.api.ModInitializer;
import net.minecraft.entity.Entity;
import net.minecraft.entity.attribute.ClampedEntityAttribute;
import net.minecraft.entity.attribute.EntityAttribute;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;

public class PortingLibAttributes implements ModInitializer {
	public static final EntityAttribute STEP_HEIGHT_ADDITION = new ClampedEntityAttribute("porting_lib.step_height", 0.0D, -512.0D, 512.0D).setTracked(true);
	/**
	 * Reach Distance represents the distance at which a player may interact with the world.  The default is 4.5 blocks.  Players in creative mode have an additional 0.5 blocks of block reach.
	 * @see PlayerAttributesExtensions#getBlockReach()
	 * @see PlayerAttributesExtensions#canReach(BlockPos, double)
	 */
	public static final EntityAttribute BLOCK_REACH = ReachEntityAttributes.REACH;

	public static final EntityAttribute ENTITY_GRAVITY = new ClampedEntityAttribute("porting_lib.entity_gravity", 0.08D, -8.0D, 8.0D).setTracked(true);
	public static final EntityAttribute SWIM_SPEED = new ClampedEntityAttribute("porting_lib.swim_speed", 1.0D, 0.0D, 1024.0D).setTracked(true);

	/**
	 * Attack Range represents the distance at which a player may attack an entity.  The default is 3 blocks.  Players in creative mode have an additional 3 blocks of entity reach.
	 * The default of 3.0 is technically considered a bug by Mojang - see MC-172289 and MC-92484. However, updating this value would allow for longer-range attacks on vanilla servers, which makes some people mad.
	 * @see PlayerAttributesExtensions#getEntityReach()
	 * @see PlayerAttributesExtensions#canReach(Entity, double)
	 * @see PlayerAttributesExtensions#canReach(Vec3d, double)
	 */
	public static final EntityAttribute ENTITY_REACH = ReachEntityAttributes.ATTACK_RANGE;

	@Override
	public void onInitialize() {
		Registry.register(Registries.ATTRIBUTE, PortingLib.id("step_height_addition"), STEP_HEIGHT_ADDITION);
		Registry.register(Registries.ATTRIBUTE, PortingLib.id("entity_gravity"), ENTITY_GRAVITY);
		Registry.register(Registries.ATTRIBUTE, PortingLib.id("swim_speed"), SWIM_SPEED);
	}
}

package io.github.tropheusj.milk;

import static net.minecraft.item.Items.field_8550;
import static net.minecraft.item.Items.field_8613;
import static net.minecraft.item.Items.field_8469;
import static net.minecraft.item.Items.field_8054;
import static net.minecraft.item.Items.field_8103;

import io.github.tropheusj.milk.mixin.BrewingRecipeRegistryAccessor;
import io.github.tropheusj.milk.potion.MilkAreaEffectCloudEntity;
import io.github.tropheusj.milk.potion.MilkPotionDispenserBehavior;
import io.github.tropheusj.milk.potion.bottle.LingeringMilkBottle;
import io.github.tropheusj.milk.potion.bottle.MilkBottle;
import io.github.tropheusj.milk.potion.bottle.SplashMilkBottle;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.item.v1.FabricItemSettings;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.fabricmc.fabric.api.object.builder.v1.block.FabricBlockSettings;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricEntityTypeBuilder;
import net.fabricmc.fabric.api.tag.convention.v1.ConventionalFluidTags;
import net.fabricmc.fabric.api.tag.convention.v1.ConventionalItemTags;
import net.fabricmc.fabric.api.transfer.v1.fluid.CauldronFluidContent;
import net.fabricmc.fabric.api.transfer.v1.fluid.FluidConstants;
import net.fabricmc.fabric.api.transfer.v1.fluid.FluidStorage;
import net.fabricmc.fabric.api.transfer.v1.fluid.FluidVariant;
import net.fabricmc.fabric.api.transfer.v1.fluid.base.EmptyItemFluidStorage;
import net.fabricmc.fabric.api.transfer.v1.fluid.base.FullItemFluidStorage;
import net.fabricmc.fabric.api.transfer.v1.item.ItemVariant;
import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.block.DispenserBlock;
import net.minecraft.block.LeveledCauldronBlock;
import net.minecraft.block.MapColor;
import net.minecraft.block.cauldron.CauldronBehavior;
import net.minecraft.entity.EntityDimensions;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.fluid.FlowableFluid;
import net.minecraft.fluid.Fluid;
import net.minecraft.fluid.FluidState;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroups;
import net.minecraft.item.Items;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.registry.tag.TagKey;
import net.minecraft.util.Identifier;

@SuppressWarnings("UnstableApiUsage")
public class Milk implements ModInitializer {
	public static final String MOD_ID = "milk";
	// fluids - if any are non-null, all are non-null.
	public static FlowableFluid STILL_MILK = null;
	public static FlowableFluid FLOWING_MILK = null;
	public static Block MILK_FLUID_BLOCK = null;

	// bottles - may be enabled individually.
	public static Item MILK_BOTTLE = null;
	public static Item SPLASH_MILK_BOTTLE = null;
	public static Item LINGERING_MILK_BOTTLE = null;

	// cauldron.
	public static Block MILK_CAULDRON = null;

	// if true, milk can be placed from buckets.
	public static boolean MILK_PLACING_ENABLED = false;
	// if true, milk can make infinite sources like water.
	public static boolean INFINITE_MILK_FLUID = true;

	public static EntityType<MilkAreaEffectCloudEntity> MILK_EFFECT_CLOUD_ENTITY_TYPE = null;

	// tags.
	// all milk fluids.
	public static final TagKey<Fluid> MILK_FLUID_TAG = ConventionalFluidTags.MILK;
	// all milk bottles.
	public static final TagKey<Item> MILK_BOTTLE_TAG = TagKey.of(RegistryKeys.field_41197, new Identifier("c", "milk_bottles"));
	// all milk buckets.
	public static final TagKey<Item> MILK_BUCKET_TAG = ConventionalItemTags.MILK_BUCKETS;

	public static void enableMilkPlacing() {
		if (STILL_MILK == null) {
			throw new RuntimeException("to enable milk placing, you need to enable milk with enableMilkFluid()!");
		}
		MILK_PLACING_ENABLED = true;
	}

	public static void enableMilkFluid() {
		if (STILL_MILK == null) {
			// register
			STILL_MILK = Registry.register(
					Registries.FLUID,
					id("still_milk"),
					new MilkFluid.Still()
			);
			FLOWING_MILK = Registry.register(
					Registries.FLUID,
					id("flowing_milk"),
					new MilkFluid.Flowing()
			);
			MILK_FLUID_BLOCK = Registry.register(
					Registries.BLOCK,
					id("milk_fluid_block"),
					new MilkFluidBlock(STILL_MILK, FabricBlockSettings.copyOf(Blocks.field_10382).mapColor(MapColor.WHITE))
			);

			// transfer
			FluidStorage.combinedItemApiProvider(field_8103).register(context ->
					new FullItemFluidStorage(context, bucket -> ItemVariant.of(field_8550), FluidVariant.of(STILL_MILK), FluidConstants.BUCKET)
			);
			FluidStorage.combinedItemApiProvider(field_8550).register(context ->
					new EmptyItemFluidStorage(context, bucket -> ItemVariant.of(field_8103), STILL_MILK, FluidConstants.BUCKET)
			);

			// extras
			if (MILK_CAULDRON != null) {
				CauldronFluidContent.registerCauldron(MILK_CAULDRON, STILL_MILK, FluidConstants.BOTTLE, LeveledCauldronBlock.LEVEL);
			}
			if (MILK_BOTTLE != null) {
				FluidStorage.combinedItemApiProvider(MILK_BOTTLE).register(context ->
						new FullItemFluidStorage(context, bottle -> ItemVariant.of(field_8469), FluidVariant.of(STILL_MILK), FluidConstants.BOTTLE)
				);
				FluidStorage.combinedItemApiProvider(field_8469).register(context ->
						new EmptyItemFluidStorage(context, bucket -> ItemVariant.of(MILK_BOTTLE), STILL_MILK, FluidConstants.BOTTLE)
				);
			}
		}
	}

	public static void finiteMilkFluid() {
		INFINITE_MILK_FLUID = false;
	}

	public static void enableCauldron() {
		if (MILK_CAULDRON == null) {
			// register
			MILK_CAULDRON = Registry.register(
					Registries.BLOCK,
					id("milk_cauldron"),
					new MilkCauldron(FabricBlockSettings.copyOf(Blocks.field_10593))
			);
			CauldronBehavior.EMPTY_CAULDRON_BEHAVIOR.put(field_8103, MilkCauldron.FILL_FROM_BUCKET);
			// transfer
			if (STILL_MILK != null) {
				CauldronFluidContent.registerCauldron(MILK_CAULDRON, STILL_MILK, FluidConstants.BOTTLE, LeveledCauldronBlock.LEVEL);
			}
			// cauldron interactions
			if (MILK_BOTTLE != null && !CauldronBehavior.EMPTY_CAULDRON_BEHAVIOR.containsKey(MILK_BOTTLE)) {
				CauldronBehavior fillFromMilkBottle = MilkCauldron.addInputToCauldronExchange(
						Milk.MILK_BOTTLE.getDefaultStack(), Items.field_8469.getDefaultStack(), true);
				CauldronBehavior.EMPTY_CAULDRON_BEHAVIOR.put(MILK_BOTTLE, fillFromMilkBottle);
				MilkCauldron.MILK_CAULDRON_BEHAVIOR.put(Milk.MILK_BOTTLE, fillFromMilkBottle);

				CauldronBehavior emptyToBottle = MilkCauldron.addOutputToItemExchange(
						Items.field_8469.getDefaultStack(), Milk.MILK_BOTTLE.getDefaultStack(), true);
				MilkCauldron.MILK_CAULDRON_BEHAVIOR.put(Items.field_8469, emptyToBottle);
			}
		}
	}

	public static void enableMilkBottle() {
		if (MILK_BOTTLE == null) {
			// register
			MILK_BOTTLE = Registry.register(
					Registries.ITEM,
					id("milk_bottle"),
					new MilkBottle(new FabricItemSettings().recipeRemainder(Items.field_8469).maxCount(1))
			);
			// potions
			BrewingRecipeRegistryAccessor.milk$registerPotionType(MILK_BOTTLE);
			// transfer
			if (STILL_MILK != null) {
				FluidStorage.combinedItemApiProvider(MILK_BOTTLE).register(context ->
						new FullItemFluidStorage(context, bottle -> ItemVariant.of(field_8469), FluidVariant.of(STILL_MILK), FluidConstants.BOTTLE)
				);
				FluidStorage.combinedItemApiProvider(field_8469).register(context ->
						new EmptyItemFluidStorage(context, bucket -> ItemVariant.of(MILK_BOTTLE), STILL_MILK, FluidConstants.BOTTLE)
				);
			}
			// cauldron interactions
			if (MILK_CAULDRON != null && !CauldronBehavior.EMPTY_CAULDRON_BEHAVIOR.containsKey(MILK_BOTTLE)) {
				CauldronBehavior fillFromMilkBottle = MilkCauldron.addInputToCauldronExchange(
						Milk.MILK_BOTTLE.getDefaultStack(), Items.field_8469.getDefaultStack(), true);
				CauldronBehavior.EMPTY_CAULDRON_BEHAVIOR.put(MILK_BOTTLE, fillFromMilkBottle);
				MilkCauldron.MILK_CAULDRON_BEHAVIOR.put(Milk.MILK_BOTTLE, fillFromMilkBottle);

				CauldronBehavior emptyToBottle = MilkCauldron.addOutputToItemExchange(
						Items.field_8469.getDefaultStack(), Milk.MILK_BOTTLE.getDefaultStack(), true);
				MilkCauldron.MILK_CAULDRON_BEHAVIOR.put(Items.field_8469, emptyToBottle);
			}
		}
	}

	public static void enableSplashMilkBottle() {
		if (SPLASH_MILK_BOTTLE == null) {
			// register
			SPLASH_MILK_BOTTLE = Registry.register(
					Registries.ITEM,
					id("splash_milk_bottle"),
					new SplashMilkBottle(new FabricItemSettings().maxCount(1))
			);
			// potions
			BrewingRecipeRegistryAccessor.milk$registerPotionType(SPLASH_MILK_BOTTLE);
			if (MILK_BOTTLE != null) {
				BrewingRecipeRegistryAccessor.milk$registerItemRecipe(MILK_BOTTLE, field_8054, SPLASH_MILK_BOTTLE);
			}
			// transfer
			if (STILL_MILK != null) {
				FluidStorage.combinedItemApiProvider(SPLASH_MILK_BOTTLE).register(context ->
						new FullItemFluidStorage(context, bottle -> ItemVariant.of(field_8469), FluidVariant.of(STILL_MILK), FluidConstants.BOTTLE)
				);
			}
			// dispenser interactions
			DispenserBlock.registerBehavior(SPLASH_MILK_BOTTLE, MilkPotionDispenserBehavior.INSTANCE);
		}
	}

	public static void enableLingeringMilkBottle() {
		if (LINGERING_MILK_BOTTLE == null) {
			// register
			LINGERING_MILK_BOTTLE = Registry.register(
					Registries.ITEM,
					id("lingering_milk_bottle"),
					new LingeringMilkBottle(new FabricItemSettings().maxCount(1))
			);
			// potions
			BrewingRecipeRegistryAccessor.milk$registerPotionType(LINGERING_MILK_BOTTLE);
			// lingering effect
			MILK_EFFECT_CLOUD_ENTITY_TYPE = Registry.register(
					Registries.ENTITY_TYPE,
					id("milk_area_effect_cloud"),
					FabricEntityTypeBuilder.<MilkAreaEffectCloudEntity>create()
							.fireImmune()
							.dimensions(EntityDimensions.fixed(6.0F, 0.5F))
							.trackRangeChunks(10)
							.trackedUpdateRate(Integer.MAX_VALUE)
							.build()
			);
			// potions
			if (SPLASH_MILK_BOTTLE != null) {
				BrewingRecipeRegistryAccessor.milk$registerItemRecipe(SPLASH_MILK_BOTTLE, field_8613, LINGERING_MILK_BOTTLE);
			}
			// transfer
			if (STILL_MILK != null) {
				FluidStorage.combinedItemApiProvider(LINGERING_MILK_BOTTLE).register(context ->
						new FullItemFluidStorage(context, bottle -> ItemVariant.of(field_8469), FluidVariant.of(STILL_MILK), FluidConstants.BOTTLE)
				);
			}
			// dispenser interactions
			DispenserBlock.registerBehavior(LINGERING_MILK_BOTTLE, MilkPotionDispenserBehavior.INSTANCE);
		}
	}

	public static void enableAllMilkBottles() {
		enableMilkBottle();
		enableSplashMilkBottle();
		enableLingeringMilkBottle();
	}

	public static boolean isMilk(FluidState state) {
		return state.isOf(Milk.STILL_MILK) || state.isOf(Milk.FLOWING_MILK);
	}

	public static boolean isMilkBottle(Item item) {
		return item == Milk.MILK_BOTTLE || item == Milk.SPLASH_MILK_BOTTLE || item == Milk.LINGERING_MILK_BOTTLE;
	}

	public static boolean tryRemoveRandomEffect(LivingEntity user) {
		if (user.getStatusEffects().size() > 0) {
			int indexOfEffectToRemove = user.getWorld().random.nextInt(user.getStatusEffects().size());
			StatusEffectInstance effectToRemove = (StatusEffectInstance) user.getStatusEffects().toArray()[indexOfEffectToRemove];
			user.removeStatusEffect(effectToRemove.getEffectType());
			return true;
		}
		return false;
	}

	@Override
	public void onInitialize() {
//		enableMilkFluid();
//		enableMilkPlacing();
//		enableAllMilkBottles();
//		enableCauldron();
		ItemGroupEvents.modifyEntriesEvent(ItemGroups.FOOD_AND_DRINK).register(entries -> {
			if (MILK_BOTTLE != null)
				entries.method_45421(MILK_BOTTLE);
			if (SPLASH_MILK_BOTTLE != null)
				entries.method_45421(SPLASH_MILK_BOTTLE);
			if (LINGERING_MILK_BOTTLE != null)
				entries.method_45421(LINGERING_MILK_BOTTLE);
		});
	}

	public static Identifier id(String path) {
		return new Identifier(MOD_ID, path);
	}
}

package io.github.tropheusj.milk.mixin;

import java.util.List;
import net.minecraft.item.Item;
import net.minecraft.recipe.BrewingRecipeRegistry;
import net.minecraft.recipe.Ingredient;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import io.github.tropheusj.milk.Milk;

@Mixin(BrewingRecipeRegistry.class)
public abstract class BrewingRecipeRegistryMixin {
	@Shadow
	@Final
	private static List<Ingredient> POTION_TYPES;

	@Shadow
	@Final
	private static List<BrewingRecipeRegistry.Recipe<Item>> ITEM_RECIPES;

	@Inject(at = @At("HEAD"), method = "registerPotionType", cancellable = true)
	private static void milk$registerPotionType(Item item, CallbackInfo ci) {
		if (Milk.isMilkBottle(item)) {
			POTION_TYPES.add(Ingredient.ofItems(item));
			ci.cancel();
		}
	}

	@Inject(at = @At("HEAD"), method = "registerItemRecipe", cancellable = true)
	private static void milk$registerItemRecipe(Item input, Item ingredient, Item output, CallbackInfo ci) {
		if (Milk.isMilkBottle(input) && Milk.isMilkBottle(output)) {
			ITEM_RECIPES.add(new BrewingRecipeRegistry.Recipe<>(input, class_1856.method_8091(ingredient), output));
			ci.cancel();
		}
	}
}

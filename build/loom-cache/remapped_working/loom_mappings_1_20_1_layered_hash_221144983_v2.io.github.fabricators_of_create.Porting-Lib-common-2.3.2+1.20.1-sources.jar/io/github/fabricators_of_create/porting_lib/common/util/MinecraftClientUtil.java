package io.github.fabricators_of_create.porting_lib.common.util;

import java.util.Locale;

import io.github.fabricators_of_create.porting_lib.common.mixin.client.accessor.MinecraftAccessor;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.resource.language.LanguageManager;

@Environment(EnvType.CLIENT)
public final class MinecraftClientUtil {
	public static float getRenderPartialTicksPaused(MinecraftClient minecraft) {
		return get(minecraft).port_lib$pausePartialTick();
	}

	public static Locale getLocale() {
		LanguageManager manager = MinecraftClient.getInstance().getLanguageManager();
		return manager.getJavaLocale(manager.getLanguage());
	}

	private static MinecraftAccessor get(MinecraftClient minecraft) {
		return MixinHelper.cast(minecraft);
	}

	private MinecraftClientUtil() {}
}

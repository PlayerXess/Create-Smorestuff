package io.github.fabricators_of_create.porting_lib.common.util;

import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.CropBlock;
import net.minecraft.block.FlowerBlock;
import net.minecraft.block.SaplingBlock;
import org.jetbrains.annotations.Nullable;

public class PlantUtil {
	public static boolean isPlant(Block block) {
		return getPlant(block) != null;
	}

	@Nullable
	public static BlockState getPlant(Block block) {
		if (block instanceof CropBlock || block instanceof SaplingBlock || block instanceof FlowerBlock ||
			block == Blocks.field_10428 || block == Blocks.field_10588 || block == Blocks.field_10559 ||
			block == Blocks.field_10251 || block == Blocks.field_9974 || block == Blocks.field_10214) {
			return block.getDefaultState();
		} else {
			return null;
		}
	}
}

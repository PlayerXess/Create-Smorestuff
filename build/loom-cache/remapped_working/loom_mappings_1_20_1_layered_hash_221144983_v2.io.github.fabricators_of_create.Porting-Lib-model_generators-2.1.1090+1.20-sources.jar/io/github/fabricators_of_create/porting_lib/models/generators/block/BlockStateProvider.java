package io.github.fabricators_of_create.porting_lib.models.generators.block;

import com.google.common.annotations.VisibleForTesting;
import com.google.common.base.Preconditions;
import com.google.common.collect.ImmutableList;
import com.google.common.collect.ImmutableMap;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;

import java.nio.file.Path;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.function.Function;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.ButtonBlock;
import net.minecraft.block.ConnectingBlock;
import net.minecraft.block.DoorBlock;
import net.minecraft.block.FenceBlock;
import net.minecraft.block.FenceGateBlock;
import net.minecraft.block.HorizontalConnectingBlock;
import net.minecraft.block.PaneBlock;
import net.minecraft.block.PillarBlock;
import net.minecraft.block.PressurePlateBlock;
import net.minecraft.block.SignBlock;
import net.minecraft.block.SlabBlock;
import net.minecraft.block.StairsBlock;
import net.minecraft.block.TrapdoorBlock;
import net.minecraft.block.WallBlock;
import net.minecraft.block.WallSignBlock;
import net.minecraft.block.enums.BlockHalf;
import net.minecraft.block.enums.DoorHinge;
import net.minecraft.block.enums.DoubleBlockHalf;
import net.minecraft.block.enums.SlabType;
import net.minecraft.block.enums.StairShape;
import net.minecraft.block.enums.WallMountLocation;
import net.minecraft.block.enums.WallShape;
import net.minecraft.data.DataOutput;
import net.minecraft.data.DataProvider;
import net.minecraft.data.DataWriter;
import net.minecraft.registry.Registries;
import net.minecraft.state.property.Properties;
import net.minecraft.state.property.Property;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Direction.Axis;
import io.github.fabricators_of_create.porting_lib.data.ExistingFileHelper;
import io.github.fabricators_of_create.porting_lib.models.generators.ConfiguredModel;
import io.github.fabricators_of_create.porting_lib.models.generators.IGeneratedBlockState;
import io.github.fabricators_of_create.porting_lib.models.generators.ModelFile;
import io.github.fabricators_of_create.porting_lib.models.generators.ModelProvider;
import io.github.fabricators_of_create.porting_lib.models.generators.item.ItemModelProvider;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.jetbrains.annotations.NotNull;

/**
 * Data provider for blockstate files. Extends {@link BlockModelProvider} so that
 * blockstates and their referenced models can be provided in tandem.
 */
public abstract class BlockStateProvider implements DataProvider {

	private static final Logger LOGGER = LogManager.getLogger();
	private static final Gson GSON = (new GsonBuilder()).setPrettyPrinting().disableHtmlEscaping().create();

	@VisibleForTesting
	protected final Map<Block, IGeneratedBlockState> registeredBlocks = new LinkedHashMap<>();

	private final DataOutput output;
	private final String modid;
	private final BlockModelProvider blockModels;
	private final ItemModelProvider itemModels;

	public BlockStateProvider(DataOutput output, String modid, ExistingFileHelper exFileHelper) {
		this.output = output;
		this.modid = modid;
		this.blockModels = new BlockModelProvider(output, modid, exFileHelper) {
			@Override public CompletableFuture<?> run(DataWriter cache) { return CompletableFuture.allOf(); }

			@Override protected void registerModels() {}
		};
		this.itemModels = new ItemModelProvider(output, modid, this.blockModels.existingFileHelper) {
			@Override protected void registerModels() {}

			@Override public CompletableFuture<?> run(DataWriter cache) { return CompletableFuture.allOf(); }
		};
	}

	@Override
	public CompletableFuture<?> run(DataWriter cache) {
		models().clear();
		itemModels().clear();
		registeredBlocks.clear();
		registerStatesAndModels();
		CompletableFuture<?>[] futures = new CompletableFuture<?>[2 + this.registeredBlocks.size()];
		int i = 0;
		futures[i++] = models().generateAll(cache);
		futures[i++] = itemModels().generateAll(cache);
		for (Map.Entry<Block, IGeneratedBlockState> entry : registeredBlocks.entrySet()) {
			futures[i++] = saveBlockState(cache, entry.getValue().toJson(), entry.getKey());
		}
		return CompletableFuture.allOf(futures);
	}

	protected abstract void registerStatesAndModels();

	public VariantBlockStateBuilder getVariantBuilder(Block b) {
		if (registeredBlocks.containsKey(b)) {
			IGeneratedBlockState old = registeredBlocks.get(b);
			Preconditions.checkState(old instanceof VariantBlockStateBuilder);
			return (VariantBlockStateBuilder) old;
		} else {
			VariantBlockStateBuilder ret = new VariantBlockStateBuilder(b);
			registeredBlocks.put(b, ret);
			return ret;
		}
	}

	public MultiPartBlockStateBuilder getMultipartBuilder(Block b) {
		if (registeredBlocks.containsKey(b)) {
			IGeneratedBlockState old = registeredBlocks.get(b);
			Preconditions.checkState(old instanceof MultiPartBlockStateBuilder);
			return (MultiPartBlockStateBuilder) old;
		} else {
			MultiPartBlockStateBuilder ret = new MultiPartBlockStateBuilder(b);
			registeredBlocks.put(b, ret);
			return ret;
		}
	}

	public BlockModelProvider models() {
		return blockModels;
	}

	public ItemModelProvider itemModels() {
		return itemModels;
	}

	public Identifier modLoc(String name) {
		return new Identifier(modid, name);
	}

	public Identifier mcLoc(String name) {
		return new Identifier(name);
	}

	private Identifier key(Block block) {
		return Registries.BLOCK.getId(block);
	}

	private String name(Block block) {
		return key(block).getPath();
	}

	public Identifier blockTexture(Block block) {
		Identifier name = key(block);
		return new Identifier(name.getNamespace(), ModelProvider.BLOCK_FOLDER + "/" + name.getPath());
	}

	private Identifier extend(Identifier rl, String suffix) {
		return new Identifier(rl.getNamespace(), rl.getPath() + suffix);
	}

	public ModelFile cubeAll(Block block) {
		return models().cubeAll(name(block), blockTexture(block));
	}

	public void simpleBlock(Block block) {
		simpleBlock(block, cubeAll(block));
	}

	public void simpleBlock(Block block, Function<ModelFile, ConfiguredModel[]> expander) {
		simpleBlock(block, expander.apply(cubeAll(block)));
	}

	public void simpleBlock(Block block, ModelFile model) {
		simpleBlock(block, new ConfiguredModel(model));
	}

	public void simpleBlockItem(Block block, ModelFile model) {
		itemModels().getBuilder(key(block).getPath()).parent(model);
	}

	public void simpleBlockWithItem(Block block, ModelFile model) {
		simpleBlock(block, model);
		simpleBlockItem(block, model);
	}

	public void simpleBlock(Block block, ConfiguredModel... models) {
		getVariantBuilder(block)
				.partialState().setModels(models);
	}

	public void axisBlock(PillarBlock block) {
		axisBlock(block, blockTexture(block));
	}

	public void logBlock(PillarBlock block) {
		axisBlock(block, blockTexture(block), extend(blockTexture(block), "_top"));
	}

	public void axisBlock(PillarBlock block, Identifier baseName) {
		axisBlock(block, extend(baseName, "_side"), extend(baseName, "_end"));
	}

	public void axisBlock(PillarBlock block, Identifier side, Identifier end) {
		axisBlock(block,
				models().cubeColumn(name(block), side, end),
				models().cubeColumnHorizontal(name(block) + "_horizontal", side, end));
	}

	public void axisBlockWithRenderType(PillarBlock block, String renderType) {
		axisBlockWithRenderType(block, blockTexture(block), renderType);
	}

	public void logBlockWithRenderType(PillarBlock block, String renderType) {
		axisBlockWithRenderType(block, blockTexture(block), extend(blockTexture(block), "_top"), renderType);
	}

	public void axisBlockWithRenderType(PillarBlock block, Identifier baseName, String renderType) {
		axisBlockWithRenderType(block, extend(baseName, "_side"), extend(baseName, "_end"), renderType);
	}

	public void axisBlockWithRenderType(PillarBlock block, Identifier side, Identifier end, String renderType) {
		axisBlock(block,
				models().cubeColumn(name(block), side, end).renderType(renderType),
				models().cubeColumnHorizontal(name(block) + "_horizontal", side, end).renderType(renderType));
	}

	public void axisBlockWithRenderType(PillarBlock block, Identifier renderType) {
		axisBlockWithRenderType(block, blockTexture(block), renderType);
	}

	public void logBlockWithRenderType(PillarBlock block, Identifier renderType) {
		axisBlockWithRenderType(block, blockTexture(block), extend(blockTexture(block), "_top"), renderType);
	}

	public void axisBlockWithRenderType(PillarBlock block, Identifier baseName, Identifier renderType) {
		axisBlockWithRenderType(block, extend(baseName, "_side"), extend(baseName, "_end"), renderType);
	}

	public void axisBlockWithRenderType(PillarBlock block, Identifier side, Identifier end, Identifier renderType) {
		axisBlock(block,
				models().cubeColumn(name(block), side, end).renderType(renderType),
				models().cubeColumnHorizontal(name(block) + "_horizontal", side, end).renderType(renderType));
	}

	public void axisBlock(PillarBlock block, ModelFile vertical, ModelFile horizontal) {
		getVariantBuilder(block)
				.partialState().with(PillarBlock.AXIS, Axis.field_11052)
				.modelForState().modelFile(vertical).addModel()
				.partialState().with(PillarBlock.AXIS, Axis.field_11051)
				.modelForState().modelFile(horizontal).rotationX(90).addModel()
				.partialState().with(PillarBlock.AXIS, Axis.field_11048)
				.modelForState().modelFile(horizontal).rotationX(90).rotationY(90).addModel();
	}

	private static final int DEFAULT_ANGLE_OFFSET = 180;

	public void horizontalBlock(Block block, Identifier side, Identifier front, Identifier top) {
		horizontalBlock(block, models().orientable(name(block), side, front, top));
	}

	public void horizontalBlock(Block block, ModelFile model) {
		horizontalBlock(block, model, DEFAULT_ANGLE_OFFSET);
	}

	public void horizontalBlock(Block block, ModelFile model, int angleOffset) {
		horizontalBlock(block, $ -> model, angleOffset);
	}

	public void horizontalBlock(Block block, Function<BlockState, ModelFile> modelFunc) {
		horizontalBlock(block, modelFunc, DEFAULT_ANGLE_OFFSET);
	}

	public void horizontalBlock(Block block, Function<BlockState, ModelFile> modelFunc, int angleOffset) {
		getVariantBuilder(block)
				.forAllStates(state -> ConfiguredModel.builder()
						.modelFile(modelFunc.apply(state))
						.rotationY(((int) state.get(Properties.HORIZONTAL_FACING).asRotation() + angleOffset) % 360)
						.build()
				);
	}

	public void horizontalFaceBlock(Block block, ModelFile model) {
		horizontalFaceBlock(block, model, DEFAULT_ANGLE_OFFSET);
	}

	public void horizontalFaceBlock(Block block, ModelFile model, int angleOffset) {
		horizontalFaceBlock(block, $ -> model, angleOffset);
	}

	public void horizontalFaceBlock(Block block, Function<BlockState, ModelFile> modelFunc) {
		horizontalFaceBlock(block, modelFunc, DEFAULT_ANGLE_OFFSET);
	}

	public void horizontalFaceBlock(Block block, Function<BlockState, ModelFile> modelFunc, int angleOffset) {
		getVariantBuilder(block)
				.forAllStates(state -> ConfiguredModel.builder()
						.modelFile(modelFunc.apply(state))
						.rotationX(state.get(Properties.WALL_MOUNT_LOCATION).ordinal() * 90)
						.rotationY((((int) state.get(Properties.HORIZONTAL_FACING).asRotation() + angleOffset) + (state.get(Properties.WALL_MOUNT_LOCATION) == WallMountLocation.field_12473 ? 180 : 0)) % 360)
						.build()
				);
	}

	public void directionalBlock(Block block, ModelFile model) {
		directionalBlock(block, model, DEFAULT_ANGLE_OFFSET);
	}

	public void directionalBlock(Block block, ModelFile model, int angleOffset) {
		directionalBlock(block, $ -> model, angleOffset);
	}

	public void directionalBlock(Block block, Function<BlockState, ModelFile> modelFunc) {
		directionalBlock(block, modelFunc, DEFAULT_ANGLE_OFFSET);
	}

	public void directionalBlock(Block block, Function<BlockState, ModelFile> modelFunc, int angleOffset) {
		getVariantBuilder(block)
				.forAllStates(state -> {
					Direction dir = state.get(Properties.FACING);
					return ConfiguredModel.builder()
							.modelFile(modelFunc.apply(state))
							.rotationX(dir == Direction.field_11033 ? 180 : dir.getAxis().isHorizontal() ? 90 : 0)
							.rotationY(dir.getAxis().isVertical() ? 0 : (((int) dir.asRotation()) + angleOffset) % 360)
							.build();
				});
	}

	public void stairsBlock(StairsBlock block, Identifier texture) {
		stairsBlock(block, texture, texture, texture);
	}

	public void stairsBlock(StairsBlock block, String name, Identifier texture) {
		stairsBlock(block, name, texture, texture, texture);
	}

	public void stairsBlock(StairsBlock block, Identifier side, Identifier bottom, Identifier top) {
		stairsBlockInternal(block, key(block).toString(), side, bottom, top);
	}

	public void stairsBlock(StairsBlock block, String name, Identifier side, Identifier bottom, Identifier top) {
		stairsBlockInternal(block, name + "_stairs", side, bottom, top);
	}

	public void stairsBlockWithRenderType(StairsBlock block, Identifier texture, String renderType) {
		stairsBlockWithRenderType(block, texture, texture, texture, renderType);
	}

	public void stairsBlockWithRenderType(StairsBlock block, String name, Identifier texture, String renderType) {
		stairsBlockWithRenderType(block, name, texture, texture, texture, renderType);
	}

	public void stairsBlockWithRenderType(StairsBlock block, Identifier side, Identifier bottom, Identifier top, String renderType) {
		stairsBlockInternalWithRenderType(block, key(block).toString(), side, bottom, top, Identifier.tryParse(renderType));
	}

	public void stairsBlockWithRenderType(StairsBlock block, String name, Identifier side, Identifier bottom, Identifier top, String renderType) {
		stairsBlockInternalWithRenderType(block, name + "_stairs", side, bottom, top, Identifier.tryParse(renderType));
	}

	public void stairsBlockWithRenderType(StairsBlock block, Identifier texture, Identifier renderType) {
		stairsBlockWithRenderType(block, texture, texture, texture, renderType);
	}

	public void stairsBlockWithRenderType(StairsBlock block, String name, Identifier texture, Identifier renderType) {
		stairsBlockWithRenderType(block, name, texture, texture, texture, renderType);
	}

	public void stairsBlockWithRenderType(StairsBlock block, Identifier side, Identifier bottom, Identifier top, Identifier renderType) {
		stairsBlockInternalWithRenderType(block, key(block).toString(), side, bottom, top, renderType);
	}

	public void stairsBlockWithRenderType(StairsBlock block, String name, Identifier side, Identifier bottom, Identifier top, Identifier renderType) {
		stairsBlockInternalWithRenderType(block, name + "_stairs", side, bottom, top, renderType);
	}

	private void stairsBlockInternal(StairsBlock block, String baseName, Identifier side, Identifier bottom, Identifier top) {
		ModelFile stairs = models().stairs(baseName, side, bottom, top);
		ModelFile stairsInner = models().stairsInner(baseName + "_inner", side, bottom, top);
		ModelFile stairsOuter = models().stairsOuter(baseName + "_outer", side, bottom, top);
		stairsBlock(block, stairs, stairsInner, stairsOuter);
	}

	private void stairsBlockInternalWithRenderType(StairsBlock block, String baseName, Identifier side, Identifier bottom, Identifier top, Identifier renderType) {
		ModelFile stairs = models().stairs(baseName, side, bottom, top).renderType(renderType);
		ModelFile stairsInner = models().stairsInner(baseName + "_inner", side, bottom, top).renderType(renderType);
		ModelFile stairsOuter = models().stairsOuter(baseName + "_outer", side, bottom, top).renderType(renderType);
		stairsBlock(block, stairs, stairsInner, stairsOuter);
	}

	public void stairsBlock(StairsBlock block, ModelFile stairs, ModelFile stairsInner, ModelFile stairsOuter) {
		getVariantBuilder(block)
				.forAllStatesExcept(state -> {
					Direction facing = state.get(StairsBlock.FACING);
					BlockHalf half = state.get(StairsBlock.HALF);
					StairShape shape = state.get(StairsBlock.SHAPE);
					int yRot = (int) facing.rotateYClockwise().asRotation(); // Stairs model is rotated 90 degrees clockwise for some reason
					if (shape == StairShape.field_12712 || shape == StairShape.field_12708) {
						yRot += 270; // Left facing stairs are rotated 90 degrees clockwise
					}
					if (shape != StairShape.field_12710 && half == BlockHalf.field_12619) {
						yRot += 90; // Top stairs are rotated 90 degrees clockwise
					}
					yRot %= 360;
					boolean uvlock = yRot != 0 || half == BlockHalf.field_12619; // Don't set uvlock for states that have no rotation
					return ConfiguredModel.builder()
							.modelFile(shape == StairShape.field_12710 ? stairs : shape == StairShape.field_12712 || shape == StairShape.field_12713 ? stairsInner : stairsOuter)
							.rotationX(half == BlockHalf.field_12617 ? 0 : 180)
							.rotationY(yRot)
							.uvLock(uvlock)
							.build();
				}, StairsBlock.WATERLOGGED);
	}

	public void slabBlock(SlabBlock block, Identifier doubleslab, Identifier texture) {
		slabBlock(block, doubleslab, texture, texture, texture);
	}

	public void slabBlock(SlabBlock block, Identifier doubleslab, Identifier side, Identifier bottom, Identifier top) {
		slabBlock(block, models().slab(name(block), side, bottom, top), models().slabTop(name(block) + "_top", side, bottom, top), models().getExistingFile(doubleslab));
	}

	public void slabBlock(SlabBlock block, ModelFile bottom, ModelFile top, ModelFile doubleslab) {
		getVariantBuilder(block)
				.partialState().with(SlabBlock.TYPE, SlabType.field_12681).addModels(new ConfiguredModel(bottom))
				.partialState().with(SlabBlock.TYPE, SlabType.field_12679).addModels(new ConfiguredModel(top))
				.partialState().with(SlabBlock.TYPE, SlabType.field_12682).addModels(new ConfiguredModel(doubleslab));
	}

	public void buttonBlock(ButtonBlock block, Identifier texture) {
		ModelFile button = models().button(name(block), texture);
		ModelFile buttonPressed = models().buttonPressed(name(block) + "_pressed", texture);
		buttonBlock(block, button, buttonPressed);
	}

	public void buttonBlock(ButtonBlock block, ModelFile button, ModelFile buttonPressed) {
		getVariantBuilder(block).forAllStates(state -> {
			Direction facing = state.get(ButtonBlock.FACING);
			WallMountLocation face = state.get(ButtonBlock.FACE);
			boolean powered = state.get(ButtonBlock.POWERED);

			return ConfiguredModel.builder()
					.modelFile(powered ? buttonPressed : button)
					.rotationX(face == WallMountLocation.field_12475 ? 0 : (face == WallMountLocation.field_12471 ? 90 : 180))
					.rotationY((int) (face == WallMountLocation.field_12473 ? facing : facing.getOpposite()).asRotation())
					.uvLock(face == WallMountLocation.field_12471)
					.build();
		});
	}

	public void pressurePlateBlock(PressurePlateBlock block, Identifier texture) {
		ModelFile pressurePlate = models().pressurePlate(name(block), texture);
		ModelFile pressurePlateDown = models().pressurePlateDown(name(block) + "_down", texture);
		pressurePlateBlock(block, pressurePlate, pressurePlateDown);
	}

	public void pressurePlateBlock(PressurePlateBlock block, ModelFile pressurePlate, ModelFile pressurePlateDown) {
		getVariantBuilder(block)
				.partialState().with(PressurePlateBlock.POWERED, true).addModels(new ConfiguredModel(pressurePlateDown))
				.partialState().with(PressurePlateBlock.POWERED, false).addModels(new ConfiguredModel(pressurePlate));
	}

	public void signBlock(SignBlock signBlock, WallSignBlock wallSignBlock, Identifier texture) {
		ModelFile sign = models().sign(name(signBlock), texture);
		signBlock(signBlock, wallSignBlock, sign);
	}

	public void signBlock(SignBlock signBlock, WallSignBlock wallSignBlock, ModelFile sign) {
		simpleBlock(signBlock, sign);
		simpleBlock(wallSignBlock, sign);
	}

	public void fourWayBlock(HorizontalConnectingBlock block, ModelFile post, ModelFile side) {
		MultiPartBlockStateBuilder builder = getMultipartBuilder(block)
				.part().modelFile(post).addModel().end();
		fourWayMultipart(builder, side);
	}

	public void fourWayMultipart(MultiPartBlockStateBuilder builder, ModelFile side) {
		ConnectingBlock.FACING_PROPERTIES.entrySet().forEach(e -> {
			Direction dir = e.getKey();
			if (dir.getAxis().isHorizontal()) {
				builder.part().modelFile(side).rotationY((((int) dir.asRotation()) + 180) % 360).uvLock(true).addModel()
						.condition(e.getValue(), true);
			}
		});
	}

	public void fenceBlock(FenceBlock block, Identifier texture) {
		String baseName = key(block).toString();
		fourWayBlock(block,
				models().fencePost(baseName + "_post", texture),
				models().fenceSide(baseName + "_side", texture));
	}

	public void fenceBlock(FenceBlock block, String name, Identifier texture) {
		fourWayBlock(block,
				models().fencePost(name + "_fence_post", texture),
				models().fenceSide(name + "_fence_side", texture));
	}

	public void fenceBlockWithRenderType(FenceBlock block, Identifier texture, String renderType) {
		String baseName = key(block).toString();
		fourWayBlock(block,
				models().fencePost(baseName + "_post", texture).renderType(renderType),
				models().fenceSide(baseName + "_side", texture).renderType(renderType));
	}

	public void fenceBlockWithRenderType(FenceBlock block, String name, Identifier texture, String renderType) {
		fourWayBlock(block,
				models().fencePost(name + "_fence_post", texture).renderType(renderType),
				models().fenceSide(name + "_fence_side", texture).renderType(renderType));
	}

	public void fenceBlockWithRenderType(FenceBlock block, Identifier texture, Identifier renderType) {
		String baseName = key(block).toString();
		fourWayBlock(block,
				models().fencePost(baseName + "_post", texture).renderType(renderType),
				models().fenceSide(baseName + "_side", texture).renderType(renderType));
	}

	public void fenceBlockWithRenderType(FenceBlock block, String name, Identifier texture, Identifier renderType) {
		fourWayBlock(block,
				models().fencePost(name + "_fence_post", texture).renderType(renderType),
				models().fenceSide(name + "_fence_side", texture).renderType(renderType));
	}

	public void fenceGateBlock(FenceGateBlock block, Identifier texture) {
		fenceGateBlockInternal(block, key(block).toString(), texture);
	}

	public void fenceGateBlock(FenceGateBlock block, String name, Identifier texture) {
		fenceGateBlockInternal(block, name + "_fence_gate", texture);
	}

	public void fenceGateBlockWithRenderType(FenceGateBlock block, Identifier texture, String renderType) {
		fenceGateBlockInternalWithRenderType(block, key(block).toString(), texture, Identifier.tryParse(renderType));
	}

	public void fenceGateBlockWithRenderType(FenceGateBlock block, String name, Identifier texture, String renderType) {
		fenceGateBlockInternalWithRenderType(block, name + "_fence_gate", texture, Identifier.tryParse(renderType));
	}

	public void fenceGateBlockWithRenderType(FenceGateBlock block, Identifier texture, Identifier renderType) {
		fenceGateBlockInternalWithRenderType(block, key(block).toString(), texture, renderType);
	}

	public void fenceGateBlockWithRenderType(FenceGateBlock block, String name, Identifier texture, Identifier renderType) {
		fenceGateBlockInternalWithRenderType(block, name + "_fence_gate", texture, renderType);
	}

	private void fenceGateBlockInternal(FenceGateBlock block, String baseName, Identifier texture) {
		ModelFile gate = models().fenceGate(baseName, texture);
		ModelFile gateOpen = models().fenceGateOpen(baseName + "_open", texture);
		ModelFile gateWall = models().fenceGateWall(baseName + "_wall", texture);
		ModelFile gateWallOpen = models().fenceGateWallOpen(baseName + "_wall_open", texture);
		fenceGateBlock(block, gate, gateOpen, gateWall, gateWallOpen);
	}

	private void fenceGateBlockInternalWithRenderType(FenceGateBlock block, String baseName, Identifier texture, Identifier renderType) {
		ModelFile gate = models().fenceGate(baseName, texture).renderType(renderType);
		ModelFile gateOpen = models().fenceGateOpen(baseName + "_open", texture).renderType(renderType);
		ModelFile gateWall = models().fenceGateWall(baseName + "_wall", texture).renderType(renderType);
		ModelFile gateWallOpen = models().fenceGateWallOpen(baseName + "_wall_open", texture).renderType(renderType);
		fenceGateBlock(block, gate, gateOpen, gateWall, gateWallOpen);
	}

	public void fenceGateBlock(FenceGateBlock block, ModelFile gate, ModelFile gateOpen, ModelFile gateWall, ModelFile gateWallOpen) {
		getVariantBuilder(block).forAllStatesExcept(state -> {
			ModelFile model = gate;
			if (state.get(FenceGateBlock.IN_WALL)) {
				model = gateWall;
			}
			if (state.get(FenceGateBlock.OPEN)) {
				model = model == gateWall ? gateWallOpen : gateOpen;
			}
			return ConfiguredModel.builder()
					.modelFile(model)
					.rotationY((int) state.get(FenceGateBlock.FACING).asRotation())
					.uvLock(true)
					.build();
		}, FenceGateBlock.POWERED);
	}

	public void wallBlock(WallBlock block, Identifier texture) {
		wallBlockInternal(block, key(block).toString(), texture);
	}

	public void wallBlock(WallBlock block, String name, Identifier texture) {
		wallBlockInternal(block, name + "_wall", texture);
	}

	public void wallBlockWithRenderType(WallBlock block, Identifier texture, String renderType) {
		wallBlockInternalWithRenderType(block, key(block).toString(), texture, Identifier.tryParse(renderType));
	}

	public void wallBlockWithRenderType(WallBlock block, String name, Identifier texture, String renderType) {
		wallBlockInternalWithRenderType(block, name + "_wall", texture, Identifier.tryParse(renderType));
	}

	public void wallBlockWithRenderType(WallBlock block, Identifier texture, Identifier renderType) {
		wallBlockInternalWithRenderType(block, key(block).toString(), texture, renderType);
	}

	public void wallBlockWithRenderType(WallBlock block, String name, Identifier texture, Identifier renderType) {
		wallBlockInternalWithRenderType(block, name + "_wall", texture, renderType);
	}

	private void wallBlockInternal(WallBlock block, String baseName, Identifier texture) {
		wallBlock(block, models().wallPost(baseName + "_post", texture),
				models().wallSide(baseName + "_side", texture),
				models().wallSideTall(baseName + "_side_tall", texture));
	}

	private void wallBlockInternalWithRenderType(WallBlock block, String baseName, Identifier texture, Identifier renderType) {
		wallBlock(block, models().wallPost(baseName + "_post", texture).renderType(renderType),
				models().wallSide(baseName + "_side", texture).renderType(renderType),
				models().wallSideTall(baseName + "_side_tall", texture).renderType(renderType));
	}

	public static final ImmutableMap<Direction, Property<WallShape>> WALL_PROPS = ImmutableMap.<Direction, Property<WallShape>>builder()
			.put(Direction.field_11034,  Properties.EAST_WALL_SHAPE)
			.put(Direction.field_11043, Properties.NORTH_WALL_SHAPE)
			.put(Direction.field_11035, Properties.SOUTH_WALL_SHAPE)
			.put(Direction.field_11039,  Properties.WEST_WALL_SHAPE)
			.build();

	public void wallBlock(WallBlock block, ModelFile post, ModelFile side, ModelFile sideTall) {
		MultiPartBlockStateBuilder builder = getMultipartBuilder(block)
				.part().modelFile(post).addModel()
				.condition(WallBlock.UP, true).end();
		WALL_PROPS.entrySet().stream()
				.filter(e -> e.getKey().getAxis().isHorizontal())
				.forEach(e -> {
					wallSidePart(builder, side, e, WallShape.field_22179);
					wallSidePart(builder, sideTall, e, WallShape.field_22180);
				});
	}

	private void wallSidePart(MultiPartBlockStateBuilder builder, ModelFile model, Map.Entry<Direction, Property<WallShape>> entry, WallShape height) {
		builder.part()
				.modelFile(model)
				.rotationY((((int) entry.getKey().asRotation()) + 180) % 360)
				.uvLock(true)
				.addModel()
				.condition(entry.getValue(), height);
	}

	public void paneBlock(PaneBlock block, Identifier pane, Identifier edge) {
		paneBlockInternal(block, key(block).toString(), pane, edge);
	}

	public void paneBlock(PaneBlock block, String name, Identifier pane, Identifier edge) {
		paneBlockInternal(block, name + "_pane", pane, edge);
	}

	public void paneBlockWithRenderType(PaneBlock block, Identifier pane, Identifier edge, String renderType) {
		paneBlockInternalWithRenderType(block, key(block).toString(), pane, edge, Identifier.tryParse(renderType));
	}

	public void paneBlockWithRenderType(PaneBlock block, String name, Identifier pane, Identifier edge, String renderType) {
		paneBlockInternalWithRenderType(block, name + "_pane", pane, edge, Identifier.tryParse(renderType));
	}

	public void paneBlockWithRenderType(PaneBlock block, Identifier pane, Identifier edge, Identifier renderType) {
		paneBlockInternalWithRenderType(block, key(block).toString(), pane, edge, renderType);
	}

	public void paneBlockWithRenderType(PaneBlock block, String name, Identifier pane, Identifier edge, Identifier renderType) {
		paneBlockInternalWithRenderType(block, name + "_pane", pane, edge, renderType);
	}

	private void paneBlockInternal(PaneBlock block, String baseName, Identifier pane, Identifier edge) {
		ModelFile post = models().panePost(baseName + "_post", pane, edge);
		ModelFile side = models().paneSide(baseName + "_side", pane, edge);
		ModelFile sideAlt = models().paneSideAlt(baseName + "_side_alt", pane, edge);
		ModelFile noSide = models().paneNoSide(baseName + "_noside", pane);
		ModelFile noSideAlt = models().paneNoSideAlt(baseName + "_noside_alt", pane);
		paneBlock(block, post, side, sideAlt, noSide, noSideAlt);
	}

	private void paneBlockInternalWithRenderType(PaneBlock block, String baseName, Identifier pane, Identifier edge, Identifier renderType) {
		ModelFile post = models().panePost(baseName + "_post", pane, edge).renderType(renderType);
		ModelFile side = models().paneSide(baseName + "_side", pane, edge).renderType(renderType);
		ModelFile sideAlt = models().paneSideAlt(baseName + "_side_alt", pane, edge).renderType(renderType);
		ModelFile noSide = models().paneNoSide(baseName + "_noside", pane).renderType(renderType);
		ModelFile noSideAlt = models().paneNoSideAlt(baseName + "_noside_alt", pane).renderType(renderType);
		paneBlock(block, post, side, sideAlt, noSide, noSideAlt);
	}

	public void paneBlock(PaneBlock block, ModelFile post, ModelFile side, ModelFile sideAlt, ModelFile noSide, ModelFile noSideAlt) {
		MultiPartBlockStateBuilder builder = getMultipartBuilder(block)
				.part().modelFile(post).addModel().end();
		ConnectingBlock.FACING_PROPERTIES.entrySet().forEach(e -> {
			Direction dir = e.getKey();
			if (dir.getAxis().isHorizontal()) {
				boolean alt = dir == Direction.field_11035;
				builder.part().modelFile(alt || dir == Direction.field_11039 ? sideAlt : side).rotationY(dir.getAxis() == Axis.field_11048 ? 90 : 0).addModel()
						.condition(e.getValue(), true).end()
						.part().modelFile(alt || dir == Direction.field_11034 ? noSideAlt : noSide).rotationY(dir == Direction.field_11039 ? 270 : dir == Direction.field_11035 ? 90 : 0).addModel()
						.condition(e.getValue(), false);
			}
		});
	}

	public void doorBlock(DoorBlock block, Identifier bottom, Identifier top) {
		doorBlockInternal(block, key(block).toString(), bottom, top);
	}

	public void doorBlock(DoorBlock block, String name, Identifier bottom, Identifier top) {
		doorBlockInternal(block, name + "_door", bottom, top);
	}

	public void doorBlockWithRenderType(DoorBlock block, Identifier bottom, Identifier top, String renderType) {
		doorBlockInternalWithRenderType(block, key(block).toString(), bottom, top, Identifier.tryParse(renderType));
	}

	public void doorBlockWithRenderType(DoorBlock block, String name, Identifier bottom, Identifier top, String renderType) {
		doorBlockInternalWithRenderType(block, name + "_door", bottom, top, Identifier.tryParse(renderType));
	}

	public void doorBlockWithRenderType(DoorBlock block, Identifier bottom, Identifier top, Identifier renderType) {
		doorBlockInternalWithRenderType(block, key(block).toString(), bottom, top, renderType);
	}

	public void doorBlockWithRenderType(DoorBlock block, String name, Identifier bottom, Identifier top, Identifier renderType) {
		doorBlockInternalWithRenderType(block, name + "_door", bottom, top, renderType);
	}

	private void doorBlockInternal(DoorBlock block, String baseName, Identifier bottom, Identifier top) {
		ModelFile bottomLeft = models().doorBottomLeft(baseName + "_bottom_left", bottom, top);
		ModelFile bottomLeftOpen = models().doorBottomLeftOpen(baseName + "_bottom_left_open", bottom, top);
		ModelFile bottomRight = models().doorBottomRight(baseName + "_bottom_right", bottom, top);
		ModelFile bottomRightOpen = models().doorBottomRightOpen(baseName + "_bottom_right_open", bottom, top);
		ModelFile topLeft = models().doorTopLeft(baseName + "_top_left", bottom, top);
		ModelFile topLeftOpen = models().doorTopLeftOpen(baseName + "_top_left_open", bottom, top);
		ModelFile topRight = models().doorTopRight(baseName + "_top_right", bottom, top);
		ModelFile topRightOpen = models().doorTopRightOpen(baseName + "_top_right_open", bottom, top);
		doorBlock(block, bottomLeft, bottomLeftOpen, bottomRight, bottomRightOpen, topLeft, topLeftOpen, topRight, topRightOpen);
	}

	private void doorBlockInternalWithRenderType(DoorBlock block, String baseName, Identifier bottom, Identifier top, Identifier renderType) {
		ModelFile bottomLeft = models().doorBottomLeft(baseName + "_bottom_left", bottom, top).renderType(renderType);
		ModelFile bottomLeftOpen = models().doorBottomLeftOpen(baseName + "_bottom_left_open", bottom, top).renderType(renderType);
		ModelFile bottomRight = models().doorBottomRight(baseName + "_bottom_right", bottom, top).renderType(renderType);
		ModelFile bottomRightOpen = models().doorBottomRightOpen(baseName + "_bottom_right_open", bottom, top).renderType(renderType);
		ModelFile topLeft = models().doorTopLeft(baseName + "_top_left", bottom, top).renderType(renderType);
		ModelFile topLeftOpen = models().doorTopLeftOpen(baseName + "_top_left_open", bottom, top).renderType(renderType);
		ModelFile topRight = models().doorTopRight(baseName + "_top_right", bottom, top).renderType(renderType);
		ModelFile topRightOpen = models().doorTopRightOpen(baseName + "_top_right_open", bottom, top).renderType(renderType);
		doorBlock(block, bottomLeft, bottomLeftOpen, bottomRight, bottomRightOpen, topLeft, topLeftOpen, topRight, topRightOpen);
	}

	public void doorBlock(DoorBlock block, ModelFile bottomLeft, ModelFile bottomLeftOpen, ModelFile bottomRight, ModelFile bottomRightOpen, ModelFile topLeft, ModelFile topLeftOpen, ModelFile topRight, ModelFile topRightOpen) {
		getVariantBuilder(block).forAllStatesExcept(state -> {
			int yRot = ((int) state.get(DoorBlock.FACING).asRotation()) + 90;
			boolean right = state.get(DoorBlock.HINGE) == DoorHinge.field_12586;
			boolean open = state.get(DoorBlock.OPEN);
			boolean lower = state.get(DoorBlock.HALF) == DoubleBlockHalf.field_12607;
			if (open) {
				yRot += 90;
			}
			if (right && open) {
				yRot += 180;
			}
			yRot %= 360;

			ModelFile model = null;
			if (lower && right && open) {
				model = bottomRightOpen;
			} else if (lower && !right && open) {
				model = bottomLeftOpen;
			}
			if (lower && right && !open) {
				model = bottomRight;
			} else if (lower && !right && !open) {
				model = bottomLeft;
			}
			if (!lower && right && open) {
				model = topRightOpen;
			} else if (!lower && !right && open) {
				model = topLeftOpen;
			}
			if (!lower && right && !open) {
				model = topRight;
			} else if (!lower && !right && !open) {
				model = topLeft;
			}

			return ConfiguredModel.builder().modelFile(model)
					.rotationY(yRot)
					.build();
		}, DoorBlock.POWERED);
	}

	public void trapdoorBlock(TrapdoorBlock block, Identifier texture, boolean orientable) {
		trapdoorBlockInternal(block, key(block).toString(), texture, orientable);
	}

	public void trapdoorBlock(TrapdoorBlock block, String name, Identifier texture, boolean orientable) {
		trapdoorBlockInternal(block, name + "_trapdoor", texture, orientable);
	}

	public void trapdoorBlockWithRenderType(TrapdoorBlock block, Identifier texture, boolean orientable, String renderType) {
		trapdoorBlockInternalWithRenderType(block, key(block).toString(), texture, orientable, Identifier.tryParse(renderType));
	}

	public void trapdoorBlockWithRenderType(TrapdoorBlock block, String name, Identifier texture, boolean orientable, String renderType) {
		trapdoorBlockInternalWithRenderType(block, name + "_trapdoor", texture, orientable, Identifier.tryParse(renderType));
	}

	public void trapdoorBlockWithRenderType(TrapdoorBlock block, Identifier texture, boolean orientable, Identifier renderType) {
		trapdoorBlockInternalWithRenderType(block, key(block).toString(), texture, orientable, renderType);
	}

	public void trapdoorBlockWithRenderType(TrapdoorBlock block, String name, Identifier texture, boolean orientable, Identifier renderType) {
		trapdoorBlockInternalWithRenderType(block, name + "_trapdoor", texture, orientable, renderType);
	}

	private void trapdoorBlockInternal(TrapdoorBlock block, String baseName, Identifier texture, boolean orientable) {
		ModelFile bottom = orientable ? models().trapdoorOrientableBottom(baseName + "_bottom", texture) : models().trapdoorBottom(baseName + "_bottom", texture);
		ModelFile top = orientable ? models().trapdoorOrientableTop(baseName + "_top", texture) : models().trapdoorTop(baseName + "_top", texture);
		ModelFile open = orientable ? models().trapdoorOrientableOpen(baseName + "_open", texture) : models().trapdoorOpen(baseName + "_open", texture);
		trapdoorBlock(block, bottom, top, open, orientable);
	}

	private void trapdoorBlockInternalWithRenderType(TrapdoorBlock block, String baseName, Identifier texture, boolean orientable, Identifier renderType) {
		ModelFile bottom = orientable ? models().trapdoorOrientableBottom(baseName + "_bottom", texture).renderType(renderType) : models().trapdoorBottom(baseName + "_bottom", texture).renderType(renderType);
		ModelFile top = orientable ? models().trapdoorOrientableTop(baseName + "_top", texture).renderType(renderType) : models().trapdoorTop(baseName + "_top", texture).renderType(renderType);
		ModelFile open = orientable ? models().trapdoorOrientableOpen(baseName + "_open", texture).renderType(renderType) : models().trapdoorOpen(baseName + "_open", texture).renderType(renderType);
		trapdoorBlock(block, bottom, top, open, orientable);
	}

	public void trapdoorBlock(TrapdoorBlock block, ModelFile bottom, ModelFile top, ModelFile open, boolean orientable) {
		getVariantBuilder(block).forAllStatesExcept(state -> {
			int xRot = 0;
			int yRot = ((int) state.get(TrapdoorBlock.FACING).asRotation()) + 180;
			boolean isOpen = state.get(TrapdoorBlock.OPEN);
			if (orientable && isOpen && state.get(TrapdoorBlock.HALF) == BlockHalf.field_12619) {
				xRot += 180;
				yRot += 180;
			}
			if (!orientable && !isOpen) {
				yRot = 0;
			}
			yRot %= 360;
			return ConfiguredModel.builder().modelFile(isOpen ? open : state.get(TrapdoorBlock.HALF) == BlockHalf.field_12619 ? top : bottom)
					.rotationX(xRot)
					.rotationY(yRot)
					.build();
		}, TrapdoorBlock.POWERED, TrapdoorBlock.WATERLOGGED);
	}

	private CompletableFuture<?> saveBlockState(DataWriter cache, JsonObject stateJson, Block owner) {
		Identifier blockName = Preconditions.checkNotNull(key(owner));
		Path outputPath = this.output.resolvePath(DataOutput.OutputType.field_39368)
				.resolve(blockName.getNamespace()).resolve("blockstates").resolve(blockName.getPath() + ".json");
		return DataProvider.writeToPath(cache, stateJson, outputPath);
	}

	@NotNull
	@Override
	public String getName() {
		return "Block States: " + modid;
	}

	public static class ConfiguredModelList {
		private final List<ConfiguredModel> models;

		private ConfiguredModelList(List<ConfiguredModel> models) {
			Preconditions.checkArgument(!models.isEmpty());
			this.models = models;
		}

		public ConfiguredModelList(ConfiguredModel model) {
			this(ImmutableList.of(model));
		}

		public ConfiguredModelList(ConfiguredModel... models) {
			this(Arrays.asList(models));
		}

		public JsonElement toJSON() {
			if (models.size()==1) {
				return models.get(0).toJSON(false);
			} else {
				JsonArray ret = new JsonArray();
				for (ConfiguredModel m:models) {
					ret.add(m.toJSON(true));
				}
				return ret;
			}
		}

		public ConfiguredModelList append(ConfiguredModel... models) {
			return new ConfiguredModelList(ImmutableList.<ConfiguredModel>builder().addAll(this.models).add(models).build());
		}
	}
}

package io.github.fabricators_of_create.porting_lib.models.generators.item;

import io.github.fabricators_of_create.porting_lib.data.ExistingFileHelper;
import io.github.fabricators_of_create.porting_lib.models.generators.ModelFile;
import io.github.fabricators_of_create.porting_lib.models.generators.ModelProvider;
import org.jetbrains.annotations.NotNull;

import java.util.Objects;
import net.minecraft.data.DataOutput;
import net.minecraft.item.Item;
import net.minecraft.registry.Registries;
import net.minecraft.util.Identifier;

/**
 * Stub class to extend for item model data providers, eliminates some
 * boilerplate constructor parameters.
 */
public abstract class ItemModelProvider extends ModelProvider<ItemModelBuilder> {

	public ItemModelProvider(DataOutput output, String modid, ExistingFileHelper existingFileHelper) {
		super(output, modid, ITEM_FOLDER, ItemModelBuilder::new, existingFileHelper);
	}

	public ItemModelBuilder basicItem(Item item)
	{
		return basicItem(Objects.requireNonNull(Registries.ITEM.getId(item)));
	}

	public ItemModelBuilder basicItem(Identifier item)
	{
		return getBuilder(item.toString())
				.parent(new ModelFile.UncheckedModelFile("item/generated"))
				.texture("layer0", new Identifier(item.getNamespace(), "item/" + item.getPath()));
	}

	@NotNull
	@Override
	public String getName() {
		return "Item Models: " + modid;
	}
}

package io.github.fabricators_of_create.porting_lib.models.generators;

import com.google.common.base.Preconditions;

import io.github.fabricators_of_create.porting_lib.data.ExistingFileHelper;
import net.minecraft.util.Identifier;

public abstract class ModelFile {

	protected Identifier location;

	protected ModelFile(Identifier location) {
		this.location = location;
	}

	protected abstract boolean exists();

	public Identifier getLocation() {
		assertExistence();
		return location;
	}

	/**
	 * Assert that this model exists.
	 * @throws IllegalStateException if this model does not exist
	 */
	public void assertExistence() {
		Preconditions.checkState(exists(), "Model at %s does not exist", location);
	}

	public Identifier getUncheckedLocation() {
		return location;
	}

	public static class UncheckedModelFile extends ModelFile {

		public UncheckedModelFile(String location) {
			this(new Identifier(location));
		}
		public UncheckedModelFile(Identifier location) {
			super(location);
		}

		@Override
		protected boolean exists() {
			return true;
		}
	}

	public static class ExistingModelFile extends ModelFile {
		private final ExistingFileHelper existingHelper;

		public ExistingModelFile(Identifier location, ExistingFileHelper existingHelper) {
			super(location);
			this.existingHelper = existingHelper;
		}

		@Override
		protected boolean exists() {
			if (getUncheckedLocation().getPath().contains("."))
				return existingHelper.exists(getUncheckedLocation(), ModelProvider.MODEL_WITH_EXTENSION);
			else
				return existingHelper.exists(getUncheckedLocation(), ModelProvider.MODEL);
		}
	}
}

package fuzs.forgeconfigapiport.mixin.client;

import fuzs.forgeconfigapiport.impl.network.client.NetworkHooks;
import net.minecraft.client.network.ClientLoginNetworkHandler;
import net.minecraft.network.ClientConnection;
import net.minecraft.network.packet.s2c.login.LoginSuccessS2CPacket;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ClientLoginNetworkHandler.class)
abstract class ClientHandshakePacketListenerImplMixin {
    @Shadow
    @Final
    private ClientConnection connection;

    @Inject(method = "handleGameProfile", at = @At(value = "INVOKE", target = "Lnet/minecraft/network/Connection;setProtocol(Lnet/minecraft/network/ConnectionProtocol;)V", shift = At.Shift.AFTER))
    public void handleGameProfile(LoginSuccessS2CPacket clientboundGameProfilePacket, CallbackInfo callbackInfo) {
        NetworkHooks.handleClientLoginSuccess(this.connection);
    }
}

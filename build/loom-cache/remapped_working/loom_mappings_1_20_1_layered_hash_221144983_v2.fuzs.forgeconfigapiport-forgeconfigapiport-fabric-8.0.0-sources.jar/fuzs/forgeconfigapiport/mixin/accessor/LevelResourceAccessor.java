package fuzs.forgeconfigapiport.mixin.accessor;

import net.minecraft.util.WorldSavePath;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(WorldSavePath.class)
public interface LevelResourceAccessor {

    @Invoker("<init>")
    static WorldSavePath forgeconfigapiport$create(String string) {
        throw new IllegalStateException();
    }
}

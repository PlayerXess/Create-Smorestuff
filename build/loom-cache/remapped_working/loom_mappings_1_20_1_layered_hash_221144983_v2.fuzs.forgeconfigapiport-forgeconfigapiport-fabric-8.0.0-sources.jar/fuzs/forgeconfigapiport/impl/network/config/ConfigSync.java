/*
 * Copyright (c) Forge Development LLC and contributors
 * SPDX-License-Identifier: LGPL-2.1-only
 */

package fuzs.forgeconfigapiport.impl.network.config;

import fuzs.forgeconfigapiport.impl.ForgeConfigAPIPort;
import io.netty.buffer.Unpooled;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerLoginNetworkHandler;
import net.minecraft.util.Identifier;
import net.minecraftforge.fml.config.ConfigTracker;
import net.minecraftforge.fml.config.ModConfig;
import org.apache.commons.lang3.tuple.Pair;

import java.io.IOException;
import java.nio.file.Files;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

// Forge Config API Port: this class is greatly altered from Forge, as it includes all relevant parts from net.minecraftforge.network.HandshakeHandler which has not been ported separately
// also there are a number of changes to adapt to Fabric's style of networking
public final class ConfigSync {
    public static final Identifier SYNC_CONFIGS_CHANNEL = new Identifier(ForgeConfigAPIPort.MOD_ID, "sync_configs");
    public static final Identifier ESTABLISH_MODDED_CONNECTION_CHANNEL = new Identifier(ForgeConfigAPIPort.MOD_ID, "modded_connection");

    private ConfigSync() {

    }

    public static List<Pair<String, PacketByteBuf>> onSyncConfigs() {
        final Map<String, byte[]> configData = ConfigTracker.INSTANCE.configSets().get(ModConfig.Type.SERVER).stream().collect(Collectors.toMap(ModConfig::getFileName, config -> {
            try {
                return Files.readAllBytes(config.getFullPath());
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        }));
        return configData.entrySet().stream().map(e -> {
            PacketByteBuf buf = new PacketByteBuf(Unpooled.buffer());
            buf.writeString(e.getKey());
            buf.writeByteArray(e.getValue());
            return Pair.of("Config " + e.getKey(), buf);
        }).collect(Collectors.toList());
    }

    public static void onSyncConfigs(MinecraftServer server, ServerLoginNetworkHandler handler, boolean understood, PacketByteBuf buf) {
        // The client is likely a vanilla client.
        if (!understood) return;
        String fileName = buf.readString(32767);
        ForgeConfigAPIPort.LOGGER.debug("Received acknowledgement for config sync for {} from client", fileName);
    }

    public static void onEstablishModdedConnection(MinecraftServer server, ServerLoginNetworkHandler handler, boolean understood, PacketByteBuf buf) {
        ForgeConfigAPIPort.LOGGER.debug("Received acknowledgement for modded connection marker from client");
    }

    public static void unloadSyncedConfig() {
        ConfigTracker.INSTANCE.configSets().get(ModConfig.Type.SERVER).forEach(config -> config.acceptSyncedConfig(null));
    }
}
package dev.emi.emi.mixin.accessor;

import java.util.Map;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.item.ShovelItem;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(ShovelItem.class)
public interface ShovelItemAccessor {

	@Accessor("PATH_STATES")
	static Map<Block, BlockState> getPathStates() {
		throw new UnsupportedOperationException();
	}
}

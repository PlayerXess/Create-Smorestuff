package dev.emi.emi.mixin.accessor;

import net.minecraft.recipe.BrewingRecipeRegistry;
import net.minecraft.recipe.Ingredient;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(BrewingRecipeRegistry.Recipe.class)
public interface BrewingRecipeRegistryRecipeAccessor {

	@Accessor("input")
	Object getInput();

	@Accessor("ingredient")
	Ingredient getIngredient();

	@Accessor("output")
	Object getOutput();
}

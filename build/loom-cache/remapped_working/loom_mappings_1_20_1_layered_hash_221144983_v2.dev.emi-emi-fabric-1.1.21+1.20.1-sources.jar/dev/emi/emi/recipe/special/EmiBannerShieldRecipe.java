package dev.emi.emi.recipe.special;

import java.util.List;
import java.util.Random;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import net.minecraft.block.entity.BannerPattern;
import net.minecraft.block.entity.BlockEntityType;
import net.minecraft.item.BannerItem;
import net.minecraft.item.BlockItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.util.Identifier;
import dev.emi.emi.EmiPort;
import dev.emi.emi.api.recipe.EmiPatternCraftingRecipe;
import dev.emi.emi.api.stack.EmiIngredient;
import dev.emi.emi.api.stack.EmiStack;
import dev.emi.emi.api.widget.GeneratedSlotWidget;
import dev.emi.emi.api.widget.SlotWidget;

public class EmiBannerShieldRecipe extends EmiPatternCraftingRecipe {
	public static final List<Item> BANNERS = List.of(
		Items.field_8539, Items.field_8824, Items.field_8671, Items.field_8379,
		Items.field_8049, Items.field_8778, Items.field_8329, Items.field_8617,
		Items.field_8855, Items.field_8629, Items.field_8405, Items.field_8128,
		Items.field_8124, Items.field_8295, Items.field_8586, Items.field_8572
	);
	private static final List<EmiStack> EMI_BANNERS = BANNERS.stream().map(i -> EmiStack.of(i)).collect(Collectors.toList());
	public static final EmiStack SHIELD = EmiStack.of(Items.field_8255);

	@SuppressWarnings("unchecked")
	public EmiBannerShieldRecipe(Identifier id) {
		super((List<EmiIngredient>) (List<?>) Stream.concat(Stream.of(SHIELD), EMI_BANNERS.stream()).toList(), EmiStack.of(Items.field_8255), id);
	}

	@Override
	public SlotWidget getInputWidget(int slot, int x, int y) {
		if (slot == 0) {
			return new SlotWidget(SHIELD, x, y);
		} else if (slot == 1) {
			return new GeneratedSlotWidget(r -> getPattern(r, null), unique, x, y);
		}
		return new SlotWidget(EmiStack.EMPTY, x, y);
	}

	@Override
	public SlotWidget getOutputWidget(int x, int y) {
		return new GeneratedSlotWidget(r -> getPattern(r, Items.field_8255), unique, x, y);
	}
	
	public EmiStack getPattern(Random random, Item item) {
		int base = random.nextInt(BANNERS.size());
		if (item == null) {
			item = BANNERS.get(base);
		}
		ItemStack stack = new ItemStack(item);
		int patterns = 1 + Math.max(random.nextInt(5), random.nextInt(3));
		BannerPattern.Patterns pattern = new BannerPattern.Patterns();
		for (int i = 0; i < patterns; i++) {
			pattern = EmiPort.addRandomBanner(pattern, random);
		}
		NbtCompound tag = new NbtCompound();
		tag.put("Patterns", pattern.toNbt());
		if (item == Items.field_8255) {
			tag.putInt("Base", ((BannerItem) BANNERS.get(base)).getColor().getId());
		}
		BlockItem.setBlockEntityNbt(stack, BlockEntityType.field_11905, tag);
		//stack.setNbt(tag);
		return EmiStack.of(stack);
	}
}

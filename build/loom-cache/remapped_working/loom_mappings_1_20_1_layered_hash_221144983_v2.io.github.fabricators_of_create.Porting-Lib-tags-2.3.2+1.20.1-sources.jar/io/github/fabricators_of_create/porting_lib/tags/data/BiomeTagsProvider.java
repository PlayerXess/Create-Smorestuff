package io.github.fabricators_of_create.porting_lib.tags.data;

import io.github.fabricators_of_create.porting_lib.tags.Tags;
import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricTagProvider;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.registry.RegistryWrapper;
import net.minecraft.registry.tag.BiomeTags;
import net.minecraft.registry.tag.TagKey;
import net.minecraft.world.biome.Biome;
import net.minecraft.world.biome.BiomeKeys;
import java.util.concurrent.CompletableFuture;

public final class BiomeTagsProvider extends FabricTagProvider<Biome> {

	public BiomeTagsProvider(FabricDataOutput output, CompletableFuture<RegistryWrapper.WrapperLookup> registriesFuture) {
		super(output, RegistryKeys.BIOME, registriesFuture);
	}

	@Override
	protected void configure(RegistryWrapper.WrapperLookup arg) {
		tag(BiomeKeys.field_9451, Tags.Biomes.IS_PLAINS);
		tag(BiomeKeys.field_9424, Tags.Biomes.IS_HOT_OVERWORLD, Tags.Biomes.IS_DRY_OVERWORLD, Tags.Biomes.IS_SANDY, Tags.Biomes.IS_DESERT);
		tag(BiomeKeys.field_9420, Tags.Biomes.IS_COLD_OVERWORLD, Tags.Biomes.IS_CONIFEROUS);
		tag(BiomeKeys.field_9471, Tags.Biomes.IS_WET_OVERWORLD, Tags.Biomes.IS_SWAMP);
		tag(BiomeKeys.field_9461, Tags.Biomes.IS_HOT_NETHER, Tags.Biomes.IS_DRY_NETHER);
		tag(BiomeKeys.field_9411, Tags.Biomes.IS_COLD_END, Tags.Biomes.IS_DRY_END);
		tag(BiomeKeys.field_9435, Tags.Biomes.IS_COLD_OVERWORLD, Tags.Biomes.IS_SNOWY);
		tag(BiomeKeys.field_9463, Tags.Biomes.IS_COLD_OVERWORLD, Tags.Biomes.IS_SNOWY);
		tag(BiomeKeys.field_35117, Tags.Biomes.IS_COLD_OVERWORLD, Tags.Biomes.IS_SNOWY, Tags.Biomes.IS_WASTELAND, Tags.Biomes.IS_PLAINS);
		tag(BiomeKeys.field_9462, Tags.Biomes.IS_MUSHROOM, Tags.Biomes.IS_RARE);
		tag(BiomeKeys.field_9417, Tags.Biomes.IS_HOT_OVERWORLD, Tags.Biomes.IS_WET_OVERWORLD, Tags.Biomes.IS_DENSE_OVERWORLD);
		tag(BiomeKeys.field_35118, Tags.Biomes.IS_HOT_OVERWORLD, Tags.Biomes.IS_WET_OVERWORLD, Tags.Biomes.IS_RARE);
		tag(BiomeKeys.field_9434, Tags.Biomes.IS_WET_OVERWORLD, Tags.Biomes.IS_SANDY);
		tag(BiomeKeys.field_9478, Tags.Biomes.IS_COLD_OVERWORLD, Tags.Biomes.IS_SNOWY);
		tag(BiomeKeys.field_9475, Tags.Biomes.IS_SPOOKY, Tags.Biomes.IS_DENSE_OVERWORLD);
		tag(BiomeKeys.field_9454, Tags.Biomes.IS_COLD_OVERWORLD, Tags.Biomes.IS_CONIFEROUS, Tags.Biomes.IS_SNOWY);
		tag(BiomeKeys.field_35119, Tags.Biomes.IS_COLD_OVERWORLD, Tags.Biomes.IS_CONIFEROUS);
		tag(BiomeKeys.field_35120, Tags.Biomes.IS_SPARSE_OVERWORLD);
		tag(BiomeKeys.field_9449, Tags.Biomes.IS_HOT_OVERWORLD, Tags.Biomes.IS_SPARSE_OVERWORLD);
		tag(BiomeKeys.field_9430, Tags.Biomes.IS_HOT_OVERWORLD, Tags.Biomes.IS_SPARSE_OVERWORLD, Tags.Biomes.IS_RARE, Tags.Biomes.IS_SLOPE, Tags.Biomes.IS_PLATEAU);
		tag(BiomeKeys.field_9415, Tags.Biomes.IS_SANDY, Tags.Biomes.IS_DRY_OVERWORLD);
		tag(BiomeKeys.field_35110, Tags.Biomes.IS_SANDY, Tags.Biomes.IS_DRY_OVERWORLD, Tags.Biomes.IS_SPARSE_OVERWORLD, Tags.Biomes.IS_SLOPE, Tags.Biomes.IS_PLATEAU);
		tag(BiomeKeys.field_34470, Tags.Biomes.IS_PLAINS, Tags.Biomes.IS_PLATEAU, Tags.Biomes.IS_SLOPE);
		tag(BiomeKeys.field_34471, Tags.Biomes.IS_COLD_OVERWORLD, Tags.Biomes.IS_CONIFEROUS, Tags.Biomes.IS_SNOWY, Tags.Biomes.IS_SLOPE);
		tag(BiomeKeys.field_34472, Tags.Biomes.IS_COLD_OVERWORLD, Tags.Biomes.IS_SPARSE_OVERWORLD, Tags.Biomes.IS_SNOWY, Tags.Biomes.IS_SLOPE);
		tag(BiomeKeys.field_34474, Tags.Biomes.IS_COLD_OVERWORLD, Tags.Biomes.IS_SPARSE_OVERWORLD, Tags.Biomes.IS_SNOWY, Tags.Biomes.IS_PEAK);
		tag(BiomeKeys.field_35115, Tags.Biomes.IS_COLD_OVERWORLD, Tags.Biomes.IS_SPARSE_OVERWORLD, Tags.Biomes.IS_SNOWY, Tags.Biomes.IS_PEAK);
		tag(BiomeKeys.field_34475, Tags.Biomes.IS_HOT_OVERWORLD, Tags.Biomes.IS_PEAK);
		tag(BiomeKeys.field_9457, Tags.Biomes.IS_COLD_END, Tags.Biomes.IS_DRY_END);
		tag(BiomeKeys.field_9447, Tags.Biomes.IS_COLD_END, Tags.Biomes.IS_DRY_END);
		tag(BiomeKeys.field_9442, Tags.Biomes.IS_COLD_END, Tags.Biomes.IS_DRY_END);
		tag(BiomeKeys.field_9465, Tags.Biomes.IS_COLD_END, Tags.Biomes.IS_DRY_END);
		tag(BiomeKeys.field_9408, Tags.Biomes.IS_HOT_OVERWORLD);
		tag(BiomeKeys.field_9467, Tags.Biomes.IS_COLD_OVERWORLD);
		tag(BiomeKeys.field_9470, Tags.Biomes.IS_COLD_OVERWORLD);
		tag(BiomeKeys.field_9418, Tags.Biomes.IS_COLD_OVERWORLD);
		tag(BiomeKeys.field_9473, Tags.Biomes.IS_VOID);
		tag(BiomeKeys.field_9455, Tags.Biomes.IS_PLAINS, Tags.Biomes.IS_RARE);
		tag(BiomeKeys.field_35111, Tags.Biomes.IS_SPARSE_OVERWORLD, Tags.Biomes.IS_RARE);
		tag(BiomeKeys.field_9414, Tags.Biomes.IS_RARE);
		tag(BiomeKeys.field_9453, Tags.Biomes.IS_COLD_OVERWORLD, Tags.Biomes.IS_SNOWY, Tags.Biomes.IS_RARE);
		tag(BiomeKeys.field_35112, Tags.Biomes.IS_DENSE_OVERWORLD, Tags.Biomes.IS_RARE);
		tag(BiomeKeys.field_35113, Tags.Biomes.IS_DENSE_OVERWORLD, Tags.Biomes.IS_RARE);
		tag(BiomeKeys.field_35114, Tags.Biomes.IS_HOT_OVERWORLD, Tags.Biomes.IS_DRY_OVERWORLD, Tags.Biomes.IS_SPARSE_OVERWORLD, Tags.Biomes.IS_RARE);
		tag(BiomeKeys.field_9443, Tags.Biomes.IS_HOT_OVERWORLD, Tags.Biomes.IS_DRY_OVERWORLD, Tags.Biomes.IS_SPARSE_OVERWORLD, Tags.Biomes.IS_RARE);
		tag(BiomeKeys.field_9440, Tags.Biomes.IS_HOT_OVERWORLD, Tags.Biomes.IS_WET_OVERWORLD, Tags.Biomes.IS_RARE);
		tag(BiomeKeys.field_29218, Tags.Biomes.IS_CAVE, Tags.Biomes.IS_LUSH, Tags.Biomes.IS_WET_OVERWORLD);
		tag(BiomeKeys.field_28107, Tags.Biomes.IS_CAVE, Tags.Biomes.IS_SPARSE_OVERWORLD);
		tag(BiomeKeys.field_22076, Tags.Biomes.IS_HOT_NETHER, Tags.Biomes.IS_DRY_NETHER);
		tag(BiomeKeys.field_22077, Tags.Biomes.IS_HOT_NETHER, Tags.Biomes.IS_DRY_NETHER);
		tag(BiomeKeys.field_22075, Tags.Biomes.IS_HOT_NETHER, Tags.Biomes.IS_DRY_NETHER);
		tag(BiomeKeys.field_23859, Tags.Biomes.IS_HOT_NETHER, Tags.Biomes.IS_DRY_NETHER);
		tag(BiomeKeys.field_38748, Tags.Biomes.IS_WET_OVERWORLD, Tags.Biomes.IS_HOT_OVERWORLD, Tags.Biomes.IS_SWAMP);
		tag(BiomeKeys.field_37543, Tags.Biomes.IS_CAVE, Tags.Biomes.IS_RARE, Tags.Biomes.IS_SPOOKY);

		getOrCreateTagBuilder(Tags.Biomes.IS_HOT).addTag(Tags.Biomes.IS_HOT_OVERWORLD).addTag(Tags.Biomes.IS_HOT_NETHER).addOptionalTag(Tags.Biomes.IS_HOT_END.id());
		getOrCreateTagBuilder(Tags.Biomes.IS_COLD).addTag(Tags.Biomes.IS_COLD_OVERWORLD).addOptionalTag(Tags.Biomes.IS_COLD_NETHER.id()).addTag(Tags.Biomes.IS_COLD_END);
		getOrCreateTagBuilder(Tags.Biomes.IS_SPARSE).addTag(Tags.Biomes.IS_SPARSE_OVERWORLD).addOptionalTag(Tags.Biomes.IS_SPARSE_NETHER.id()).addOptionalTag(Tags.Biomes.IS_SPARSE_END.id());
		getOrCreateTagBuilder(Tags.Biomes.IS_DENSE).addTag(Tags.Biomes.IS_DENSE_OVERWORLD).addOptionalTag(Tags.Biomes.IS_DENSE_NETHER.id()).addOptionalTag(Tags.Biomes.IS_DENSE_END.id());
		getOrCreateTagBuilder(Tags.Biomes.IS_WET).addTag(Tags.Biomes.IS_WET_OVERWORLD).addOptionalTag(Tags.Biomes.IS_WET_NETHER.id()).addOptionalTag(Tags.Biomes.IS_WET_END.id());
		getOrCreateTagBuilder(Tags.Biomes.IS_DRY).addTag(Tags.Biomes.IS_DRY_OVERWORLD).addTag(Tags.Biomes.IS_DRY_NETHER).addTag(Tags.Biomes.IS_DRY_END);

		getOrCreateTagBuilder(Tags.Biomes.IS_WATER).forceAddTag(BiomeTags.field_36509).forceAddTag(BiomeTags.field_36511); // force because it thinks they don't exist
		getOrCreateTagBuilder(Tags.Biomes.IS_MOUNTAIN).addTag(Tags.Biomes.IS_PEAK).addTag(Tags.Biomes.IS_SLOPE);
		getOrCreateTagBuilder(Tags.Biomes.IS_UNDERGROUND).addTag(Tags.Biomes.IS_CAVE);
	}

	@SafeVarargs
	private void tag(RegistryKey<Biome> biome, TagKey<Biome>... tags) {
		for (TagKey<Biome> key : tags) {
			getOrCreateTagBuilder(key).add(biome);
		}
	}

	public FabricTagBuilder getOrCreateTagBuilder(TagKey<Biome> tag) {
		return getOrCreateTagBuilder(tag);
	}
}

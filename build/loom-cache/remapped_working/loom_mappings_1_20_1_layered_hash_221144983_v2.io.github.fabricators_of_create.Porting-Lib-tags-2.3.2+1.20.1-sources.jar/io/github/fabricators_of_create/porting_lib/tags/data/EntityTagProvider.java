package io.github.fabricators_of_create.porting_lib.tags.data;

import java.util.concurrent.CompletableFuture;

import io.github.fabricators_of_create.porting_lib.tags.Tags;
import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricTagProvider;
import net.minecraft.entity.EntityType;
import net.minecraft.registry.RegistryWrapper;

public class EntityTagProvider extends FabricTagProvider.EntityTypeTagProvider {
	public EntityTagProvider(FabricDataOutput output, CompletableFuture<RegistryWrapper.WrapperLookup> registriesFuture) {
		super(output, registriesFuture);
	}

	@Override
	protected void configure(RegistryWrapper.WrapperLookup arg) {
		getOrCreateTagBuilder(Tags.EntityTypes.BOSSES).add(EntityType.field_6116, EntityType.field_6119);
	}
}

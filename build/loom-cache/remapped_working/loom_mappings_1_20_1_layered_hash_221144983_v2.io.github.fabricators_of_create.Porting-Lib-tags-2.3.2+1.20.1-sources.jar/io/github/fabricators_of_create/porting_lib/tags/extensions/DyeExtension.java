package io.github.fabricators_of_create.porting_lib.tags.extensions;

import net.minecraft.item.Item;
import net.minecraft.registry.tag.TagKey;

public interface DyeExtension {
	default TagKey<Item> getTag() {
		return null;
	}
}

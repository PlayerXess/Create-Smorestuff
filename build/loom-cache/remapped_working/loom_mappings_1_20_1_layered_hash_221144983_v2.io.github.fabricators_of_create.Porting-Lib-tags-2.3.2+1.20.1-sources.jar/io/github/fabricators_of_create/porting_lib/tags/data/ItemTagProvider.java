package io.github.fabricators_of_create.porting_lib.tags.data;

import java.util.Locale;
import java.util.concurrent.CompletableFuture;
import java.util.function.Consumer;

import io.github.fabricators_of_create.porting_lib.tags.Tags;
import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricTagProvider;
import net.minecraft.block.Block;
import net.minecraft.item.Item;
import net.minecraft.item.Items;
import net.minecraft.registry.Registries;
import net.minecraft.registry.RegistryWrapper;
import net.minecraft.registry.tag.TagKey;
import net.minecraft.util.DyeColor;
import net.minecraft.util.Identifier;

public class ItemTagProvider extends FabricTagProvider.ItemTagProvider {
	public ItemTagProvider(FabricDataOutput output, CompletableFuture<RegistryWrapper.WrapperLookup> registriesFuture, BlockTagProvider blockTags) {
		super(output, registriesFuture, blockTags);
	}

	@Override
	protected void configure(RegistryWrapper.WrapperLookup arg) {
		copy(Tags.Blocks.BARRELS, Tags.Items.BARRELS);
		copy(Tags.Blocks.BARRELS_WOODEN, Tags.Items.BARRELS_WOODEN);
		getOrCreateTagBuilder(Tags.Items.BONES).add(Items.field_8606);
		copy(Tags.Blocks.BOOKSHELVES, Tags.Items.BOOKSHELVES);
		copy(Tags.Blocks.CHESTS, Tags.Items.CHESTS);
		copy(Tags.Blocks.CHESTS_ENDER, Tags.Items.CHESTS_ENDER);
		copy(Tags.Blocks.CHESTS_TRAPPED, Tags.Items.CHESTS_TRAPPED);
		copy(Tags.Blocks.CHESTS_WOODEN, Tags.Items.CHESTS_WOODEN);
		copy(Tags.Blocks.COBBLESTONE, Tags.Items.COBBLESTONE);
		copy(Tags.Blocks.COBBLESTONE_NORMAL, Tags.Items.COBBLESTONE_NORMAL);
		copy(Tags.Blocks.COBBLESTONE_INFESTED, Tags.Items.COBBLESTONE_INFESTED);
		copy(Tags.Blocks.COBBLESTONE_MOSSY, Tags.Items.COBBLESTONE_MOSSY);
		copy(Tags.Blocks.COBBLESTONE_DEEPSLATE, Tags.Items.COBBLESTONE_DEEPSLATE);
		getOrCreateTagBuilder(Tags.Items.CROPS).addTag(Tags.Items.CROPS_BEETROOT).addTag(Tags.Items.CROPS_CARROT).addTag(Tags.Items.CROPS_NETHER_WART).addTag(Tags.Items.CROPS_POTATO).addTag(Tags.Items.CROPS_WHEAT);
		getOrCreateTagBuilder(Tags.Items.CROPS_BEETROOT).add(Items.field_8186);
		getOrCreateTagBuilder(Tags.Items.CROPS_CARROT).add(Items.field_8179);
		getOrCreateTagBuilder(Tags.Items.CROPS_NETHER_WART).add(Items.field_8790);
		getOrCreateTagBuilder(Tags.Items.CROPS_POTATO).add(Items.field_8567);
		getOrCreateTagBuilder(Tags.Items.CROPS_WHEAT).add(Items.field_8861);
		getOrCreateTagBuilder(Tags.Items.DUSTS).addTag(Tags.Items.DUSTS_GLOWSTONE).addTag(Tags.Items.DUSTS_PRISMARINE).addTag(Tags.Items.DUSTS_REDSTONE);
		getOrCreateTagBuilder(Tags.Items.DUSTS_GLOWSTONE).add(Items.field_8601);
		getOrCreateTagBuilder(Tags.Items.DUSTS_PRISMARINE).add(Items.field_8662);
		getOrCreateTagBuilder(Tags.Items.DUSTS_REDSTONE).add(Items.field_8725);
		addColored(getOrCreateTagBuilder(Tags.Items.DYES)::addTag, Tags.Items.DYES, "{color}_dye");
		getOrCreateTagBuilder(Tags.Items.EGGS).add(Items.field_8803);
		getOrCreateTagBuilder(Tags.Items.ENCHANTING_FUELS).addTag(Tags.Items.GEMS_LAPIS);
		copy(Tags.Blocks.END_STONES, Tags.Items.END_STONES);
		getOrCreateTagBuilder(Tags.Items.ENDER_PEARLS).add(Items.field_8634);
		getOrCreateTagBuilder(Tags.Items.FEATHERS).add(Items.field_8153);
		copy(Tags.Blocks.FENCE_GATES, Tags.Items.FENCE_GATES);
		copy(Tags.Blocks.FENCE_GATES_WOODEN, Tags.Items.FENCE_GATES_WOODEN);
		copy(Tags.Blocks.FENCES, Tags.Items.FENCES);
		copy(Tags.Blocks.FENCES_NETHER_BRICK, Tags.Items.FENCES_NETHER_BRICK);
		copy(Tags.Blocks.FENCES_WOODEN, Tags.Items.FENCES_WOODEN);
		getOrCreateTagBuilder(Tags.Items.GEMS).addTag(Tags.Items.GEMS_AMETHYST).addTag(Tags.Items.GEMS_DIAMOND).addTag(Tags.Items.GEMS_EMERALD).addTag(Tags.Items.GEMS_LAPIS).addTag(Tags.Items.GEMS_PRISMARINE).addTag(Tags.Items.GEMS_QUARTZ);
		getOrCreateTagBuilder(Tags.Items.GEMS_AMETHYST).add(Items.field_27063);
		getOrCreateTagBuilder(Tags.Items.GEMS_DIAMOND).add(Items.field_8477);
		getOrCreateTagBuilder(Tags.Items.GEMS_EMERALD).add(Items.field_8687);
		getOrCreateTagBuilder(Tags.Items.GEMS_LAPIS).add(Items.field_8759);
		getOrCreateTagBuilder(Tags.Items.GEMS_PRISMARINE).add(Items.field_8434);
		getOrCreateTagBuilder(Tags.Items.GEMS_QUARTZ).add(Items.field_8155);
		copy(Tags.Blocks.GLASS, Tags.Items.GLASS);
		copy(Tags.Blocks.GLASS_TINTED, Tags.Items.GLASS_TINTED);
		copy(Tags.Blocks.GLASS_SILICA, Tags.Items.GLASS_SILICA);
		copyColored(Tags.Blocks.GLASS, Tags.Items.GLASS);
		copy(Tags.Blocks.GLASS_PANES, Tags.Items.GLASS_PANES);
		copyColored(Tags.Blocks.GLASS_PANES, Tags.Items.GLASS_PANES);
		copy(Tags.Blocks.GRAVEL, Tags.Items.GRAVEL);
		getOrCreateTagBuilder(Tags.Items.GUNPOWDER).add(Items.field_8054);
		getOrCreateTagBuilder(Tags.Items.HEADS).add(Items.CREEPER_HEAD, Items.DRAGON_HEAD, Items.PLAYER_HEAD, Items.SKELETON_SKULL, Items.WITHER_SKELETON_SKULL, Items.ZOMBIE_HEAD);
		getOrCreateTagBuilder(Tags.Items.INGOTS).addTag(Tags.Items.INGOTS_BRICK).addTag(Tags.Items.INGOTS_COPPER).addTag(Tags.Items.INGOTS_GOLD).addTag(Tags.Items.INGOTS_IRON).addTag(Tags.Items.INGOTS_NETHERITE).addTag(Tags.Items.INGOTS_NETHER_BRICK);
		getOrCreateTagBuilder(Tags.Items.INGOTS_BRICK).add(Items.field_8621);
		getOrCreateTagBuilder(Tags.Items.INGOTS_COPPER).add(Items.field_27022);
		getOrCreateTagBuilder(Tags.Items.INGOTS_GOLD).add(Items.field_8695);
		getOrCreateTagBuilder(Tags.Items.INGOTS_IRON).add(Items.field_8620);
		getOrCreateTagBuilder(Tags.Items.INGOTS_NETHERITE).add(Items.field_22020);
		getOrCreateTagBuilder(Tags.Items.INGOTS_NETHER_BRICK).add(Items.field_8729);
		getOrCreateTagBuilder(Tags.Items.LEATHER).add(Items.field_8745);
		getOrCreateTagBuilder(Tags.Items.MUSHROOMS).add(Items.BROWN_MUSHROOM, Items.RED_MUSHROOM);
		getOrCreateTagBuilder(Tags.Items.NETHER_STARS).add(Items.field_8137);
		copy(Tags.Blocks.NETHERRACK, Tags.Items.NETHERRACK);
		getOrCreateTagBuilder(Tags.Items.NUGGETS).addTag(Tags.Items.NUGGETS_IRON).addTag(Tags.Items.NUGGETS_GOLD);
		getOrCreateTagBuilder(Tags.Items.NUGGETS_IRON).add(Items.field_8675);
		getOrCreateTagBuilder(Tags.Items.NUGGETS_GOLD).add(Items.field_8397);
		copy(Tags.Blocks.OBSIDIAN, Tags.Items.OBSIDIAN);
		copy(Tags.Blocks.ORE_BEARING_GROUND_DEEPSLATE, Tags.Items.ORE_BEARING_GROUND_DEEPSLATE);
		copy(Tags.Blocks.ORE_BEARING_GROUND_NETHERRACK, Tags.Items.ORE_BEARING_GROUND_NETHERRACK);
		copy(Tags.Blocks.ORE_BEARING_GROUND_STONE, Tags.Items.ORE_BEARING_GROUND_STONE);
		copy(Tags.Blocks.ORE_RATES_DENSE, Tags.Items.ORE_RATES_DENSE);
		copy(Tags.Blocks.ORE_RATES_SINGULAR, Tags.Items.ORE_RATES_SINGULAR);
		copy(Tags.Blocks.ORE_RATES_SPARSE, Tags.Items.ORE_RATES_SPARSE);
		copy(Tags.Blocks.ORES, Tags.Items.ORES);
		copy(Tags.Blocks.ORES_COAL, Tags.Items.ORES_COAL);
		copy(Tags.Blocks.ORES_COPPER, Tags.Items.ORES_COPPER);
		copy(Tags.Blocks.ORES_DIAMOND, Tags.Items.ORES_DIAMOND);
		copy(Tags.Blocks.ORES_EMERALD, Tags.Items.ORES_EMERALD);
		copy(Tags.Blocks.ORES_GOLD, Tags.Items.ORES_GOLD);
		copy(Tags.Blocks.ORES_IRON, Tags.Items.ORES_IRON);
		copy(Tags.Blocks.ORES_LAPIS, Tags.Items.ORES_LAPIS);
		copy(Tags.Blocks.ORES_QUARTZ, Tags.Items.ORES_QUARTZ);
		copy(Tags.Blocks.ORES_REDSTONE, Tags.Items.ORES_REDSTONE);
		copy(Tags.Blocks.ORES_NETHERITE_SCRAP, Tags.Items.ORES_NETHERITE_SCRAP);
		copy(Tags.Blocks.ORES_IN_GROUND_DEEPSLATE, Tags.Items.ORES_IN_GROUND_DEEPSLATE);
		copy(Tags.Blocks.ORES_IN_GROUND_NETHERRACK, Tags.Items.ORES_IN_GROUND_NETHERRACK);
		copy(Tags.Blocks.ORES_IN_GROUND_STONE, Tags.Items.ORES_IN_GROUND_STONE);
		getOrCreateTagBuilder(Tags.Items.RAW_MATERIALS).addTag(Tags.Items.RAW_MATERIALS_COPPER).addTag(Tags.Items.RAW_MATERIALS_GOLD).addTag(Tags.Items.RAW_MATERIALS_IRON);
		getOrCreateTagBuilder(Tags.Items.RAW_MATERIALS_COPPER).add(Items.field_33401);
		getOrCreateTagBuilder(Tags.Items.RAW_MATERIALS_GOLD).add(Items.field_33402);
		getOrCreateTagBuilder(Tags.Items.RAW_MATERIALS_IRON).add(Items.field_33400);
		getOrCreateTagBuilder(Tags.Items.RODS).addTag(Tags.Items.RODS_BLAZE).addTag(Tags.Items.RODS_WOODEN);
		getOrCreateTagBuilder(Tags.Items.RODS_BLAZE).add(Items.field_8894);
		getOrCreateTagBuilder(Tags.Items.RODS_WOODEN).add(Items.field_8600);
		copy(Tags.Blocks.SAND, Tags.Items.SAND);
		copy(Tags.Blocks.SAND_COLORLESS, Tags.Items.SAND_COLORLESS);
		copy(Tags.Blocks.SAND_RED, Tags.Items.SAND_RED);
		copy(Tags.Blocks.SANDSTONE, Tags.Items.SANDSTONE);
		getOrCreateTagBuilder(Tags.Items.SEEDS).addTag(Tags.Items.SEEDS_BEETROOT).addTag(Tags.Items.SEEDS_MELON).addTag(Tags.Items.SEEDS_PUMPKIN).addTag(Tags.Items.SEEDS_WHEAT);
		getOrCreateTagBuilder(Tags.Items.SEEDS_BEETROOT).add(Items.field_8309);
		getOrCreateTagBuilder(Tags.Items.SEEDS_MELON).add(Items.field_8188);
		getOrCreateTagBuilder(Tags.Items.SEEDS_PUMPKIN).add(Items.field_8706);
		getOrCreateTagBuilder(Tags.Items.SEEDS_WHEAT).add(Items.field_8317);
		getOrCreateTagBuilder(Tags.Items.SHEARS).add(Items.field_8868);
		getOrCreateTagBuilder(Tags.Items.SLIMEBALLS).add(Items.field_8777);
		copy(Tags.Blocks.STAINED_GLASS, Tags.Items.STAINED_GLASS);
		copy(Tags.Blocks.STAINED_GLASS_PANES, Tags.Items.STAINED_GLASS_PANES);
		copy(Tags.Blocks.STONE, Tags.Items.STONE);
		copy(Tags.Blocks.STORAGE_BLOCKS, Tags.Items.STORAGE_BLOCKS);
		copy(Tags.Blocks.STORAGE_BLOCKS_AMETHYST, Tags.Items.STORAGE_BLOCKS_AMETHYST);
		copy(Tags.Blocks.STORAGE_BLOCKS_COAL, Tags.Items.STORAGE_BLOCKS_COAL);
		copy(Tags.Blocks.STORAGE_BLOCKS_COPPER, Tags.Items.STORAGE_BLOCKS_COPPER);
		copy(Tags.Blocks.STORAGE_BLOCKS_DIAMOND, Tags.Items.STORAGE_BLOCKS_DIAMOND);
		copy(Tags.Blocks.STORAGE_BLOCKS_EMERALD, Tags.Items.STORAGE_BLOCKS_EMERALD);
		copy(Tags.Blocks.STORAGE_BLOCKS_GOLD, Tags.Items.STORAGE_BLOCKS_GOLD);
		copy(Tags.Blocks.STORAGE_BLOCKS_IRON, Tags.Items.STORAGE_BLOCKS_IRON);
		copy(Tags.Blocks.STORAGE_BLOCKS_LAPIS, Tags.Items.STORAGE_BLOCKS_LAPIS);
		copy(Tags.Blocks.STORAGE_BLOCKS_QUARTZ, Tags.Items.STORAGE_BLOCKS_QUARTZ);
		copy(Tags.Blocks.STORAGE_BLOCKS_REDSTONE, Tags.Items.STORAGE_BLOCKS_REDSTONE);
		copy(Tags.Blocks.STORAGE_BLOCKS_RAW_COPPER, Tags.Items.STORAGE_BLOCKS_RAW_COPPER);
		copy(Tags.Blocks.STORAGE_BLOCKS_RAW_GOLD, Tags.Items.STORAGE_BLOCKS_RAW_GOLD);
		copy(Tags.Blocks.STORAGE_BLOCKS_RAW_IRON, Tags.Items.STORAGE_BLOCKS_RAW_IRON);
		copy(Tags.Blocks.STORAGE_BLOCKS_NETHERITE, Tags.Items.STORAGE_BLOCKS_NETHERITE);
		getOrCreateTagBuilder(Tags.Items.STRING).add(Items.field_8276);
		getOrCreateTagBuilder(Tags.Items.TOOLS_SWORDS).add(Items.field_8091, Items.field_8528, Items.field_8371, Items.field_8845, Items.field_8802, Items.field_22022);
		getOrCreateTagBuilder(Tags.Items.TOOLS_AXES).add(Items.field_8406, Items.field_8062, Items.field_8475, Items.field_8825, Items.field_8556, Items.field_22025);
		getOrCreateTagBuilder(Tags.Items.TOOLS_PICKAXES).add(Items.field_8647, Items.field_8387, Items.field_8403, Items.field_8335, Items.field_8377, Items.field_22024);
		getOrCreateTagBuilder(Tags.Items.TOOLS_SHOVELS).add(Items.field_8876, Items.field_8776, Items.field_8699, Items.field_8322, Items.field_8250, Items.field_22023);
		getOrCreateTagBuilder(Tags.Items.TOOLS_HOES).add(Items.field_8167, Items.field_8431, Items.field_8609, Items.field_8303, Items.field_8527, Items.field_22026);
		getOrCreateTagBuilder(Tags.Items.TOOLS_SHIELDS).add(Items.field_8255);
		getOrCreateTagBuilder(Tags.Items.TOOLS_BOWS).add(Items.field_8102);
		getOrCreateTagBuilder(Tags.Items.TOOLS_CROSSBOWS).add(Items.field_8399);
		getOrCreateTagBuilder(Tags.Items.TOOLS_FISHING_RODS).add(Items.field_8378);
		getOrCreateTagBuilder(Tags.Items.TOOLS_TRIDENTS).add(Items.field_8547);
		getOrCreateTagBuilder(Tags.Items.TOOLS).addTag(Tags.Items.TOOLS_SWORDS).addTag(Tags.Items.TOOLS_AXES).addTag(Tags.Items.TOOLS_PICKAXES).addTag(Tags.Items.TOOLS_SHOVELS).addTag(Tags.Items.TOOLS_HOES).addTag(Tags.Items.TOOLS_SHIELDS).addTag(Tags.Items.TOOLS_BOWS).addTag(Tags.Items.TOOLS_CROSSBOWS).addTag(Tags.Items.TOOLS_FISHING_RODS).addTag(Tags.Items.TOOLS_TRIDENTS);
		getOrCreateTagBuilder(Tags.Items.ARMORS_HELMETS).add(Items.field_8267, Items.field_8090, Items.field_8283, Items.field_8743, Items.field_8862, Items.field_8805, Items.field_22027);
		getOrCreateTagBuilder(Tags.Items.ARMORS_CHESTPLATES).add(Items.field_8577, Items.field_8873, Items.field_8523, Items.field_8678, Items.field_8058, Items.field_22028);
		getOrCreateTagBuilder(Tags.Items.ARMORS_LEGGINGS).add(Items.field_8570, Items.field_8218, Items.field_8396, Items.field_8416, Items.field_8348, Items.field_22029);
		getOrCreateTagBuilder(Tags.Items.ARMORS_BOOTS).add(Items.field_8370, Items.field_8313, Items.field_8660, Items.field_8753, Items.field_8285, Items.field_22030);
		getOrCreateTagBuilder(Tags.Items.ARMORS).addTag(Tags.Items.ARMORS_HELMETS).addTag(Tags.Items.ARMORS_CHESTPLATES).addTag(Tags.Items.ARMORS_LEGGINGS).addTag(Tags.Items.ARMORS_BOOTS);
	}

	private void addColored(Consumer<TagKey<Item>> consumer, TagKey<Item> group, String pattern) {
		String prefix = group.id().getPath().toUpperCase(Locale.ENGLISH) + '_';
		for (DyeColor color : DyeColor.values()) {
			Identifier key = new Identifier("minecraft", pattern.replace("{color}", color.getName()));
			TagKey<Item> tag = getForgeItemTag(prefix + color.getName());
			Item item = Registries.ITEM.get(key);
			if (item == null || item == Items.AIR)
				throw new IllegalStateException("Unknown vanilla item: " + key.toString());
			getOrCreateTagBuilder(tag).add(item);
			consumer.accept(tag);
		}
	}

	private void copyColored(TagKey<Block> blockGroup, TagKey<Item> itemGroup) {
		String blockPre = blockGroup.id().getPath().toUpperCase(Locale.ENGLISH) + '_';
		String itemPre = itemGroup.id().getPath().toUpperCase(Locale.ENGLISH) + '_';
		for (DyeColor color : DyeColor.values()) {
			TagKey<Block> from = getForgeBlockTag(blockPre + color.getName());
			TagKey<Item> to = getForgeItemTag(itemPre + color.getName());
			copy(from, to);
		}
		copy(getForgeBlockTag(blockPre + "colorless"), getForgeItemTag(itemPre + "colorless"));
	}

	@SuppressWarnings("unchecked")
	private TagKey<Block> getForgeBlockTag(String name) {
		try {
			name = name.toUpperCase(Locale.ENGLISH).replace("_BLOCKS", "");;
			return (TagKey<Block>) Tags.Blocks.class.getDeclaredField(name).get(null);
		} catch (IllegalArgumentException | IllegalAccessException | NoSuchFieldException | SecurityException e) {
			throw new IllegalStateException(Tags.Blocks.class.getName() + " is missing tag name: " + name);
		}
	}

	@SuppressWarnings("unchecked")
	private TagKey<Item> getForgeItemTag(String name) {
		try {
			name = name.toUpperCase(Locale.ENGLISH).replace("_BLOCKS", "");;
			return (TagKey<Item>) Tags.Items.class.getDeclaredField(name).get(null);
		} catch (IllegalArgumentException | IllegalAccessException | NoSuchFieldException | SecurityException e) {
			throw new IllegalStateException(Tags.Items.class.getName() + " is missing tag name: " + name);
		}
	}

	public FabricTagBuilder getOrCreateTagBuilder(TagKey<Item> tag) {
		return getOrCreateTagBuilder(tag);
	}
}

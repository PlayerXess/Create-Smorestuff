package io.github.fabricators_of_create.porting_lib.tags.data;

import static io.github.fabricators_of_create.porting_lib.tags.Tags.Blocks.BARRELS;
import static io.github.fabricators_of_create.porting_lib.tags.Tags.Blocks.BARRELS_WOODEN;
import static io.github.fabricators_of_create.porting_lib.tags.Tags.Blocks.CHESTS;
import static io.github.fabricators_of_create.porting_lib.tags.Tags.Blocks.CHESTS_ENDER;
import static io.github.fabricators_of_create.porting_lib.tags.Tags.Blocks.CHESTS_TRAPPED;
import static io.github.fabricators_of_create.porting_lib.tags.Tags.Blocks.CHESTS_WOODEN;
import static io.github.fabricators_of_create.porting_lib.tags.Tags.Blocks.COBBLESTONE;
import static io.github.fabricators_of_create.porting_lib.tags.Tags.Blocks.COBBLESTONE_DEEPSLATE;
import static io.github.fabricators_of_create.porting_lib.tags.Tags.Blocks.COBBLESTONE_INFESTED;
import static io.github.fabricators_of_create.porting_lib.tags.Tags.Blocks.COBBLESTONE_MOSSY;
import static io.github.fabricators_of_create.porting_lib.tags.Tags.Blocks.COBBLESTONE_NORMAL;
import static io.github.fabricators_of_create.porting_lib.tags.Tags.Blocks.ENDERMAN_PLACE_ON_BLACKLIST;
import static io.github.fabricators_of_create.porting_lib.tags.Tags.Blocks.END_STONES;
import static io.github.fabricators_of_create.porting_lib.tags.Tags.Blocks.FENCES;
import static io.github.fabricators_of_create.porting_lib.tags.Tags.Blocks.FENCES_NETHER_BRICK;
import static io.github.fabricators_of_create.porting_lib.tags.Tags.Blocks.FENCES_WOODEN;
import static io.github.fabricators_of_create.porting_lib.tags.Tags.Blocks.FENCE_GATES;
import static io.github.fabricators_of_create.porting_lib.tags.Tags.Blocks.FENCE_GATES_WOODEN;
import static io.github.fabricators_of_create.porting_lib.tags.Tags.Blocks.GLASS;
import static io.github.fabricators_of_create.porting_lib.tags.Tags.Blocks.GLASS_COLORLESS;
import static io.github.fabricators_of_create.porting_lib.tags.Tags.Blocks.GLASS_PANES;
import static io.github.fabricators_of_create.porting_lib.tags.Tags.Blocks.GLASS_PANES_COLORLESS;
import static io.github.fabricators_of_create.porting_lib.tags.Tags.Blocks.GLASS_SILICA;
import static io.github.fabricators_of_create.porting_lib.tags.Tags.Blocks.GLASS_TINTED;
import static io.github.fabricators_of_create.porting_lib.tags.Tags.Blocks.GRAVEL;
import static io.github.fabricators_of_create.porting_lib.tags.Tags.Blocks.NETHERRACK;
import static io.github.fabricators_of_create.porting_lib.tags.Tags.Blocks.OBSIDIAN;
import static io.github.fabricators_of_create.porting_lib.tags.Tags.Blocks.ORES;
import static io.github.fabricators_of_create.porting_lib.tags.Tags.Blocks.ORES_COAL;
import static io.github.fabricators_of_create.porting_lib.tags.Tags.Blocks.ORES_COPPER;
import static io.github.fabricators_of_create.porting_lib.tags.Tags.Blocks.ORES_DIAMOND;
import static io.github.fabricators_of_create.porting_lib.tags.Tags.Blocks.ORES_EMERALD;
import static io.github.fabricators_of_create.porting_lib.tags.Tags.Blocks.ORES_GOLD;
import static io.github.fabricators_of_create.porting_lib.tags.Tags.Blocks.ORES_IN_GROUND_DEEPSLATE;
import static io.github.fabricators_of_create.porting_lib.tags.Tags.Blocks.ORES_IN_GROUND_NETHERRACK;
import static io.github.fabricators_of_create.porting_lib.tags.Tags.Blocks.ORES_IN_GROUND_STONE;
import static io.github.fabricators_of_create.porting_lib.tags.Tags.Blocks.ORES_IRON;
import static io.github.fabricators_of_create.porting_lib.tags.Tags.Blocks.ORES_LAPIS;
import static io.github.fabricators_of_create.porting_lib.tags.Tags.Blocks.ORES_NETHERITE_SCRAP;
import static io.github.fabricators_of_create.porting_lib.tags.Tags.Blocks.ORES_QUARTZ;
import static io.github.fabricators_of_create.porting_lib.tags.Tags.Blocks.ORES_REDSTONE;
import static io.github.fabricators_of_create.porting_lib.tags.Tags.Blocks.ORE_BEARING_GROUND_DEEPSLATE;
import static io.github.fabricators_of_create.porting_lib.tags.Tags.Blocks.ORE_BEARING_GROUND_NETHERRACK;
import static io.github.fabricators_of_create.porting_lib.tags.Tags.Blocks.ORE_BEARING_GROUND_STONE;
import static io.github.fabricators_of_create.porting_lib.tags.Tags.Blocks.ORE_RATES_DENSE;
import static io.github.fabricators_of_create.porting_lib.tags.Tags.Blocks.ORE_RATES_SINGULAR;
import static io.github.fabricators_of_create.porting_lib.tags.Tags.Blocks.ORE_RATES_SPARSE;
import static io.github.fabricators_of_create.porting_lib.tags.Tags.Blocks.SAND;
import static io.github.fabricators_of_create.porting_lib.tags.Tags.Blocks.SANDSTONE;
import static io.github.fabricators_of_create.porting_lib.tags.Tags.Blocks.SAND_COLORLESS;
import static io.github.fabricators_of_create.porting_lib.tags.Tags.Blocks.SAND_RED;
import static io.github.fabricators_of_create.porting_lib.tags.Tags.Blocks.STAINED_GLASS;
import static io.github.fabricators_of_create.porting_lib.tags.Tags.Blocks.STAINED_GLASS_PANES;
import static io.github.fabricators_of_create.porting_lib.tags.Tags.Blocks.STONE;
import static io.github.fabricators_of_create.porting_lib.tags.Tags.Blocks.STORAGE_BLOCKS;
import static io.github.fabricators_of_create.porting_lib.tags.Tags.Blocks.STORAGE_BLOCKS_AMETHYST;
import static io.github.fabricators_of_create.porting_lib.tags.Tags.Blocks.STORAGE_BLOCKS_COAL;
import static io.github.fabricators_of_create.porting_lib.tags.Tags.Blocks.STORAGE_BLOCKS_COPPER;
import static io.github.fabricators_of_create.porting_lib.tags.Tags.Blocks.STORAGE_BLOCKS_DIAMOND;
import static io.github.fabricators_of_create.porting_lib.tags.Tags.Blocks.STORAGE_BLOCKS_EMERALD;
import static io.github.fabricators_of_create.porting_lib.tags.Tags.Blocks.STORAGE_BLOCKS_GOLD;
import static io.github.fabricators_of_create.porting_lib.tags.Tags.Blocks.STORAGE_BLOCKS_IRON;
import static io.github.fabricators_of_create.porting_lib.tags.Tags.Blocks.STORAGE_BLOCKS_LAPIS;
import static io.github.fabricators_of_create.porting_lib.tags.Tags.Blocks.STORAGE_BLOCKS_NETHERITE;
import static io.github.fabricators_of_create.porting_lib.tags.Tags.Blocks.STORAGE_BLOCKS_QUARTZ;
import static io.github.fabricators_of_create.porting_lib.tags.Tags.Blocks.STORAGE_BLOCKS_RAW_COPPER;
import static io.github.fabricators_of_create.porting_lib.tags.Tags.Blocks.STORAGE_BLOCKS_RAW_GOLD;
import static io.github.fabricators_of_create.porting_lib.tags.Tags.Blocks.STORAGE_BLOCKS_RAW_IRON;
import static io.github.fabricators_of_create.porting_lib.tags.Tags.Blocks.STORAGE_BLOCKS_REDSTONE;

import java.util.Locale;
import java.util.concurrent.CompletableFuture;
import java.util.function.Consumer;

import io.github.fabricators_of_create.porting_lib.tags.Tags;
import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricTagProvider;
import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.registry.Registries;
import net.minecraft.registry.RegistryWrapper;
import net.minecraft.registry.tag.BlockTags;
import net.minecraft.registry.tag.TagKey;
import net.minecraft.util.DyeColor;
import net.minecraft.util.Identifier;

public class BlockTagProvider extends FabricTagProvider.BlockTagProvider {
	public BlockTagProvider(FabricDataOutput output, CompletableFuture<RegistryWrapper.WrapperLookup> registriesFuture) {
		super(output, registriesFuture);
	}

	@Override
	protected void configure(RegistryWrapper.WrapperLookup arg) {
		getOrCreateTagBuilder(BARRELS).addTag(BARRELS_WOODEN);
		getOrCreateTagBuilder(BARRELS_WOODEN).add(Blocks.field_16328);
		getOrCreateTagBuilder(CHESTS).addTag(CHESTS_ENDER).addTag(CHESTS_TRAPPED).addTag(CHESTS_WOODEN);
		getOrCreateTagBuilder(CHESTS_ENDER).add(Blocks.field_10443);
		getOrCreateTagBuilder(CHESTS_TRAPPED).add(Blocks.field_10380);
		getOrCreateTagBuilder(CHESTS_WOODEN).add(Blocks.field_10034, Blocks.field_10380);
		getOrCreateTagBuilder(COBBLESTONE).addTag(COBBLESTONE_NORMAL).addTag(COBBLESTONE_INFESTED).addTag(COBBLESTONE_MOSSY).addTag(COBBLESTONE_DEEPSLATE);
		getOrCreateTagBuilder(COBBLESTONE_NORMAL).add(Blocks.field_10445);
		getOrCreateTagBuilder(COBBLESTONE_INFESTED).add(Blocks.field_10492);
		getOrCreateTagBuilder(COBBLESTONE_MOSSY).add(Blocks.field_9989);
		getOrCreateTagBuilder(COBBLESTONE_DEEPSLATE).add(Blocks.field_29031);
		getOrCreateTagBuilder(END_STONES).add(Blocks.field_10471);
		getOrCreateTagBuilder(ENDERMAN_PLACE_ON_BLACKLIST);
		getOrCreateTagBuilder(FENCE_GATES).addTag(FENCE_GATES_WOODEN);
		getOrCreateTagBuilder(FENCE_GATES_WOODEN).add(Blocks.field_10188, Blocks.field_10291, Blocks.field_10513, Blocks.field_10041, Blocks.field_10457, Blocks.field_10196, Blocks.field_22096, Blocks.field_22097);
		getOrCreateTagBuilder(FENCES).addTag(FENCES_NETHER_BRICK).addTag(FENCES_WOODEN);
		getOrCreateTagBuilder(FENCES_NETHER_BRICK).add(Blocks.field_10364);
		getOrCreateTagBuilder(FENCES_WOODEN).forceAddTag(BlockTags.field_17619);
		getOrCreateTagBuilder(GLASS).addTag(GLASS_COLORLESS).addTag(STAINED_GLASS).addTag(GLASS_TINTED);
		getOrCreateTagBuilder(GLASS_COLORLESS).add(Blocks.field_10033);
		getOrCreateTagBuilder(GLASS_SILICA).add(Blocks.field_10033, Blocks.field_9997, Blocks.field_10060, Blocks.field_10073, Blocks.field_10248, Blocks.field_10555, Blocks.field_10357, Blocks.field_10271, Blocks.field_9996, Blocks.field_10157, Blocks.field_10574, Blocks.field_10227, Blocks.field_10317, Blocks.field_10399, Blocks.field_10272, Blocks.field_10087, Blocks.field_10049);
		getOrCreateTagBuilder(GLASS_TINTED).add(Blocks.field_27115);
		addColored(getOrCreateTagBuilder(STAINED_GLASS)::add, GLASS, "{color}_stained_glass");
		getOrCreateTagBuilder(GLASS_PANES).addTag(GLASS_PANES_COLORLESS).addTag(STAINED_GLASS_PANES);
		getOrCreateTagBuilder(GLASS_PANES_COLORLESS).add(Blocks.field_10285);
		addColored(getOrCreateTagBuilder(STAINED_GLASS_PANES)::add, GLASS_PANES, "{color}_stained_glass_pane");
		getOrCreateTagBuilder(GRAVEL).add(Blocks.field_10255);
		getOrCreateTagBuilder(NETHERRACK).add(Blocks.field_10515);
		getOrCreateTagBuilder(OBSIDIAN).add(Blocks.field_10540);
		getOrCreateTagBuilder(ORE_BEARING_GROUND_DEEPSLATE).add(Blocks.field_28888);
		getOrCreateTagBuilder(ORE_BEARING_GROUND_NETHERRACK).add(Blocks.field_10515);
		getOrCreateTagBuilder(ORE_BEARING_GROUND_STONE).add(Blocks.field_10340);
		getOrCreateTagBuilder(ORE_RATES_DENSE).add(Blocks.field_27120, Blocks.field_29221, Blocks.field_29028, Blocks.field_29030, Blocks.field_10090, Blocks.field_10080);
		getOrCreateTagBuilder(ORE_RATES_SINGULAR).add(Blocks.field_22109, Blocks.field_10418, Blocks.field_29219, Blocks.field_29029, Blocks.field_29220, Blocks.field_29026, Blocks.field_29027, Blocks.field_10442, Blocks.field_10013, Blocks.field_10571, Blocks.field_10212, Blocks.field_10213);
		getOrCreateTagBuilder(ORE_RATES_SPARSE).add(Blocks.field_23077);
		getOrCreateTagBuilder(ORES).addTag(ORES_COAL).addTag(ORES_COPPER).addTag(ORES_DIAMOND).addTag(ORES_EMERALD).addTag(ORES_GOLD).addTag(ORES_IRON).addTag(ORES_LAPIS).addTag(ORES_REDSTONE).addTag(ORES_QUARTZ).addTag(ORES_NETHERITE_SCRAP);
		getOrCreateTagBuilder(ORES_COAL).forceAddTag(BlockTags.field_29193);
		getOrCreateTagBuilder(ORES_COPPER).forceAddTag(BlockTags.field_29195);
		getOrCreateTagBuilder(ORES_DIAMOND).forceAddTag(BlockTags.field_28989);
		getOrCreateTagBuilder(ORES_EMERALD).forceAddTag(BlockTags.field_29194);
		getOrCreateTagBuilder(ORES_GOLD).forceAddTag(BlockTags.field_23062);
		getOrCreateTagBuilder(ORES_IRON).forceAddTag(BlockTags.field_28988);
		getOrCreateTagBuilder(ORES_LAPIS).forceAddTag(BlockTags.field_28991);
		getOrCreateTagBuilder(ORES_QUARTZ).add(Blocks.field_10213);
		getOrCreateTagBuilder(ORES_REDSTONE).forceAddTag(BlockTags.field_28990);
		getOrCreateTagBuilder(ORES_NETHERITE_SCRAP).add(Blocks.field_22109);
		getOrCreateTagBuilder(ORES_IN_GROUND_DEEPSLATE).add(Blocks.field_29219, Blocks.field_29221, Blocks.field_29029, Blocks.field_29220, Blocks.field_29026, Blocks.field_29027, Blocks.field_29028, Blocks.field_29030);
		getOrCreateTagBuilder(ORES_IN_GROUND_NETHERRACK).add(Blocks.field_23077, Blocks.field_10213);
		getOrCreateTagBuilder(ORES_IN_GROUND_STONE).add(Blocks.field_10418, Blocks.field_27120, Blocks.field_10442, Blocks.field_10013, Blocks.field_10571, Blocks.field_10212, Blocks.field_10090, Blocks.field_10080);
		getOrCreateTagBuilder(SAND).addTag(SAND_COLORLESS).addTag(SAND_RED);
		getOrCreateTagBuilder(SAND_COLORLESS).add(Blocks.field_10102);
		getOrCreateTagBuilder(SAND_RED).add(Blocks.field_10534);
		getOrCreateTagBuilder(SANDSTONE).add(Blocks.field_9979, Blocks.field_10361, Blocks.field_10292, Blocks.field_10467, Blocks.field_10344, Blocks.field_10518, Blocks.field_10117, Blocks.field_10483);
		getOrCreateTagBuilder(STONE).add(Blocks.field_10115, Blocks.field_10508, Blocks.field_10474, Blocks.field_10277, Blocks.field_10340, Blocks.field_10093, Blocks.field_10346, Blocks.field_10289, Blocks.field_28888, Blocks.field_28892, Blocks.field_29224, Blocks.field_27165);
		getOrCreateTagBuilder(STORAGE_BLOCKS).addTag(STORAGE_BLOCKS_AMETHYST).addTag(STORAGE_BLOCKS_COAL).addTag(STORAGE_BLOCKS_COPPER).addTag(STORAGE_BLOCKS_DIAMOND).addTag(STORAGE_BLOCKS_EMERALD).addTag(STORAGE_BLOCKS_GOLD).addTag(STORAGE_BLOCKS_IRON).addTag(STORAGE_BLOCKS_LAPIS).addTag(STORAGE_BLOCKS_QUARTZ).addTag(STORAGE_BLOCKS_RAW_COPPER).addTag(STORAGE_BLOCKS_RAW_GOLD).addTag(STORAGE_BLOCKS_RAW_IRON).addTag(STORAGE_BLOCKS_REDSTONE).addTag(STORAGE_BLOCKS_NETHERITE);
		getOrCreateTagBuilder(STORAGE_BLOCKS_AMETHYST).add(Blocks.field_27159);
		getOrCreateTagBuilder(STORAGE_BLOCKS_COAL).add(Blocks.field_10381);
		getOrCreateTagBuilder(STORAGE_BLOCKS_COPPER).add(Blocks.field_27119); // cut copper intentionally not included: #62
		getOrCreateTagBuilder(STORAGE_BLOCKS_DIAMOND).add(Blocks.field_10201);
		getOrCreateTagBuilder(STORAGE_BLOCKS_EMERALD).add(Blocks.field_10234);
		getOrCreateTagBuilder(STORAGE_BLOCKS_GOLD).add(Blocks.field_10205);
		getOrCreateTagBuilder(STORAGE_BLOCKS_IRON).add(Blocks.field_10085);
		getOrCreateTagBuilder(STORAGE_BLOCKS_LAPIS).add(Blocks.field_10441);
		getOrCreateTagBuilder(STORAGE_BLOCKS_QUARTZ).add(Blocks.field_10153);
		getOrCreateTagBuilder(STORAGE_BLOCKS_RAW_COPPER).add(Blocks.field_33509);
		getOrCreateTagBuilder(STORAGE_BLOCKS_RAW_GOLD).add(Blocks.field_33510);
		getOrCreateTagBuilder(STORAGE_BLOCKS_RAW_IRON).add(Blocks.field_33508);
		getOrCreateTagBuilder(STORAGE_BLOCKS_REDSTONE).add(Blocks.field_10002);
		getOrCreateTagBuilder(STORAGE_BLOCKS_NETHERITE).add(Blocks.field_22108);
	}

	private void addColored(Consumer<Block> consumer, TagKey<Block> group, String pattern) {
		String prefix = group.id().getPath().toUpperCase(Locale.ENGLISH) + '_';
		for (DyeColor color : DyeColor.values()) {
			Identifier key = new Identifier("minecraft", pattern.replace("{color}", color.getName()));
			TagKey<Block> tag = getForgeTag(prefix + color.getName());
			Block block = Registries.BLOCK.get(key);
			if (block == null || block == Blocks.field_10124)
				throw new IllegalStateException("Unknown vanilla block: " + key.toString());
			getOrCreateTagBuilder(tag).add(block);
			consumer.accept(block);
		}
	}

	@SuppressWarnings("unchecked")
	private TagKey<Block> getForgeTag(String name) {
		try {
			name = name.toUpperCase(Locale.ENGLISH).replace("_BLOCKS", "");
			return (TagKey<Block>) Tags.Blocks.class.getDeclaredField(name).get(null);
		} catch (IllegalArgumentException | IllegalAccessException | NoSuchFieldException | SecurityException e) {
			throw new IllegalStateException(Tags.Blocks.class.getName() + " is missing tag name: " + name);
		}
	}


	public FabricTagBuilder getOrCreateTagBuilder(TagKey<Block> tag) {
		return getOrCreateTagBuilder(tag);
	}
}

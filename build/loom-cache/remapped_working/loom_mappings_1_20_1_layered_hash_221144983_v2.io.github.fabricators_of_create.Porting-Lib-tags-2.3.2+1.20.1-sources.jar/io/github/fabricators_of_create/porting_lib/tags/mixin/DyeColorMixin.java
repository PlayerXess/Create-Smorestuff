package io.github.fabricators_of_create.porting_lib.tags.mixin;

import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import io.github.fabricators_of_create.porting_lib.tags.extensions.DyeExtension;
import net.minecraft.block.MapColor;
import net.minecraft.item.Item;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.registry.tag.TagKey;
import net.minecraft.util.DyeColor;
import net.minecraft.util.Identifier;

@Mixin(DyeColor.class)
public class DyeColorMixin implements DyeExtension {
	@Shadow
	@Final
	private String name;
	@Unique
	private TagKey<Item> tag;

	@Inject(method = "<init>", at = @At("TAIL"))
	public void addTag(String enumName, int enumIndex, int id, String name, int color, MapColor mapColor, int fireworkColor, int signColor, CallbackInfo ci) {
		tag = TagKey.of(RegistryKeys.field_41197, new Identifier("c", name + "_dyes"));
	}

	@Override
	public TagKey<Item> getTag() {
		return tag;
	}
}

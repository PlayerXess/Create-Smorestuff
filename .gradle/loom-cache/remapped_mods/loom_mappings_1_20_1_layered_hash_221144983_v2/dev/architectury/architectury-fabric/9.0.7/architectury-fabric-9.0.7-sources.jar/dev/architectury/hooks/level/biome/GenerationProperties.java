/*
 * This file is part of architectury.
 * Copyright (C) 2020, 2021, 2022 architectury
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 3 of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program; if not, write to the Free Software Foundation,
 * Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

package dev.architectury.hooks.level.biome;

import org.jetbrains.annotations.ApiStatus;

import java.util.List;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.world.gen.GenerationStep;
import net.minecraft.world.gen.carver.ConfiguredCarver;
import net.minecraft.world.gen.feature.PlacedFeature;

public interface GenerationProperties {
    Iterable<RegistryEntry<ConfiguredCarver<?>>> getCarvers(GenerationStep.Carver carving);
    
    Iterable<RegistryEntry<PlacedFeature>> getFeatures(GenerationStep.Feature decoration);
    
    List<Iterable<RegistryEntry<PlacedFeature>>> getFeatures();
    
    interface Mutable extends GenerationProperties {
        Mutable addFeature(GenerationStep.Feature decoration, RegistryEntry<PlacedFeature> feature);
        
        @ApiStatus.Experimental
        Mutable addFeature(GenerationStep.Feature decoration, RegistryKey<PlacedFeature> feature);
        
        Mutable addCarver(GenerationStep.Carver carving, RegistryEntry<ConfiguredCarver<?>> feature);
        
        @ApiStatus.Experimental
        Mutable addCarver(GenerationStep.Carver carving, RegistryKey<ConfiguredCarver<?>> feature);
        
        Mutable removeFeature(GenerationStep.Feature decoration, RegistryKey<PlacedFeature> feature);
        
        Mutable removeCarver(GenerationStep.Carver carving, RegistryKey<ConfiguredCarver<?>> feature);
    }
}

/*
 * This file is part of architectury.
 * Copyright (C) 2020, 2021, 2022 architectury
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 3 of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program; if not, write to the Free Software Foundation,
 * Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

package dev.architectury.hooks.level.entity.fabric;

import J;
import dev.architectury.event.events.common.EntityEvent;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.ChunkSectionPos;
import net.minecraft.world.entity.EntityChangeListener;

public class EntityHooksImpl {
    public static EntityChangeListener wrapEntityInLevelCallback(Entity entity, EntityChangeListener callback) {
        if (callback == EntityChangeListener.NONE) return callback;
        if (callback == null) return callback;
        return new EntityChangeListener() {
            private long lastSectionKey = ChunkSectionPos.toLong(entity.getBlockPos());
            
            @Override
            public void updateEntityPosition() {
                callback.updateEntityPosition();
                var currentSectionKey = ChunkSectionPos.toLong(entity.getBlockPos());
                if (currentSectionKey != lastSectionKey) {
                    EntityEvent.ENTER_SECTION.invoker().enterSection(entity, ChunkSectionPos.unpackX(lastSectionKey), ChunkSectionPos.unpackY(lastSectionKey),
                            ChunkSectionPos.unpackZ(lastSectionKey), ChunkSectionPos.unpackX(currentSectionKey), ChunkSectionPos.unpackY(currentSectionKey),
                            ChunkSectionPos.unpackZ(currentSectionKey));
                    lastSectionKey = currentSectionKey;
                }
            }
            
            @Override
            public void remove(Entity.RemovalReason removalReason) {
                callback.remove(removalReason);
            }
        };
    }
}

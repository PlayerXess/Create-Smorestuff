/*
 * This file is part of architectury.
 * Copyright (C) 2020, 2021, 2022 architectury
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 3 of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program; if not, write to the Free Software Foundation,
 * Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

package dev.architectury.extensions.injected;

import dev.architectury.hooks.item.food.FoodPropertiesHooks;
import java.util.function.Supplier;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.item.FoodComponent;

public interface InjectedFoodPropertiesBuilderExtension {
    default FoodComponent.Builder arch$effect(Supplier<? extends StatusEffectInstance> effectSupplier, float chance) {
        FoodPropertiesHooks.effect((FoodComponent.Builder) this, effectSupplier, chance);
        return (FoodComponent.Builder) this;
    }
}

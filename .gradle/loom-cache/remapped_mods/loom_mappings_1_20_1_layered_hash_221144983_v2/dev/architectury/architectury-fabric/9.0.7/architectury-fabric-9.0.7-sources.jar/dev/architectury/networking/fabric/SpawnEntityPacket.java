/*
 * This file is part of architectury.
 * Copyright (C) 2020, 2021, 2022 architectury
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 3 of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program; if not, write to the Free Software Foundation,
 * Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

package dev.architectury.networking.fabric;

import D;
import F;
import I;
import dev.architectury.extensions.network.EntitySpawnExtension;
import dev.architectury.networking.NetworkManager;
import java.util.UUID;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.network.listener.ClientPlayPacketListener;
import net.minecraft.network.packet.Packet;
import net.minecraft.registry.Registries;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.Vec3d;

/**
 * @see net.minecraft.network.packet.s2c.play.EntitySpawnS2CPacket
 */
public class SpawnEntityPacket {
    private static final Identifier PACKET_ID = new Identifier("architectury", "spawn_entity_packet");
    
    public static Packet<ClientPlayPacketListener> create(Entity entity) {
        if (entity.getWorld().isClient()) {
            throw new IllegalStateException("SpawnPacketUtil.create called on the logical client!");
        }
        var buffer = PacketByteBufs.create();
        buffer.writeVarInt(Registries.ENTITY_TYPE.getRawId(entity.getType()));
        buffer.writeUUID(entity.getUuid());
        buffer.writeVarInt(entity.getId());
        var position = entity.getPos();
        buffer.writeDouble(position.x);
        buffer.writeDouble(position.y);
        buffer.writeDouble(position.z);
        buffer.writeFloat(entity.getPitch());
        buffer.writeFloat(entity.getYaw());
        buffer.writeFloat(entity.getHeadYaw());
        var deltaMovement = entity.getVelocity();
        buffer.writeDouble(deltaMovement.x);
        buffer.writeDouble(deltaMovement.y);
        buffer.writeDouble(deltaMovement.z);
        if (entity instanceof EntitySpawnExtension ext) {
            ext.saveAdditionalSpawnData(buffer);
        }
        return (Packet<ClientPlayPacketListener>) NetworkManager.toPacket(NetworkManager.s2c(), PACKET_ID, buffer);
    }
    
    
    @Environment(EnvType.CLIENT)
    public static class Client {
        @Environment(EnvType.CLIENT)
        public static void register() {
            NetworkManager.registerReceiver(NetworkManager.s2c(), PACKET_ID, Client::receive);
        }
        
        @Environment(EnvType.CLIENT)
        public static void receive(PacketByteBuf buf, NetworkManager.PacketContext context) {
            var entityTypeId = buf.readVarInt();
            var uuid = buf.readUuid();
            var id = buf.readVarInt();
            var x = buf.readDouble();
            var y = buf.readDouble();
            var z = buf.readDouble();
            var xRot = buf.readFloat();
            var yRot = buf.readFloat();
            var yHeadRot = buf.readFloat();
            var deltaX = buf.readDouble();
            var deltaY = buf.readDouble();
            var deltaZ = buf.readDouble();
            // Retain this buffer so we can use it in the queued task (EntitySpawnExtension)
            buf.retain();
            context.queue(() -> {
                var entityType = Registries.ENTITY_TYPE.get(entityTypeId);
                if (entityType == null) {
                    throw new IllegalStateException("Entity type (" + entityTypeId + ") is unknown, spawning at (" + x + ", " + y + ", " + z + ")");
                }
                if (MinecraftClient.getInstance().world == null) {
                    throw new IllegalStateException("Client world is null!");
                }
                var entity = entityType.create(MinecraftClient.getInstance().world);
                if (entity == null) {
                    throw new IllegalStateException("Created entity is null!");
                }
                entity.setUuid(uuid);
                entity.setId(id);
                entity.updateTrackedPosition(x, y, z);
                entity.refreshPositionAfterTeleport(x, y, z);
                entity.setPitch(xRot);
                entity.setYaw(yRot);
                entity.setHeadYaw(yHeadRot);
                entity.setBodyYaw(yHeadRot);
                if (entity instanceof EntitySpawnExtension ext) {
                    ext.loadAdditionalSpawnData(buf);
                }
                buf.release();
                MinecraftClient.getInstance().world.addEntity(id, entity);
                entity.setVelocityClient(deltaX, deltaY, deltaZ);
            });
        }
    }
}

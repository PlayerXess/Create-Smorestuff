/*
 * This file is licensed under the MIT License, part of Roughly Enough Items.
 * Copyright (c) 2018, 2019, 2020, 2021, 2022, 2023 shedaniel
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */

package me.shedaniel.rei.plugin.common.displays.brewing;

import com.google.common.collect.Lists;
import me.shedaniel.rei.api.common.category.CategoryIdentifier;
import me.shedaniel.rei.api.common.display.Display;
import me.shedaniel.rei.api.common.display.DisplaySerializer;
import me.shedaniel.rei.api.common.entry.EntryIngredient;
import me.shedaniel.rei.api.common.entry.EntryStack;
import me.shedaniel.rei.api.common.util.EntryIngredients;
import me.shedaniel.rei.api.common.util.EntryStacks;
import me.shedaniel.rei.plugin.common.BuiltinPlugin;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.nbt.NbtElement;
import net.minecraft.recipe.Ingredient;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import org.jetbrains.annotations.ApiStatus;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * The default display for brewing recipes.
 *
 * @see BrewingRecipe
 */
@ApiStatus.Internal
public class DefaultBrewingDisplay implements Display {
    private EntryStack<?> output;
    private EntryIngredient reactant, input;
    
    public DefaultBrewingDisplay(BrewingRecipe recipe) {
        this(recipe.input, recipe.ingredient, recipe.output);
    }
    
    public DefaultBrewingDisplay(Ingredient input, Ingredient reactant, ItemStack output) {
        this(EntryIngredients.ofIngredient(input), EntryIngredients.ofIngredient(reactant), EntryStacks.of(output));
    }
    
    public DefaultBrewingDisplay(EntryIngredient input, EntryIngredient reactant, EntryStack<?> output) {
        this.input = input.map(stack -> stack.copy().tooltip(Text.translatable("category.rei.brewing.input").formatted(Formatting.field_1054)));
        this.reactant = reactant.map(stack -> stack.copy().tooltip(Text.translatable("category.rei.brewing.reactant").formatted(Formatting.field_1054)));
        this.output = output.copy().tooltip(Text.translatable("category.rei.brewing.result").formatted(Formatting.field_1054));
    }
    
    @Override
    public List<EntryIngredient> getInputEntries() {
        return Lists.newArrayList(input, reactant);
    }
    
    @Override
    public List<EntryIngredient> getOutputEntries() {
        return Collections.singletonList(EntryIngredient.of(output));
    }
    
    @Override
    public CategoryIdentifier<?> getCategoryIdentifier() {
        return BuiltinPlugin.BREWING;
    }
    
    public List<EntryStack<?>> getOutput(int slot) {
        List<EntryStack<?>> stack = new ArrayList<>();
        for (int i = 0; i < slot * 2; i++)
            stack.add(EntryStack.empty());
        for (int i = 0; i < 6 - slot * 2; i++)
            stack.add(output);
        return stack;
    }
    
    public static DisplaySerializer<DefaultBrewingDisplay> serializer() {
        return new DisplaySerializer<DefaultBrewingDisplay>() {
            @Override
            public NbtCompound save(NbtCompound tag, DefaultBrewingDisplay display) {
                tag.put("input", display.input.saveIngredient());
                tag.put("reactant", display.reactant.saveIngredient());
                tag.put("output", display.output.saveStack());
                return tag;
            }
            
            @Override
            public DefaultBrewingDisplay read(NbtCompound tag) {
                EntryIngredient input = EntryIngredient.read(tag.getList("input", NbtElement.COMPOUND_TYPE));
                EntryIngredient reactant = EntryIngredient.read(tag.getList("reactant", NbtElement.COMPOUND_TYPE));
                EntryStack<?> output = EntryStack.read(tag.getCompound("output"));
                return new DefaultBrewingDisplay(input, reactant, output);
            }
        };
    }
}

/*
 * This file is licensed under the MIT License, part of Roughly Enough Items.
 * Copyright (c) 2018, 2019, 2020, 2021, 2022, 2023 shedaniel
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */

package me.shedaniel.rei.impl.client.config.entries;

import me.shedaniel.clothconfig2.gui.widget.DynamicElementListWidget;
import me.shedaniel.rei.api.client.entry.filtering.FilteringRule;
import me.shedaniel.rei.api.client.entry.filtering.FilteringRuleType;
import me.shedaniel.rei.api.client.entry.filtering.FilteringRuleTypeRegistry;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.Element;
import net.minecraft.client.gui.Selectable;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.StringVisitable;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import net.minecraft.util.Language;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.function.Function;
import java.util.function.Supplier;

public class FilteringAddRuleScreen extends Screen {
    private final List<FilteringRule<?>> rules;
    private RulesList rulesList;
    Screen parent;
    
    public FilteringAddRuleScreen(List<FilteringRule<?>> rules) {
        super(Text.translatable("config.roughlyenoughitems.filteringRulesScreen.new"));
        this.rules = rules;
    }
    
    @Override
    public void init() {
        super.init();
        {
            Text backText = Text.literal("↩ ").append(Text.translatable("gui.back"));
            addDrawableChild(new ButtonWidget(4, 4, MinecraftClient.getInstance().textRenderer.getWidth(backText) + 10, 20, backText, button -> {
                client.setScreen(parent);
                this.parent = null;
            }, Supplier::get) {
            });
        }
        rulesList = addSelectableChild(new RulesList(client, width, height, 30, height, OPTIONS_BACKGROUND_TEXTURE));
        for (FilteringRuleType<?> rule : FilteringRuleTypeRegistry.getInstance()) {
            if (!rule.isSingular())
                rulesList.addItem(new DefaultRuleEntry(parent, rules, rule.createNew(), null));
        }
        rulesList.selectItem(rulesList.children().get(0));
    }
    
    @Override
    public void render(DrawContext graphics, int mouseX, int mouseY, float delta) {
        this.rulesList.render(graphics, mouseX, mouseY, delta);
        super.render(graphics, mouseX, mouseY, delta);
        graphics.drawTextWithShadow(this.textRenderer, this.title.asOrderedText(), (int) (this.width / 2.0F - this.textRenderer.getWidth(this.title) / 2.0F), 12, -1);
    }
    
    @Override
    public void close() {
        this.client.setScreen(parent);
    }
    
    public static class RulesList extends DynamicElementListWidget<RuleEntry> {
        private boolean inFocus;
        
        public RulesList(MinecraftClient client, int width, int height, int top, int bottom, Identifier backgroundLocation) {
            super(client, width, height, top, bottom, backgroundLocation);
        }
        
        @Override
        protected boolean isSelected(int index) {
            return Objects.equals(this.getSelectedItem(), this.children().get(index));
        }
        
        @Override
        protected int addItem(RuleEntry item) {
            return super.addItem(item);
        }
        
        @Override
        public int getItemWidth() {
            return width - 40;
        }
        
        @Override
        protected int getScrollbarPosition() {
            return width - 14;
        }
    }
    
    public static abstract class RuleEntry extends DynamicElementListWidget.ElementEntry<RuleEntry> {
        private final FilteringRule<?> rule;
        
        public RuleEntry(FilteringRule<?> rule) {
            this.rule = rule;
        }
        
        public FilteringRule<?> getRule() {
            return rule;
        }
        
        @Override
        public int getItemHeight() {
            return 26;
        }
    }
    
    public static class DefaultRuleEntry extends RuleEntry {
        private final ButtonWidget addButton;
        private final Function<Screen, Screen> screenFunction;
        
        public DefaultRuleEntry(Screen parent, List<FilteringRule<?>> rules, FilteringRule<?> rule, Function<Screen, Screen> screenFunction) {
            super(rule);
            this.screenFunction = (screenFunction == null ? ((FilteringRuleType<FilteringRule<?>>) rule.getType()).createEntryScreen(rule) : screenFunction);
            addButton = new ButtonWidget(0, 0, 20, 20, Text.of(" + "), button -> {
                MinecraftClient.getInstance().setScreen(this.screenFunction.apply(parent));
                rules.add(0, rule);
            }, Supplier::get) {
            };
            addButton.active = this.screenFunction != null;
        }
        
        @Override
        public void render(DrawContext graphics, int index, int y, int x, int entryWidth, int entryHeight, int mouseX, int mouseY, boolean isHovered, float delta) {
            MinecraftClient client = MinecraftClient.getInstance();
            {
                Text title = ((FilteringRuleType<FilteringRule<?>>) getRule().getType()).getTitle(getRule());
                int i = client.textRenderer.getWidth(title);
                if (i > entryWidth - 28) {
                    StringVisitable titleTrimmed = StringVisitable.concat(client.textRenderer.trimToWidth(title, entryWidth - 28 - client.textRenderer.getWidth("...")), StringVisitable.plain("..."));
                    graphics.drawTextWithShadow(client.textRenderer, Language.getInstance().reorder(titleTrimmed), x + 2, y + 1, 16777215);
                } else {
                    graphics.drawTextWithShadow(client.textRenderer, title.asOrderedText(), x + 2, y + 1, 16777215);
                }
            }
            {
                Text subtitle = ((FilteringRuleType<FilteringRule<?>>) getRule().getType()).getSubtitle(getRule());
                int i = client.textRenderer.getWidth(subtitle);
                if (i > entryWidth - 28) {
                    StringVisitable subtitleTrimmed = StringVisitable.concat(client.textRenderer.trimToWidth(subtitle, entryWidth - 28 - client.textRenderer.getWidth("...")), StringVisitable.plain("..."));
                    graphics.drawTextWithShadow(client.textRenderer, Language.getInstance().reorder(subtitleTrimmed), x + 2, y + 12, 8421504);
                } else {
                    graphics.drawTextWithShadow(client.textRenderer, subtitle.asOrderedText(), x + 2, y + 12, 8421504);
                }
            }
            addButton.method_46421(x + entryWidth - 25);
            addButton.method_46419(y + 1);
            addButton.render(graphics, mouseX, mouseY, delta);
        }
        
        @Override
        public List<? extends Element> children() {
            return Collections.singletonList(addButton);
        }
        
        @Override
        public List<? extends Selectable> narratables() {
            return Collections.singletonList(addButton);
        }
    }
}

/*
 * This file is licensed under the MIT License, part of Roughly Enough Items.
 * Copyright (c) 2018, 2019, 2020, 2021, 2022, 2023 shedaniel
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */

package me.shedaniel.rei.plugin.client.entry;

import com.google.common.collect.Lists;
import com.mojang.blaze3d.platform.GlStateManager;
import com.mojang.blaze3d.systems.RenderSystem;
import dev.architectury.hooks.item.ItemStackHooks;
import dev.architectury.utils.Env;
import dev.architectury.utils.EnvExecutor;
import it.unimi.dsi.fastutil.objects.ReferenceOpenHashSet;
import it.unimi.dsi.fastutil.objects.ReferenceSet;
import me.shedaniel.math.Rectangle;
import me.shedaniel.rei.api.client.entry.renderer.BatchedEntryRenderer;
import me.shedaniel.rei.api.client.entry.renderer.EntryRenderer;
import me.shedaniel.rei.api.client.gui.widgets.Tooltip;
import me.shedaniel.rei.api.client.gui.widgets.TooltipContext;
import me.shedaniel.rei.api.common.entry.EntrySerializer;
import me.shedaniel.rei.api.common.entry.EntryStack;
import me.shedaniel.rei.api.common.entry.comparison.ComparisonContext;
import me.shedaniel.rei.api.common.entry.comparison.ItemComparatorRegistry;
import me.shedaniel.rei.api.common.entry.type.EntryDefinition;
import me.shedaniel.rei.api.common.entry.type.EntryType;
import me.shedaniel.rei.api.common.entry.type.VanillaEntryTypes;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.item.TooltipData;
import net.minecraft.client.render.DiffuseLighting;
import net.minecraft.client.render.OverlayTexture;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.model.BakedModel;
import net.minecraft.client.render.model.json.ModelTransformationMode;
import net.minecraft.client.resource.language.I18n;
import net.minecraft.client.texture.SpriteAtlasTexture;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.item.BlockItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.registry.Registries;
import net.minecraft.registry.tag.TagKey;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import net.minecraft.util.crash.CrashReport;
import net.minecraft.util.crash.CrashReportSection;
import org.jetbrains.annotations.Nullable;
import org.joml.Matrix4f;

import java.util.List;
import java.util.Optional;
import java.util.stream.Stream;

public class ItemEntryDefinition implements EntryDefinition<ItemStack>, EntrySerializer<ItemStack> {
    @Environment(EnvType.CLIENT)
    private EntryRenderer<ItemStack> renderer;
    
    public ItemEntryDefinition() {
        EnvExecutor.runInEnv(Env.CLIENT, () -> () -> Client.init(this));
    }
    
    @Environment(EnvType.CLIENT)
    private static class Client {
        private static void init(ItemEntryDefinition definition) {
            definition.renderer = definition.new ItemEntryRenderer();
        }
    }
    
    @Override
    public Class<ItemStack> getValueType() {
        return ItemStack.class;
    }
    
    @Override
    public EntryType<ItemStack> getType() {
        return VanillaEntryTypes.ITEM;
    }
    
    @Override
    @Environment(EnvType.CLIENT)
    public EntryRenderer<ItemStack> getRenderer() {
        return renderer;
    }
    
    @Override
    @Nullable
    public Identifier getIdentifier(EntryStack<ItemStack> entry, ItemStack value) {
        return Registries.ITEM.getId(value.getItem());
    }
    
    @Override
    public boolean isEmpty(EntryStack<ItemStack> entry, ItemStack value) {
        return value.isEmpty();
    }
    
    @Override
    public ItemStack copy(EntryStack<ItemStack> entry, ItemStack value) {
        return value.copy();
    }
    
    @Override
    public ItemStack normalize(EntryStack<ItemStack> entry, ItemStack value) {
        ItemStack copy = value.copy();
        copy.setCount(1);
        return copy;
    }
    
    @Override
    public ItemStack wildcard(EntryStack<ItemStack> entry, ItemStack value) {
        return new ItemStack(value.getItem(), 1);
    }
    
    @Override
    @Nullable
    public ItemStack cheatsAs(EntryStack<ItemStack> entry, ItemStack value) {
        return value.copy();
    }
    
    @Nullable
    @Override
    public ItemStack add(ItemStack o1, ItemStack o2) {
        return ItemStackHooks.copyWithCount(o1, o1.getCount() + o2.getCount());
    }
    
    @Override
    public long hash(EntryStack<ItemStack> entry, ItemStack value, ComparisonContext context) {
        int code = 1;
        code = 31 * code + System.identityHashCode(value.getItem());
        code = 31 * code + Long.hashCode(ItemComparatorRegistry.getInstance().hashOf(context, value));
        return code;
    }
    
    @Override
    public boolean equals(ItemStack o1, ItemStack o2, ComparisonContext context) {
        if (o1.getItem() != o2.getItem())
            return false;
        return ItemComparatorRegistry.getInstance().hashOf(context, o1) == ItemComparatorRegistry.getInstance().hashOf(context, o2);
    }
    
    @Override
    @Nullable
    public EntrySerializer<ItemStack> getSerializer() {
        return this;
    }
    
    @Override
    public boolean supportSaving() {
        return true;
    }
    
    @Override
    public boolean supportReading() {
        return true;
    }
    
    @Override
    public boolean acceptsNull() {
        return false;
    }
    
    @Override
    public NbtCompound save(EntryStack<ItemStack> entry, ItemStack value) {
        return value.writeNbt(new NbtCompound());
    }
    
    @Override
    public ItemStack read(NbtCompound tag) {
        return ItemStack.fromNbt(tag);
    }
    
    private static final ReferenceSet<Item> SEARCH_BLACKLISTED = new ReferenceOpenHashSet<>();
    
    @Override
    public Text asFormattedText(EntryStack<ItemStack> entry, ItemStack value) {
        return asFormattedText(entry, value, TooltipContext.of());
    }
    
    @Override
    public Text asFormattedText(EntryStack<ItemStack> entry, ItemStack value, TooltipContext context) {
        if (!SEARCH_BLACKLISTED.contains(value.getItem()))
            try {
                return value.getName();
            } catch (Throwable e) {
                if (context != null && context.isSearch()) throw e;
                e.printStackTrace();
                SEARCH_BLACKLISTED.add(value.getItem());
            }
        try {
            return Text.literal(I18n.translate("item." + Registries.ITEM.getId(value.getItem()).toString().replace(":", ".")));
        } catch (Throwable e) {
            e.printStackTrace();
        }
        return Text.literal("ERROR");
    }
    
    @Override
    public Stream<? extends TagKey<?>> getTagsFor(EntryStack<ItemStack> entry, ItemStack value) {
        Stream<? extends TagKey<?>> tags = value.streamTags();
        if (value.getItem() instanceof BlockItem blockItem) {
            tags = Stream.concat(tags, blockItem.getBlock().getRegistryEntry().streamTags());
        }
        return tags;
    }
    
    @Environment(EnvType.CLIENT)
    private List<Text> tryGetItemStackToolTip(EntryStack<ItemStack> entry, ItemStack value, TooltipContext context) {
        if (!SEARCH_BLACKLISTED.contains(value.getItem()))
            try {
                return value.getTooltip(MinecraftClient.getInstance().player, context.getFlag());
            } catch (Throwable e) {
                if (context.isSearch()) throw e;
                e.printStackTrace();
                SEARCH_BLACKLISTED.add(value.getItem());
            }
        return Lists.newArrayList(asFormattedText(entry, value, context));
    }
    
    @Override
    public void fillCrashReport(CrashReport report, CrashReportSection category, EntryStack<ItemStack> entry) {
        EntryDefinition.super.fillCrashReport(report, category, entry);
        ItemStack stack = entry.getValue();
        category.add("Item Type", () -> String.valueOf(stack.getItem()));
        category.add("Item Damage", () -> String.valueOf(stack.getDamage()));
        category.add("Item NBT", () -> String.valueOf(stack.getNbt()));
        category.add("Item Foil", () -> String.valueOf(stack.hasGlint()));
    }
    
    @Environment(EnvType.CLIENT)
    public class ItemEntryRenderer implements BatchedEntryRenderer<ItemStack, BakedModel> {
        private static final float SCALE = 20.0F;
        public static final int ITEM_LIGHT = 0xf000f0;
        
        @Override
        public BakedModel getExtraData(EntryStack<ItemStack> entry) {
            MinecraftClient minecraft = MinecraftClient.getInstance();
            return minecraft.getItemRenderer().getModel(entry.getValue(), minecraft.world, minecraft.player, 0);
        }
        
        @Override
        public void render(EntryStack<ItemStack> entry, DrawContext graphics, Rectangle bounds, int mouseX, int mouseY, float delta) {
            BakedModel model = getExtraData(entry);
            setupGL(entry, model);
            if (!entry.isEmpty()) {
                ItemStack value = entry.getValue();
                graphics.getMatrices().push();
                graphics.getMatrices().translate(bounds.getCenterX(), bounds.getCenterY(), 0);
                graphics.getMatrices().multiplyPositionMatrix(new Matrix4f().scaling(1.0F, -1.0F, 1.0F));
                graphics.getMatrices().scale(bounds.getWidth(), bounds.getHeight(), (bounds.getWidth() + bounds.getHeight()) / 2.0F);
                VertexConsumerProvider.Immediate immediate = MinecraftClient.getInstance().getBufferBuilders().getEntityVertexConsumers();
                MinecraftClient.getInstance().getItemRenderer().renderItem(value, ModelTransformationMode.field_4317, false, graphics.getMatrices(), immediate,
                        ITEM_LIGHT, OverlayTexture.DEFAULT_UV, model);
                immediate.draw();
                graphics.getMatrices().pop();
            }
            MatrixStack modelViewStack = RenderSystem.getModelViewStack();
            modelViewStack.push();
            modelViewStack.multiplyPositionMatrix(graphics.getMatrices().peek().getPositionMatrix());
            modelViewStack.translate(bounds.x, bounds.y, 0);
            modelViewStack.scale(bounds.width / 16f, (bounds.getWidth() + bounds.getHeight()) / 2f / 16f, 1.0F);
            RenderSystem.applyModelViewMatrix();
            renderOverlay(new DrawContext(MinecraftClient.getInstance(), graphics.getVertexConsumers()), entry, bounds);
            modelViewStack.pop();
            endGL(entry, model);
            RenderSystem.applyModelViewMatrix();
        }
        
        @Override
        public int getBatchIdentifier(EntryStack<ItemStack> entry, Rectangle bounds, BakedModel model) {
            return 1738923 + (model.isSideLit() ? 1 : 0);
        }
        
        @Override
        public void startBatch(EntryStack<ItemStack> entry, BakedModel model, DrawContext graphics, float delta) {
            setupGL(entry, model);
            MatrixStack modelViewStack = RenderSystem.getModelViewStack();
            modelViewStack.push();
            modelViewStack.scale(SCALE, -SCALE, 1.0F);
            RenderSystem.applyModelViewMatrix();
        }
        
        public void setupGL(EntryStack<ItemStack> entry, BakedModel model) {
            MinecraftClient.getInstance().getTextureManager().getTexture(SpriteAtlasTexture.BLOCK_ATLAS_TEXTURE).setFilter(false, false);
            RenderSystem.setShaderTexture(0, SpriteAtlasTexture.BLOCK_ATLAS_TEXTURE);
            RenderSystem.enableBlend();
            RenderSystem.blendFunc(GlStateManager.SrcFactor.SRC_ALPHA, GlStateManager.DstFactor.ONE_MINUS_SRC_ALPHA);
            RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
            boolean sideLit = model.isSideLit();
            if (!sideLit) DiffuseLighting.disableGuiDepthLighting();
        }
        
        @Override
        public void renderBase(EntryStack<ItemStack> entry, BakedModel model, DrawContext graphics, VertexConsumerProvider.Immediate immediate, Rectangle bounds, int mouseX, int mouseY, float delta) {
            if (!entry.isEmpty()) {
                ItemStack value = entry.getValue();
                graphics.getMatrices().push();
                graphics.getMatrices().translate(bounds.getCenterX() / SCALE, bounds.getCenterY() / -SCALE, 0);
                graphics.getMatrices().scale(bounds.getWidth() / SCALE, (bounds.getWidth() + bounds.getHeight()) / 2f / SCALE, 1.0F);
                MinecraftClient.getInstance().getItemRenderer().renderItem(value, ModelTransformationMode.field_4317, false, graphics.getMatrices(), immediate,
                        ITEM_LIGHT, OverlayTexture.DEFAULT_UV, model);
                graphics.getMatrices().pop();
            }
        }
        
        @Override
        public void afterBase(EntryStack<ItemStack> entry, BakedModel model, DrawContext graphics, float delta) {
            endGL(entry, model);
            RenderSystem.getModelViewStack().pop();
            RenderSystem.applyModelViewMatrix();
        }
        
        @Override
        public void renderOverlay(EntryStack<ItemStack> entry, BakedModel model, DrawContext graphics, VertexConsumerProvider.Immediate immediate, Rectangle bounds, int mouseX, int mouseY, float delta) {
            MatrixStack modelViewStack = RenderSystem.getModelViewStack();
            modelViewStack.push();
            modelViewStack.multiplyPositionMatrix(graphics.getMatrices().peek().getPositionMatrix());
            modelViewStack.translate(bounds.x, bounds.y, 0);
            modelViewStack.scale(bounds.width / 16f, (bounds.getWidth() + bounds.getHeight()) / 2f / 16f, 1.0F);
            RenderSystem.applyModelViewMatrix();
            renderOverlay(new DrawContext(MinecraftClient.getInstance(), graphics.getVertexConsumers()), entry, bounds);
            modelViewStack.pop();
            RenderSystem.applyModelViewMatrix();
        }
        
        public void renderOverlay(DrawContext graphics, EntryStack<ItemStack> entry, Rectangle bounds) {
            if (!entry.isEmpty()) {
                graphics.drawItemInSlot(MinecraftClient.getInstance().textRenderer, entry.getValue(), 0, 0, null);
            }
        }
        
        @Override
        public void endBatch(EntryStack<ItemStack> entry, BakedModel model, DrawContext graphics, float delta) {
        }
        
        public void endGL(EntryStack<ItemStack> entry, BakedModel model) {
            RenderSystem.enableDepthTest();
            boolean sideLit = model.isSideLit();
            if (!sideLit) DiffuseLighting.enableGuiDepthLighting();
        }
        
        @Override
        @Nullable
        public Tooltip getTooltip(EntryStack<ItemStack> entry, TooltipContext context) {
            if (entry.isEmpty())
                return null;
            Tooltip tooltip = Tooltip.create();
            Optional<TooltipData> component = entry.getValue().getTooltipData();
            List<Text> components = tryGetItemStackToolTip(entry, entry.getValue(), context);
            if (!components.isEmpty()) {
                tooltip.add(components.get(0));
            }
            component.ifPresent(tooltip::add);
            for (int i = 1; i < components.size(); i++) {
                tooltip.add(components.get(i));
            }
            return tooltip;
        }
    }
}

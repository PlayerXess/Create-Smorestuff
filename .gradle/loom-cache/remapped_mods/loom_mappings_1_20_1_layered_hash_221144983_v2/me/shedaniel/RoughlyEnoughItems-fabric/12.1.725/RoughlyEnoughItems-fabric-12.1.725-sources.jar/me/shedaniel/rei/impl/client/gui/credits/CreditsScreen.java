/*
 * This file is licensed under the MIT License, part of Roughly Enough Items.
 * Copyright (c) 2018, 2019, 2020, 2021, 2022, 2023 shedaniel
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */

package me.shedaniel.rei.impl.client.gui.credits;

import com.google.common.collect.Lists;
import dev.architectury.platform.Platform;
import me.shedaniel.rei.impl.client.gui.credits.CreditsEntryListWidget.TextCreditsItem;
import me.shedaniel.rei.impl.client.gui.credits.CreditsEntryListWidget.TranslationCreditsItem;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.PressableWidget;
import net.minecraft.client.resource.language.I18n;
import net.minecraft.text.MutableText;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.Pair;
import org.jetbrains.annotations.ApiStatus;

import java.lang.reflect.InvocationTargetException;
import java.util.List;
import java.util.Locale;
import java.util.function.Supplier;
import java.util.stream.Collectors;

@ApiStatus.Internal
public class CreditsScreen extends Screen {
    private Screen parent;
    private PressableWidget buttonDone;
    private CreditsEntryListWidget entryListWidget;
    
    public CreditsScreen(Screen parent) {
        super(Text.literal(""));
        this.parent = parent;
    }
    
    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (keyCode == 256 && this.shouldCloseOnEsc()) {
            openPrevious();
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }
    
    public static class TranslatorEntry {
        private final String name;
        private final boolean proofreader;
        
        public TranslatorEntry(String name) {
            this(name, false);
        }
        
        public TranslatorEntry(String name, boolean proofreader) {
            this.name = name;
            this.proofreader = proofreader;
        }
        
        public String getName() {
            return name;
        }
    }
    
    @Override
    public void init() {
        addSelectableChild(entryListWidget = new CreditsEntryListWidget(client, width, height, 32, height - 32));
        entryListWidget.creditsClearEntries();
        List<Pair<String, List<TranslatorEntry>>> translators = Lists.newArrayList();
        Exception[] exception = {null};
        fillTranslators(exception, translators);
        List<Pair<String, List<TranslatorEntry>>> translatorsMapped = translators.stream().map(pair -> {
            return new Pair<>(
                    "  " + (I18n.hasTranslation("language.roughlyenoughitems." + pair.getLeft().toLowerCase(Locale.ROOT).replace(' ', '_')) ? I18n.translate("language.roughlyenoughitems." + pair.getLeft().toLowerCase(Locale.ROOT).replace(' ', '_')) : pair.getLeft()),
                    pair.getRight()
            );
        }).collect(Collectors.toList());
        int i = width - 80 - 6;
        for (String line : String.format("§lRoughly Enough Items (v%s)\n§7Originally a fork for Almost Enough Items.\n\n§lLanguage Translation\n%s\n\n§lLicense\n§7Roughly Enough Items is licensed under MIT.", Platform.getMod("roughlyenoughitems").getVersion(), "%translators%").split("\n"))
            if (line.equalsIgnoreCase("%translators%")) {
                if (exception[0] != null) {
                    entryListWidget.creditsAddEntry(new TextCreditsItem(Text.literal("Failed to get translators: " + exception[0].toString())));
                    for (StackTraceElement traceElement : exception[0].getStackTrace())
                        entryListWidget.creditsAddEntry(new TextCreditsItem(Text.literal("  at " + traceElement)));
                } else {
                    int maxWidth = translatorsMapped.stream().mapToInt(pair -> textRenderer.getWidth(pair.getLeft())).max().orElse(0) + 5;
                    for (Pair<String, List<TranslatorEntry>> pair : translatorsMapped) {
                        MutableText text = Text.literal("");
                        boolean isFirst = true;
                        for (TranslatorEntry entry : pair.getRight()) {
                            if (!isFirst) {
                                text = text.append(Text.literal(", "));
                            }
                            isFirst = false;
                            MutableText component = Text.literal(entry.getName());
                            if (entry.proofreader)
                                component = component.formatted(Formatting.field_1065);
                            text = text.append(component);
                        }
                        entryListWidget.creditsAddEntry(new TranslationCreditsItem(Text.translatable(pair.getLeft()), text, i - maxWidth - 10, maxWidth));
                    }
                }
            } else entryListWidget.creditsAddEntry(new TextCreditsItem(Text.literal(line)));
        entryListWidget.creditsAddEntry(new TextCreditsItem(Text.empty()));
        entryListWidget.creditsAddEntry(new CreditsEntryListWidget.LinkItem(Text.literal("Visit the project at GitHub."), "https://www.github.com/shedaniel/RoughlyEnoughItems", entryListWidget.getItemWidth(), false));
        entryListWidget.creditsAddEntry(new CreditsEntryListWidget.LinkItem(Text.literal("Visit the project page at CurseForge."), "https://www.curseforge.com/minecraft/mc-mods/roughly-enough-items", entryListWidget.getItemWidth(), false));
        entryListWidget.creditsAddEntry(new CreditsEntryListWidget.LinkItem(Text.literal("Support the project via Patreon!"), "https://patreon.com/shedaniel", entryListWidget.getItemWidth(), true));
        entryListWidget.creditsAddEntry(new TextCreditsItem(Text.empty()));
        addDrawableChild(buttonDone = new ButtonWidget(width / 2 - 100, height - 26, 200, 20, Text.translatable("gui.done"), button -> openPrevious(), Supplier::get) {});
    }
    
    private static void fillTranslators(Exception[] exception, List<Pair<String, List<TranslatorEntry>>> translators) {
        try {
            Class.forName("me.shedaniel.rei.impl.client.gui.credits.%s.CreditsScreenImpl".formatted(Platform.isForge() ? "forge" : "fabric"))
                    .getDeclaredMethod("fillTranslators", Exception[].class, List.class)
                    .invoke(null, exception, translators);
        } catch (IllegalAccessException | ClassNotFoundException | NoSuchMethodException | InvocationTargetException e) {
            throw new RuntimeException(e);
        }
    }
    
    private void openPrevious() {
        MinecraftClient.getInstance().setScreen(parent);
    }
    
    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double amount) {
        if (entryListWidget.mouseScrolled(mouseX, mouseY, amount))
            return true;
        return super.mouseScrolled(mouseX, mouseY, amount);
    }
    
    @Override
    public void render(DrawContext graphics, int mouseX, int mouseY, float delta) {
        this.renderBackgroundTexture(graphics);
        this.entryListWidget.render(graphics, mouseX, mouseY, delta);
        graphics.drawCenteredTextWithShadow(this.textRenderer, I18n.translate("text.rei.credits"), this.width / 2, 16, 16777215);
        super.render(graphics, mouseX, mouseY, delta);
    }
    
}

/*
 * This file is licensed under the MIT License, part of Roughly Enough Items.
 * Copyright (c) 2018, 2019, 2020, 2021, 2022, 2023 shedaniel
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */

package me.shedaniel.rei.impl.client.gui.screen.collapsible;

import com.google.common.collect.Multimap;
import com.google.common.collect.Multimaps;
import com.mojang.blaze3d.systems.RenderSystem;
import me.shedaniel.clothconfig2.ClothConfigInitializer;
import me.shedaniel.clothconfig2.api.scroll.ScrollingContainer;
import me.shedaniel.math.Rectangle;
import me.shedaniel.rei.api.client.config.ConfigObject;
import me.shedaniel.rei.api.client.config.entry.EntryStackProvider;
import me.shedaniel.rei.api.client.gui.widgets.CloseableScissors;
import me.shedaniel.rei.api.client.gui.widgets.Widget;
import me.shedaniel.rei.api.client.registry.entry.CollapsibleEntryRegistry;
import me.shedaniel.rei.api.client.registry.entry.EntryRegistry;
import me.shedaniel.rei.api.common.entry.EntryStack;
import me.shedaniel.rei.api.common.util.CollectionUtils;
import me.shedaniel.rei.impl.client.config.collapsible.CollapsibleConfigManager;
import me.shedaniel.rei.impl.client.gui.ScreenOverlayImpl;
import me.shedaniel.rei.impl.client.gui.screen.collapsible.selection.CustomCollapsibleEntrySelectionScreen;
import me.shedaniel.rei.impl.client.gui.screen.generic.OptionEntriesScreen;
import me.shedaniel.rei.impl.client.gui.widget.DynamicErrorFreeEntryListWidget;
import me.shedaniel.rei.impl.common.entry.type.EntryRegistryImpl;
import me.shedaniel.rei.impl.common.entry.type.collapsed.CollapsibleEntryRegistryImpl;
import me.shedaniel.rei.impl.common.util.HashedEntryStackWrapper;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.Element;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.GameRenderer;
import net.minecraft.client.render.Tessellator;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.VertexFormat;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.Identifier;
import org.joml.Matrix4f;

import java.util.*;
import java.util.function.Consumer;
import java.util.function.Supplier;

public class CollapsibleEntriesScreen extends Screen {
    private final Runnable onClose;
    private final CollapsibleConfigManager.CollapsibleConfigObject configObject;
    private final List<CollapsibleEntryWidget> widgets = new ArrayList<>();
    private ListWidget listWidget;
    private boolean dirty = true;
    
    public CollapsibleEntriesScreen(Runnable onClose, CollapsibleConfigManager.CollapsibleConfigObject configObject) {
        super(Text.translatable("text.rei.collapsible.entries.title"));
        this.onClose = onClose;
        this.configObject = configObject;
        this.prepareWidgets(configObject);
    }
    
    public void prepareWidgets(CollapsibleConfigManager.CollapsibleConfigObject configObject) {
        this.widgets.clear();
        
        for (CollapsibleConfigManager.CustomGroup customEntry : configObject.customGroups) {
            this.widgets.add(new CollapsibleEntryWidget(true, customEntry.id, Text.literal(customEntry.name),
                    CollectionUtils.filterAndMap(customEntry.stacks, EntryStackProvider::isValid, EntryStackProvider::provide), configObject,
                    () -> {
                        this.prepareWidgets(configObject);
                        this.dirty = true;
                    }));
        }
        
        CollapsibleEntryRegistryImpl collapsibleRegistry = (CollapsibleEntryRegistryImpl) CollapsibleEntryRegistry.getInstance();
        Multimap<Identifier, EntryStack<?>> entries = Multimaps.newListMultimap(new HashMap<>(), ArrayList::new);
        for (HashedEntryStackWrapper wrapper : ((EntryRegistryImpl) EntryRegistry.getInstance()).getFilteredList().getList()) {
            for (CollapsibleEntryRegistryImpl.Entry entry : collapsibleRegistry.getEntries()) {
                if (entry.getMatcher().matches(wrapper.unwrap(), wrapper.hashExact())) {
                    entries.put(entry.getId(), wrapper.unwrap());
                }
            }
        }
        
        for (CollapsibleEntryRegistryImpl.Entry entry : collapsibleRegistry.getEntries()) {
            this.widgets.add(new CollapsibleEntryWidget(false, entry.getId(), entry.getName(), entries.get(entry.getId()), configObject,
                    () -> {
                        this.prepareWidgets(configObject);
                        this.dirty = true;
                    }));
        }
    }
    
    @Override
    public void init() {
        super.init();
        {
            Text backText = Text.literal("↩ ").append(Text.translatable("gui.back"));
            addDrawableChild(new ButtonWidget(4, 4, textRenderer.getWidth(backText) + 10, 20, backText,
                    button -> this.close(), Supplier::get) {
            });
        }
        {
            Text addText = Text.literal(" + ");
            addDrawableChild(new ButtonWidget(width - 4 - 20, 4, 20, 20, addText, $ -> {
                setupCustom(new Identifier("custom:" + UUID.randomUUID()), "", new ArrayList<>(), this.configObject, () -> {
                    this.prepareWidgets(configObject);
                    this.dirty = true;
                });
            }, Supplier::get) {
            });
        }
        
        this.listWidget = new ListWidget(width, height, 30);
        ((List<Element>) this.children()).add(this.listWidget);
        this.dirty = true;
    }
    
    public static void setupCustom(Identifier id, String name, List<EntryStack<?>> stacks, CollapsibleConfigManager.CollapsibleConfigObject configObject, Runnable markDirty) {
        MinecraftClient.getInstance().setScreen(new OptionEntriesScreen(Text.translatable("text.rei.collapsible.entries.custom.title"), MinecraftClient.getInstance().currentScreen) {
            private TextFieldListEntry entry;
            
            @Override
            public void addEntries(Consumer<ListEntry> entryConsumer) {
                addEmpty(entryConsumer, 10);
                addText(entryConsumer, Text.translatable("text.rei.collapsible.entries.custom.id").formatted(Formatting.field_1080)
                        .append(Text.literal(" " + id).formatted(Formatting.field_1063)));
                addEmpty(entryConsumer, 10);
                addText(entryConsumer, Text.translatable("text.rei.collapsible.entries.custom.name").formatted(Formatting.field_1080));
                entryConsumer.accept(this.entry = new TextFieldListEntry(width - 36, widget -> {
                    widget.setMaxLength(40);
                    if (this.entry != null) widget.setText(this.entry.getWidget().getText());
                    else widget.setText(name);
                }));
                addEmpty(entryConsumer, 10);
                entryConsumer.accept(new ButtonListEntry(width - 36, $ -> Text.translatable("text.rei.collapsible.entries.custom.select"), ($, button) -> {
                    CustomCollapsibleEntrySelectionScreen screen = new CustomCollapsibleEntrySelectionScreen(stacks);
                    screen.parent = this.client.currentScreen;
                    this.client.setScreen(screen);
                }));
            }
            
            @Override
            public void save() {
                configObject.customGroups.removeIf(customGroup -> customGroup.id.equals(id));
                configObject.customGroups.add(new CollapsibleConfigManager.CustomGroup(id, this.entry.getWidget().getText(),
                        CollectionUtils.map(stacks, EntryStackProvider::ofStack)));
                markDirty.run();
            }
        });
    }
    
    @Override
    public void render(DrawContext graphics, int mouseX, int mouseY, float delta) {
        if (this.dirty) {
            this.listWidget.clear();
            
            for (CollapsibleEntryWidget widget : this.widgets) {
                this.listWidget.add(widget);
            }
            
            this.dirty = false;
        }
        
        this.listWidget.render(graphics, mouseX, mouseY, delta);
        super.render(graphics, mouseX, mouseY, delta);
        graphics.drawTextWithShadow(this.textRenderer, this.title, this.width / 2 - this.textRenderer.getWidth(this.title) / 2, 12, -1);
        
        if (ConfigObject.getInstance().doDebugRenderTimeRequired()) {
            Text debugText = Text.literal(String.format("%s fps", client.fpsDebugString.split(" ")[0]));
            int stringWidth = textRenderer.getWidth(debugText);
            graphics.fillGradient(client.currentScreen.width - stringWidth - 2, 32, client.currentScreen.width, 32 + textRenderer.fontHeight + 2, -16777216, -16777216);
            VertexConsumerProvider.Immediate immediate = VertexConsumerProvider.immediate(Tessellator.getInstance().getBuffer());
            graphics.getMatrices().push();
            Matrix4f matrix = graphics.getMatrices().peek().getPositionMatrix();
            textRenderer.draw(debugText.asOrderedText(), client.currentScreen.width - stringWidth, 32 + 2, -1, false, matrix, immediate, TextRenderer.TextLayerType.field_33993, 0, 15728880);
            immediate.draw();
            graphics.getMatrices().pop();
        }
    }
    
    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double amount) {
        return this.listWidget.mouseScrolled(mouseX, mouseY, amount) || super.mouseScrolled(mouseX, mouseY, amount);
    }
    
    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        return this.listWidget.mouseClicked(mouseX, mouseY, button) || super.mouseClicked(mouseX, mouseY, button);
    }
    
    @Override
    public boolean mouseDragged(double mouseX, double mouseY, int button, double deltaX, double deltaY) {
        return this.listWidget.mouseDragged(mouseX, mouseY, button, deltaX, deltaY) || super.mouseDragged(mouseX, mouseY, button, deltaX, deltaY);
    }
    
    @Override
    public void close() {
        this.onClose.run();
    }
    
    private static class ListWidget extends Widget {
        private static final int PADDING = 6;
        private final int width;
        private final int height;
        private final int top;
        private final ScrollingContainer scroller = new ScrollingContainer() {
            @Override
            public Rectangle getBounds() {
                return new Rectangle(0, top, width, height - top);
            }
            
            @Override
            public int getMaxScrollHeight() {
                return getMaxScrollDist();
            }
        };
        private final List<CollapsibleEntryWidget>[] columns;
        private final List<CollapsibleEntryWidget> children = new ArrayList<>();
        
        public ListWidget(int width, int height, int top) {
            this.width = width;
            this.height = height;
            this.top = top;
            this.columns = new List[Math.max(1, (width - 12 - PADDING) / (130 + PADDING))];
            for (int i = 0; i < columns.length; i++) {
                columns[i] = new ArrayList<>();
            }
        }
        
        @Override
        public void render(DrawContext graphics, int mouseX, int mouseY, float delta) {
            this.scroller.updatePosition(delta);
            
            Tessellator tesselator = Tessellator.getInstance();
            BufferBuilder buffer = tesselator.getBuffer();
            DynamicErrorFreeEntryListWidget.renderBackBackground(graphics, buffer, tesselator,
                    Screen.OPTIONS_BACKGROUND_TEXTURE, 0, this.top, this.width, this.height, 0, 32);
            RenderSystem.enableBlend();
            RenderSystem.blendFuncSeparate(770, 771, 0, 1);
            RenderSystem.setShader(GameRenderer::getPositionTexColorProgram);
            Matrix4f matrix = graphics.getMatrices().peek().getPositionMatrix();
            buffer.begin(VertexFormat.DrawMode.field_27382, VertexFormats.POSITION_TEXTURE_COLOR);
            buffer.vertex(matrix, 0, this.top + 4, 0.0F).texture(0, 1).color(0x00000000).next();
            buffer.vertex(matrix, this.width, this.top + 4, 0.0F).texture(1, 1).color(0x00000000).next();
            buffer.vertex(matrix, this.width, this.top, 0.0F).texture(1, 0).color(0xFF000000).next();
            buffer.vertex(matrix, 0, this.top, 0.0F).texture(0, 0).color(0xFF000000).next();
            tesselator.draw();
            RenderSystem.disableBlend();
            
            try (CloseableScissors scissors = scissor(graphics, new Rectangle(0, this.top, this.width - 6, this.height - this.top))) {
                int entryWidth = (this.width - 12 - 6 - PADDING) / this.columns.length - PADDING;
                for (int i = 0; i < this.columns.length; i++) {
                    int x = 6 + PADDING + i * (entryWidth + PADDING);
                    int y = this.top + PADDING - scroller.scrollAmountInt();
                    for (CollapsibleEntryWidget widget : this.columns[i]) {
                        widget.setPosition(x, y);
                        widget.setWidth(entryWidth);
                        widget.render(graphics, mouseX, mouseY, delta);
                        y += widget.getHeight() + PADDING;
                    }
                }
            }
            
            this.scroller.renderScrollBar(graphics);
            
            DynamicErrorFreeEntryListWidget.renderBackBackground(graphics, buffer, tesselator,
                    Screen.OPTIONS_BACKGROUND_TEXTURE, 0, 0, this.width, this.top, 0, 64);
            ScreenOverlayImpl.getInstance().lateRender(graphics, mouseX, mouseY, delta);
        }
        
        private int getMaxScrollDist() {
            return Arrays.stream(this.columns).mapToInt(ListWidget::getHeightOf)
                    .max()
                    .orElse(0)
                    + PADDING * 2;
        }
        
        @Override
        public List<? extends Element> children() {
            return children;
        }
        
        @Override
        public boolean mouseScrolled(double mouseX, double mouseY, double amount) {
            for (CollapsibleEntryWidget widget : children) {
                if (widget.mouseScrolled(mouseX, mouseY, amount)) {
                    return true;
                }
            }
            if (mouseY > this.top) {
                this.scroller.offset(ClothConfigInitializer.getScrollStep() * -amount, true);
                return true;
            } else {
                return false;
            }
        }
        
        @Override
        public boolean mouseClicked(double mouseX, double mouseY, int button) {
            return this.scroller.updateDraggingState(mouseX, mouseY, button) || super.mouseClicked(mouseX, mouseY, button);
        }
        
        @Override
        public boolean mouseDragged(double mouseX, double mouseY, int button, double deltaX, double deltaY) {
            return this.scroller.mouseDragged(mouseX, mouseY, button, deltaX, deltaY) || super.mouseDragged(mouseX, mouseY, button, deltaX, deltaY);
        }
        
        public void clear() {
            this.children.clear();
            for (List<CollapsibleEntryWidget> column : columns) {
                column.clear();
            }
        }
        
        public void add(CollapsibleEntryWidget widget) {
            Arrays.stream(columns)
                    .min(Comparator.comparingInt(ListWidget::getHeightOf))
                    .ifPresent(widgets -> widgets.add(widget));
            this.children.add(widget);
        }
        
        private static int getHeightOf(List<CollapsibleEntryWidget> widgets) {
            int height = 0;
            for (CollapsibleEntryWidget w : widgets) {
                height += w.getHeight() + PADDING;
            }
            return Math.max(0, height - PADDING);
        }
    }
}

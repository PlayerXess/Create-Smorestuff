/*
 * This file is licensed under the MIT License, part of Roughly Enough Items.
 * Copyright (c) 2018, 2019, 2020, 2021, 2022, 2023 shedaniel
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */

package me.shedaniel.rei.plugin.client.favorites;

import com.mojang.serialization.DataResult;
import com.mojang.serialization.Lifecycle;
import me.shedaniel.math.Rectangle;
import me.shedaniel.rei.api.client.REIRuntime;
import me.shedaniel.rei.api.client.config.ConfigObject;
import me.shedaniel.rei.api.client.favorites.CompoundFavoriteRenderer;
import me.shedaniel.rei.api.client.favorites.FavoriteEntry;
import me.shedaniel.rei.api.client.favorites.FavoriteEntryType;
import me.shedaniel.rei.api.client.favorites.FavoriteMenuEntry;
import me.shedaniel.rei.api.client.gui.Renderer;
import me.shedaniel.rei.api.client.gui.widgets.Tooltip;
import me.shedaniel.rei.api.client.gui.widgets.TooltipContext;
import me.shedaniel.rei.api.common.util.CollectionUtils;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.Element;
import net.minecraft.client.sound.PositionedSoundInstance;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.Identifier;
import net.minecraft.world.GameMode;
import org.apache.commons.lang3.StringUtils;
import org.jetbrains.annotations.Nullable;

import java.util.*;
import java.util.function.Supplier;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

public class GameModeFavoriteEntry extends FavoriteEntry {
    public static final Identifier ID = new Identifier("roughlyenoughitems", "gamemode");
    public static final String TRANSLATION_KEY = "favorite.section.gamemode";
    public static final String KEY = "mode";
    @Nullable
    private final GameMode gameMode;
    
    public GameModeFavoriteEntry(@Nullable GameMode gameMode) {
        this.gameMode = gameMode;
    }
    
    @Override
    public boolean isInvalid() {
        return false;
    }
    
    @Override
    public Renderer getRenderer(boolean showcase) {
        if (gameMode == null) {
            List<Renderer> renderers = IntStream.range(0, 4).mapToObj(GameModeFavoriteEntry::getRenderer).collect(Collectors.toList());
            return new CompoundFavoriteRenderer(showcase, renderers, () -> MinecraftClient.getInstance().interactionManager.getCurrentGameMode().getId()) {
                @Override
                @Nullable
                public Tooltip getTooltip(TooltipContext context) {
                    return Tooltip.create(context.getPoint(), Text.translatable("text.rei.gamemode_button.tooltip.dropdown"));
                }
                
                @Override
                public boolean equals(Object o) {
                    if (this == o) return true;
                    if (o == null || getClass() != o.getClass()) return false;
                    return hashCode() == o.hashCode();
                }
                
                @Override
                public int hashCode() {
                    return Objects.hash(getClass(), showcase);
                }
            };
        }
        return getRenderer(gameMode.getId());
    }
    
    private static Renderer getRenderer(int id) {
        GameMode type = GameMode.byId(id);
        return new Renderer() {
            @Override
            public void render(DrawContext graphics, Rectangle bounds, int mouseX, int mouseY, float delta) {
                int color = bounds.contains(mouseX, mouseY) ? 0xFFEEEEEE : 0xFFAAAAAA;
                if (bounds.width > 4 && bounds.height > 4) {
                    graphics.getMatrices().push();
                    graphics.getMatrices().translate(bounds.getCenterX(), bounds.getCenterY(), 0);
                    graphics.getMatrices().scale(bounds.getWidth() / 18f, bounds.getHeight() / 18f, 1);
                    renderGameModeText(graphics, type, 0, 0, color);
                    graphics.getMatrices().pop();
                }
            }
            
            private void renderGameModeText(DrawContext graphics, GameMode type, int centerX, int centerY, int color) {
                Text s = Text.translatable("text.rei.short_gamemode." + type.getName());
                TextRenderer font = MinecraftClient.getInstance().textRenderer;
                graphics.getMatrices().push();
                graphics.getMatrices().translate(centerX - font.getWidth(s) / 2f + 0.5f, centerY - 3.5f, 0);
                graphics.drawText(font, s, 0, 0, color, false);
                graphics.getMatrices().pop();
            }
            
            @Override
            @Nullable
            public Tooltip getTooltip(TooltipContext context) {
                return Tooltip.create(context.getPoint(), Text.translatable("text.rei.gamemode_button.tooltip.entry", type.getTranslatableName().getString()));
            }
            
            @Override
            public boolean equals(Object o) {
                if (this == o) return true;
                if (o == null || getClass() != o.getClass()) return false;
                return hashCode() == o.hashCode();
            }
            
            @Override
            public int hashCode() {
                return Objects.hash(getClass(), false, type);
            }
        };
    }
    
    @Override
    public boolean doAction(int button) {
        if (button == 0) {
            GameMode mode = gameMode;
            if (mode == null) {
                mode = GameMode.byId(MinecraftClient.getInstance().interactionManager.getCurrentGameMode().getId() + 1 % 4);
            }
            MinecraftClient.getInstance().player.networkHandler.sendChatCommand(StringUtils.removeStart(ConfigObject.getInstance().getGamemodeCommand().replaceAll("\\{gamemode}", mode.name().toLowerCase(Locale.ROOT)), "/"));
            MinecraftClient.getInstance().getSoundManager().play(PositionedSoundInstance.master(SoundEvents.field_15015, 1.0F));
            return true;
        }
        return false;
    }
    
    @Override
    public Optional<Supplier<Collection<FavoriteMenuEntry>>> getMenuEntries() {
        if (gameMode == null)
            return Optional.of(this::_getMenuEntries);
        return Optional.empty();
    }
    
    private Collection<FavoriteMenuEntry> _getMenuEntries() {
        return CollectionUtils.filterAndMap(Arrays.asList(GameMode.values()), type -> type.getId() >= 0, GameModeMenuEntry::new);
    }
    
    @Override
    public long hashIgnoreAmount() {
        return gameMode == null ? 31290831290L : gameMode.ordinal();
    }
    
    @Override
    public FavoriteEntry copy() {
        return this;
    }
    
    @Override
    public Identifier getType() {
        return ID;
    }
    
    @Override
    public boolean isSame(FavoriteEntry other) {
        if (!(other instanceof GameModeFavoriteEntry that)) return false;
        return Objects.equals(gameMode, that.gameMode);
    }
    
    public enum Type implements FavoriteEntryType<GameModeFavoriteEntry> {
        INSTANCE;
        
        @Override
        public DataResult<GameModeFavoriteEntry> read(NbtCompound object) {
            String stringValue = object.getString(KEY);
            GameMode type = stringValue.equals("NOT_SET") ? null : GameMode.valueOf(stringValue);
            return DataResult.success(new GameModeFavoriteEntry(type), Lifecycle.stable());
        }
        
        @Override
        public DataResult<GameModeFavoriteEntry> fromArgs(Object... args) {
            if (args.length == 0) return DataResult.error(() -> "Cannot create GameModeFavoriteEntry from empty args!");
            if (!(args[0] instanceof GameMode type))
                return DataResult.error(() -> "Creation of GameModeFavoriteEntry from args expected GameType as the first argument!");
            return DataResult.success(new GameModeFavoriteEntry(type), Lifecycle.stable());
        }
        
        @Override
        public NbtCompound save(GameModeFavoriteEntry entry, NbtCompound tag) {
            tag.putString(KEY, entry.gameMode == null ? "NOT_SET" : entry.gameMode.name());
            return tag;
        }
    }
    
    public static class GameModeMenuEntry extends FavoriteMenuEntry {
        public final String text;
        public final GameMode gameMode;
        private int x, y, width;
        private boolean selected, containsMouse, rendering;
        private int textWidth = -69;
        
        public GameModeMenuEntry(GameMode gameMode) {
            this.text = gameMode.getTranslatableName().getString();
            this.gameMode = gameMode;
        }
        
        private int getTextWidth() {
            if (textWidth == -69) {
                this.textWidth = Math.max(0, font.getWidth(text));
            }
            return this.textWidth;
        }
        
        @Override
        public int getEntryWidth() {
            return getTextWidth() + 4;
        }
        
        @Override
        public int getEntryHeight() {
            return 12;
        }
        
        @Override
        public List<? extends Element> children() {
            return Collections.emptyList();
        }
        
        @Override
        public void updateInformation(int xPos, int yPos, boolean selected, boolean containsMouse, boolean rendering, int width) {
            this.x = xPos;
            this.y = yPos;
            this.selected = selected;
            this.containsMouse = containsMouse;
            this.rendering = rendering;
            this.width = width;
        }
        
        @Override
        public void render(DrawContext graphics, int mouseX, int mouseY, float delta) {
            boolean disabled = this.minecraft.interactionManager.getCurrentGameMode() == gameMode;
            if (selected && !disabled) {
                graphics.fill(x, y, x + width, y + 12, -12237499);
            }
            if (!disabled && selected && containsMouse) {
                REIRuntime.getInstance().queueTooltip(Tooltip.create(Text.translatable("text.rei.gamemode_button.tooltip.entry", text)));
            }
            String s = text;
            if (disabled) {
                s = Formatting.field_1055 + s;
            }
            graphics.drawText(font, s, x + 2, y + 2, selected && !disabled ? 16777215 : 8947848, false);
        }
        
        @Override
        public boolean mouseClicked(double mouseX, double mouseY, int button) {
            boolean disabled = this.minecraft.interactionManager.getCurrentGameMode() == gameMode;
            if (!disabled && rendering && mouseX >= x && mouseX <= x + width && mouseY >= y && mouseY <= y + 12) {
                MinecraftClient.getInstance().player.networkHandler.sendChatCommand(StringUtils.removeStart(ConfigObject.getInstance().getGamemodeCommand().replaceAll("\\{gamemode}", gameMode.name().toLowerCase(Locale.ROOT)), "/"));
                minecraft.getSoundManager().play(PositionedSoundInstance.master(SoundEvents.field_15015, 1.0F));
                closeMenu();
                return true;
            }
            return super.mouseClicked(mouseX, mouseY, button);
        }
    }
}

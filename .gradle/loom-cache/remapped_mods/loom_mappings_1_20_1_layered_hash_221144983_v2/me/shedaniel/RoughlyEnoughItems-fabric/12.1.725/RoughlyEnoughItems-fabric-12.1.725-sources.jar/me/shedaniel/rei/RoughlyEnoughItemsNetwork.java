/*
 * This file is licensed under the MIT License, part of Roughly Enough Items.
 * Copyright (c) 2018, 2019, 2020, 2021, 2022, 2023 shedaniel
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */

package me.shedaniel.rei;

import dev.architectury.networking.NetworkManager;
import dev.architectury.networking.transformers.SplitPacketTransformer;
import io.netty.buffer.Unpooled;
import me.shedaniel.rei.api.common.category.CategoryIdentifier;
import me.shedaniel.rei.api.common.display.Display;
import me.shedaniel.rei.api.common.entry.EntryIngredient;
import me.shedaniel.rei.api.common.entry.EntryStack;
import me.shedaniel.rei.api.common.entry.InputIngredient;
import me.shedaniel.rei.api.common.entry.type.VanillaEntryTypes;
import me.shedaniel.rei.api.common.transfer.info.stack.SlotAccessor;
import me.shedaniel.rei.api.common.transfer.info.stack.SlotAccessorRegistry;
import me.shedaniel.rei.impl.common.transfer.InputSlotCrafter;
import me.shedaniel.rei.impl.common.transfer.LegacyInputSlotCrafter;
import me.shedaniel.rei.impl.common.transfer.NewInputSlotCrafter;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.inventory.Inventory;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.nbt.NbtElement;
import net.minecraft.nbt.NbtList;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.screen.AbstractRecipeScreenHandler;
import net.minecraft.screen.PlayerScreenHandler;
import net.minecraft.screen.ScreenHandler;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.MathHelper;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;

public class RoughlyEnoughItemsNetwork {
    public static final Identifier DELETE_ITEMS_PACKET = new Identifier("roughlyenoughitems", "delete_item");
    public static final Identifier CREATE_ITEMS_PACKET = new Identifier("roughlyenoughitems", "create_item");
    public static final Identifier CREATE_ITEMS_HOTBAR_PACKET = new Identifier("roughlyenoughitems", "create_item_hotbar");
    public static final Identifier CREATE_ITEMS_GRAB_PACKET = new Identifier("roughlyenoughitems", "create_item_grab");
    public static final Identifier CREATE_ITEMS_MESSAGE_PACKET = new Identifier("roughlyenoughitems", "ci_msg");
    public static final Identifier MOVE_ITEMS_PACKET = new Identifier("roughlyenoughitems", "move_items");
    public static final Identifier MOVE_ITEMS_NEW_PACKET = new Identifier("roughlyenoughitems", "move_items_new");
    public static final Identifier NOT_ENOUGH_ITEMS_PACKET = new Identifier("roughlyenoughitems", "og_not_enough");
    
    public static void onInitialize() {
        NetworkManager.registerReceiver(NetworkManager.c2s(), DELETE_ITEMS_PACKET, Collections.singletonList(new SplitPacketTransformer()), (buf, context) -> {
            ServerPlayerEntity player = (ServerPlayerEntity) context.getPlayer();
            if (player.getServer().getPermissionLevel(player.getGameProfile()) < player.getServer().getOpPermissionLevel()) {
                player.sendMessage(Text.translatable("text.rei.no_permission_cheat").formatted(Formatting.field_1061), false);
                return;
            }
            ScreenHandler menu = player.currentScreenHandler;
            if (!menu.getCursorStack().isEmpty()) {
                menu.setCursorStack(ItemStack.EMPTY);
                menu.sendContentUpdates();
            }
        });
        NetworkManager.registerReceiver(NetworkManager.c2s(), CREATE_ITEMS_PACKET, Collections.singletonList(new SplitPacketTransformer()), (buf, context) -> {
            ServerPlayerEntity player = (ServerPlayerEntity) context.getPlayer();
            if (player.getServer().getPermissionLevel(player.getGameProfile()) < player.getServer().getOpPermissionLevel()) {
                player.sendMessage(Text.translatable("text.rei.no_permission_cheat").formatted(Formatting.field_1061), false);
                return;
            }
            ItemStack stack = buf.readItemStack();
            if (player.getInventory().insertStack(stack.copy())) {
                NetworkManager.sendToPlayer(player, RoughlyEnoughItemsNetwork.CREATE_ITEMS_MESSAGE_PACKET, new PacketByteBuf(Unpooled.buffer()).writeItemStack(stack.copy()).writeString(player.getEntityName(), 32767));
            } else {
                player.sendMessage(Text.translatable("text.rei.failed_cheat_items"), false);
            }
        });
        NetworkManager.registerReceiver(NetworkManager.c2s(), CREATE_ITEMS_GRAB_PACKET, Collections.singletonList(new SplitPacketTransformer()), (buf, context) -> {
            ServerPlayerEntity player = (ServerPlayerEntity) context.getPlayer();
            if (player.getServer().getPermissionLevel(player.getGameProfile()) < player.getServer().getOpPermissionLevel()) {
                player.sendMessage(Text.translatable("text.rei.no_permission_cheat").formatted(Formatting.field_1061), false);
                return;
            }
            
            ScreenHandler menu = player.currentScreenHandler;
            ItemStack itemStack = buf.readItemStack();
            ItemStack stack = itemStack.copy();
            if (!menu.getCursorStack().isEmpty() && ItemStack.canCombine(menu.getCursorStack(), stack)) {
                stack.setCount(MathHelper.clamp(stack.getCount() + menu.getCursorStack().getCount(), 1, stack.getMaxCount()));
            } else if (!menu.getCursorStack().isEmpty()) {
                return;
            }
            menu.setCursorStack(stack.copy());
            menu.sendContentUpdates();
            NetworkManager.sendToPlayer(player, RoughlyEnoughItemsNetwork.CREATE_ITEMS_MESSAGE_PACKET, new PacketByteBuf(Unpooled.buffer()).writeItemStack(itemStack.copy()).writeString(player.getEntityName(), 32767));
        });
        NetworkManager.registerReceiver(NetworkManager.c2s(), CREATE_ITEMS_HOTBAR_PACKET, Collections.singletonList(new SplitPacketTransformer()), (buf, context) -> {
            ServerPlayerEntity player = (ServerPlayerEntity) context.getPlayer();
            if (player.getServer().getPermissionLevel(player.getGameProfile()) < player.getServer().getOpPermissionLevel()) {
                player.sendMessage(Text.translatable("text.rei.no_permission_cheat").formatted(Formatting.field_1061), false);
                return;
            }
            ItemStack stack = buf.readItemStack();
            int hotbarSlotId = buf.readVarInt();
            if (hotbarSlotId >= 0 && hotbarSlotId < 9) {
                ScreenHandler menu = player.currentScreenHandler;
                player.getInventory().main.set(hotbarSlotId, stack.copy());
                menu.sendContentUpdates();
                NetworkManager.sendToPlayer(player, RoughlyEnoughItemsNetwork.CREATE_ITEMS_MESSAGE_PACKET, new PacketByteBuf(Unpooled.buffer()).writeItemStack(stack.copy()).writeString(player.getEntityName(), 32767));
            } else {
                player.sendMessage(Text.translatable("text.rei.failed_cheat_items"), false);
            }
        });
        NetworkManager.registerReceiver(NetworkManager.c2s(), MOVE_ITEMS_PACKET, Collections.singletonList(new SplitPacketTransformer()), (packetByteBuf, context) -> {
            ServerPlayerEntity player = (ServerPlayerEntity) context.getPlayer();
            CategoryIdentifier<Display> category = CategoryIdentifier.of(packetByteBuf.readIdentifier());
            ScreenHandler container = player.currentScreenHandler;
            PlayerScreenHandler playerContainer = player.playerScreenHandler;
            try {
                boolean shift = packetByteBuf.readBoolean();
                try {
                    LegacyInputSlotCrafter<ScreenHandler, Inventory, Display> crafter = LegacyInputSlotCrafter.start(category, container, player, packetByteBuf.readUnlimitedNbt(), shift);
                } catch (InputSlotCrafter.NotEnoughMaterialsException e) {
                    if (!(container instanceof AbstractRecipeScreenHandler)) {
                        return;
                    }
                    // TODO Implement Ghost Recipes
                    /*FriendlyByteBuf buf = new FriendlyByteBuf(Unpooled.buffer());
                    buf.writeInt(input.size());
                    for (List<ItemStack> stacks : input) {
                        buf.writeInt(stacks.size());
                        for (ItemStack stack : stacks) {
                            buf.writeItem(stack);
                        }
                    }
                    NetworkManager.sendToPlayer(player, NOT_ENOUGH_ITEMS_PACKET, buf);*/
                } catch (IllegalStateException e) {
                    player.sendMessage(Text.translatable(e.getMessage()).formatted(Formatting.field_1061));
                } catch (Exception e) {
                    player.sendMessage(Text.translatable("error.rei.internal.error", e.getMessage()).formatted(Formatting.field_1061));
                    e.printStackTrace();
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
        NetworkManager.registerReceiver(NetworkManager.c2s(), MOVE_ITEMS_NEW_PACKET, Collections.singletonList(new SplitPacketTransformer()), (packetByteBuf, context) -> {
            ServerPlayerEntity player = (ServerPlayerEntity) context.getPlayer();
            CategoryIdentifier<Display> category = CategoryIdentifier.of(packetByteBuf.readIdentifier());
            ScreenHandler container = player.currentScreenHandler;
            PlayerScreenHandler playerContainer = player.playerScreenHandler;
            try {
                boolean shift = packetByteBuf.readBoolean();
                try {
                    NbtCompound nbt = packetByteBuf.readUnlimitedNbt();
                    int version = nbt.getInt("Version");
                    if (version != 1) throw new IllegalStateException("Server and client REI protocol version mismatch! Server: 1, Client: " + version);
                    List<InputIngredient<ItemStack>> inputs = readInputs(nbt.getList("Inputs", NbtElement.COMPOUND_TYPE));
                    List<SlotAccessor> input = readSlots(container, player, nbt.getList("InputSlots", NbtElement.COMPOUND_TYPE));
                    List<SlotAccessor> inventory = readSlots(container, player, nbt.getList("InventorySlots", NbtElement.COMPOUND_TYPE));
                    NewInputSlotCrafter<ScreenHandler, Inventory> crafter = new NewInputSlotCrafter<>(container, input, inventory, inputs);
                    crafter.fillInputSlots(player, shift);
                } catch (InputSlotCrafter.NotEnoughMaterialsException e) {
                    if (!(container instanceof AbstractRecipeScreenHandler)) {
                        return;
                    }
                } catch (IllegalStateException e) {
                    player.sendMessage(Text.translatable(e.getMessage()).formatted(Formatting.field_1061));
                } catch (Exception e) {
                    player.sendMessage(Text.translatable("error.rei.internal.error", e.getMessage()).formatted(Formatting.field_1061));
                    e.printStackTrace();
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }
    
    private static List<SlotAccessor> readSlots(ScreenHandler menu, PlayerEntity player, NbtList tag) {
        List<SlotAccessor> slots = new ArrayList<>();
        for (NbtElement t : tag) {
            slots.add(SlotAccessorRegistry.getInstance().read(menu, player, (NbtCompound) t));
        }
        return slots;
    }
    
    private static List<InputIngredient<ItemStack>> readInputs(NbtList tag) {
        List<InputIngredient<ItemStack>> inputs = new ArrayList<>();
        for (NbtElement t : tag) {
            NbtCompound compoundTag = (NbtCompound) t;
            InputIngredient<EntryStack<?>> stacks = InputIngredient.of(compoundTag.getInt("Index"), EntryIngredient.read(compoundTag.getList("Ingredient", NbtElement.COMPOUND_TYPE)));
            inputs.add(InputIngredient.withType(stacks, VanillaEntryTypes.ITEM));
        }
        return inputs;
    }
}

/*
 * This file is licensed under the MIT License, part of Roughly Enough Items.
 * Copyright (c) 2018, 2019, 2020, 2021, 2022, 2023 shedaniel
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */

package me.shedaniel.rei.impl.client.config.addon;

import me.shedaniel.clothconfig2.gui.widget.DynamicElementListWidget;
import me.shedaniel.rei.api.client.config.addon.ConfigAddon;
import me.shedaniel.rei.api.client.config.addon.ConfigAddonRegistry;
import me.shedaniel.rei.impl.client.gui.InternalTextures;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.Element;
import net.minecraft.client.gui.Selectable;
import net.minecraft.client.gui.navigation.GuiNavigation;
import net.minecraft.client.gui.navigation.GuiNavigationPath;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.StringVisitable;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import net.minecraft.util.Language;
import org.jetbrains.annotations.Nullable;

import java.util.Collections;
import java.util.List;
import java.util.function.Supplier;

public class ConfigAddonsScreen extends Screen {
    private AddonsList rulesList;
    private final Screen parent;
    
    public ConfigAddonsScreen(Screen parent) {
        super(Text.translatable("text.rei.addons"));
        this.parent = parent;
    }
    
    @Override
    public void init() {
        super.init();
        {
            Text backText = Text.literal("↩ ").append(Text.translatable("gui.back"));
            addDrawableChild(ButtonWidget.builder(backText, button -> {
                client.setScreen(parent);
            }).dimensions(4, 4, MinecraftClient.getInstance().textRenderer.getWidth(backText) + 10, 20).build());
        }
        rulesList = addSelectableChild(new AddonsList(client, width, height, 30, height, OPTIONS_BACKGROUND_TEXTURE));
        ConfigAddonRegistryImpl addonRegistry = (ConfigAddonRegistryImpl) ConfigAddonRegistry.getInstance();
        for (ConfigAddon addon : addonRegistry.getAddons()) {
            rulesList.addItem(new DefaultAddonEntry(parent, addon));
        }
    }
    
    @Override
    public void render(DrawContext graphics, int mouseX, int mouseY, float delta) {
        this.rulesList.render(graphics, mouseX, mouseY, delta);
        super.render(graphics, mouseX, mouseY, delta);
        graphics.drawTextWithShadow(this.textRenderer, this.title.asOrderedText(), (int) (this.width / 2.0F - this.textRenderer.getWidth(this.title) / 2.0F), 12, -1);
    }
    
    public static class AddonsList extends DynamicElementListWidget<AddonEntry> {
        private boolean inFocus;
        
        public AddonsList(MinecraftClient client, int width, int height, int top, int bottom, Identifier backgroundLocation) {
            super(client, width, height, top, bottom, backgroundLocation);
        }
        
        @Override
        protected boolean isSelected(int index) {
            return false;
        }
        
        @Override
        protected int addItem(AddonEntry item) {
            return super.addItem(item);
        }
        
        @Override
        public int getItemWidth() {
            return width - 40;
        }
        
        @Override
        protected int getScrollbarPosition() {
            return width - 14;
        }
    }
    
    public static abstract class AddonEntry extends DynamicElementListWidget.ElementEntry<AddonEntry> {
        @Override
        public int getItemHeight() {
            return 26;
        }
        
        @Override
        @Nullable
        public GuiNavigationPath getNavigationPath(GuiNavigation focusNavigationEvent) {
            return null;
        }
    }
    
    public static class DefaultAddonEntry extends AddonEntry {
        private final ButtonWidget configureButton;
        private final ConfigAddon addon;
        
        public DefaultAddonEntry(Screen parent, ConfigAddon addon) {
            this.addon = addon;
            this.configureButton = new ButtonWidget(0, 0, 20, 20, Text.of(null), button -> {
                MinecraftClient.getInstance().setScreen(this.addon.createScreen(MinecraftClient.getInstance().currentScreen));
            }, Supplier::get) {
                @Override
                public void render(DrawContext graphics, int mouseX, int mouseY, float delta) {
                    super.render(graphics, mouseX, mouseY, delta);
                    graphics.drawTexture(InternalTextures.CHEST_GUI_TEXTURE, getX() + 3, getY() + 3, 0, 0, 14, 14);
                }
            };
        }
        
        @Override
        public void render(DrawContext graphics, int index, int y, int x, int entryWidth, int entryHeight, int mouseX, int mouseY, boolean isHovered, float delta) {
            MinecraftClient client = MinecraftClient.getInstance();
            {
                Text title = addon.getName();
                int i = client.textRenderer.getWidth(title);
                if (i > entryWidth - 28) {
                    StringVisitable titleTrimmed = StringVisitable.concat(client.textRenderer.trimToWidth(title, entryWidth - 28 - client.textRenderer.getWidth("...")), StringVisitable.plain("..."));
                    graphics.drawTextWithShadow(client.textRenderer, Language.getInstance().reorder(titleTrimmed), x + 2, y + 1, 16777215);
                } else {
                    graphics.drawTextWithShadow(client.textRenderer, title.asOrderedText(), x + 2, y + 1, 16777215);
                }
            }
            {
                Text subtitle = addon.getDescription();
                int i = client.textRenderer.getWidth(subtitle);
                if (i > entryWidth - 28) {
                    StringVisitable subtitleTrimmed = StringVisitable.concat(client.textRenderer.trimToWidth(subtitle, entryWidth - 28 - client.textRenderer.getWidth("...")), StringVisitable.plain("..."));
                    graphics.drawTextWithShadow(client.textRenderer, Language.getInstance().reorder(subtitleTrimmed), x + 2, y + 12, 8421504);
                } else {
                    graphics.drawTextWithShadow(client.textRenderer, subtitle.asOrderedText(), x + 2, y + 12, 8421504);
                }
            }
            configureButton.method_46421(x + entryWidth - 25);
            configureButton.method_46419(y + 1);
            configureButton.render(graphics, mouseX, mouseY, delta);
        }
        
        @Override
        public List<? extends Element> children() {
            return Collections.singletonList(configureButton);
        }
        
        @Override
        public List<? extends Selectable> narratables() {
            return Collections.singletonList(configureButton);
        }
    }
}

/*
 * This file is licensed under the MIT License, part of Roughly Enough Items.
 * Copyright (c) 2018, 2019, 2020, 2021, 2022, 2023 shedaniel
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */

package me.shedaniel.rei.plugin.client.entry;

import com.google.common.base.Suppliers;
import com.google.common.collect.Lists;
import dev.architectury.fluid.FluidStack;
import dev.architectury.hooks.fluid.FluidStackHooks;
import dev.architectury.platform.Platform;
import dev.architectury.utils.Env;
import dev.architectury.utils.EnvExecutor;
import me.shedaniel.math.Rectangle;
import me.shedaniel.rei.api.client.entry.renderer.BatchedEntryRenderer;
import me.shedaniel.rei.api.client.entry.renderer.EntryRenderer;
import me.shedaniel.rei.api.client.gui.widgets.Tooltip;
import me.shedaniel.rei.api.client.gui.widgets.TooltipContext;
import me.shedaniel.rei.api.client.util.SpriteRenderer;
import me.shedaniel.rei.api.common.entry.EntrySerializer;
import me.shedaniel.rei.api.common.entry.EntryStack;
import me.shedaniel.rei.api.common.entry.comparison.ComparisonContext;
import me.shedaniel.rei.api.common.entry.comparison.FluidComparatorRegistry;
import me.shedaniel.rei.api.common.entry.type.EntryDefinition;
import me.shedaniel.rei.api.common.entry.type.EntryType;
import me.shedaniel.rei.api.common.entry.type.VanillaEntryTypes;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.OverlayTexture;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.resource.language.I18n;
import net.minecraft.client.texture.MissingSprite;
import net.minecraft.client.texture.Sprite;
import net.minecraft.client.texture.SpriteAtlasTexture;
import net.minecraft.fluid.FlowableFluid;
import net.minecraft.fluid.Fluid;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.registry.Registries;
import net.minecraft.registry.tag.TagKey;
import net.minecraft.screen.PlayerScreenHandler;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.Identifier;
import net.minecraft.util.crash.CrashReport;
import net.minecraft.util.crash.CrashReportSection;
import net.minecraft.util.math.MathHelper;
import org.jetbrains.annotations.Nullable;

import java.util.List;
import java.util.function.Supplier;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class FluidEntryDefinition implements EntryDefinition<FluidStack>, EntrySerializer<FluidStack> {
    private static final String FLUID_AMOUNT = Platform.isForge() ? "tooltip.rei.fluid_amount.forge" : "tooltip.rei.fluid_amount";
    @Environment(EnvType.CLIENT)
    private EntryRenderer<FluidStack> renderer;
    
    public FluidEntryDefinition() {
        EnvExecutor.runInEnv(Env.CLIENT, () -> () -> Client.init(this));
    }
    
    @Environment(EnvType.CLIENT)
    private static class Client {
        private static void init(FluidEntryDefinition definition) {
            definition.renderer = new FluidEntryRenderer();
        }
    }
    
    @Override
    public Class<FluidStack> getValueType() {
        return FluidStack.class;
    }
    
    @Override
    public EntryType<FluidStack> getType() {
        return VanillaEntryTypes.FLUID;
    }
    
    @Override
    @Environment(EnvType.CLIENT)
    public EntryRenderer<FluidStack> getRenderer() {
        return renderer;
    }
    
    @Override
    @Nullable
    public Identifier getIdentifier(EntryStack<FluidStack> entry, FluidStack value) {
        return Registries.FLUID.getId(value.getFluid());
    }
    
    @Override
    public boolean isEmpty(EntryStack<FluidStack> entry, FluidStack value) {
        return value.isEmpty();
    }
    
    @Override
    public FluidStack copy(EntryStack<FluidStack> entry, FluidStack value) {
        return value.copy();
    }
    
    @Override
    public FluidStack normalize(EntryStack<FluidStack> entry, FluidStack value) {
        Fluid fluid = value.getFluid();
        if (fluid instanceof FlowableFluid flowingFluid) fluid = flowingFluid.getStill();
        return FluidStack.create(fluid, FluidStack.bucketAmount(), value.getTag());
    }
    
    @Override
    public FluidStack wildcard(EntryStack<FluidStack> entry, FluidStack value) {
        Fluid fluid = value.getFluid();
        if (fluid instanceof FlowableFluid) fluid = ((FlowableFluid) fluid).getStill();
        return FluidStack.create(fluid, FluidStack.bucketAmount());
    }
    
    @Override
    @Nullable
    public ItemStack cheatsAs(EntryStack<FluidStack> entry, FluidStack value) {
        if (value.isEmpty()) return ItemStack.EMPTY;
        Item bucket = value.getFluid().getBucketItem();
        if (bucket == null) return ItemStack.EMPTY;
        return new ItemStack(bucket);
    }
    
    @Nullable
    @Override
    public FluidStack add(FluidStack o1, FluidStack o2) {
        return o1.copyWithAmount(o1.getAmount() + o2.getAmount());
    }
    
    @Override
    public long hash(EntryStack<FluidStack> entry, FluidStack value, ComparisonContext context) {
        int code = 1;
        code = 31 * code + value.getFluid().hashCode();
        code = 31 * code + Long.hashCode(FluidComparatorRegistry.getInstance().hashOf(context, value));
        return code;
    }
    
    @Override
    public boolean equals(FluidStack o1, FluidStack o2, ComparisonContext context) {
        if (o1.getFluid() != o2.getFluid())
            return false;
        return FluidComparatorRegistry.getInstance().hashOf(context, o1) == FluidComparatorRegistry.getInstance().hashOf(context, o2);
    }
    
    @Override
    @Nullable
    public EntrySerializer<FluidStack> getSerializer() {
        return this;
    }
    
    @Override
    public boolean supportSaving() {
        return true;
    }
    
    @Override
    public boolean supportReading() {
        return true;
    }
    
    @Override
    public boolean acceptsNull() {
        return false;
    }
    
    @Override
    public NbtCompound save(EntryStack<FluidStack> entry, FluidStack value) {
        return value.write(new NbtCompound());
    }
    
    @Override
    public FluidStack read(NbtCompound tag) {
        return FluidStack.read(tag);
    }
    
    @Override
    public Text asFormattedText(EntryStack<FluidStack> entry, FluidStack value) {
        return value.getName();
    }
    
    @Override
    public Stream<? extends TagKey<?>> getTagsFor(EntryStack<FluidStack> entry, FluidStack value) {
        return value.getFluid().getRegistryEntry().streamTags();
    }
    
    @Override
    public void fillCrashReport(CrashReport report, CrashReportSection category, EntryStack<FluidStack> entry) {
        EntryDefinition.super.fillCrashReport(report, category, entry);
        FluidStack stack = entry.getValue();
        category.add("Fluid Type", () -> String.valueOf(Registries.FLUID.getId(stack.getFluid())));
        category.add("Fluid Amount", () -> String.valueOf(stack.getAmount()));
        category.add("Fluid NBT", () -> String.valueOf(stack.getTag()));
    }
    
    @Environment(EnvType.CLIENT)
    public static class FluidEntryRenderer implements BatchedEntryRenderer<FluidStack, Sprite> {
        private static final Supplier<Sprite> MISSING_SPRITE = Suppliers.memoize(() -> {
            SpriteAtlasTexture atlas = MinecraftClient.getInstance().getBakedModelManager().getAtlas(SpriteAtlasTexture.BLOCK_ATLAS_TEXTURE);
            return atlas.getSprite(MissingSprite.getMissingSpriteId());
        });
        
        @Override
        public Sprite getExtraData(EntryStack<FluidStack> entry) {
            FluidStack stack = entry.getValue();
            if (stack.isEmpty()) return null;
            return FluidStackHooks.getStillTexture(stack);
        }
        
        private Sprite missingTexture() {
            return MISSING_SPRITE.get();
        }
        
        @Override
        public int getBatchIdentifier(EntryStack<FluidStack> entry, Rectangle bounds, Sprite extraData) {
            return 0;
        }
        
        @Override
        public void startBatch(EntryStack<FluidStack> entry, Sprite extraData, DrawContext graphics, float delta) {}
        
        @Override
        public void renderBase(EntryStack<FluidStack> entry, Sprite sprite, DrawContext graphics, VertexConsumerProvider.Immediate immediate, Rectangle bounds, int mouseX, int mouseY, float delta) {
            Sprite s = sprite == null ? missingTexture() : sprite;
            SpriteRenderer.beginPass()
                    .setup(immediate, RenderLayer.getSolid())
                    .sprite(s)
                    .color(sprite == null ? 0xFFFFFF : FluidStackHooks.getColor(entry.getValue()))
                    .light(0x00f000f0)
                    .overlay(OverlayTexture.DEFAULT_UV)
                    .alpha(0xff)
                    .normal(graphics.getMatrices().peek().getNormalMatrix(), 0, 0, 0)
                    .position(graphics.getMatrices().peek().getPositionMatrix(), bounds.x, bounds.getMaxY() - bounds.height * MathHelper.clamp(entry.get(EntryStack.Settings.FLUID_RENDER_RATIO), 0, 1), bounds.getMaxX(), bounds.getMaxY(), 0)
                    .next(s.getAtlasId());
        }
        
        @Override
        public void afterBase(EntryStack<FluidStack> entry, Sprite extraData, DrawContext graphics, float delta) {}
        
        @Override
        public void renderOverlay(EntryStack<FluidStack> entry, Sprite extraData, DrawContext graphics, VertexConsumerProvider.Immediate immediate, Rectangle bounds, int mouseX, int mouseY, float delta) {}
        
        @Override
        public void endBatch(EntryStack<FluidStack> entry, Sprite extraData, DrawContext graphics, float delta) {}
        
        @Override
        public void render(EntryStack<FluidStack> entry, DrawContext graphics, Rectangle bounds, int mouseX, int mouseY, float delta) {
            FluidStack stack = entry.getValue();
            if (stack.isEmpty()) return;
            Sprite sprite = FluidStackHooks.getStillTexture(stack);
            if (sprite == null) return;
            int color = FluidStackHooks.getColor(stack);
            
            VertexConsumerProvider.Immediate immediate = MinecraftClient.getInstance().getBufferBuilders().getEntityVertexConsumers();
            
            SpriteRenderer.beginPass()
                    .setup(immediate, RenderLayer.getSolid())
                    .sprite(sprite)
                    .color(color)
                    .light(0x00f000f0)
                    .overlay(OverlayTexture.DEFAULT_UV)
                    .alpha(0xff)
                    .normal(graphics.getMatrices().peek().getNormalMatrix(), 0, 0, 0)
                    .position(graphics.getMatrices().peek().getPositionMatrix(), bounds.x, bounds.getMaxY() - bounds.height * MathHelper.clamp(entry.get(EntryStack.Settings.FLUID_RENDER_RATIO), 0, 1), bounds.getMaxX(), bounds.getMaxY(), 0)
                    .next(PlayerScreenHandler.BLOCK_ATLAS_TEXTURE);
            
            immediate.draw();
        }
        
        @Override
        @Nullable
        public Tooltip getTooltip(EntryStack<FluidStack> entry, TooltipContext context) {
            if (entry.isEmpty())
                return null;
            List<Text> toolTip = Lists.newArrayList(entry.asFormattedText());
            long amount = entry.getValue().getAmount();
            if (amount >= 0 && entry.get(EntryStack.Settings.FLUID_AMOUNT_VISIBLE)) {
                String amountTooltip = I18n.translate(FLUID_AMOUNT, entry.getValue().getAmount());
                if (amountTooltip != null) {
                    toolTip.addAll(Stream.of(amountTooltip.split("\n")).map(Text::literal).collect(Collectors.toList()));
                }
            }
            if (MinecraftClient.getInstance().options.advancedItemTooltips) {
                Identifier fluidId = Registries.FLUID.getId(entry.getValue().getFluid());
                toolTip.add((Text.literal(fluidId.toString())).formatted(Formatting.field_1063));
            }
            return Tooltip.create(toolTip);
        }
    }
}

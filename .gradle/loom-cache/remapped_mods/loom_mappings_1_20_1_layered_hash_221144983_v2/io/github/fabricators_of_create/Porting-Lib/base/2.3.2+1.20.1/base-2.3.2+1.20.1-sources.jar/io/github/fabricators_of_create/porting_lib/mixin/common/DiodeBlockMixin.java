package io.github.fabricators_of_create.porting_lib.mixin.common;

import io.github.fabricators_of_create.porting_lib.event.common.BlockEvents;
import net.minecraft.block.AbstractRedstoneGateBlock;
import net.minecraft.block.BlockState;
import net.minecraft.block.HorizontalFacingBlock;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.world.World;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(AbstractRedstoneGateBlock.class)
public class DiodeBlockMixin {
	@Inject(method = "updateNeighborsInFront", at = @At("HEAD"), cancellable = true)
	private void notifyNeighborsEvent(World pLevel, BlockPos pPos, BlockState blockState, CallbackInfo ci) {
		Direction direction = blockState.get(HorizontalFacingBlock.FACING);
		BlockEvents.NeighborNotifyEvent event = new BlockEvents.NeighborNotifyEvent(pLevel, pPos, pLevel.getBlockState(pPos), java.util.EnumSet.of(direction.getOpposite()), false);
		event.sendEvent();
		if (event.isCanceled())
			ci.cancel();
	}
}

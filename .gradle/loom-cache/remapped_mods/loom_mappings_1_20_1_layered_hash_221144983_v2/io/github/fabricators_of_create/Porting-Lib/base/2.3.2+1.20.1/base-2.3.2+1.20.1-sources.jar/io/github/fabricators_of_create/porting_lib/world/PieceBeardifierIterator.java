package io.github.fabricators_of_create.porting_lib.world;

import java.util.Iterator;
import java.util.NoSuchElementException;
import net.minecraft.structure.StructurePiece;
import net.minecraft.world.gen.StructureTerrainAdaptation;
import net.minecraft.world.gen.StructureWeightSampler;
import it.unimi.dsi.fastutil.objects.ObjectList;

public class PieceBeardifierIterator implements Iterator<StructurePiece> {
	private final Iterator<? extends StructurePiece> wrapped;
	private final ObjectList<StructureWeightSampler.Piece> rigids;

	private StructurePiece next;
	private boolean nextChecked;

	public PieceBeardifierIterator(Iterator<? extends StructurePiece> iterator, ObjectList<StructureWeightSampler.Piece> rigids) {
		wrapped = iterator;
		this.rigids = rigids;
	}

	@Override
	public boolean hasNext() {
		ensureNextChecked();
		return next != null;
	}

	@Override
	public StructurePiece next() {
		ensureNextChecked();
		if (next == null) {
			throw new NoSuchElementException();
		}
		nextChecked = false;
		return next;
	}

	@Override
	public void remove() {
		wrapped.remove();
	}

	private void ensureNextChecked() {
		if (!nextChecked) {
			next = nextPiece();
			nextChecked = true;
		}
	}

	private StructurePiece nextPiece() {
		while (true) {
			if (wrapped.hasNext()) {
				StructurePiece next = wrapped.next();
				if (next instanceof PieceBeardifierModifier modifier) {
					if (modifier.getTerrainAdjustment() != StructureTerrainAdaptation.field_28922) {
						rigids.add(new StructureWeightSampler.Piece(modifier.getBeardifierBox(), modifier.getTerrainAdjustment(), modifier.getGroundLevelDelta()));
					}
				} else {
					return next;
				}
			} else {
				return null;
			}
		}
	}
}

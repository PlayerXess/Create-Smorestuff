package io.github.fabricators_of_create.porting_lib.entity.extensions;

import javax.annotation.Nullable;
import net.minecraft.block.BlockState;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.BlockPos;

public interface PlayerExtension {
	default float getDigSpeed(BlockState state, @Nullable BlockPos pos) {
		setDigSpeedContext(pos);
		return ((PlayerEntity) this).getBlockBreakingSpeed(state);
	}

	default void setDigSpeedContext(@Nullable BlockPos pos) {
		throw new RuntimeException("this should be overridden via mixin. what?");
	}
}

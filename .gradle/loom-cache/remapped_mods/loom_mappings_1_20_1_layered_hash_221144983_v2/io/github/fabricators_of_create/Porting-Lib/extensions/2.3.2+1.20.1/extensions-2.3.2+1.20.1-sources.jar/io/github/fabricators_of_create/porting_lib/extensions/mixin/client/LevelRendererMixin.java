package io.github.fabricators_of_create.porting_lib.extensions.mixin.client;

import net.minecraft.client.render.Camera;
import net.minecraft.client.render.LightmapTextureManager;
import net.minecraft.client.render.WorldRenderer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.client.world.ClientWorld;
import org.jetbrains.annotations.Nullable;
import org.joml.Matrix4f;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(WorldRenderer.class)
public class LevelRendererMixin {
	@Shadow
	@Nullable
	private ClientWorld level;

	@Shadow
	private int ticks;

	@Inject(method = "tickRain", at = @At("HEAD"), cancellable = true)
	private void port_lib$customRainTick(Camera camera, CallbackInfo ci) {
		if (level.getDimensionEffects().tickRain(level, ticks, camera))
			ci.cancel();
	}

	@Inject(method = "renderClouds", at = @At("HEAD"), cancellable = true)
	private void renderCustomClouds(MatrixStack pPoseStack, Matrix4f pProjectionMatrix, float pPartialTick, double pCamX, double pCamY, double pCamZ, CallbackInfo ci) {
		if (level.getDimensionEffects().renderClouds(level, ticks, pPartialTick, pPoseStack, pCamX, pCamY, pCamZ, pProjectionMatrix))
			ci.cancel();
	}

	@Inject(method = "renderSky", at = @At("HEAD"), cancellable = true)
	private void renderCustomSky(MatrixStack pPoseStack, Matrix4f pProjectionMatrix, float pPartialTick, Camera pCamera, boolean pIsFoggy, Runnable pSkyFogSetup, CallbackInfo ci) {
		if (level.getDimensionEffects().renderSky(level, ticks, pPartialTick, pPoseStack, pCamera, pProjectionMatrix, pIsFoggy, pSkyFogSetup))
			ci.cancel();
	}

	@Inject(method = "renderSnowAndRain", at = @At("HEAD"), cancellable = true)
	private void renderCustomWeather(LightmapTextureManager pLightTexture, float pPartialTick, double pCamX, double pCamY, double pCamZ, CallbackInfo ci) {
		if (level.getDimensionEffects().renderSnowAndRain(level, ticks, pPartialTick, pLightTexture, pCamX, pCamY, pCamZ))
			ci.cancel();
	}
}

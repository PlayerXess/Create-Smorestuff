package io.github.fabricators_of_create.porting_lib.brewing;

import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.recipe.BrewingRecipeRegistry;

/**
 * Used in BrewingRecipeRegistry to maintain the vanilla behaviour.
 *
 * Most of the code was simply adapted from {@link net.minecraft.block.entity.BrewingStandBlockEntity}
 */
public class VanillaBrewingRecipe implements IBrewingRecipe {

	/**
	 * Code adapted from TileEntityBrewingStand.isItemValidForSlot(int index, ItemStack stack)
	 */
	@Override
	public boolean isInput(ItemStack stack) {
		Item item = stack.getItem();
		return item == Items.field_8574 || item == Items.field_8436 || item == Items.field_8150 || item == Items.field_8469;
	}

	/**
	 * Code adapted from TileEntityBrewingStand.isItemValidForSlot(int index, ItemStack stack)
	 */
	@Override
	public boolean isIngredient(ItemStack stack) {
		return BrewingRecipeRegistry.isValidIngredient(stack);
	}

	/**
	 * Code copied from TileEntityBrewingStand.brewPotions()
	 * It brews the potion by doing the bit-shifting magic and then checking if the new PotionEffect list is different to the old one,
	 * or if the new potion is a splash potion when the old one wasn't.
	 */
	@Override
	public ItemStack getOutput(ItemStack input, ItemStack ingredient) {
		if (!input.isEmpty() && !ingredient.isEmpty() && isIngredient(ingredient)) {
			ItemStack result = BrewingRecipeRegistry.craft(ingredient, input);
			if (result != input) {
				return result;
			}
			return ItemStack.EMPTY;
		}

		return ItemStack.EMPTY;
	}
}

package io.github.fabricators_of_create.porting_lib.mixin.client.frex;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;

import io.github.fabricators_of_create.porting_lib.util.client.ClientHooks;
import io.vram.frex.base.renderer.context.render.EntityBlockRenderContext;
import net.minecraft.block.BlockState;
import net.minecraft.client.render.RenderLayer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(EntityBlockRenderContext.class)
public class EntityBlockRenderContextMixin {
	@WrapOperation(method = "render", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/renderer/ItemBlockRenderTypes;getRenderType(Lnet/minecraft/world/level/block/state/BlockState;Z)Lnet/minecraft/client/renderer/RenderType;"))
	private RenderLayer useCustomRenderType(BlockState state, boolean fancy, Operation<RenderLayer> operation) {
		if (ClientHooks.RENDER_TYPE != null)
			return ClientHooks.RENDER_TYPE;
		return operation.call(state, fancy);
	}
}

package io.github.fabricators_of_create.porting_lib.tool.mixin;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;

import io.github.fabricators_of_create.porting_lib.tool.ToolActions;
import io.github.fabricators_of_create.porting_lib.tool.addons.ToolActionItem;
import net.minecraft.entity.ai.brain.task.RemoveOffHandItemTask;
import net.minecraft.entity.mob.PiglinEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.server.world.ServerWorld;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(RemoveOffHandItemTask.class)
public class StopHoldingItemIfNoLongerAdmiringMixin {
	@ModifyExpressionValue(method = "method_47299", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/item/ItemStack;is(Lnet/minecraft/world/item/Item;)Z"))
	private static boolean isToolActionBlocking(boolean original, ServerWorld level, PiglinEntity piglin) {
		ItemStack offHand = piglin.getOffHandStack();
		if (offHand.getItem() instanceof ToolActionItem)
			return offHand.canPerformAction(ToolActions.SHIELD_BLOCK);
		return original;
	}
}

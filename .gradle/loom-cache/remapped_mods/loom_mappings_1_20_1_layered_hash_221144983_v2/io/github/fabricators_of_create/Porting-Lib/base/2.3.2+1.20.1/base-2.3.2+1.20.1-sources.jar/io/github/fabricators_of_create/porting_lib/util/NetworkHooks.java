package io.github.fabricators_of_create.porting_lib.util;

import java.util.function.Consumer;

import io.github.fabricators_of_create.porting_lib.core.PortingLib;
import io.github.fabricators_of_create.porting_lib.mixin.accessors.common.accessor.ServerPlayerAccessor;
import io.netty.buffer.Unpooled;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.registry.Registries;
import net.minecraft.screen.NamedScreenHandlerFactory;
import net.minecraft.screen.ScreenHandler;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;

public class NetworkHooks {
	public static final Identifier OPEN_ID = PortingLib.id("open_screen");

	/**
	 * Request to open a GUI on the client, from the server
	 *
	 * @param player The player to open the GUI for
	 * @param containerSupplier A supplier creating a menu instance on the server.
	 */
	public static void openScreen(ServerPlayerEntity player, NamedScreenHandlerFactory containerSupplier) {
		openScreen(player, containerSupplier, buf -> {});
	}

	/**
	 * Request to open a GUI on the client, from the server
	 *
	 * @param player The player to open the GUI for
	 * @param containerProvider A supplier creating a menu instance on the server.
	 * @param pos A block pos, which will be encoded into the auxillary data for this request
	 */
	public static void openScreen(ServerPlayerEntity player, NamedScreenHandlerFactory containerProvider, BlockPos pos) {
		openScreen(player, containerProvider, buf -> buf.writeBlockPos(pos));
	}

	/**
	 * Request to open a GUI on the client, from the server
	 *
	 * @param player The player to open the GUI for
	 * @param factory A supplier creating a menu instance on the server.
	 * @param extraDataWriter Consumer to write any additional data the GUI needs
	 */
	public static void openScreen(ServerPlayerEntity player, NamedScreenHandlerFactory factory, Consumer<PacketByteBuf> extraDataWriter) {
		player.onHandledScreenClosed();
		((ServerPlayerAccessor)player).callNextContainerCounter();
		int openContainerId = ((ServerPlayerAccessor)player).getContainerCounter();

		PacketByteBuf extraData = new PacketByteBuf(Unpooled.buffer());
		extraDataWriter.accept(extraData);
		extraData.readerIndex(0); // reset to beginning in case modders read for whatever reason
		PacketByteBuf buf = new PacketByteBuf(Unpooled.buffer());
		ScreenHandler menu = factory.createMenu(openContainerId, player.getInventory(), player);
		buf.writeVarInt(Registries.SCREEN_HANDLER.getRawId(menu.getType()));
		buf.writeVarInt(openContainerId);
		buf.writeText(factory.getDisplayName());
		buf.writeVarInt(extraData.readableBytes());
		buf.writeBytes(extraData);

		ServerPlayNetworking.send(player, OPEN_ID, buf);

		player.currentScreenHandler = menu;
		((ServerPlayerAccessor)player).callInitMenu(menu);
	}
}

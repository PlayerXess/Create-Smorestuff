package io.github.fabricators_of_create.porting_lib.mixin.client;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;

import io.github.fabricators_of_create.porting_lib.util.client.ClientHooks;
import net.minecraft.block.BlockState;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.block.BlockRenderManager;

@Mixin(BlockRenderManager.class)
public class BlockRenderDispatcherMixin {
	@WrapOperation(method = "renderSingleBlock", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/renderer/ItemBlockRenderTypes;getRenderType(Lnet/minecraft/world/level/block/state/BlockState;Z)Lnet/minecraft/client/renderer/RenderType;"))
	private RenderLayer useCustomRenderType(BlockState state, boolean fancy, Operation<RenderLayer> operation) {
		if (ClientHooks.RENDER_TYPE != null)
			return ClientHooks.RENDER_TYPE;
		return operation.call(state, fancy);
	}
}

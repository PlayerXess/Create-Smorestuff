package io.github.fabricators_of_create.porting_lib.mixin.common;

import java.util.List;
import java.util.Objects;
import net.minecraft.structure.StructurePlacementData;
import net.minecraft.structure.StructureTemplate;
import net.minecraft.structure.StructureTemplate.StructureEntityInfo;
import net.minecraft.util.BlockMirror;
import net.minecraft.util.BlockRotation;
import net.minecraft.util.math.BlockBox;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.math.random.Random;
import net.minecraft.world.ServerWorldAccess;
import net.minecraft.world.WorldAccess;
import com.llamalad7.mixinextras.injector.ModifyExpressionValue;

import com.llamalad7.mixinextras.sugar.Local;

import io.github.fabricators_of_create.porting_lib.core.PortingLib;
import io.github.fabricators_of_create.porting_lib.util.StructureTemplateUtils;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;

import io.github.fabricators_of_create.porting_lib.extensions.extensions.StructureTemplateExtensions;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(StructureTemplate.class)
public abstract class StructureTemplateMixin implements StructureTemplateExtensions {
	@Shadow
	@Final
	private List<StructureEntityInfo> entityInfoList;

	@Shadow
	protected abstract void placeEntities(ServerWorldAccess serverLevelAccessor, BlockPos blockPos, BlockMirror mirror, BlockRotation rotation, BlockPos blockPos2, @Nullable BlockBox boundingBox, boolean bl);

	@Unique
	private static final ThreadLocal<StructurePlacementData> currentSettings = new ThreadLocal<>();

	@Inject(
			method = "placeInWorld",
			at = @At(
					value = "INVOKE",
					target = "Lnet/minecraft/world/level/levelgen/structure/templatesystem/StructureTemplate;placeEntities(Lnet/minecraft/world/level/ServerLevelAccessor;Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/Mirror;Lnet/minecraft/world/level/block/Rotation;Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/levelgen/structure/BoundingBox;Z)V"
			)
	)
	private void grabSettings(ServerWorldAccess level, BlockPos pos, BlockPos pivot, StructurePlacementData settings,
							  Random random, int i, CallbackInfoReturnable<Boolean> cir) {
		currentSettings.set(settings);
	}

	@ModifyExpressionValue(
			method = "placeEntities",
			at = @At(
					value = "FIELD",
					target = "Lnet/minecraft/world/level/levelgen/structure/templatesystem/StructureTemplate;entityInfoList:Ljava/util/List;"
			)
	)
	private List<StructureEntityInfo> processEntityInfos(List<StructureEntityInfo> original,
														 ServerWorldAccess level, BlockPos pos, BlockMirror mirror, BlockRotation rotation,
														 BlockPos pivot, @Nullable BlockBox bounds, boolean finalizeMobs) {
		StructurePlacementData settings = currentSettings.get();

		if (PortingLib.DEBUG)
			Objects.requireNonNull(settings);

		if (settings == null)
			return original;

		return StructureTemplateUtils.processEntityInfos(
				(StructureTemplate) (Object) this, level, pos, settings, original
		);
	}

	@ModifyExpressionValue(
			method = "placeEntities",
			at = @At(
					value = "INVOKE",
					target = "Lnet/minecraft/core/BlockPos;offset(Lnet/minecraft/core/Vec3i;)Lnet/minecraft/core/BlockPos;"
			)
	)
	private BlockPos dontProcessBlockPosTwice(BlockPos original, @Local StructureEntityInfo info) {
		StructurePlacementData settings = currentSettings.get();
		if (settings != null) { // pos was already processed.
			return info.blockPos;
		}
		return original;
	}

	@ModifyExpressionValue(
			method = "placeEntities",
			at = @At(
					value = "INVOKE",
					target = "Lnet/minecraft/world/phys/Vec3;add(DDD)Lnet/minecraft/world/phys/Vec3;"
			)
	)
	private Vec3d dontProcessVecTwice(Vec3d original, @Local StructureEntityInfo info) {
		StructurePlacementData settings = currentSettings.get();
		if (settings != null) { // pos was already processed.
			return info.pos;
		}
		return original;
	}

	@Inject(method = "placeEntities", at = @At("RETURN"))
	private void clearGrabbedSettings(CallbackInfo ci) {
		currentSettings.remove(); // clear the settings when done to avoid leaking it
	}

	// --- deprecated API ---

	@Override
	public List<StructureEntityInfo> getEntities() {
		return entityInfoList;
	}

	@Override
	public Vec3d transformedVec3d(StructurePlacementData settings, Vec3d pos) {
		return StructureTemplateUtils.transformedVec3d(settings, pos);
	}

	@Override
	public List<StructureEntityInfo> processEntityInfos(@Nullable StructureTemplate template, WorldAccess world, BlockPos blockPos, StructurePlacementData settings, List<StructureEntityInfo> infos) {
		return StructureTemplateUtils.processEntityInfos(template, world, blockPos, settings, infos);
	}

	@Override
	public void addEntitiesToWorld(ServerWorldAccess level, BlockPos pos, StructurePlacementData settings) {
		this.placeEntities(
				level, pos, settings.getMirror(), settings.getRotation(),
				settings.getPosition(), settings.getBoundingBox(),
				settings.shouldInitializeMobs()
		);
	}
}

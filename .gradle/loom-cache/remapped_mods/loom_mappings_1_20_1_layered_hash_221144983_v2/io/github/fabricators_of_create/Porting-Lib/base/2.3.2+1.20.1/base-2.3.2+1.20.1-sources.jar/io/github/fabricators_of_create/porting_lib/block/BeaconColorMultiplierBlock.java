package io.github.fabricators_of_create.porting_lib.block;

import net.minecraft.block.BlockState;
import net.minecraft.block.Stainable;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.WorldView;
import org.jetbrains.annotations.Nullable;

public interface BeaconColorMultiplierBlock {
	/**
	 * @param state The state
	 * @param level The level
	 * @param pos The position of this state
	 * @param beaconPos The position of the beacon
	 * @return A float RGB [0.0, 1.0] array to be averaged with a beacon's existing beam color, or null to do nothing to the beam
	 */
	@Nullable
	default float[] getBeaconColorMultiplier(BlockState state, WorldView level, BlockPos pos, BlockPos beaconPos) {
		if (this instanceof Stainable beamBlock)
			return beamBlock.getColor().getColorComponents();
		return null;
	}
}

package io.github.fabricators_of_create.porting_lib.extensions.mixin.client;

import io.github.fabricators_of_create.porting_lib.extensions.extensions.PoseStackExtensions;
import net.minecraft.client.util.math.MatrixStack;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(MatrixStack.class)
public class PoseStackMixin implements PoseStackExtensions {
}

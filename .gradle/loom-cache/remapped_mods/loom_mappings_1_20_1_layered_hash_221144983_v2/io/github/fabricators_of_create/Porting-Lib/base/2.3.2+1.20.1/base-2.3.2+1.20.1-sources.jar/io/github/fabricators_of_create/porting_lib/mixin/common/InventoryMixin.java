package io.github.fabricators_of_create.porting_lib.mixin.common;

import io.github.fabricators_of_create.porting_lib.item.ArmorTickListeningItem;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.player.PlayerInventory;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(PlayerInventory.class)
public class InventoryMixin {
	@Shadow
	@Final
	public PlayerEntity player;

	@Inject(method = "tick", at = @At("HEAD"))
	private void port_lib$inventoryTick(CallbackInfo ci) {
		player.getArmorItems().forEach(stack -> {
			if(stack.getItem() instanceof ArmorTickListeningItem item) {
				item.onArmorTick(stack, player.getWorld(), player);
			}
		});
	}
}

package io.github.fabricators_of_create.porting_lib.util;

import java.util.Objects;
import java.util.Optional;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.function.Supplier;
import java.util.stream.Stream;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.util.Identifier;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@SuppressWarnings("CanBeRecord")
public final class RegistryObject<T> implements Supplier<T> {

	private final Identifier id;
	private T value;
	@Nullable
	private final RegistryKey<T> key;

	@Nullable
	private RegistryEntry<T> holder;

	private static final RegistryObject<?> EMPTY = new RegistryObject<>();

	private static <T> RegistryObject<T> empty() {
		@SuppressWarnings("unchecked")
		RegistryObject<T> t = (RegistryObject<T>) EMPTY;
		return t;
	}

	private RegistryObject() {
		this.id = null;
		this.key = null;
	}

	public RegistryObject(Identifier id, RegistryKey<?> key) {
		this.id = id;
		this.key = (RegistryKey<T>) key;
	}

	void setValue(T value) {
		this.value = value;
	}

	public Identifier getId() {
		return id;
	}

	@Override
	public T get() {
		return Objects.requireNonNull(this.value, () -> "Registry Object not present: " + this.id);
	}

	@Nullable
	public RegistryKey<T> getKey() {
		return this.key;
	}

	public Stream<T> stream() {
		return isPresent() ? Stream.of(get()) : Stream.of();
	}

	public boolean isPresent() {
		return this.value != null;
	}

	public void ifPresent(Consumer<? super T> consumer) {
		if (isPresent())
			consumer.accept(get());
	}

	public RegistryObject<T> filter(Predicate<? super T> predicate) {
		Objects.requireNonNull(predicate);
		if (!isPresent())
			return this;
		else
			return predicate.test(get()) ? this : empty();
	}

	public<U> Optional<U> map(Function<? super T, ? extends U> mapper) {
		Objects.requireNonNull(mapper);
		if (!isPresent())
			return Optional.empty();
		else {
			return Optional.ofNullable(mapper.apply(get()));
		}
	}

	public<U> Optional<U> flatMap(Function<? super T, Optional<U>> mapper) {
		Objects.requireNonNull(mapper);
		if (!isPresent())
			return Optional.empty();
		else {
			return Objects.requireNonNull(mapper.apply(get()));
		}
	}

	public<U> Supplier<U> lazyMap(Function<? super T, ? extends U> mapper) {
		Objects.requireNonNull(mapper);
		return () -> isPresent() ? mapper.apply(get()) : null;
	}

	public T orElse(T other) {
		return isPresent() ? get() : other;
	}

	public T orElseGet(Supplier<? extends T> other) {
		return isPresent() ? get() : other.get();
	}

	public <X extends Throwable> T orElseThrow(Supplier<? extends X> exceptionSupplier) throws X {
		if (isPresent()) {
			return get();
		} else {
			throw exceptionSupplier.get();
		}
	}

	@SuppressWarnings("unchecked")
	@NotNull
	public Optional<RegistryEntry<T>> getHolder() {
		if (this.holder == null && this.key != null && registryExists(this.key.getRegistry())) {
			Identifier registryName = this.key.getRegistry();
			Registry<T> registry = (Registry<T>) Registries.REGISTRIES.get(registryName);

			if (registry != null)
				this.holder = registry.getEntry(this.key).orElse(null);
		}

		return Optional.ofNullable(this.holder);
	}

	private static boolean registryExists(Identifier registryName) {
		return Registries.REGISTRIES.containsId(registryName);
	}
}

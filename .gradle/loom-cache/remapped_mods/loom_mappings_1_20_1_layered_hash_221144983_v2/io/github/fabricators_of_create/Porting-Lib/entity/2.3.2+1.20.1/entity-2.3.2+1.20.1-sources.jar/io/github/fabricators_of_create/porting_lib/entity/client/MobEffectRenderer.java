package io.github.fabricators_of_create.porting_lib.entity.client;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.hud.InGameHud;
import net.minecraft.client.gui.screen.ingame.AbstractInventoryScreen;
import net.minecraft.entity.effect.StatusEffectInstance;

public interface MobEffectRenderer {
	MobEffectRenderer DEFAULT = new MobEffectRenderer() { };

	/**
	 * Queries whether the given effect should be shown in the player's inventory.
	 * <p>
	 * By default, this returns {@code true}.
	 */
	default boolean isVisibleInInventory(StatusEffectInstance instance) {
		return true;
	}

	/**
	 * Queries whether the given effect should be shown in the HUD.
	 * <p>
	 * By default, this returns {@code true}.
	 */
	default boolean isVisibleInGui(StatusEffectInstance instance) {
		return true;
	}

	/**
	 * Renders the icon of the specified effect in the player's inventory.
	 * This can be used to render icons from your own texture sheet.
	 *
	 * @param instance     The effect instance
	 * @param screen       The effect-rendering screen
	 * @param guiGraphics  The gui graphics
	 * @param x            The x coordinate
	 * @param y            The y coordinate
	 * @param blitOffset   The blit offset
	 * @return true to prevent default rendering, false otherwise
	 */
	default boolean renderInventoryIcon(StatusEffectInstance instance, AbstractInventoryScreen<?> screen, DrawContext guiGraphics, int x, int y, int blitOffset) {
		return false;
	}

	/**
	 * Renders the text of the specified effect in the player's inventory.
	 *
	 * @param instance     The effect instance
	 * @param screen       The effect-rendering screen
	 * @param guiGraphics  The gui graphics
	 * @param x            The x coordinate
	 * @param y            The y coordinate
	 * @param blitOffset   The blit offset
	 * @return true to prevent default rendering, false otherwise
	 */
	default boolean renderInventoryText(StatusEffectInstance instance, AbstractInventoryScreen<?> screen, DrawContext guiGraphics, int x, int y, int blitOffset) {
		return false;
	}

	/**
	 * Renders the icon of the specified effect on the player's HUD.
	 * This can be used to render icons from your own texture sheet.
	 *
	 * @param instance    The effect instance
	 * @param gui         The gui
	 * @param guiGraphics The gui graphics
	 * @param x           The x coordinate
	 * @param y           The y coordinate
	 * @param z           The z depth
	 * @param alpha       The alpha value. Blinks when the effect is about to run out
	 * @return true to prevent default rendering, false otherwise
	 */
	default boolean renderGuiIcon(StatusEffectInstance instance, InGameHud gui, DrawContext guiGraphics, int x, int y, float z, float alpha) {
		return false;
	}
}

package io.github.fabricators_of_create.porting_lib.mixin.common;

import org.spongepowered.asm.mixin.Mixin;

import io.github.fabricators_of_create.porting_lib.extensions.extensions.StructureProcessorExtensions;
import net.minecraft.structure.StructurePlacementData;
import net.minecraft.structure.StructureTemplate;
import net.minecraft.structure.processor.StructureProcessor;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.WorldView;

@Mixin(StructureProcessor.class)
public abstract class StructureProcessorMixin implements StructureProcessorExtensions {
	@Override
	public StructureTemplate.StructureEntityInfo processEntity(WorldView world, BlockPos seedPos, StructureTemplate.StructureEntityInfo rawEntityInfo,
															   StructureTemplate.StructureEntityInfo entityInfo, StructurePlacementData placementSettings,
															   StructureTemplate template) {
		return entityInfo;
	}
}

package io.github.fabricators_of_create.porting_lib.util;

import javax.annotation.Nullable;
import net.minecraft.block.AbstractRailBlock;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.enums.RailShape;
import net.minecraft.entity.vehicle.AbstractMinecartEntity;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.registry.tag.TagKey;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.BlockView;
import io.github.fabricators_of_create.porting_lib.extensions.extensions.BaseRailBlockExtensions;
import io.github.fabricators_of_create.porting_lib.mixin.accessors.common.accessor.AbstractMinecartAccessor;

public class MinecartAndRailUtil {

	// rails

	public static final TagKey<Block> ACTIVATOR_RAILS = TagKey.of(RegistryKeys.field_41254, new Identifier("c", "rails/activator"));

	public static boolean isActivatorRail(Block rail) {
		return rail.getRegistryEntry().isIn(ACTIVATOR_RAILS);
	}

	public static RailShape getDirectionOfRail(BlockState state, BlockView world, BlockPos pos, @Nullable AbstractRailBlock block) {
		return ((BaseRailBlockExtensions) state.getBlock()).getRailDirection(state, world, pos, block);
	}

	// carts

	public static double getMaximumSpeed(AbstractMinecartEntity cart) {
		return ((AbstractMinecartAccessor) cart).port_lib$getMaxSpeed();
	}

	public static double getSlopeAdjustment() {
		return 0.0078125D;
	}
}

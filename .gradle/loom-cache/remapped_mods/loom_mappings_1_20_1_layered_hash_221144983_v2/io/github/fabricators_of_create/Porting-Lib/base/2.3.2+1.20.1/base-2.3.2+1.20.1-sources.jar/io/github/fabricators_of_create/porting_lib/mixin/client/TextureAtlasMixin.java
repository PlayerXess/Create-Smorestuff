package io.github.fabricators_of_create.porting_lib.mixin.client;

import io.github.fabricators_of_create.porting_lib.event.client.TextureStitchCallback;
import net.minecraft.client.texture.SpriteAtlasTexture;
import net.minecraft.client.texture.SpriteLoader;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(SpriteAtlasTexture.class)
public abstract class TextureAtlasMixin {
  @Inject(method = "upload", at = @At("RETURN"))
  private void port_lib$postStitch(SpriteLoader.StitchResult preparations, CallbackInfo ci) {
    TextureStitchCallback.POST.invoker().stitch((SpriteAtlasTexture) (Object) this);
  }
}

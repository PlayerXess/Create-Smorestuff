package io.github.fabricators_of_create.porting_lib.extensions.extensions;

import net.minecraft.client.render.Camera;
import net.minecraft.client.render.LightmapTextureManager;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.client.world.ClientWorld;
import org.joml.Matrix4f;
import org.joml.Vector3f;

public interface DimensionSpecialEffectsExtensions {
	/**
	 * Renders the clouds of this dimension.
	 *
	 * @return true to prevent vanilla cloud rendering
	 */
	default boolean renderClouds(ClientWorld level, int ticks, float partialTick, MatrixStack poseStack, double camX, double camY, double camZ, Matrix4f projectionMatrix) {
		return false;
	}

	/**
	 * Renders the sky of this dimension.
	 *
	 * @return true to prevent vanilla sky rendering
	 */
	default boolean renderSky(ClientWorld level, int ticks, float partialTick, MatrixStack poseStack, Camera camera, Matrix4f projectionMatrix, boolean isFoggy, Runnable setupFog) {
		return false;
	}

	/**
	 * Renders the snow and rain effects of this dimension.
	 *
	 * @return true to prevent vanilla snow and rain rendering
	 */
	default boolean renderSnowAndRain(ClientWorld level, int ticks, float partialTick, LightmapTextureManager lightTexture, double camX, double camY, double camZ) {
		return false;
	}

	/**
	 * Ticks the rain of this dimension.
	 *
	 * @return true to prevent vanilla rain ticking
	 */
	default boolean tickRain(ClientWorld level, int ticks, Camera camera) {
		return false;
	}

	/**
	 * Allows for manipulating the coloring of the lightmap texture.
	 * Will be called for each 16*16 combination of sky/block light values.
	 *
	 * @param level        The current level (client-side).
	 * @param partialTicks Progress between ticks.
	 * @param skyDarken    Current darkness of the sky.
	 * @param skyLight     Sky light brightness factor.
	 * @param blockLight   Block light brightness factor.
	 * @param pixelX       X-coordinate of the lightmap texture.
	 * @param pixelY       Y-coordinate of the lightmap texture.
	 * @param colors       The color values that will be used: [r, g, b].
	 * @see LightmapTextureManager#update(float)
	 */
	default void adjustLightmapColors(ClientWorld level, float partialTicks, float skyDarken, float skyLight, float blockLight, int pixelX, int pixelY, Vector3f colors) {}
}

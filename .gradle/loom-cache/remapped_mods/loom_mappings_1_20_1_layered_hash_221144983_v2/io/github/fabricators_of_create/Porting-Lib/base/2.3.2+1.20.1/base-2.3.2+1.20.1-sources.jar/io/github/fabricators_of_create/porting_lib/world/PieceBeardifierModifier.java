package io.github.fabricators_of_create.porting_lib.world;

import net.minecraft.util.math.BlockBox;
import net.minecraft.world.gen.StructureTerrainAdaptation;

/** Implement this interface in a {@link net.minecraft.structure.StructurePiece} class extension to modify its {@link net.minecraft.world.gen.StructureWeightSampler} behavior. */
public interface PieceBeardifierModifier {
	BlockBox getBeardifierBox();

	StructureTerrainAdaptation getTerrainAdjustment();

	int getGroundLevelDelta();
}

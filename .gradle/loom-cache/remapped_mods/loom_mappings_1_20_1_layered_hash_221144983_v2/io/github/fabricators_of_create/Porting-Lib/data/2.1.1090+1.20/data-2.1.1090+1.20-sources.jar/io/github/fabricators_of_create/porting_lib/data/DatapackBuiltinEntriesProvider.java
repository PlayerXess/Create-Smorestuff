package io.github.fabricators_of_create.porting_lib.data;

import com.google.gson.JsonElement;
import com.mojang.serialization.DynamicOps;
import com.mojang.serialization.JsonOps;
import java.util.HashSet;
import java.util.Optional;
import java.util.Set;
import java.util.concurrent.CompletableFuture;
import java.util.stream.Stream;
import net.minecraft.data.DataOutput;
import net.minecraft.data.DataWriter;
import net.minecraft.data.report.DynamicRegistriesProvider;
import net.minecraft.registry.DynamicRegistryManager;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.registry.RegistryBuilder;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryLoader;
import net.minecraft.registry.RegistryOps;
import net.minecraft.registry.RegistryWrapper;
import net.minecraft.util.Identifier;

/**
 * An extension of the {@link DynamicRegistriesProvider} which properly handles
 * referencing existing dynamic registry objects within another dynamic registry
 * object.
 */
public class DatapackBuiltinEntriesProvider extends DynamicRegistriesProvider {
	private final DataOutput output;
	private final CompletableFuture<RegistryWrapper.WrapperLookup> registries;
	private final java.util.function.Predicate<String> namespacePredicate;

	/**
	 * Constructs a new datapack provider which generates all registry objects
	 * from the provided mods using the holder.
	 *
	 * @param output the target directory of the data generator
	 * @param registries a future of a lookup for registries and their objects
	 * @param modIds a set of mod ids to generate the dynamic registry objects of
	 */
	public DatapackBuiltinEntriesProvider(DataOutput output, CompletableFuture<RegistryWrapper.WrapperLookup> registries, Set<String> modIds) {
		super(output, registries);
		this.namespacePredicate = modIds == null ? namespace -> true : modIds::contains;
		this.registries = registries;
		this.output = output;
	}

	/**
	 * Constructs a new datapack provider which generates all registry objects
	 * from the provided mods using the holder. All entries that need to be
	 * bootstrapped are provided within the {@link RegistryBuilder}.
	 *
	 * @param output the target directory of the data generator
	 * @param registries a future of a lookup for registries and their objects
	 * @param datapackEntriesBuilder a builder containing the dynamic registry objects added by this provider
	 * @param modIds a set of mod ids to generate the dynamic registry objects of
	 */
	public DatapackBuiltinEntriesProvider(DataOutput output, CompletableFuture<RegistryWrapper.WrapperLookup> registries, RegistryBuilder datapackEntriesBuilder, Set<String> modIds) {
		this(output, registries.thenApply(r -> constructRegistries(r, datapackEntriesBuilder)), modIds);
	}

	/**
	 * A method used to construct empty bootstraps for all registries this provider
	 * did not touch such that existing dynamic registry objects do not get inlined.
	 *
	 * @param original a future of a lookup for registries and their objects
	 * @param datapackEntriesBuilder a builder containing the dynamic registry objects added by this provider
	 * @return a new lookup containing the existing and to be generated registries and their objects
	 */
	private static RegistryWrapper.WrapperLookup constructRegistries(RegistryWrapper.WrapperLookup original, RegistryBuilder datapackEntriesBuilder) {
		var builderKeys = new HashSet<>(datapackEntriesBuilder.registries.stream().map(RegistrySetBuilder.RegistryStub::key).toList());
		getDataPackRegistriesWithDimensions().filter(data -> !builderKeys.contains(data.comp_985())).forEach(data -> datapackEntriesBuilder.addRegistry(data.comp_985(), context -> {}));
		return datapackEntriesBuilder.createWrapperLookup(DynamicRegistryManager.of(Registries.REGISTRIES), original);
	}

	@Override
	public CompletableFuture<?> run(DataWriter output) {
		return this.registries.thenCompose((provider) -> {
			DynamicOps<JsonElement> dynamicops = RegistryOps.of(JsonOps.INSTANCE, provider);
			return CompletableFuture.allOf(getDataPackRegistriesWithDimensions().flatMap((registryData) -> {
				return this.method_39678(output, provider, dynamicops, registryData).stream();
			}).toArray(CompletableFuture[]::new));
		});
	}

	private <T> Optional<CompletableFuture<?>> method_39678(DataWriter p_256502_, RegistryWrapper.WrapperLookup p_256492_, DynamicOps<JsonElement> p_256000_, RegistryLoader.Entry<T> p_256449_) {
		RegistryKey<? extends Registry<T>> resourcekey = p_256449_.comp_985();
		return p_256492_.getOptionalWrapper(resourcekey).map((registryLookup) -> {
			DataOutput.PathResolver packoutput$pathprovider = this.output.getResolver(DataOutput.OutputType.field_39367, prefixNamespace(resourcekey.getValue()));
			return CompletableFuture.allOf(registryLookup.streamEntries().filter(holder -> this.namespacePredicate.test(holder.registryKey().getValue().getNamespace())).map((p_256105_) -> {
				return writeToPath(packoutput$pathprovider.resolveJson(p_256105_.registryKey().getValue()), p_256502_, p_256000_, p_256449_.comp_986(), p_256105_.comp_349());
			}).toArray(CompletableFuture[]::new));
		});
	}

	public static Stream<RegistryLoader.Entry<?>> getDataPackRegistriesWithDimensions() {
		return Stream.concat(RegistryLoader.DYNAMIC_REGISTRIES.stream(), RegistryLoader.DIMENSION_REGISTRIES.stream());
	}

	public static String prefixNamespace(Identifier registryKey) {
		return registryKey.getNamespace().equals("minecraft") ? registryKey.getPath() : registryKey.getNamespace() +  "/"  + registryKey.getPath();
	}
}

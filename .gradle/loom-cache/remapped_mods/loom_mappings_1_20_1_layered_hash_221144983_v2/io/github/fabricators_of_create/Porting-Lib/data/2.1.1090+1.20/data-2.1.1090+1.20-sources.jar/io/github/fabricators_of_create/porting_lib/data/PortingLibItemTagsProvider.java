package io.github.fabricators_of_create.porting_lib.data;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.CompletableFuture;
import net.minecraft.block.Block;
import net.minecraft.data.DataOutput;
import net.minecraft.data.server.tag.TagProvider;
import net.minecraft.data.server.tag.ValueLookupTagProvider;
import net.minecraft.item.Item;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.registry.RegistryWrapper;
import net.minecraft.registry.tag.TagBuilder;
import net.minecraft.registry.tag.TagKey;

public abstract class PortingLibItemTagsProvider extends ValueLookupTagProvider<Item> {
	/** A function that resolves block tag builders. */
	private final CompletableFuture<TagLookup<Block>> blockTags;
	private final Map<TagKey<Block>, TagKey<Item>> tagsToCopy = new HashMap<>();

	public PortingLibItemTagsProvider(DataOutput p_275343_, CompletableFuture<RegistryWrapper.WrapperLookup> p_275729_, CompletableFuture<TagProvider.TagLookup<Block>> p_275322_, String modId) {
		super(p_275343_, RegistryKeys.field_41197, p_275729_, (p_255790_) -> {
			return p_255790_.getRegistryEntry().registryKey();
		});
		this.blockTags = p_275322_;
	}

	/**
	 * Copies the entries from a block tag into an item tag.
	 */
	protected void copy(TagKey<Block> pBlockTag, TagKey<Item> pItemTag) {
		this.tagsToCopy.put(pBlockTag, pItemTag);
	}

	protected CompletableFuture<RegistryWrapper.WrapperLookup> getRegistryLookupFuture() {
		return super.getRegistryLookupFuture().thenCombineAsync(this.blockTags, (p_274766_, p_274767_) -> {
			this.tagsToCopy.forEach((p_274763_, p_274764_) -> {
				TagBuilder tagbuilder = this.getTagBuilder(p_274764_);
				Optional<TagBuilder> optional = p_274767_.apply(p_274763_);
				optional.orElseThrow(() -> {
					return new IllegalStateException("Missing block tag " + p_274764_.id());
				}).build().forEach(tagbuilder::add);
			});
			return p_274766_;
		});
	}
}

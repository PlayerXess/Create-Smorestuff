package io.github.fabricators_of_create.porting_lib.extensions.extensions;

import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.AffineTransformation;
import org.joml.Vector3f;

public interface PoseStackExtensions {
	/**
	 * Pushes and applies the {@code transformation} to this pose stack. <br>
	 * The effects of this method can be reversed by a corresponding {@link MatrixStack#pop()} call.
	 *
	 * @param transformation the transformation to push
	 */
	default void pushTransformation(AffineTransformation transformation) {
		final MatrixStack self = (MatrixStack) this;
		self.push();

		Vector3f trans = transformation.getTranslation();
		self.translate(trans.x(), trans.y(), trans.z());

		self.multiply(transformation.getLeftRotation());

		Vector3f scale = transformation.getScale();
		self.scale(scale.x(), scale.y(), scale.z());

		self.multiply(transformation.getRightRotation());
	}
}

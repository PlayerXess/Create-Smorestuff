package io.github.fabricators_of_create.porting_lib.util;

import javax.annotation.Nullable;
import net.minecraft.block.Block;
import net.minecraft.item.DyeItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ToolMaterial;
import net.minecraft.item.ToolMaterials;
import net.minecraft.registry.tag.BlockTags;
import net.minecraft.registry.tag.TagKey;
import net.minecraft.util.DyeColor;
import io.github.fabricators_of_create.porting_lib.tags.Tags;

public class TagUtil {
	@Nullable
	public static DyeColor getColorFromStack(ItemStack stack) {
		Item item = stack.getItem();
		if (item instanceof DyeItem dyeItem) {
			return dyeItem.getColor();
		}

		for (DyeColor color : DyeColor.values()) {
			if (stack.isIn(color.getTag())) return color;
		}

		return null;
	}

	public static TagKey<Block> getTagFromVanillaTier(ToolMaterials tier) {
		return switch (tier) {
			case field_8922 -> Tags.Blocks.NEEDS_WOOD_TOOL;
			case field_8929 -> Tags.Blocks.NEEDS_GOLD_TOOL;
			case field_8927 -> BlockTags.field_33719;
			case field_8923 -> BlockTags.field_33718;
			case field_8930 -> BlockTags.field_33717;
			case field_22033 -> Tags.Blocks.NEEDS_NETHERITE_TOOL;
		};
	}

	public static TagKey<Block> getTagFromTier(ToolMaterial tier) {
		return tier.getTag();
	}
}

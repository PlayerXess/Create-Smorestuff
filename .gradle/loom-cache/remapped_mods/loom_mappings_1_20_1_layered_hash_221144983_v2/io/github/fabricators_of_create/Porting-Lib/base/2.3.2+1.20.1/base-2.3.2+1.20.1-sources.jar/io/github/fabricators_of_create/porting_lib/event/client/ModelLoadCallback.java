package io.github.fabricators_of_create.porting_lib.event.client;

import net.fabricmc.fabric.api.event.Event;
import net.fabricmc.fabric.api.event.EventFactory;
import net.minecraft.client.color.block.BlockColors;
import net.minecraft.client.render.model.ModelLoader;
import net.minecraft.client.render.model.json.JsonUnbakedModel;
import net.minecraft.util.Identifier;
import net.minecraft.util.profiler.Profiler;
import java.util.List;
import java.util.Map;

public interface ModelLoadCallback {
	Event<ModelLoadCallback> EVENT = EventFactory.createArrayBacked(ModelLoadCallback.class, callbacks -> (colors, profiler, modelResources, blockStateResources) -> {
		for (ModelLoadCallback e : callbacks)
			e.onModelsStartLoading(colors, profiler, modelResources, blockStateResources);
	});


	void onModelsStartLoading(BlockColors colors, Profiler profiler, Map<Identifier, JsonUnbakedModel> modelResources, Map<Identifier, List<ModelLoader.SourceTrackedData>> blockStateResources);
}

package io.github.fabricators_of_create.porting_lib.util;

import javax.annotation.Nullable;
import net.minecraft.item.ArmorMaterial;
import net.minecraft.util.Identifier;
import java.util.IdentityHashMap;
import java.util.Map;

/**
 * A Map of ArmorMaterials to ResourceLocations for armor textures.
 */
public class ArmorTextureRegistry {
	private static final Map<ArmorMaterial, Identifier> TEXTURES = new IdentityHashMap<>();

	public static void register(ArmorMaterial material, Identifier location) {
		TEXTURES.put(material, location);
	}

	@Nullable
	public static Identifier get(ArmorMaterial material) {
		return TEXTURES.get(material);
	}
}

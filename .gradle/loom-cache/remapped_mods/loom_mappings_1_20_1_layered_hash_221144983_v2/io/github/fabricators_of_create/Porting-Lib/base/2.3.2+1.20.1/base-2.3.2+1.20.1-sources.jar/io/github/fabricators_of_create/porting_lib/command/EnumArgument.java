package io.github.fabricators_of_create.porting_lib.command;

import com.google.gson.JsonObject;
import com.mojang.brigadier.StringReader;
import com.mojang.brigadier.arguments.ArgumentType;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.mojang.brigadier.exceptions.Dynamic2CommandExceptionType;
import com.mojang.brigadier.suggestion.Suggestions;
import com.mojang.brigadier.suggestion.SuggestionsBuilder;
import java.util.Arrays;
import java.util.Collection;
import java.util.concurrent.CompletableFuture;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import net.minecraft.command.CommandRegistryAccess;
import net.minecraft.command.CommandSource;
import net.minecraft.command.argument.serialize.ArgumentSerializer;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.text.Text;

public class EnumArgument<T extends Enum<T>> implements ArgumentType<T> {
	private static final Dynamic2CommandExceptionType INVALID_ENUM = new Dynamic2CommandExceptionType(
			(found, constants) -> Text.translatable("commands.porting_lib.arguments.enum.invalid", constants, found));
	private final Class<T> enumClass;

	public static <R extends Enum<R>> EnumArgument<R> enumArgument(Class<R> enumClass) {
		return new EnumArgument<>(enumClass);
	}

	private EnumArgument(final Class<T> enumClass) {
		this.enumClass = enumClass;
	}

	@Override
	public T parse(final StringReader reader) throws CommandSyntaxException {
		String name = reader.readUnquotedString();
		try {
			return Enum.valueOf(enumClass, name);
		} catch (IllegalArgumentException e) {
			throw INVALID_ENUM.createWithContext(reader, name, Arrays.toString(Arrays.stream(enumClass.getEnumConstants()).map(Enum::name).toArray()));
		}
	}

	@Override
	public <S> CompletableFuture<Suggestions> listSuggestions(final CommandContext<S> context, final SuggestionsBuilder builder) {
		return CommandSource.suggestMatching(Stream.of(enumClass.getEnumConstants()).map(Enum::name), builder);
	}

	@Override
	public Collection<String> getExamples() {
		return Stream.of(enumClass.getEnumConstants()).map(Enum::name).collect(Collectors.toList());
	}

	public static class Info<T extends Enum<T>> implements ArgumentSerializer<EnumArgument<T>, Info<T>.Template> {
		@Override
		public void serializeToNetwork(Template template, PacketByteBuf buffer) {
			buffer.writeString(template.enumClass.getName());
		}

		@SuppressWarnings("unchecked")
		@Override
		public Template fromPacket(PacketByteBuf buffer) {
			try {
				String name = buffer.readString();
				return new Template((Class<T>) Class.forName(name));
			} catch (ClassNotFoundException e) {
				return null;
			}
		}

		@Override
		public void serializeToJson(Template template, JsonObject json) {
			json.addProperty("enum", template.enumClass.getName());
		}

		@Override
		public Template unpack(EnumArgument<T> argument) {
			return new Template(argument.enumClass);
		}

		public class Template implements ArgumentSerializer.ArgumentTypeProperties<EnumArgument<T>> {
			final Class<T> enumClass;

			Template(Class<T> enumClass) {
				this.enumClass = enumClass;
			}

			@Override
			public EnumArgument<T> createType(CommandRegistryAccess pStructure) {
				return new EnumArgument<>(this.enumClass);
			}

			@Override
			public ArgumentSerializer<EnumArgument<T>, ?> getSerializer() {
				return Info.this;
			}
		}
	}
}

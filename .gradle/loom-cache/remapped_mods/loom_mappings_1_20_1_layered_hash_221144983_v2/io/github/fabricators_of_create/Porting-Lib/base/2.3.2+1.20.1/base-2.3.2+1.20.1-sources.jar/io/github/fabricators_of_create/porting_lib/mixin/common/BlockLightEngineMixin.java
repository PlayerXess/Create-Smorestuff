package io.github.fabricators_of_create.porting_lib.mixin.common;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;

import io.github.fabricators_of_create.porting_lib.block.LightEmissiveBlock;
import net.minecraft.block.BlockState;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.chunk.ChunkProvider;
import net.minecraft.world.chunk.light.BlockLightStorage;
import net.minecraft.world.chunk.light.ChunkBlockLightProvider;
import net.minecraft.world.chunk.light.ChunkLightProvider;

@Mixin(ChunkBlockLightProvider.class)
public abstract class BlockLightEngineMixin extends ChunkLightProvider<BlockLightStorage.Data, BlockLightStorage> {
	protected BlockLightEngineMixin(ChunkProvider chunkProvider, BlockLightStorage lightStorage) {
		super(chunkProvider, lightStorage);
	}

	@WrapOperation(method = "getEmission", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/level/block/state/BlockState;getLightEmission()I"))
	private int getCustomLightEmission(BlockState state, Operation<Integer> operation, long blockPos, BlockState blockState) {
		if (state.getBlock() instanceof LightEmissiveBlock lightEmissiveBlock)
			return lightEmissiveBlock.getLightEmission(state, this.chunkProvider.getWorld(), BlockPos.fromLong(blockPos));
		return operation.call(state);
	}
}

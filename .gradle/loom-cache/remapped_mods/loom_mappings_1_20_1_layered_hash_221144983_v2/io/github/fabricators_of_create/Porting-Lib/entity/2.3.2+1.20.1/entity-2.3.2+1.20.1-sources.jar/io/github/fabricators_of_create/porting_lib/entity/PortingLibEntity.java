package io.github.fabricators_of_create.porting_lib.entity;

import com.mojang.logging.LogUtils;

import io.github.fabricators_of_create.porting_lib.entity.events.LivingAttackEvent;
import io.github.fabricators_of_create.porting_lib.entity.events.LivingEntityEvents;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerEntityEvents;
import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.entity.Entity;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.network.listener.ClientPlayPacketListener;
import net.minecraft.network.packet.Packet;
import net.minecraft.network.packet.s2c.play.BundleS2CPacket;
import net.minecraft.network.packet.s2c.play.EntitySpawnS2CPacket;
import org.jetbrains.annotations.ApiStatus;
import org.slf4j.Logger;

import java.util.List;

public class PortingLibEntity implements ModInitializer {
	public static final Logger LOGGER = LogUtils.getLogger();

	@Override
	public void onInitialize() {
		ServerEntityEvents.ENTITY_LOAD.register((entity, world) -> {
			if (entity instanceof MultiPartEntity partEntity && partEntity.isMultipartEntity()) {
				PartEntity<?>[] parts = partEntity.getParts();
				if (parts != null) {
					for (PartEntity<?> part : parts) {
						world.getPartEntityMap().put(part.getId(), part);
					}
				}
			}
		});
		ServerEntityEvents.ENTITY_UNLOAD.register((entity, world) -> {
			if (entity instanceof MultiPartEntity partEntity && partEntity.isMultipartEntity()) {
				PartEntity<?>[] parts = partEntity.getParts();
				if (parts != null) {
					for (PartEntity<?> part : parts) {
						world.getPartEntityMap().remove(part.getId());
					}
				}
			}
		});
		ServerEntityEvents.EQUIPMENT_CHANGE.register((livingEntity, equipmentSlot, previousStack, currentStack) -> {
			LivingEntityEvents.EQUIPMENT_CHANGE.invoker().onEquipmentChange(livingEntity, equipmentSlot, previousStack, currentStack);
		});
		LivingEntityEvents.LivingJumpEvent.JUMP.register(event -> {
			LivingEntityEvents.JUMP.invoker().onLivingEntityJump(event.getEntity());
		});
		LivingEntityEvents.LivingVisibilityEvent.VISIBILITY.register(event -> {
			LivingEntityEvents.VISIBILITY.invoker().getEntityVisibilityMultiplier(event.getEntity(), event.getLookingEntity(), event.getVisibilityModifier());
		});
		LivingEntityEvents.LivingTickEvent.TICK.register(event -> {
			if (!event.isCanceled())
				LivingEntityEvents.TICK.invoker().onLivingEntityTick(event.getEntity());
		});
		LivingAttackEvent.ATTACK.register(event -> {
			LivingEntityEvents.ATTACK.invoker().onAttack(event.getEntity(), event.getSource(), event.getAmount());
		});
	}

	public static Packet<ClientPlayPacketListener> getEntitySpawningPacket(Entity entity) {
		return getEntitySpawningPacket(entity, new EntitySpawnS2CPacket(entity));
	}

	@ApiStatus.Internal
	public static Packet<ClientPlayPacketListener> getEntitySpawningPacket(Entity entity, Packet<ClientPlayPacketListener> base) {
		if (entity instanceof IEntityAdditionalSpawnData extra) {
			PacketByteBuf buf = PacketByteBufs.create();
			buf.writeVarInt(entity.getId());
			extra.writeSpawnData(buf);
			Packet<ClientPlayPacketListener> extraPacket = ServerPlayNetworking.createS2CPacket(IEntityAdditionalSpawnData.EXTRA_DATA_PACKET, buf);
			return new BundleS2CPacket(List.of(base, extraPacket));
		}
		return base;
	}
}

package io.github.fabricators_of_create.porting_lib.data;

import com.mojang.serialization.JsonOps;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.BiConsumer;
import net.minecraft.client.texture.atlas.AtlasSource;
import net.minecraft.client.texture.atlas.AtlasSourceManager;
import net.minecraft.data.DataOutput;
import net.minecraft.resource.ResourceType;
import net.minecraft.util.Identifier;

/**
 * <p>Data provider for atlas configuration files.<br>
 * An atlas configuration is bound to a specific texture atlas such as the {@code minecraft:blocks} atlas and
 * allows adding additional textures to the atlas by adding {@link AtlasSource}s to the configuration.</p>
 * <p>See {@link AtlasSourceManager} for the available sources and the constants in this class for the
 * atlases used in vanilla Minecraft</p>
 */
public abstract class SpriteSourceProvider extends JsonCodecProvider<List<AtlasSource>> {
	protected static final Identifier BLOCKS_ATLAS = new Identifier("blocks");
	protected static final Identifier BANNER_PATTERNS_ATLAS = new Identifier("banner_patterns");
	protected static final Identifier BEDS_ATLAS = new Identifier("beds");
	protected static final Identifier CHESTS_ATLAS = new Identifier("chests");
	protected static final Identifier SHIELD_PATTERNS_ATLAS = new Identifier("shield_patterns");
	protected static final Identifier SHULKER_BOXES_ATLAS = new Identifier("shulker_boxes");
	protected static final Identifier SIGNS_ATLAS = new Identifier("signs");
	protected static final Identifier MOB_EFFECTS_ATLAS = new Identifier("mob_effects");
	protected static final Identifier PAINTINGS_ATLAS = new Identifier("paintings");
	protected static final Identifier PARTICLES_ATLAS = new Identifier("particles");

	private final Map<Identifier, SourceList> atlases = new HashMap<>();

	public SpriteSourceProvider(DataOutput output, String modid) {
		super(output, modid, JsonOps.INSTANCE, ResourceType.field_14188, "atlases", AtlasSourceManager.LIST_CODEC, Map.of());
	}

	@Override
	protected final void gather(BiConsumer<Identifier, List<AtlasSource>> consumer) {
		addSources();
		atlases.forEach((atlas, srcList) -> consumer.accept(atlas, srcList.sources));
	}

	protected abstract void addSources();

	/**
	 * Get or create a {@link SourceList} for the given atlas
	 * @param atlas The texture atlas the sources should be added to, see constants at the top for the format
	 *              and the vanilla atlases
	 * @return an existing {@code SourceList} for the given atlas or a new one if not present yet
	 */
	protected final SourceList atlas(Identifier atlas) {
		return atlases.computeIfAbsent(atlas, $ -> new SourceList());
	}

	protected static final class SourceList {
		private final List<AtlasSource> sources = new ArrayList<>();

		/**
		 * Add the given {@link AtlasSource} to this atlas configuration
		 * @param source The {@code SpriteSource} to be added
		 */
		public SourceList addSource(AtlasSource source) {
			sources.add(source);
			return this;
		}
	}
}

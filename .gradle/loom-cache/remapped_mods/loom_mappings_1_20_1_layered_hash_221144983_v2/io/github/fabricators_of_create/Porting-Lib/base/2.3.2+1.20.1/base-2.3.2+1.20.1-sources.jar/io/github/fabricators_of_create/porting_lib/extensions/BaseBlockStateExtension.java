package io.github.fabricators_of_create.porting_lib.extensions;

import io.github.fabricators_of_create.porting_lib.block.BeaconColorMultiplierBlock;
import io.github.fabricators_of_create.porting_lib.block.CustomSlimeBlock;
import io.github.fabricators_of_create.porting_lib.block.EntityDestroyBlock;
import io.github.fabricators_of_create.porting_lib.block.PlayerDestroyBlock;
import io.github.fabricators_of_create.porting_lib.block.StickToBlock;
import io.github.fabricators_of_create.porting_lib.block.StickyBlock;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.Stainable;
import net.minecraft.entity.Entity;
import net.minecraft.entity.boss.WitherEntity;
import net.minecraft.entity.boss.dragon.EnderDragonEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.projectile.WitherSkullEntity;
import net.minecraft.fluid.FluidState;
import net.minecraft.registry.tag.BlockTags;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.BlockView;
import net.minecraft.world.World;
import net.minecraft.world.WorldView;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/**
 * These extensions aren't implemented themselves and are only here so modders don't need to manually check for their mod compatible interfaces preventing.
 */
public interface BaseBlockStateExtension {
	/**
	 * @param level  The level
	 * @param pos    The position of this state
	 * @param beacon The position of the beacon
	 * @return A float RGB [0.0, 1.0] array to be averaged with a beacon's existing beam color, or null to do nothing to the beam
	 */
	@Nullable
	default float[] getBeaconColorMultiplier(WorldView level, BlockPos pos, BlockPos beacon) {
		Block block = ((BlockState) this).getBlock();
		if (block instanceof BeaconColorMultiplierBlock beaconColorMultiplierBlock)
			return beaconColorMultiplierBlock.getBeaconColorMultiplier((BlockState) this, level, pos, beacon);
		if (block instanceof Stainable beamBlock)
			return beamBlock.getColor().getColorComponents();
		return null;
	}

	/**
	 * Called when a player removes a block.  This is responsible for
	 * actually destroying the block, and the block is intact at time of call.
	 * This is called regardless of whether the player can harvest the block or
	 * not.
	 * <p>
	 * Return true if the block is actually destroyed.
	 * <p>
	 * Note: When used in multiplayer, this is called on both client and
	 * server sides!
	 *
	 * @param level       The current level
	 * @param player      The player damaging the block, may be null
	 * @param pos         Block position in level
	 * @param willHarvest True if Block.harvestBlock will be called after this, if the return in true.
	 *                    Can be useful to delay the destruction of tile entities till after harvestBlock
	 * @param fluid       The current fluid and block state for the position in the level.
	 * @return True if the block is actually destroyed.
	 */
	default boolean onDestroyedByPlayer(World level, BlockPos pos, PlayerEntity player, boolean willHarvest, FluidState fluid) {
		Block block = ((BlockState) this).getBlock();
		if (block instanceof PlayerDestroyBlock destroyBlock)
			return destroyBlock.onDestroyedByPlayer((BlockState) this, level, pos, player, willHarvest, fluid);

		block.onBreak(level, pos, (BlockState) this, player);
		return level.setBlockState(pos, fluid.getBlockState(), level.isClient ? 11 : 3);
	}

	/**
	 * Determines if this block is can be destroyed by the specified entities normal behavior.
	 *
	 * @param level The current level
	 * @param pos   Block position in level
	 * @return True to allow the ender dragon to destroy this block
	 */
	default boolean canEntityDestroy(BlockView level, BlockPos pos, Entity entity) {
		Block block = ((BlockState) this).getBlock();
		if (block instanceof EntityDestroyBlock destroyBlock)
			return destroyBlock.canEntityDestroy((BlockState) this, level, pos, entity);

		if (entity instanceof EnderDragonEntity) {
			return !block.getDefaultState().isIn(BlockTags.field_17753);
		} else if ((entity instanceof WitherEntity) ||
				(entity instanceof WitherSkullEntity)) {
			return ((BlockState) this).isAir() || WitherEntity.canDestroy((BlockState) this);
		}

		return true;
	}

	/**
	 * @return true if the block is sticky block which used for pull or push adjacent blocks (use by piston)
	 */
	default boolean isSlimeBlock() {
		if (((BlockState) this).getBlock() instanceof CustomSlimeBlock slimeBlock)
			return slimeBlock.isSlimeBlock((BlockState) this);
		return ((BlockState) this).isOf(Blocks.field_10030);
	}

	/**
	 * @return true if the block is sticky block which used for pull or push adjacent blocks (use by piston)
	 */
	default boolean isStickyBlock() {
		Block block = ((BlockState) this).getBlock();
		if (block instanceof StickyBlock stickyBlock)
			return stickyBlock.isStickyBlock((BlockState) this);
		return block == Blocks.field_10030 || block == Blocks.field_21211;
	}

	/**
	 * Determines if this block can stick to another block when pushed by a piston.
	 *
	 * @param other Other block
	 * @return True to link blocks
	 */
	default boolean canStickTo(@NotNull BlockState other) {
		Block block = ((BlockState) this).getBlock();
		if (block instanceof StickToBlock stickTo)
			return stickTo.canStickTo((BlockState) this, other);
		if (block == Blocks.field_21211 && other.getBlock() == Blocks.field_10030) return false;
		if (block == Blocks.field_10030 && other.getBlock() == Blocks.field_21211) return false;
		return isStickyBlock() || other.isStickyBlock();
	}
}

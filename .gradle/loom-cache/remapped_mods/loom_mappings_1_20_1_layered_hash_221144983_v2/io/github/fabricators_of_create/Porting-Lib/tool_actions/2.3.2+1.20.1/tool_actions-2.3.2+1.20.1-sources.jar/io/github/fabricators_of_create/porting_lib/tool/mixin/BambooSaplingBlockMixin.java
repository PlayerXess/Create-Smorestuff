package io.github.fabricators_of_create.porting_lib.tool.mixin;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;

import io.github.fabricators_of_create.porting_lib.tool.ToolActions;
import io.github.fabricators_of_create.porting_lib.tool.addons.ToolActionItem;
import net.minecraft.block.BambooSaplingBlock;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.item.SwordItem;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(BambooSaplingBlock.class)
public class BambooSaplingBlockMixin {
	@ModifyExpressionValue(method = "getDestroyProgress", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/entity/player/Player;getMainHandItem()Lnet/minecraft/world/item/ItemStack;"))
	private ItemStack toolActionIsSword(ItemStack original) {
		if (original.getItem() instanceof ToolActionItem)
			return original.canPerformAction(ToolActions.SWORD_DIG) ? original.getItem() instanceof SwordItem ? original : Items.field_8371.getDefaultStack() : Items.AIR.getDefaultStack();
		return original;
	}
}

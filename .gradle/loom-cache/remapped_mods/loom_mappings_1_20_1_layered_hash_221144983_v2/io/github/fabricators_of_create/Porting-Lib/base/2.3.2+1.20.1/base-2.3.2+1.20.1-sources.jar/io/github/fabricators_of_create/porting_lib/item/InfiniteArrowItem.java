package io.github.fabricators_of_create.porting_lib.item;

import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.world.World;

public interface InfiniteArrowItem {
	/**
	 * Allows you to override vanillas logic for checking if the player how infinite arrows
	 * See {@link net.minecraft.item.BowItem#onStoppedUsing(ItemStack, World, LivingEntity, int)}
	 * @param projectile The current projectile to use.
	 * @param bow The bow the player is holding.
	 * @param player The player using the bow.
	 * @return Return whether the player has infinite arrows.
	 */
	boolean isInfinite(ItemStack projectile, ItemStack bow, PlayerEntity player);
}

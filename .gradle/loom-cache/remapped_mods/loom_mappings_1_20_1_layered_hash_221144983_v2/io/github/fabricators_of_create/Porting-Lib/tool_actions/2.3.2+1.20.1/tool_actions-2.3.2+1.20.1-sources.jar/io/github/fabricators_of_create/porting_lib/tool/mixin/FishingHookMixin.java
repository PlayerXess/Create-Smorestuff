package io.github.fabricators_of_create.porting_lib.tool.mixin;

import com.llamalad7.mixinextras.injector.ModifyReceiver;

import io.github.fabricators_of_create.porting_lib.tool.ToolActions;
import io.github.fabricators_of_create.porting_lib.tool.addons.ToolActionItem;
import net.minecraft.entity.projectile.FishingBobberEntity;
import net.minecraft.item.FishingRodItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(FishingBobberEntity.class)
public class FishingHookMixin {
	@ModifyReceiver(method = "shouldStopFishing", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/item/ItemStack;is(Lnet/minecraft/world/item/Item;)Z"))
	private ItemStack toolActionCast(ItemStack instance, Item item) {
		if (instance.getItem() instanceof ToolActionItem) {
			if (instance.canPerformAction(ToolActions.FISHING_ROD_CAST)) {
				return instance.getItem() instanceof FishingRodItem ? instance : Items.field_8378.getDefaultStack();
			}
			return Items.AIR.getDefaultStack();
		}
		return instance;
	}
}

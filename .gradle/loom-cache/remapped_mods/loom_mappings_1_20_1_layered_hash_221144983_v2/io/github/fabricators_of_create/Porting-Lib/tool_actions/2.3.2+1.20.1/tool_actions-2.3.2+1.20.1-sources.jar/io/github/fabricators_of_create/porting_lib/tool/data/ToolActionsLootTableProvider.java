package io.github.fabricators_of_create.porting_lib.tool.data;

import java.nio.file.Path;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.CompletableFuture;
import java.util.stream.Collectors;

import javax.annotation.Nullable;

import com.google.common.collect.Maps;
import com.google.common.collect.Multimap;

import io.github.fabricators_of_create.porting_lib.tool.ToolAction;
import io.github.fabricators_of_create.porting_lib.tool.ToolActions;
import io.github.fabricators_of_create.porting_lib.tool.loot.CanToolPerformAction;
import io.github.fabricators_of_create.porting_lib.tool.mixin.BuilderAccessor;
import io.github.fabricators_of_create.porting_lib.tool.mixin.InvertedLootItemConditionAccessor;
import it.unimi.dsi.fastutil.objects.Object2ObjectOpenHashMap;
import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.minecraft.data.DataProvider;
import net.minecraft.data.DataWriter;
import net.minecraft.data.server.loottable.LootTableGenerator;
import net.minecraft.data.server.loottable.LootTableProvider;
import net.minecraft.data.server.loottable.vanilla.VanillaLootTableProviders;
import net.minecraft.item.Item;
import net.minecraft.item.Items;
import net.minecraft.loot.LootDataKey;
import net.minecraft.loot.LootDataLookup;
import net.minecraft.loot.LootDataType;
import net.minecraft.loot.LootPool;
import net.minecraft.loot.LootTable;
import net.minecraft.loot.LootTableReporter;
import net.minecraft.loot.condition.AlternativeLootCondition;
import net.minecraft.loot.condition.InvertedLootCondition;
import net.minecraft.loot.condition.LootCondition;
import net.minecraft.loot.condition.MatchToolLootCondition;
import net.minecraft.loot.context.LootContextTypes;
import net.minecraft.loot.entry.CombinedEntry;
import net.minecraft.loot.entry.LootPoolEntry;
import net.minecraft.predicate.item.ItemPredicate;
import net.minecraft.util.Identifier;
import net.minecraft.util.Util;
import net.minecraft.util.math.random.RandomSeed;
import net.minecraft.util.math.random.RandomSequence;

/**
 * Currently used only for replacing shears item to shears_dig tool action
 */
public final class ToolActionsLootTableProvider extends LootTableProvider {
	public ToolActionsLootTableProvider(FabricDataOutput packOutput) {
		super(packOutput, Set.of(), VanillaLootTableProviders.createVanillaProvider(packOutput).lootTypeGenerators);
	}

	protected void validate(Map<Identifier, LootTable> map, LootTableReporter validationcontext) {
		// Do not validate against all registered loot tables
	}

	public List<LootTableProvider.LootTypeGenerator> getTables() {
		return this.lootTypeGenerators.stream().map(entry -> {
			// Provides new sub provider with filtering only changed loot tables and replacing condition item to condition tag
			return new LootTableProvider.LootTypeGenerator(() -> replaceAndFilterChangesOnly(entry.comp_1068().get()), entry.comp_1069());
		}).collect(Collectors.toList());
	}

	private LootTableGenerator replaceAndFilterChangesOnly(LootTableGenerator subProvider) {
		return newConsumer -> subProvider.accept((resourceLocation, builder) -> {
			if (findAndReplaceInLootTableBuilder(builder, Items.field_8868, ToolActions.SHEARS_DIG)) {
				newConsumer.accept(resourceLocation, builder);
			}
		});
	}

	private boolean findAndReplaceInLootTableBuilder(LootTable.Builder builder, Item from, ToolAction toolAction) {
		List<LootPool> lootPools = ((BuilderAccessor) builder).getPools();
		boolean found = false;

		for (LootPool lootPool : lootPools) {
			if (findAndReplaceInLootPool(lootPool, from, toolAction)) {
				found = true;
			}
		}

		return found;
	}

	private boolean findAndReplaceInLootPool(LootPool lootPool, Item from, ToolAction toolAction) {
		LootPoolEntry[] lootEntries = lootPool.entries;
		LootCondition[] lootConditions = lootPool.conditions;
		boolean found = false;

		if (lootEntries == null) {
			throw new IllegalStateException(LootPool.class.getName() + " is missing field f_7902" + "3_");
		}

		for (LootPoolEntry lootEntry : lootEntries) {
			if (findAndReplaceInLootEntry(lootEntry, from, toolAction)) {
				found = true;
			}
			if (lootEntry instanceof CombinedEntry) {
				if (findAndReplaceInParentedLootEntry((CombinedEntry) lootEntry, from, toolAction)) {
					found = true;
				}
			}
		}

		if (lootConditions == null) {
			throw new IllegalStateException(LootPool.class.getName() + " is missing field f_7902" + "4_");
		}

		for (int i = 0; i < lootConditions.length; i++) {
			LootCondition lootCondition = lootConditions[i];
			if (lootCondition instanceof MatchToolLootCondition && checkMatchTool((MatchToolLootCondition) lootCondition, from)) {
				lootConditions[i] = CanToolPerformAction.canToolPerformAction(toolAction).build();
				found = true;
			} else if (lootCondition instanceof InvertedLootCondition) {
				LootCondition invLootCondition = ((InvertedLootItemConditionAccessor) lootCondition).getTerm();

				if (invLootCondition instanceof MatchToolLootCondition && checkMatchTool((MatchToolLootCondition) invLootCondition, from)) {
					lootConditions[i] = InvertedLootCondition.builder(CanToolPerformAction.canToolPerformAction(toolAction)).build();
					found = true;
				} else if (invLootCondition instanceof AlternativeLootCondition compositeLootItemCondition && findAndReplaceInComposite(compositeLootItemCondition, from, toolAction)) {
					found = true;
				}
			}
		}

		return found;
	}

	private boolean findAndReplaceInParentedLootEntry(CombinedEntry entry, Item from, ToolAction toolAction) {
		LootPoolEntry[] lootEntries = entry.children;
		boolean found = false;

		if (lootEntries == null) {
			throw new IllegalStateException(CombinedEntry.class.getName() + " is missing field f_7942" + "8_");
		}

		for (LootPoolEntry lootEntry : lootEntries) {
			if (findAndReplaceInLootEntry(lootEntry, from, toolAction)) {
				found = true;
			}
		}

		return found;
	}

	private boolean findAndReplaceInLootEntry(LootPoolEntry entry, Item from, ToolAction toolAction) {
		LootCondition[] lootConditions = entry.conditions;
		boolean found = false;

		if (lootConditions == null) {
			throw new IllegalStateException(LootPoolEntry.class.getName() + " is missing field f_7963" + "6_");
		}

		for (int i = 0; i < lootConditions.length; i++) {
			if (lootConditions[i] instanceof AlternativeLootCondition composite && findAndReplaceInComposite(composite, from, toolAction)) {
				found = true;
			} else if (lootConditions[i] instanceof MatchToolLootCondition && checkMatchTool((MatchToolLootCondition) lootConditions[i], from)) {
				lootConditions[i] = CanToolPerformAction.canToolPerformAction(toolAction).build();
				found = true;
			}
		}

		return found;
	}

	private boolean findAndReplaceInComposite(AlternativeLootCondition alternative, Item from, ToolAction toolAction) {
		LootCondition[] lootConditions = alternative.terms;
		boolean found = false;

		if (lootConditions == null) {
			throw new IllegalStateException(AlternativeLootCondition.class.getName() + " is missing field f_28560" + "9_");
		}

		for (int i = 0; i < lootConditions.length; i++) {
			if (lootConditions[i] instanceof MatchToolLootCondition && checkMatchTool((MatchToolLootCondition) lootConditions[i], from)) {
				lootConditions[i] = CanToolPerformAction.canToolPerformAction(toolAction).build();
				found = true;
			}
		}

		return found;
	}

	private boolean checkMatchTool(MatchToolLootCondition lootCondition, Item expected) {
		ItemPredicate predicate = lootCondition.predicate;
		Set<Item> items = predicate.items;
		return items != null && items.contains(expected);
	}

	@Override
	public CompletableFuture<?> run(DataWriter pOutput) {
		final Map<Identifier, LootTable> map = Maps.newHashMap();
		Map<RandomSeed.XoroshiroSeed, Identifier> map1 = new Object2ObjectOpenHashMap<>();
		this.getTables().forEach((entry) -> entry.comp_1068().get().accept((key, builder) -> {
			Identifier id = map1.put(RandomSequence.createSeed(key), key);
			if (id != null) {
				Util.error("Loot table random sequence seed collision on " + id + " and " + key);
			}

			builder.randomSequenceId(key);
			if (map.put(key, builder.type(entry.comp_1069()).build()) != null) {
				throw new IllegalStateException("Duplicate loot table " + key);
			}
		}));
		LootTableReporter validationcontext = new LootTableReporter(LootContextTypes.field_1177, new LootDataLookup() {
			@Nullable
			public <T> T getElement(LootDataKey<T> p_279283_) {
				return (T) (p_279283_.comp_1474() == LootDataType.field_44498 ? map.get(p_279283_.id()) : null);
			}
		});

		validate(map, validationcontext);

		Multimap<String, String> multimap = validationcontext.getMessages();
		if (!multimap.isEmpty()) {
			multimap.forEach((p_124446_, p_124447_) -> {
				LOGGER.warn("Found validation problem in {}: {}", p_124446_, p_124447_);
			});
			throw new IllegalStateException("Failed to validate loot tables, see logs");
		} else {
			return CompletableFuture.allOf(map.entrySet().stream().map((lootTableEntry) -> {
				Identifier lootTableId = lootTableEntry.getKey();
				LootTable loottable = lootTableEntry.getValue();
				Path path = this.pathResolver.resolveJson(lootTableId);
				return DataProvider.writeToPath(pOutput, LootDataType.field_44498.getGson().toJsonTree(loottable), path);
			}).toArray(CompletableFuture[]::new));
		}
	}
}

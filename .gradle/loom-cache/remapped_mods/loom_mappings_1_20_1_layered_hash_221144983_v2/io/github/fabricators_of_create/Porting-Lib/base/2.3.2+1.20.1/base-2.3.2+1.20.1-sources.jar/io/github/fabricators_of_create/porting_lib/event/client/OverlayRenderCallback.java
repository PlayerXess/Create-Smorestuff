package io.github.fabricators_of_create.porting_lib.event.client;

import com.mojang.blaze3d.systems.RenderSystem;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.event.Event;
import net.fabricmc.fabric.api.event.EventFactory;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.util.Window;
import net.minecraft.util.Identifier;

@Environment(EnvType.CLIENT)
public interface OverlayRenderCallback {
	Identifier GUI_ICONS_LOCATION = new Identifier("textures/gui/icons.png");

	Event<OverlayRenderCallback> EVENT = EventFactory.createArrayBacked(OverlayRenderCallback.class, callbacks -> (guiGraphics, partialTicks, window, type) -> {
		for (OverlayRenderCallback callback : callbacks) {
			if (callback.onOverlayRender(guiGraphics, partialTicks, window, type)) {
				resetTexture();
				return true;
			}
		}
		resetTexture();
		return false;
	});

	private static void resetTexture() { // in case overlays change it, which is very likely.
		RenderSystem.setShaderTexture(0, GUI_ICONS_LOCATION);
	}

	boolean onOverlayRender(DrawContext guiGraphics, float partialTicks, Window window, Types type);

	enum Types {
		AIR,
		CROSSHAIRS,
		PLAYER_HEALTH
	}
}

package io.github.fabricators_of_create.porting_lib.models.geometry.extensions;

import io.github.fabricators_of_create.porting_lib.models.geometry.IUnbakedGeometry;
import io.github.fabricators_of_create.porting_lib.models.geometry.VisibilityData;
import java.util.function.Function;
import net.minecraft.client.render.model.Baker;
import net.minecraft.client.render.model.json.JsonUnbakedModel;
import net.minecraft.client.render.model.json.ModelOverrideList;
import net.minecraft.client.texture.Sprite;
import net.minecraft.client.util.SpriteIdentifier;
import net.minecraft.util.math.AffineTransformation;

public interface BlockModelExtensions {
	default ModelOverrideList getOverrides(Baker pModelBakery, JsonUnbakedModel pModel, Function<SpriteIdentifier, Sprite> textureGetter) {
		throw new RuntimeException("this should be overridden via mixin. what?");
	}

	default void setCustomGeometry(IUnbakedGeometry<?> geometry) {
		throw new RuntimeException("this should be overridden via mixin. what?");
	}

	default IUnbakedGeometry<?> getCustomGeometry() {
		throw new RuntimeException("this should be overridden via mixin. what?");
	}

	default boolean isComponentVisible(String part, boolean fallback) {
		throw new RuntimeException("this should be overridden via mixin. what?");
	}

	default VisibilityData getVisibilityData() {
		throw new RuntimeException("this should be overridden via mixin. what?");
	}

	default AffineTransformation getRootTransform() {
		throw new RuntimeException("this should be overridden via mixin. what?");
	}

	default void setRootTransform(AffineTransformation rootTransform) {
		throw new RuntimeException("this should be overridden via mixin. what?");
	}
}

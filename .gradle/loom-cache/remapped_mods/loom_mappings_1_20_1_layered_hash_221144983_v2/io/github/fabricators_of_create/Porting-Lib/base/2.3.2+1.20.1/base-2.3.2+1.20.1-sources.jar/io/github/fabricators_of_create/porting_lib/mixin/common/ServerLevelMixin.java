package io.github.fabricators_of_create.porting_lib.mixin.common;

import io.github.fabricators_of_create.porting_lib.event.common.BlockEvents;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.EnumSet;
import java.util.function.Supplier;
import net.minecraft.block.Block;
import net.minecraft.registry.DynamicRegistryManager;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.profiler.Profiler;
import net.minecraft.world.MutableWorldProperties;
import net.minecraft.world.World;
import net.minecraft.world.dimension.DimensionType;

@Mixin(ServerWorld.class)
public abstract class ServerLevelMixin extends World {
	protected ServerLevelMixin(MutableWorldProperties writableLevelData, RegistryKey<World> resourceKey, DynamicRegistryManager registryAccess, RegistryEntry<DimensionType> holder, Supplier<Profiler> supplier, boolean bl, boolean bl2, long l, int i) {
		super(writableLevelData, resourceKey, registryAccess, holder, supplier, bl, bl2, l, i);
	}

	@Inject(method = "updateNeighborsAt", at = @At("HEAD"))
	private void neighborNotify(BlockPos pPos, Block block, CallbackInfo ci) {
		BlockEvents.NeighborNotifyEvent event = new BlockEvents.NeighborNotifyEvent(this, pPos, this.getBlockState(pPos), EnumSet.allOf(Direction.class), false);
		event.sendEvent();
	}

	@Inject(method = "updateNeighborsAtExceptFromFacing", at = @At("HEAD"), cancellable = true)
	private void neighborNotifyExpectFacing(BlockPos pPos, Block block, Direction pSkipSide, CallbackInfo ci) {
		EnumSet<Direction> directions =EnumSet.allOf(Direction.class);
		directions.remove(pSkipSide);
		BlockEvents.NeighborNotifyEvent event = new BlockEvents.NeighborNotifyEvent(this, pPos, this.getBlockState(pPos), directions, false);
		event.sendEvent();
		if (event.isCanceled())
			ci.cancel();
	}
}

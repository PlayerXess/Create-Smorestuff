package io.github.fabricators_of_create.porting_lib.data;

import java.util.Set;
import java.util.function.BiConsumer;
import net.minecraft.block.Block;
import net.minecraft.data.server.loottable.BlockLootTableGenerator;
import net.minecraft.item.Item;
import net.minecraft.loot.LootTable;
import net.minecraft.loot.LootTables;
import net.minecraft.registry.Registries;
import net.minecraft.resource.featuretoggle.FeatureSet;
import net.minecraft.util.Identifier;
import com.google.common.collect.Sets;

public abstract class ModdedBlockLootSubProvider extends BlockLootTableGenerator {
	protected ModdedBlockLootSubProvider(Set<Item> set, FeatureSet featureFlagSet) {
		super(set, featureFlagSet);
	}

	@Override
	public void accept(BiConsumer<Identifier, LootTable.Builder> biConsumer) {
		this.generate();
		Set<Identifier> set = Sets.<Identifier>newHashSet();

		for(Block block : getKnownBlocks()) {
			Identifier resourceLocation = block.getLootTableId();
			if (resourceLocation != LootTables.EMPTY && set.add(resourceLocation)) {
				LootTable.Builder builder6 = lootTables.remove(resourceLocation);
				if (builder6 == null) {
					throw new IllegalStateException(String.format("Missing loottable '%s' for '%s'", resourceLocation, Registries.BLOCK.getId(block)));
				}

				biConsumer.accept(resourceLocation, builder6);
			}
		}

		if (!lootTables.isEmpty()) {
			throw new IllegalStateException("Created block loot tables for non-blocks: " + lootTables.keySet());
		}
	}

	protected Iterable<Block> getKnownBlocks() {
		return Registries.BLOCK;
	}
}

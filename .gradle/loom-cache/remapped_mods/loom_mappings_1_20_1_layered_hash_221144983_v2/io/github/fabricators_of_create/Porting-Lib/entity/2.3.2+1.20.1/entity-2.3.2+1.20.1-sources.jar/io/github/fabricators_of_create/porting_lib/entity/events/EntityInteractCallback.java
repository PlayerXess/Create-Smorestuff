package io.github.fabricators_of_create.porting_lib.entity.events;

import net.fabricmc.fabric.api.event.Event;
import net.fabricmc.fabric.api.event.EventFactory;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import org.jetbrains.annotations.Nullable;

public interface EntityInteractCallback {
	/**
	 * Fired when an entity is interacted with by a player, from {@link PlayerEntity#interact(Entity, Hand)}
	 */
	Event<EntityInteractCallback> EVENT = EventFactory.createArrayBacked(EntityInteractCallback.class, callbacks -> ((player, hand, target) -> {
		for(EntityInteractCallback e : callbacks) {
			ActionResult result = e.onEntityInteract(player, hand, target);
			if(result != null)
				return result;
		}
		return null;
	}));

	/**
	 * @return any non-null value to cancel the interaction and replace the result of it
	 */
	@Nullable
	ActionResult onEntityInteract(PlayerEntity player, Hand hand, Entity target);
}

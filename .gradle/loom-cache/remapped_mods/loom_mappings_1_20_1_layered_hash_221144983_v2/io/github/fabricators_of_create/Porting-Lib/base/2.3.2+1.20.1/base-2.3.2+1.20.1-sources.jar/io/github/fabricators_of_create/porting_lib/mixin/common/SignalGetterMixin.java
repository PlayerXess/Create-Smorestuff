package io.github.fabricators_of_create.porting_lib.mixin.common;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;

import io.github.fabricators_of_create.porting_lib.block.WeakPowerCheckingBlock;
import net.minecraft.block.BlockState;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.world.BlockView;
import net.minecraft.world.RedstoneView;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(RedstoneView.class)
public interface SignalGetterMixin extends BlockView {
	@WrapOperation(
			method = "getSignal",
			at = @At(
					value = "INVOKE",
					target = "Lnet/minecraft/world/level/block/state/BlockState;isRedstoneConductor(Lnet/minecraft/world/level/BlockGetter;Lnet/minecraft/core/BlockPos;)Z"
			)
	)
	private boolean port_lib$modifyRedstoneSignal(BlockState state, BlockView level, BlockPos pos, Operation<Boolean> original,
												  BlockPos pos2, Direction facing) {
		if (state.getBlock() instanceof WeakPowerCheckingBlock checking) {
			return checking.shouldCheckWeakPower(state, (RedstoneView) this, pos, facing);
		}
		return original.call(state, level, pos);
	}
}

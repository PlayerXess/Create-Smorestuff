package io.github.fabricators_of_create.porting_lib.extensions.extensions;

import io.github.fabricators_of_create.porting_lib.common.util.IPlantable;
import io.github.fabricators_of_create.porting_lib.common.util.PlantType;
import io.github.fabricators_of_create.porting_lib.extensions.ClientExtensionHooks;
import net.fabricmc.api.EnvType;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.GlazedTerracottaBlock;
import net.minecraft.block.PlantBlock;
import net.minecraft.client.render.Camera;
import net.minecraft.registry.tag.BlockTags;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.math.random.Random;
import net.minecraft.world.BlockView;
import net.minecraft.world.WorldView;
import net.minecraft.world.gen.feature.TreeFeatureConfig;
import java.util.function.BiConsumer;

public interface BlockExtensions {
	default boolean canSustainPlant(BlockState state, BlockView world, BlockPos pos, Direction facing, IPlantable plantable) {
		BlockState plant = plantable.getPlant(world, pos.offset(facing));
		PlantType type = plantable.getPlantType(world, pos.offset(facing));

		if (plant.getBlock() == Blocks.field_10029)
			return state.isOf(Blocks.field_10029) || state.isOf(Blocks.field_10102) || state.isOf(Blocks.field_10534);

		if (plant.getBlock() == Blocks.field_10424 && this == Blocks.field_10424)
			return true;

		if (plantable instanceof PlantBlock && ((PlantBlock)plantable).canPlantOnTop(state, world, pos))
			return true;

		if (PlantType.DESERT.equals(type)) {
			return this == Blocks.field_10102 || this == Blocks.field_10415 || this instanceof GlazedTerracottaBlock;
		} else if (PlantType.NETHER.equals(type)) {
			return this == Blocks.field_10114;
		} else if (PlantType.CROP.equals(type)) {
			return state.isOf(Blocks.field_10362);
		} else if (PlantType.CAVE.equals(type)) {
			return state.isSideSolidFullSquare(world, pos, Direction.field_11036);
		} else if (PlantType.PLAINS.equals(type)) {
			return this == Blocks.field_10219 || ((Block)this).getDefaultState().isIn(BlockTags.field_29822) || this == Blocks.field_10362;
		} else if (PlantType.BEACH.equals(type)) {
			boolean isBeach = state.isOf(Blocks.field_10219) || ((Block)this).getDefaultState().isIn(BlockTags.field_29822) || state.isOf(Blocks.field_10102) || state.isOf(Blocks.field_10534);
			boolean hasWater = false;
			for (Direction face : Direction.Type.field_11062) {
				BlockState blockState = world.getBlockState(pos.offset(face));
				net.minecraft.fluid.FluidState fluidState = world.getFluidState(pos.offset(face));
				hasWater |= blockState.isOf(Blocks.field_10110);
				hasWater |= fluidState.isIn(net.minecraft.registry.tag.FluidTags.field_15517);
				if (hasWater)
					break; //No point continuing.
			}
			return isBeach && hasWater;
		}
		return false;
	}

	/**
	 * Used to determine the state 'viewed' by an entity (see
	 * {@link Camera#getBlockAtCamera()}).
	 * Can be used by fluid blocks to determine if the viewpoint is within the fluid or not.
	 *
	 * @param state     the state
	 * @param level     the level
	 * @param pos       the position
	 * @param viewpoint the viewpoint
	 * @return the block state that should be 'seen'
	 */
	default BlockState getStateAtViewpoint(BlockState state, BlockView level, BlockPos pos, Vec3d viewpoint) {
		return state;
	}

	/**
	 * Called when a tree grows on top of this block and tries to set it to dirt by the trunk placer.
	 * An override that returns true is responsible for using the place function to
	 * set blocks in the world properly during generation. A modded grass block might override this method
	 * to ensure it turns into the corresponding modded dirt instead of regular dirt when a tree grows on it.
	 * For modded grass blocks, returning true from this method is NOT a substitute for adding your block
	 * to the #minecraft:dirt tag, rather for changing the behaviour to something other than setting to dirt.
	 *
	 * NOTE: This happens DURING world generation, the generation may be incomplete when this is called.
	 * Use the placeFunction when modifying the level.
	 *
	 * @param state The current state
	 * @param level The current level
	 * @param placeFunction Function to set blocks in the level for the tree, use this instead of the level directly
	 * @param randomSource The random source
	 * @param pos Position of the block to be set to dirt
	 * @param config Configuration of the trunk placer. Consider azalea trees, which should place rooted dirt instead of regular dirt.
	 * @return True to ignore vanilla behaviour
	 */
	default boolean onTreeGrow(BlockState state, WorldView level, BiConsumer<BlockPos, BlockState> placeFunction, Random randomSource, BlockPos pos, TreeFeatureConfig config) {
		return false;
	}

	/**
	 * Whether this block hides the neighbors face pointed towards by the given direction.
	 * <p>
	 * This method should only be used for blocks you don't control, for your own blocks override
	 * {@link Block#isSideInvisible(BlockState, BlockState, Direction)} on the respective block instead
	 * <p>
	 * WARNING: This method is likely to be called from a worker thread! If you want to retrieve a
	 *          {@link net.minecraft.block.entity.BlockEntity} from the given level, make sure to use
	 *          {@link net.minecraftforge.common.extensions.IForgeBlockGetter#getExistingBlockEntity(BlockPos)} to not
	 *          accidentally create a new or delete an old {@link net.minecraft.block.entity.BlockEntity}
	 *          off of the main thread as this would cause a write operation to the given {@link BlockView} and cause
	 *          a CME in the process. Any other direct or indirect write operation to the {@link BlockView} will have
	 *          the same outcome.
	 *
	 * @param level The world
	 * @param pos The blocks position in the world
	 * @param state The blocks {@link BlockState}
	 * @param neighborState The neighboring blocks {@link BlockState}
	 * @param dir The direction towards the neighboring block
	 */
	default boolean hidesNeighborFace(BlockView level, BlockPos pos, BlockState state, BlockState neighborState, Direction dir) {
		return false;
	}

	/**
	 * Whether this block allows a neighboring block to hide the face of this block it touches.
	 * If this returns true, {@link BlockStateExtensions#hidesNeighborFace(BlockView, BlockPos, BlockState, Direction)}
	 * will be called on the neighboring block.
	 */
	default boolean supportsExternalFaceHiding(BlockState state) {
		if (FabricLoader.getInstance().getEnvironmentType() == EnvType.CLIENT) {
			return ClientExtensionHooks.isBlockInSolidLayer(state);
		}
		return true;
	}
}

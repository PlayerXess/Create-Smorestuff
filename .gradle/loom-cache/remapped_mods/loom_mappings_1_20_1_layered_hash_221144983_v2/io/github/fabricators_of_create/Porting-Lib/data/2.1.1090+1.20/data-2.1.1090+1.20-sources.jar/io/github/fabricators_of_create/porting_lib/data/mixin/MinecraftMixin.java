package io.github.fabricators_of_create.porting_lib.data.mixin;

import io.github.fabricators_of_create.porting_lib.data.extensions.MinecraftExtension;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.RunArgs;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(MinecraftClient.class)
public class MinecraftMixin implements MinecraftExtension {
	private RunArgs port_lib$gameConfig;

	@Inject(method = "<init>", at = @At(value = "INVOKE", target = "Lnet/minecraft/Util;getNanos()J"))
	private void port_lib$saveGameConfig(RunArgs gameConfig, CallbackInfo ci) {
		this.port_lib$gameConfig = gameConfig;
	}

	@Override
	public RunArgs port_lib$getGameConfig() {
		return this.port_lib$gameConfig;
	}
}

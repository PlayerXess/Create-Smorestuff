package io.github.fabricators_of_create.porting_lib.util;

import javax.annotation.Nullable;
import net.minecraft.structure.StructurePlacementData;
import net.minecraft.structure.StructureTemplate;
import net.minecraft.structure.StructureTemplate.StructureEntityInfo;
import net.minecraft.structure.processor.StructureProcessor;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.WorldAccess;
import java.util.ArrayList;
import java.util.List;

/**
 * Small utilities for StructureTemplates provided by forge.
 */
public class StructureTemplateUtils {
	/**
	 * Transforms the given vector using the provided placement settings (mirror, rotation, pivot)
	 */
	public static Vec3d transformedVec3d(StructurePlacementData settings, Vec3d pos) {
		return StructureTemplate.transformAround(
				pos, settings.getMirror(), settings.getRotation(), settings.getPosition()
		);
	}

	/**
	 * Processes entity infos in the same way blocks are.
	 * StructureProcessors may optionally implement a method to process entities.
	 */
	public static List<StructureEntityInfo> processEntityInfos(@Nullable StructureTemplate template, WorldAccess level,
															   BlockPos pos, StructurePlacementData settings,
															   List<StructureEntityInfo> entityInfos) {
		List<StructureEntityInfo> processed = new ArrayList<>();
		for(StructureEntityInfo entityInfo : entityInfos) {
			Vec3d entityPos = transformedVec3d(settings, entityInfo.pos).add(Vec3d.of(pos));
			BlockPos blockpos = StructureTemplate.transform(settings, entityInfo.blockPos).add(pos);
			StructureEntityInfo info = new StructureEntityInfo(entityPos, blockpos, entityInfo.nbt);
			for (StructureProcessor proc : settings.getProcessors()) {
				info = proc.processEntity(level, pos, entityInfo, info, settings, template);
				if (info == null)
					break;
			}
			if (info != null)
				processed.add(info);
		}
		return processed;
	}
}

package io.github.fabricators_of_create.porting_lib.models.geometry;

import net.minecraft.client.render.model.ModelBakeSettings;
import net.minecraft.util.math.AffineTransformation;

/**
 * Simple implementation of {@link ModelBakeSettings}.
 */
public final class SimpleModelState implements ModelBakeSettings {
	private final AffineTransformation transformation;
	private final boolean uvLocked;

	public SimpleModelState(AffineTransformation transformation, boolean uvLocked) {
		this.transformation = transformation;
		this.uvLocked = uvLocked;
	}

	public SimpleModelState(AffineTransformation transformation) {
		this(transformation, false);
	}

	@Override
	public AffineTransformation getRotation() {
		return transformation;
	}

	@Override
	public boolean isUvLocked() {
		return uvLocked;
	}
}


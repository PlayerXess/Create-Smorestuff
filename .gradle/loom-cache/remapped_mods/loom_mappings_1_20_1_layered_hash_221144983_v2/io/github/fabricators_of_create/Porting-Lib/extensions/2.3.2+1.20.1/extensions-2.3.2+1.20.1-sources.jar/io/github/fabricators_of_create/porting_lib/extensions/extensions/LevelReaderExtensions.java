package io.github.fabricators_of_create.porting_lib.extensions.extensions;

import net.minecraft.util.math.BlockPos;
import net.minecraft.world.WorldView;

public interface LevelReaderExtensions {
	default boolean isAreaLoaded(BlockPos center, int range) {
		return ((WorldView)this).isRegionLoaded(center.add(-range, -range, -range), center.add(range, range, range));
	}
}

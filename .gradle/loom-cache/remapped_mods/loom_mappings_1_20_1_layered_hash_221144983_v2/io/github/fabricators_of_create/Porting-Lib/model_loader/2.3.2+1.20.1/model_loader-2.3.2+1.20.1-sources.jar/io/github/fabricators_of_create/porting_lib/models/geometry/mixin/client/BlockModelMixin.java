package io.github.fabricators_of_create.porting_lib.models.geometry.mixin.client;

import java.util.List;
import java.util.function.Function;
import net.minecraft.client.render.model.BakedModel;
import net.minecraft.client.render.model.Baker;
import net.minecraft.client.render.model.ModelBakeSettings;
import net.minecraft.client.render.model.UnbakedModel;
import net.minecraft.client.render.model.json.JsonUnbakedModel;
import net.minecraft.client.render.model.json.ModelOverride;
import net.minecraft.client.render.model.json.ModelOverrideList;
import net.minecraft.client.texture.Sprite;
import net.minecraft.client.util.SpriteIdentifier;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.AffineTransformation;
import io.github.fabricators_of_create.porting_lib.models.geometry.VisibilityData;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import io.github.fabricators_of_create.porting_lib.models.geometry.IUnbakedGeometry;
import io.github.fabricators_of_create.porting_lib.models.geometry.extensions.BlockModelExtensions;

@Mixin(JsonUnbakedModel.class)
public class BlockModelMixin implements BlockModelExtensions {
	@Shadow
	@Final
	private List<ModelOverride> overrides;
	@Shadow
	@Nullable
	public JsonUnbakedModel parent;
	@Unique
	private IUnbakedGeometry<?> customModel;
	@Unique
	@Nullable
	private AffineTransformation rootTransform;
	@Unique
	private final VisibilityData visibilityData = new VisibilityData();

	@Inject(
			method = "bake(Lnet/minecraft/client/resources/model/ModelBaker;Lnet/minecraft/client/renderer/block/model/BlockModel;Ljava/util/function/Function;Lnet/minecraft/client/resources/model/ModelState;Lnet/minecraft/resources/ResourceLocation;Z)Lnet/minecraft/client/resources/model/BakedModel;",
			at = @At("HEAD"),
			cancellable = true
	)
	public void handleCustomModels(Baker modelBaker, JsonUnbakedModel ownerModel, Function<SpriteIdentifier, Sprite> spriteGetter,
								   ModelBakeSettings modelTransform, Identifier modelLocation, boolean guiLight3d, CallbackInfoReturnable<BakedModel> cir) {
		IUnbakedGeometry<?> geometry = getCustomGeometry();
		if (geometry != null) {
			ModelOverrideList overrides = getOverrides(modelBaker, ownerModel, spriteGetter);
			cir.setReturnValue(geometry.bake(
					(JsonUnbakedModel) (Object) this, modelBaker, spriteGetter, modelTransform, overrides, modelLocation, guiLight3d
			));
		}
	}

	@Inject(method = "resolveParents", at = @At("HEAD"))
	private void handleCustomResolveParents(Function<Identifier, UnbakedModel> function, CallbackInfo ci) {
		if (getCustomGeometry() != null)
			getCustomGeometry().resolveParents(function, self());
	}

	@Override
	public ModelOverrideList getOverrides(Baker p_250138_, JsonUnbakedModel p_251800_, Function<SpriteIdentifier, Sprite> spriteGetter) {
		return this.overrides.isEmpty() ? ModelOverrideList.EMPTY : new ModelOverrideList(p_250138_, p_251800_, this.overrides/*, spriteGetter*/);
	}

	@Override
	public void setCustomGeometry(IUnbakedGeometry<?> geometry) {
		this.customModel = geometry;
	}

	@Override
	public IUnbakedGeometry<?> getCustomGeometry() {
		return this.parent != null && customModel == null ? this.parent.getCustomGeometry() : customModel;
	}

	@Override
	public VisibilityData getVisibilityData() {
		return this.visibilityData;
	}

	@Override
	public boolean isComponentVisible(String part, boolean fallback) {
		return self().parent != null && !visibilityData.hasCustomVisibility(part) ?
				self().parent.isComponentVisible(part, fallback) :
				visibilityData.isVisible(part, fallback);
	}

	@Override
	public AffineTransformation getRootTransform() {
		if (rootTransform != null)
			return rootTransform;
		return self().parent != null ? self().parent.getRootTransform() : AffineTransformation.identity();
	}

	public void setRootTransform(AffineTransformation rootTransform) {
		this.rootTransform = rootTransform;
	}

	private JsonUnbakedModel self() {
		return (JsonUnbakedModel) (Object) this;
	}
}

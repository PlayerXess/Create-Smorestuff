package io.github.fabricators_of_create.porting_lib.mixin.common;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import net.minecraft.entity.passive.SnowGolemEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import io.github.fabricators_of_create.porting_lib.extensions.extensions.IShearable;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import java.util.Collections;
import java.util.List;

@Mixin(SnowGolemEntity.class)
public abstract class SnowGolemMixin implements IShearable {

	@Shadow
	public abstract boolean readyForShearing();

	@Shadow
	public abstract void setPumpkin(boolean pumpkinEquipped);

	@Unique
	@Override
	public boolean isShearable(@Nonnull ItemStack item, World world, BlockPos pos) {
		return readyForShearing();
	}

	@Nonnull
	@Override
	public List<ItemStack> onSheared(@Nullable PlayerEntity player, @Nonnull ItemStack item, World world, BlockPos pos, int fortune) {
		world.playSoundFromEntity(null, (SnowGolemEntity) (Object) this, SoundEvents.field_22273, player == null ? SoundCategory.field_15245 : SoundCategory.field_15248, 1.0F, 1.0F);
		if (!world.isClient()) {
			setPumpkin(false);
			return Collections.singletonList(new ItemStack(Items.CARVED_PUMPKIN));
		}
		return Collections.emptyList();
	}
}

package io.github.fabricators_of_create.porting_lib.entity.mixin.common;

import io.github.fabricators_of_create.porting_lib.entity.events.PlayerEvents;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.ExperienceOrbEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.world.World;
import org.objectweb.asm.Opcodes;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ExperienceOrbEntity.class)
public abstract class ExperienceOrbMixin extends Entity {
	public ExperienceOrbMixin(EntityType<?> variant, World world) {
		super(variant, world);
	}

	@Inject(method = "playerTouch", at = @At(value = "FIELD", opcode = Opcodes.PUTFIELD, ordinal = 0), cancellable = true)
	private void port_lib$onPlayerPickupXp(PlayerEntity player, CallbackInfo ci) {
		PlayerEvents.PickupXp pickupXp = new PlayerEvents.PickupXp(player, (ExperienceOrbEntity) (Object) this);
		pickupXp.sendEvent();
		if (pickupXp.isCanceled())
			ci.cancel();
	}
}

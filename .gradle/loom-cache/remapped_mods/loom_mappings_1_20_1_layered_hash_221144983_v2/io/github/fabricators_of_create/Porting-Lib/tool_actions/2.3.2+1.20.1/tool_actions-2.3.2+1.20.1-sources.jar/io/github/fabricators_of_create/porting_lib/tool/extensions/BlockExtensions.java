package io.github.fabricators_of_create.porting_lib.tool.extensions;

import io.github.fabricators_of_create.porting_lib.tool.ToolAction;
import io.github.fabricators_of_create.porting_lib.tool.ToolActions;
import org.jetbrains.annotations.Nullable;

import java.util.Optional;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.Oxidizable;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.AxeItem;
import net.minecraft.item.HoneycombItem;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemUsageContext;
import net.minecraft.item.Items;
import net.minecraft.item.ShovelItem;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

// TODO: Re-evaluate how to make this work
@Deprecated(forRemoval = true)
public interface BlockExtensions {
	/**
	 * Returns the state that this block should transform into when right-clicked by a tool.
	 * For example: Used to determine if {@link ToolActions#AXE_STRIP an axe can strip},
	 * {@link ToolActions#SHOVEL_FLATTEN a shovel can path}, or {@link ToolActions#HOE_TILL a hoe can till}.
	 * Returns {@code null} if nothing should happen.
	 *
	 * @param state The current state
	 * @param context The use on context that the action was performed in
	 * @param toolAction The action being performed by the tool
	 * @param simulate If {@code true}, no actions that modify the world in any way should be performed. If {@code false}, the world may be modified.
	 * @return The resulting state after the action has been performed
	 */
	@Nullable
	default BlockState getToolModifiedState(BlockState state, ItemUsageContext context, ToolAction toolAction, boolean simulate) {
		BlockState toolModifiedState = getToolModifiedState(state, context.getWorld(), context.getBlockPos(),
				context.getPlayer(), context.getStack(), toolAction);

		if (toolModifiedState == null && ToolActions.HOE_TILL == toolAction && context.getStack().canPerformAction(ToolActions.HOE_TILL)) {
			// Logic copied from HoeItem#TILLABLES; needs to be kept in sync during updating
			Block block = state.getBlock();
			if (block == Blocks.field_28685) {
				if (!simulate && !context.getWorld().isClient) {
					Block.dropStack(context.getWorld(), context.getBlockPos(), context.getSide(), new ItemStack(Items.HANGING_ROOTS));
				}
				return Blocks.field_10566.getDefaultState();
			} else if ((block == Blocks.field_10219 || block == Blocks.field_10194 || block == Blocks.field_10566 || block == Blocks.field_10253) &&
					context.getWorld().getBlockState(context.getBlockPos().up()).isAir()) {
				return block == Blocks.field_10253 ? Blocks.field_10566.getDefaultState() : Blocks.field_10362.getDefaultState();
			}
		}

		return toolModifiedState;
	}

	/**
	 * Returns the state that this block should transform into when right clicked by a tool.
	 * For example: Used to determine if an axe can strip, a shovel can path, or a hoe can till.
	 * Return null if vanilla behavior should be disabled.
	 *
	 * @param state The current state
	 * @param world The world
	 * @param pos The block position in world
	 * @param player The player clicking the block
	 * @param stack The stack being used by the player
	 * @param toolAction The action being performed by the tool
	 * @return The resulting state after the action has been performed
	 */
	@Nullable
	default BlockState getToolModifiedState(BlockState state, World world, BlockPos pos, PlayerEntity player, ItemStack stack, ToolAction toolAction) {
		if (!stack.canPerformAction(toolAction)) return null;
		if (ToolActions.AXE_STRIP.equals(toolAction)) {
			Block block = AxeItem.STRIPPED_BLOCKS.get(state.getBlock());
			return block != null ? block.getDefaultState() : null;
		}
		else if(ToolActions.AXE_SCRAPE.equals(toolAction)) return Oxidizable.getDecreasedOxidationState(state).orElse(null);
		else if(ToolActions.AXE_WAX_OFF.equals(toolAction)) return Optional.ofNullable(HoneycombItem.WAXED_TO_UNWAXED_BLOCKS.get().get(state.getBlock())).map((p_150694_) -> {
			return p_150694_.getStateWithProperties(state);
		}).orElse(null);
			//else if(ToolActions.HOE_TILL.equals(toolAction)) return HoeItem.getHoeTillingState(state); //TODO HoeItem bork
		else if (ToolActions.SHOVEL_FLATTEN.equals(toolAction)) return ShovelItem.PATH_STATES.get(state.getBlock());
		return null;
	}
}

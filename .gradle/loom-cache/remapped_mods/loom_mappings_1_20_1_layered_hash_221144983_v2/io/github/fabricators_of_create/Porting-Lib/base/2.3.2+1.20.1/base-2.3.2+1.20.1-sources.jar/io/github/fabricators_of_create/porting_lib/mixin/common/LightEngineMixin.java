package io.github.fabricators_of_create.porting_lib.mixin.common;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;

import io.github.fabricators_of_create.porting_lib.block.LightEmissiveBlock;
import net.minecraft.block.BlockState;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.BlockView;
import net.minecraft.world.chunk.light.ChunkLightProvider;

@Mixin(ChunkLightProvider.class)
public class LightEngineMixin {
	@WrapOperation(method = "hasDifferentLightProperties", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/level/block/state/BlockState;getLightEmission()I"))
	private static int customLightEmissionBlock(BlockState state, Operation<Integer> operation, BlockView world, BlockPos pos) {
		if (state.getBlock() instanceof LightEmissiveBlock lightEmissiveBlock)
			return lightEmissiveBlock.getLightEmission(state, world, pos);
		return operation.call(state);
	}
}

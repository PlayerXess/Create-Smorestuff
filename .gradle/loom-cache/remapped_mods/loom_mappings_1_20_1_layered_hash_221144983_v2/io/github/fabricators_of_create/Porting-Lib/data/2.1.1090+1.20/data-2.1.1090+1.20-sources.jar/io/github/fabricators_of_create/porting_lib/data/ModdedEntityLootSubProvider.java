package io.github.fabricators_of_create.porting_lib.data;

import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.function.BiConsumer;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import net.minecraft.data.server.loottable.EntityLootTableGenerator;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnGroup;
import net.minecraft.loot.LootTable;
import net.minecraft.loot.LootTables;
import net.minecraft.registry.Registries;
import net.minecraft.resource.featuretoggle.FeatureSet;
import net.minecraft.util.Identifier;
import com.google.common.collect.Maps;
import com.google.common.collect.Sets;

public abstract class ModdedEntityLootSubProvider extends EntityLootTableGenerator {

	private final FeatureSet allowed;
	private final FeatureSet required;

	public ModdedEntityLootSubProvider(FeatureSet enabledFeatures) {
		this(enabledFeatures, enabledFeatures);
	}

	public ModdedEntityLootSubProvider(FeatureSet allowed, FeatureSet required) {
		super(allowed, required);
		this.allowed = allowed;
		this.required = required;
	}

	public void accept(BiConsumer<Identifier, LootTable.Builder> output) {
		this.generate();
		Set<Identifier> set = Sets.newHashSet();
		this.getKnownEntityTypes().map(EntityType::getRegistryEntry).forEach((entityTypeReference) -> {
			EntityType<?> entitytype = entityTypeReference.comp_349();
			if (entitytype.isEnabled(this.allowed)) {
				if (shouldCheck(entitytype)) {
					Map<Identifier, LootTable.Builder> map = this.lootTables.remove(entitytype);
					Identifier resourcelocation = entitytype.getLootTableId();
					if (!resourcelocation.equals(LootTables.EMPTY) && entitytype.isEnabled(this.required) && (map == null || !map.containsKey(resourcelocation))) {
						throw new IllegalStateException(String.format(Locale.ROOT, "Missing loottable '%s' for '%s'", resourcelocation, entityTypeReference.registryKey().getValue()));
					}

					if (map != null) {
						map.forEach((location, builder) -> {
							if (!set.add(location)) {
								throw new IllegalStateException(String.format(Locale.ROOT, "Duplicate loottable '%s' for '%s'", location, entityTypeReference.registryKey().getValue()));
							} else {
								output.accept(location, builder);
							}
						});
					}
				} else {
					Map<Identifier, LootTable.Builder> map1 = this.lootTables.remove(entitytype);
					if (map1 != null) {
						throw new IllegalStateException(String.format(Locale.ROOT, "Weird loottables '%s' for '%s', not a LivingEntity so should not have loot", map1.keySet().stream().map(Identifier::toString).collect(Collectors.joining(",")), entityTypeReference.registryKey().getValue()));
					}
				}

			}
		});
		if (!this.lootTables.isEmpty()) {
			throw new IllegalStateException("Created loot tables for entities not supported by datapack: " + this.lootTables.keySet());
		}
	}

	protected Stream<EntityType<?>> getKnownEntityTypes() {
		return Registries.ENTITY_TYPE.stream();
	}

	private static boolean shouldCheck(EntityType<?> entityType) {
		return ENTITY_TYPES_IN_MISC_GROUP_TO_CHECK.contains(entityType) || entityType.getSpawnGroup() != SpawnGroup.field_17715;
	}
}

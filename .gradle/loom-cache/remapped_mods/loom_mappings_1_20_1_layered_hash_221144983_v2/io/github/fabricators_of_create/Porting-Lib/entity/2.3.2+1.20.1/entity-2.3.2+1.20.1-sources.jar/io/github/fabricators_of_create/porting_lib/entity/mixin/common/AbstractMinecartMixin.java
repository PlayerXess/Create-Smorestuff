package io.github.fabricators_of_create.porting_lib.entity.mixin.common;

import io.github.fabricators_of_create.porting_lib.entity.extensions.AbstractMinecartExtensions;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.MovementType;
import net.minecraft.entity.vehicle.AbstractMinecartEntity;
import net.minecraft.registry.tag.BlockTags;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;

@Mixin(AbstractMinecartEntity.class)
public abstract class AbstractMinecartMixin extends Entity implements AbstractMinecartExtensions {
	@Shadow
	protected abstract double getMaxSpeed();

	public AbstractMinecartMixin(EntityType<?> variant, World world) {
		super(variant, world);
	}

	@Override
	public void moveMinecartOnRail(BlockPos pos) {
		double d24 = hasPassengers() ? 0.75D : 1.0D;
		double d25 = getMaxSpeed(); // getMaxSpeed instead of getMaxSpeedWithRail *should* be fine after intense pain looking at Forge patches
		Vec3d vec3d1 = getVelocity();
		move(MovementType.field_6308, new Vec3d(MathHelper.clamp(d24 * vec3d1.x, -d25, d25), 0.0D, MathHelper.clamp(d24 * vec3d1.z, -d25, d25)));
	}

	@Override
	public BlockPos getCurrentRailPos() {
		BlockPos pos = new BlockPos(MathHelper.floor(getX()), MathHelper.floor(getY()), MathHelper.floor(getZ()));
		BlockPos below = pos.down();
		if (getWorld().getBlockState(below).isIn(BlockTags.field_15463)) {
			pos = below;
		}

		return pos;
	}
}

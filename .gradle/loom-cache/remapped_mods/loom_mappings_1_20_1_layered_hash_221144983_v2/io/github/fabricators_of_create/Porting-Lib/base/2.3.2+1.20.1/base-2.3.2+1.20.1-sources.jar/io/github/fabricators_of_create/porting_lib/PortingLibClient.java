package io.github.fabricators_of_create.porting_lib;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import io.github.fabricators_of_create.porting_lib.util.FluidTextUtil;
import io.github.fabricators_of_create.porting_lib.util.LogicalSidedProvider;
import io.github.fabricators_of_create.porting_lib.util.NetworkHooks;
import io.netty.buffer.Unpooled;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.resource.ResourceManagerHelper;
import net.fabricmc.fabric.api.screenhandler.v1.ExtendedScreenHandlerType;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.ingame.HandledScreens;
import net.minecraft.client.gui.screen.ingame.ScreenHandlerProvider;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.registry.Registries;
import net.minecraft.resource.ResourceType;
import net.minecraft.screen.ScreenHandler;
import net.minecraft.screen.ScreenHandlerType;
import net.minecraft.text.Text;

public class PortingLibClient implements ClientModInitializer {
	private final Logger LOGGER = LoggerFactory.getLogger("porting_lib_client");

	@Override
	public void onInitializeClient() {
		ResourceManagerHelper.get(ResourceType.field_14188).registerReloadListener(FluidTextUtil.NUMBER_FORMAT);
		ClientPlayNetworking.registerGlobalReceiver(NetworkHooks.OPEN_ID, (client, handler, buf, responseSender) -> {
			int typeId = buf.readVarInt();
			int syncId = buf.readVarInt();
			Text title = buf.readText();
			PacketByteBuf extraData = new PacketByteBuf(Unpooled.wrappedBuffer(buf.readByteArray(32600)));
			// Retain the buf since we must open the screen handler with it's extra modded data on the client thread
			// The buf will be released after the screen is opened
			buf.retain();

			client.execute(() -> openScreen(typeId, syncId, title, extraData));
		});
		ClientLifecycleEvents.CLIENT_STARTED.register(client -> LogicalSidedProvider.setClient(() -> client));


	}

	private void openScreen(int typeId, int syncId, Text title, PacketByteBuf buf) {
		try {
			ScreenHandlerType<?> type = Registries.SCREEN_HANDLER.get(typeId);

			if (type == null) {
				LOGGER.warn("Unknown screen handler ID: {}", typeId);
				return;
			}

			if (!(type instanceof ExtendedScreenHandlerType<?>)) {
				LOGGER.warn("Received extended opening packet for non-extended screen handler {}", typeId);
				return;
			}

			ScreenHandler c = ((ExtendedScreenHandlerType)type).create(syncId, MinecraftClient.getInstance().player.getInventory(), buf);
			@SuppressWarnings("unchecked")
			Screen s = ((HandledScreens.Provider<ScreenHandler, ?>)HandledScreens.getProvider(type)).create(c, MinecraftClient.getInstance().player.getInventory(), title);
			MinecraftClient.getInstance().player.currentScreenHandler = ((ScreenHandlerProvider<?>)s).getScreenHandler();
			MinecraftClient.getInstance().setScreen(s);
		} finally {
			buf.release(); // Release the buf
		}
	}
}

package io.github.fabricators_of_create.porting_lib.item;

import javax.annotation.Nullable;
import net.minecraft.item.ItemStack;
import net.minecraft.item.map.MapState;
import net.minecraft.world.World;

import static net.minecraft.item.FilledMapItem.getMapId;
import static net.minecraft.item.FilledMapItem.getMapState;

public interface CustomMapItem {
	@Nullable
	default MapState getCustomMapData(ItemStack p_42910_, World p_42911_) {
		Integer integer = getMapId(p_42910_);
		return method_7997(integer, p_42911_);
	}
}

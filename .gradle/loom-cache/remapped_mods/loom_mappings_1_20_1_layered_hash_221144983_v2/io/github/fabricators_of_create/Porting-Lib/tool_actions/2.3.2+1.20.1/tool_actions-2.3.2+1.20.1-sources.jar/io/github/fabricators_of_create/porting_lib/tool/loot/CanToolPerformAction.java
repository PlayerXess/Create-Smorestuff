package io.github.fabricators_of_create.porting_lib.tool.loot;

import com.google.common.collect.ImmutableSet;
import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonObject;
import com.google.gson.JsonSerializationContext;

import io.github.fabricators_of_create.porting_lib.core.PortingLib;
import io.github.fabricators_of_create.porting_lib.tool.ToolAction;
import org.jetbrains.annotations.NotNull;

import java.util.Set;
import net.minecraft.item.ItemStack;
import net.minecraft.loot.condition.LootCondition;
import net.minecraft.loot.condition.LootConditionType;
import net.minecraft.loot.context.LootContext;
import net.minecraft.loot.context.LootContextParameter;
import net.minecraft.loot.context.LootContextParameters;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;

/**
 * This LootItemCondition "porting_lib:can_tool_perform_action" can be used to check if a tool can perform a given ToolAction.
 */
public class CanToolPerformAction implements LootCondition {

	public static final LootConditionType LOOT_CONDITION_TYPE = new LootConditionType(new CanToolPerformAction.Serializer());

	final ToolAction action;

	public CanToolPerformAction(ToolAction action) {
		this.action = action;
	}

	@NotNull
	public LootConditionType getType() {
		return LOOT_CONDITION_TYPE;
	}

	@NotNull
	public Set<LootContextParameter<?>> getRequiredParameters() {
		return ImmutableSet.of(LootContextParameters.field_1229);
	}

	public boolean test(LootContext lootContext) {
		ItemStack itemstack = lootContext.get(LootContextParameters.field_1229);
		return itemstack != null && itemstack.canPerformAction(this.action);
	}

	public static LootCondition.Builder canToolPerformAction(ToolAction action) {
		return () -> new CanToolPerformAction(action);
	}

	public static class Serializer implements net.minecraft.util.JsonSerializer<CanToolPerformAction> {
		public void serialize(JsonObject json, CanToolPerformAction itemCondition, @NotNull JsonSerializationContext context) {
			json.addProperty("action", itemCondition.action.name());
		}

		@NotNull
		public CanToolPerformAction fromJson(JsonObject json, @NotNull JsonDeserializationContext context) {
			return new CanToolPerformAction(ToolAction.get(json.get("action").getAsString()));
		}
	}

	public static void init() {
		Registry.register(Registries.LOOT_CONDITION_TYPE, PortingLib.id("can_tool_perform_action"), CanToolPerformAction.LOOT_CONDITION_TYPE);
	}
}


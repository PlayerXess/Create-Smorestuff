package io.github.fabricators_of_create.porting_lib.resource;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import net.minecraft.resource.AbstractFileResourcePack;
import net.minecraft.resource.InputSupplier;
import net.minecraft.resource.ResourcePack;
import net.minecraft.resource.ResourceType;
import net.minecraft.resource.metadata.PackResourceMetadata;
import net.minecraft.resource.metadata.ResourceMetadataReader;
import net.minecraft.util.Identifier;
import org.jetbrains.annotations.Nullable;

import com.google.common.collect.ImmutableList;
import com.google.common.collect.ImmutableMap;

public class DelegatingPackResources extends AbstractFileResourcePack {
	private final PackResourceMetadata packMeta;
	private final List<ResourcePack> delegates;
	private final Map<String, List<ResourcePack>> namespacesAssets;
	private final Map<String, List<ResourcePack>> namespacesData;

	public DelegatingPackResources(String packId,  boolean isBuiltin, PackResourceMetadata packMeta, List<? extends ResourcePack> packs) {
		super(packId, isBuiltin);
		this.packMeta = packMeta;
		this.delegates = ImmutableList.copyOf(packs);
		this.namespacesAssets = this.buildNamespaceMap(ResourceType.field_14188, delegates);
		this.namespacesData = this.buildNamespaceMap(ResourceType.field_14190, delegates);
	}

	private Map<String, List<ResourcePack>> buildNamespaceMap(ResourceType type, List<ResourcePack> packList) {
		Map<String, List<ResourcePack>> map = new HashMap<>();
		for (ResourcePack pack : packList) {
			for (String namespace : pack.getNamespaces(type)) {
				map.computeIfAbsent(namespace, k -> new ArrayList<>()).add(pack);
			}
		}
		map.replaceAll((k, list) -> ImmutableList.copyOf(list));
		return ImmutableMap.copyOf(map);
	}

	@SuppressWarnings("unchecked")
	@Nullable
	@Override
	public <T> T parseMetadata(ResourceMetadataReader<T> deserializer) throws IOException {
		return deserializer.getKey().equals("pack") ? (T) this.packMeta : null;
	}

	@Override
	public void findResources(ResourceType type, String resourceNamespace, String paths, ResultConsumer resourceOutput) {
		for (ResourcePack delegate : this.delegates) {
			delegate.findResources(type, resourceNamespace, paths, resourceOutput);
		}
	}

	@Override
	public Set<String> getNamespaces(ResourceType type) {
		return type == ResourceType.field_14188 ? namespacesAssets.keySet() : namespacesData.keySet();
	}

	@Override
	public void close() {
		for (ResourcePack pack : delegates) {
			pack.close();
		}
	}

	@Nullable
	@Override
	public InputSupplier<InputStream> openRoot(String... paths) {
		// Root resources do not make sense here
		return null;
	}

	@Nullable
	@Override
	public InputSupplier<InputStream> open(ResourceType type, Identifier location) {
		for (ResourcePack pack : getCandidatePacks(type, location)) {
			InputSupplier<InputStream> ioSupplier = pack.open(type, location);
			if (ioSupplier != null)
				return pack.open(type, location);
		}

		return null;
	}

	@Nullable
	public Collection<ResourcePack> getChildren() {
		return delegates;
	}

	private List<ResourcePack> getCandidatePacks(ResourceType type, Identifier location) {
		Map<String, List<ResourcePack>> map = type == ResourceType.field_14188 ? namespacesAssets : namespacesData;
		List<ResourcePack> packsWithNamespace = map.get(location.getNamespace());
		return packsWithNamespace == null ? Collections.emptyList() : packsWithNamespace;
	}
}

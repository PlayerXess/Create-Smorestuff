package io.github.fabricators_of_create.porting_lib.block;

import io.github.fabricators_of_create.porting_lib.util.PortingHooks;
import net.minecraft.block.BlockState;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.BlockView;

public interface HarvestableBlock {
	/**
	 * Determines if the player can harvest this block, obtaining it's drops when the block is destroyed.
	 *
	 * @param level The current level
	 * @param pos The block's current position
	 * @param player The player damaging the block
	 * @return True to spawn the drops
	 */
	default boolean canHarvestBlock(BlockState state, BlockView level, BlockPos pos, PlayerEntity player) {
		return PortingHooks.isCorrectToolForDrops(state, player);
	}
}

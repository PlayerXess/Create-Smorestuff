package io.github.fabricators_of_create.porting_lib.command;

import java.io.File;
import net.minecraft.command.CommandRegistryAccess;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.text.ClickEvent;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.builder.ArgumentBuilder;
import com.mojang.brigadier.context.CommandContext;

import io.github.fabricators_of_create.porting_lib.config.ConfigTracker;
import io.github.fabricators_of_create.porting_lib.config.ConfigType;

public class ConfigCommand {
	public static void register(CommandDispatcher<ServerCommandSource> dispatcher, CommandRegistryAccess registryAccess, CommandManager.RegistrationEnvironment environment) {
		dispatcher.register(
				CommandManager.literal("porting_lib")
						.then(CommandManager.literal("config").
							then(ShowFile.register())
		));
	}

	public static class ShowFile {
		static ArgumentBuilder<ServerCommandSource, ?> register() {
			return CommandManager.literal("showfile").
					requires(cs->cs.hasPermissionLevel(0)).
					then(CommandManager.argument("mod", ModIdArgument.modIdArgument()).
							then(CommandManager.argument("type", EnumArgument.enumArgument(ConfigType.class)).
									executes(ShowFile::showFile)
							)
					);
		}

		private static int showFile(final CommandContext<ServerCommandSource> context) {
			final String modId = context.getArgument("mod", String.class);
			final ConfigType type = context.getArgument("type", ConfigType.class);
			final String configFileName = ConfigTracker.INSTANCE.getConfigFileName(modId, type);
			if (configFileName != null) {
				File f = new File(configFileName);
				context.getSource().sendFeedback(() -> Text.translatable("commands.config.getwithtype",
						modId, type,
						Text.literal(f.getName()).formatted(Formatting.field_1073).
								styled((style) -> style.withClickEvent(new ClickEvent(ClickEvent.Action.field_11746, f.getAbsolutePath())))
				), true);
			} else {
				context.getSource().sendFeedback(() -> Text.translatable("commands.config.noconfig", modId, type),
						true);
			}
			return 0;
		}
	}
}

package io.github.fabricators_of_create.porting_lib.item;

import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemUsageContext;
import net.minecraft.util.ActionResult;

public interface UseFirstBehaviorItem {
	/**
	 * This is called when the item is used, before the block is activated.
	 *
	 * @return Return PASS to allow vanilla handling, any other to skip normal code.
	 */
	default ActionResult onItemUseFirst(ItemStack stack, ItemUsageContext context) {
		return ActionResult.PASS;
	}
}

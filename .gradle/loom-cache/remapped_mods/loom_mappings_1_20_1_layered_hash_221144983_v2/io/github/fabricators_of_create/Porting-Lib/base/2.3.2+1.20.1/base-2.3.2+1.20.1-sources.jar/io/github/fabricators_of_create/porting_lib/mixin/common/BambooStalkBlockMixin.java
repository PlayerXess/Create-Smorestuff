package io.github.fabricators_of_create.porting_lib.mixin.common;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;

import io.github.fabricators_of_create.porting_lib.common.util.IPlantable;
import net.minecraft.block.BambooBlock;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.BlockView;

@Mixin(BambooBlock.class)
public abstract class BambooStalkBlockMixin extends Block implements IPlantable {
	public BambooStalkBlockMixin(Settings properties) {
		super(properties);
	}

	@Unique
	@Override
	public BlockState getPlant(BlockView world, BlockPos pos) {
		BlockState state = world.getBlockState(pos);
		if (state.getBlock() != this) return getDefaultState();
		return state;
	}
}

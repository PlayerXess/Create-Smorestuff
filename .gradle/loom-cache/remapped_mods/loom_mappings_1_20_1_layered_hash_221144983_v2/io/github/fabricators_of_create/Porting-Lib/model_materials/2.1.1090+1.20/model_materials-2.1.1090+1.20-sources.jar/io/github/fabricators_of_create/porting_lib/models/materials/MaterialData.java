package io.github.fabricators_of_create.porting_lib.models.materials;

import java.util.function.Function;
import net.minecraft.util.Identifier;
import net.minecraft.util.dynamic.Codecs;
import com.mojang.datafixers.util.Either;
import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;

public record MaterialData(int color, boolean emissive, boolean ambientOcclusion, Identifier blendMode) {
	public static final MaterialData DEFAULT = new MaterialData(0xFFFFFFFF, false, true, new Identifier("solid"));

	public static final Codec<Integer> COLOR = new Codecs.Either<>(Codec.INT, Codec.STRING).xmap(
			either -> either.map(Function.identity(), str -> (int) Long.parseLong(str, 16)),
			color -> Either.right(Integer.toHexString(color)));

	public static final Codec<MaterialData> CODEC = RecordCodecBuilder.create(builder -> builder.group(
					COLOR.optionalFieldOf("color", 0xFFFFFFFF).forGetter(MaterialData::color),
					Codec.BOOL.optionalFieldOf("emissive", false).forGetter(MaterialData::emissive),
					Codec.BOOL.optionalFieldOf("ambient_occlusion", true).forGetter(MaterialData::ambientOcclusion),
					Identifier.CODEC.optionalFieldOf("blendMode", new Identifier("solid")).forGetter(MaterialData::blendMode))
			.apply(builder, MaterialData::new));
}

package io.github.fabricators_of_create.porting_lib.entity.mixin.common;

import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityDimensions;
import net.minecraft.entity.EntityPose;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(Entity.class)
public interface EntityAccessor {
	@Invoker
	float callGetEyeHeight(EntityPose pose, EntityDimensions dimensions);
}

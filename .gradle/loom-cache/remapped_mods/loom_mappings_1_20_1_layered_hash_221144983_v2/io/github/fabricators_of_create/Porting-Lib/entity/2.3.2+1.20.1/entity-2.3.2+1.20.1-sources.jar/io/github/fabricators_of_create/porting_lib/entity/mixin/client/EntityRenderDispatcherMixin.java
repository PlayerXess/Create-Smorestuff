package io.github.fabricators_of_create.porting_lib.entity.mixin.client;

import io.github.fabricators_of_create.porting_lib.entity.MultiPartEntity;
import io.github.fabricators_of_create.porting_lib.entity.PartEntity;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.WorldRenderer;
import net.minecraft.client.render.entity.EntityRenderDispatcher;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.MathHelper;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(EntityRenderDispatcher.class)
public abstract class EntityRenderDispatcherMixin {
	@Inject(method = "renderHitbox", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/renderer/LevelRenderer;renderLineBox(Lcom/mojang/blaze3d/vertex/PoseStack;Lcom/mojang/blaze3d/vertex/VertexConsumer;Lnet/minecraft/world/phys/AABB;FFFF)V", ordinal = 0, shift = At.Shift.AFTER))
	private static void renderMultipartHitboxes(MatrixStack pMatrixStack, VertexConsumer pBuffer, Entity entity, float pPartialTicks, CallbackInfo ci) {
		if (entity instanceof MultiPartEntity pEntity && pEntity.isMultipartEntity()) {
			double d0 = -MathHelper.lerp(pPartialTicks, entity.lastRenderX, entity.getX());
			double d1 = -MathHelper.lerp(pPartialTicks, entity.lastRenderY, entity.getY());
			double d2 = -MathHelper.lerp(pPartialTicks, entity.lastRenderZ, entity.getZ());

			for(PartEntity<?> part : pEntity.getParts()) {
				pMatrixStack.push();
				double d3 = d0 + MathHelper.lerp(pPartialTicks, part.lastRenderX, part.getX());
				double d4 = d1 + MathHelper.lerp(pPartialTicks, part.lastRenderY, part.getY());
				double d5 = d2 + MathHelper.lerp(pPartialTicks, part.lastRenderZ, part.getZ());
				pMatrixStack.translate(d3, d4, d5);
				WorldRenderer.drawBox(pMatrixStack, pBuffer, part.getBoundingBox().offset(-part.getX(), -part.getY(), -part.getZ()), 0.25F, 1.0F, 0.0F, 1.0F);
				pMatrixStack.pop();
			}
		}
	}
}

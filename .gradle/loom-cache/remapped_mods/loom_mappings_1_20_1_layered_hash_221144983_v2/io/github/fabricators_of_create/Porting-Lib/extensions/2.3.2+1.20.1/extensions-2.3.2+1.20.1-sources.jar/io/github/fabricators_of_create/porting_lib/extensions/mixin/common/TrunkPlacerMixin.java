package io.github.fabricators_of_create.porting_lib.extensions.mixin.common;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import java.util.function.BiConsumer;
import net.minecraft.block.BlockState;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.random.Random;
import net.minecraft.world.TestableWorld;
import net.minecraft.world.gen.feature.TreeFeatureConfig;
import net.minecraft.world.gen.trunk.TrunkPlacer;

@Mixin(TrunkPlacer.class)
public class TrunkPlacerMixin {
	@ModifyExpressionValue(method = "setDirtAt", at = @At(value = "FIELD", target = "Lnet/minecraft/world/level/levelgen/feature/configurations/TreeConfiguration;forceDirt:Z"))
	private static boolean shouldUseModdedDirt(boolean original, TestableWorld pLevel, BiConsumer<BlockPos, BlockState> pBlockSetter, Random pRandom, BlockPos pPos, TreeFeatureConfig pConfig) {
		return !(((net.minecraft.world.WorldView) pLevel).getBlockState(pPos).onTreeGrow((net.minecraft.world.WorldView) pLevel, pBlockSetter, pRandom, pPos, pConfig)) && original;
	}
}

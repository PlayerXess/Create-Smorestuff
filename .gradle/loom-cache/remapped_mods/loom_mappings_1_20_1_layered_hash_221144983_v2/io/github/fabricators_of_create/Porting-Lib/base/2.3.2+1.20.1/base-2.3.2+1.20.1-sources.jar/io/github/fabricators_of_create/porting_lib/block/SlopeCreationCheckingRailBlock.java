package io.github.fabricators_of_create.porting_lib.block;

import javax.annotation.Nonnull;
import net.minecraft.block.BlockState;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.BlockView;

public interface SlopeCreationCheckingRailBlock {
	boolean canMakeSlopes(@Nonnull BlockState state, @Nonnull BlockView world, @Nonnull BlockPos pos);
}

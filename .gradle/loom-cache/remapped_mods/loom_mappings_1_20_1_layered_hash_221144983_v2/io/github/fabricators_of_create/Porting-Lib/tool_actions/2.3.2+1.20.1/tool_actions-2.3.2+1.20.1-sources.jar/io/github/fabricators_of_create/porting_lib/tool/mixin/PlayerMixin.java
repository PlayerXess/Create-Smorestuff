package io.github.fabricators_of_create.porting_lib.tool.mixin;

import com.llamalad7.mixinextras.injector.ModifyReceiver;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;

import io.github.fabricators_of_create.porting_lib.tool.ToolActions;
import io.github.fabricators_of_create.porting_lib.tool.addons.ToolActionItem;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.item.SwordItem;
import net.minecraft.world.World;

@Mixin(PlayerEntity.class)
public abstract class PlayerMixin extends LivingEntity {
	protected PlayerMixin(EntityType<? extends LivingEntity> entityType, World level) {
		super(entityType, level);
	}

	@ModifyExpressionValue(method = "hurtCurrentlyUsedShield", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/item/ItemStack;is(Lnet/minecraft/world/item/Item;)Z"))
	private boolean shieldToolAction(boolean original) {
		if (this.activeItemStack.getItem() instanceof ToolActionItem) {
			return this.activeItemStack.canPerformAction(ToolActions.SHIELD_BLOCK);
		}
		return original;
	}

	@ModifyReceiver(method = "attack", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/item/ItemStack;getItem()Lnet/minecraft/world/item/Item;"))
	private ItemStack canSwordSweep(ItemStack instance) {
		if (instance.getItem() instanceof ToolActionItem) {
			if (instance.canPerformAction(ToolActions.SWORD_SWEEP)) {
				return instance.getItem() instanceof SwordItem ? instance : Items.field_8371.getDefaultStack();
			}
			return Items.AIR.getDefaultStack();
		}
		return instance;
	}
}

package io.github.fabricators_of_create.porting_lib.extensions.extensions;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.entity.effect.StatusEffect;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;

public interface MobEffectExtensions {
	private StatusEffect self() {
		return (StatusEffect)this;
	}

	/**
	 * Get a fresh list of items that can cure this Potion.
	 * All new PotionEffects created from this Potion will call this to initialize the default curative items
	 * @see MobEffectInstanceExtensions#getCurativeItems()
	 * @return A list of items that can cure this Potion
	 */
	default List<ItemStack> getCurativeItems() {
		ArrayList<ItemStack> ret = new ArrayList<ItemStack>();
		ret.add(new ItemStack(Items.field_8103));
		return ret;
	}

	/**
	 * Used for determining {@code PotionEffect} sort order in GUIs.
	 * Defaults to the {@code PotionEffect}'s liquid color.
	 * @param potionEffect the {@code PotionEffect} instance containing the potion
	 * @return a value used to sort {@code PotionEffect}s in GUIs
	 */
	default int getSortOrder(StatusEffectInstance potionEffect) {
		return self().getColor();
	} // TODO: Implement
}

package io.github.fabricators_of_create.porting_lib.extensions.extensions;

import java.util.List;
import net.minecraft.structure.StructurePlacementData;
import net.minecraft.structure.StructureTemplate;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.ServerWorldAccess;
import net.minecraft.world.WorldAccess;
import org.jetbrains.annotations.Nullable;

@Deprecated(forRemoval = true)
public interface StructureTemplateExtensions {
	/**
	 * @deprecated not provided on Forge, make an accessor if you really need it
	 */
	@Deprecated(forRemoval = true)
	default List<StructureTemplate.StructureEntityInfo> getEntities() {
		throw new RuntimeException("this should be overridden via mixin. what?");
	}

	/**
	 * @deprecated use StructureTemplateUtils in base module
	 */
	@Deprecated(forRemoval = true)
	default Vec3d transformedVec3d(StructurePlacementData placementIn, Vec3d pos) {
		throw new RuntimeException("this should be overridden via mixin. what?");
	}

	/**
	 * @deprecated use StructureTemplateUtils in base module
	 */
	@Deprecated(forRemoval = true)
	default List<StructureTemplate.StructureEntityInfo> processEntityInfos(@Nullable StructureTemplate template, WorldAccess world, BlockPos blockPos, StructurePlacementData settings, List<StructureTemplate.StructureEntityInfo> infos) {
		throw new RuntimeException("this should be overridden via mixin. what?");
	}

	/**
	 * @deprecated see placeEntities
	 */
	@Deprecated(forRemoval = true)
	default void addEntitiesToWorld(ServerWorldAccess world, BlockPos blockPos, StructurePlacementData settings) {
		throw new RuntimeException("this should be overridden via mixin. what?");
	}
}

package io.github.fabricators_of_create.porting_lib.block;

import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;

public interface StickToBlock {
	/**
	 * Determines if this block can stick to another block when pushed by a piston.
	 *
	 * @param state My state
	 * @param other Other block
	 * @return True to link blocks
	 */
	default boolean canStickTo(BlockState state, BlockState other) {
		if (state.getBlock() == Blocks.field_21211 && other.getBlock() == Blocks.field_10030) return false;
		if (state.getBlock() == Blocks.field_10030 && other.getBlock() == Blocks.field_21211) return false;
		return state.isStickyBlock() || other.isStickyBlock();
	}
}

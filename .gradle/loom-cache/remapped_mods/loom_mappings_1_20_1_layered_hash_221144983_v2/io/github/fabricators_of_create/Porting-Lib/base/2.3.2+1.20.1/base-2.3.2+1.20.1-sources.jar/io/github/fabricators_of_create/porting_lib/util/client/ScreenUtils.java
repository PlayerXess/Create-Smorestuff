package io.github.fabricators_of_create.porting_lib.util.client;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.Nonnull;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.GameRenderer;
import net.minecraft.client.render.Tessellator;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.VertexFormat;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.item.ItemStack;
import net.minecraft.text.StringVisitable;
import net.minecraft.text.Style;
import net.minecraft.util.Identifier;
import net.minecraft.util.Language;
import com.mojang.blaze3d.systems.RenderSystem;
import org.joml.Matrix4f;

public class ScreenUtils {
	public static final int DEFAULT_BACKGROUND_COLOR = 0xF0100010;
	public static final int DEFAULT_BORDER_COLOR_START = 0x505000FF;
	public static final int DEFAULT_BORDER_COLOR_END = (DEFAULT_BORDER_COLOR_START & 0xFEFEFE) >> 1 | DEFAULT_BORDER_COLOR_START & 0xFF000000;
	public static void drawGradientRect(Matrix4f matrix, int z, int left, int top, int right, int bottom, int startColor, int endColor) {
		float startAlpha = (float)(startColor >> 24 & 255) / 255.0F;
		float startRed   = (float)(startColor >> 16 & 255) / 255.0F;
		float startGreen = (float)(startColor >>  8 & 255) / 255.0F;
		float startBlue  = (float)(startColor       & 255) / 255.0F;
		float endAlpha   = (float)(endColor   >> 24 & 255) / 255.0F;
		float endRed     = (float)(endColor   >> 16 & 255) / 255.0F;
		float endGreen   = (float)(endColor   >>  8 & 255) / 255.0F;
		float endBlue    = (float)(endColor         & 255) / 255.0F;

		RenderSystem.enableDepthTest();
		RenderSystem.enableBlend();
		RenderSystem.defaultBlendFunc();
		RenderSystem.setShader(GameRenderer::getPositionColorProgram);

		Tessellator tessellator = Tessellator.getInstance();
		BufferBuilder buffer = tessellator.getBuffer();
		buffer.begin(VertexFormat.DrawMode.field_27382, VertexFormats.POSITION_COLOR);
		buffer.vertex(matrix, right,    top, z).color(startRed, startGreen, startBlue, startAlpha).next();
		buffer.vertex(matrix,  left,    top, z).color(startRed, startGreen, startBlue, startAlpha).next();
		buffer.vertex(matrix,  left, bottom, z).color(  endRed,   endGreen,   endBlue,   endAlpha).next();
		buffer.vertex(matrix, right, bottom, z).color(  endRed,   endGreen,   endBlue,   endAlpha).next();
		tessellator.draw();

		RenderSystem.disableBlend();
	}

	public static void drawHoveringText(MatrixStack mStack, List<? extends StringVisitable> textLines, int mouseX, int mouseY, int screenWidth, int screenHeight, int maxTextWidth, int backgroundColor, int borderColorStart, int borderColorEnd, TextRenderer font) {
		drawHoveringText(ItemStack.EMPTY, mStack, textLines, mouseX, mouseY, screenWidth, screenHeight, maxTextWidth, backgroundColor, borderColorStart, borderColorEnd, font);
	}

	public static void drawHoveringText(@Nonnull final ItemStack stack, MatrixStack mStack, List<? extends StringVisitable> textLines, int mouseX, int mouseY, int screenWidth, int screenHeight, int maxTextWidth, int backgroundColor, int borderColorStart, int borderColorEnd, TextRenderer font) {
		if (!textLines.isEmpty()) {
			//RenderSystem.disableRescaleNormal();
			RenderSystem.disableDepthTest();
			int tooltipTextWidth = 0;

			for (StringVisitable textLine : textLines)
			{
				int textLineWidth = font.getWidth(textLine);
				if (textLineWidth > tooltipTextWidth)
					tooltipTextWidth = textLineWidth;
			}

			boolean needsWrap = false;

			int titleLinesCount = 1;
			int tooltipX = mouseX + 12;
			if (tooltipX + tooltipTextWidth + 4 > screenWidth)
			{
				tooltipX = mouseX - 16 - tooltipTextWidth;
				if (tooltipX < 4) // if the tooltip doesn't fit on the screen
				{
					if (mouseX > screenWidth / 2)
						tooltipTextWidth = mouseX - 12 - 8;
					else
						tooltipTextWidth = screenWidth - 16 - mouseX;
					needsWrap = true;
				}
			}

			if (maxTextWidth > 0 && tooltipTextWidth > maxTextWidth)
			{
				tooltipTextWidth = maxTextWidth;
				needsWrap = true;
			}

			if (needsWrap)
			{
				int wrappedTooltipWidth = 0;
				List<StringVisitable> wrappedTextLines = new ArrayList<>();
				for (int i = 0; i < textLines.size(); i++)
				{
					StringVisitable textLine = textLines.get(i);
					List<StringVisitable> wrappedLine = font.getTextHandler().wrapLines(textLine, tooltipTextWidth, Style.EMPTY);
					if (i == 0)
						titleLinesCount = wrappedLine.size();

					for (StringVisitable line : wrappedLine)
					{
						int lineWidth = font.getWidth(line);
						if (lineWidth > wrappedTooltipWidth)
							wrappedTooltipWidth = lineWidth;
						wrappedTextLines.add(line);
					}
				}
				tooltipTextWidth = wrappedTooltipWidth;
				textLines = wrappedTextLines;

				if (mouseX > screenWidth / 2)
					tooltipX = mouseX - 16 - tooltipTextWidth;
				else
					tooltipX = mouseX + 12;
			}

			int tooltipY = mouseY - 12;
			int tooltipHeight = 8;

			if (textLines.size() > 1)
			{
				tooltipHeight += (textLines.size() - 1) * 10;
				if (textLines.size() > titleLinesCount)
					tooltipHeight += 2; // gap between title lines and next lines
			}

			if (tooltipY < 4)
				tooltipY = 4;
			else if (tooltipY + tooltipHeight + 4 > screenHeight)
				tooltipY = screenHeight - tooltipHeight - 4;

			final int zLevel = 400;

			mStack.push();
			Matrix4f mat = mStack.peek().getPositionMatrix();
			drawGradientRect(mat, zLevel, tooltipX - 3, tooltipY - 4, tooltipX + tooltipTextWidth + 3, tooltipY - 3, backgroundColor, backgroundColor);
			drawGradientRect(mat, zLevel, tooltipX - 3, tooltipY + tooltipHeight + 3, tooltipX + tooltipTextWidth + 3, tooltipY + tooltipHeight + 4, backgroundColor, backgroundColor);
			drawGradientRect(mat, zLevel, tooltipX - 3, tooltipY - 3, tooltipX + tooltipTextWidth + 3, tooltipY + tooltipHeight + 3, backgroundColor, backgroundColor);
			drawGradientRect(mat, zLevel, tooltipX - 4, tooltipY - 3, tooltipX - 3, tooltipY + tooltipHeight + 3, backgroundColor, backgroundColor);
			drawGradientRect(mat, zLevel, tooltipX + tooltipTextWidth + 3, tooltipY - 3, tooltipX + tooltipTextWidth + 4, tooltipY + tooltipHeight + 3, backgroundColor, backgroundColor);
			drawGradientRect(mat, zLevel, tooltipX - 3, tooltipY - 3 + 1, tooltipX - 3 + 1, tooltipY + tooltipHeight + 3 - 1, borderColorStart, borderColorEnd);
			drawGradientRect(mat, zLevel, tooltipX + tooltipTextWidth + 2, tooltipY - 3 + 1, tooltipX + tooltipTextWidth + 3, tooltipY + tooltipHeight + 3 - 1, borderColorStart, borderColorEnd);
			drawGradientRect(mat, zLevel, tooltipX - 3, tooltipY - 3, tooltipX + tooltipTextWidth + 3, tooltipY - 3 + 1, borderColorStart, borderColorStart);
			drawGradientRect(mat, zLevel, tooltipX - 3, tooltipY + tooltipHeight + 2, tooltipX + tooltipTextWidth + 3, tooltipY + tooltipHeight + 3, borderColorEnd, borderColorEnd);

			VertexConsumerProvider.Immediate renderType = VertexConsumerProvider.immediate(Tessellator.getInstance().getBuffer());
			mStack.translate(0.0D, 0.0D, zLevel);

			int tooltipTop = tooltipY;

			for (int lineNumber = 0; lineNumber < textLines.size(); ++lineNumber)
			{
				StringVisitable line = textLines.get(lineNumber);
				if (line != null)
					font.draw(Language.getInstance().reorder(line), (float)tooltipX, (float)tooltipY, -1, true, mat, renderType, TextRenderer.TextLayerType.field_33993, 0, 15728880);

				if (lineNumber + 1 == titleLinesCount)
					tooltipY += 2;

				tooltipY += 10;
			}

			renderType.draw();
			mStack.pop();

			RenderSystem.enableDepthTest();
			//RenderSystem.enableRescaleNormal();
		}
	}

	/**
	 * Draws a textured box of any size (smallest size is borderSize * 2 square) based on a fixed size textured box with continuous borders
	 * and filler. The provided ResourceLocation object will be bound using
	 * Minecraft.getMinecraft().getTextureManager().bindTexture(resourceLocation).
	 *
	 * @param guiGraphics the gui pose stack
	 * @param res the ResourceLocation object that contains the desired image
	 * @param x x axis offset
	 * @param y y axis offset
	 * @param u bound resource location image x offset
	 * @param v bound resource location image y offset
	 * @param width the desired box width
	 * @param height the desired box height
	 * @param textureWidth the width of the box texture in the resource location image
	 * @param textureHeight the height of the box texture in the resource location image
	 * @param topBorder the size of the box's top border
	 * @param bottomBorder the size of the box's bottom border
	 * @param leftBorder the size of the box's left border
	 * @param rightBorder the size of the box's right border
	 * @param zLevel the zLevel to draw at
	 */
	public static void drawContinuousTexturedBox(DrawContext guiGraphics, Identifier res, int x, int y, int u, int v, int width, int height, int textureWidth, int textureHeight,
												 int topBorder, int bottomBorder, int leftBorder, int rightBorder, float zLevel) {
		RenderSystem.setShader(GameRenderer::getPositionTexProgram);
		RenderSystem.setShaderTexture(0, res);
		drawContinuousTexturedBox(guiGraphics, x, y, u, v, width, height, textureWidth, textureHeight, topBorder, bottomBorder, leftBorder, rightBorder, zLevel);
	}

	/**
	 * Draws a textured box of any size (smallest size is borderSize * 2 square) based on a fixed size textured box with continuous borders
	 * and filler. It is assumed that the desired texture ResourceLocation object has been bound using
	 * Minecraft.getMinecraft().getTextureManager().bindTexture(resourceLocation).
	 *
	 * @param guiGraphics the gui pose stack
	 * @param x x axis offset
	 * @param y y axis offset
	 * @param u bound resource location image x offset
	 * @param v bound resource location image y offset
	 * @param width the desired box width
	 * @param height the desired box height
	 * @param textureWidth the width of the box texture in the resource location image
	 * @param textureHeight the height of the box texture in the resource location image
	 * @param topBorder the size of the box's top border
	 * @param bottomBorder the size of the box's bottom border
	 * @param leftBorder the size of the box's left border
	 * @param rightBorder the size of the box's right border
	 * @param zLevel the zLevel to draw at
	 */
	public static void drawContinuousTexturedBox(DrawContext guiGraphics, int x, int y, int u, int v, int width, int height, int textureWidth, int textureHeight,
												 int topBorder, int bottomBorder, int leftBorder, int rightBorder, float zLevel) {
		RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
		RenderSystem.enableBlend();
		RenderSystem.defaultBlendFunc();

		int fillerWidth = textureWidth - leftBorder - rightBorder;
		int fillerHeight = textureHeight - topBorder - bottomBorder;
		int canvasWidth = width - leftBorder - rightBorder;
		int canvasHeight = height - topBorder - bottomBorder;
		int xPasses = canvasWidth / fillerWidth;
		int remainderWidth = canvasWidth % fillerWidth;
		int yPasses = canvasHeight / fillerHeight;
		int remainderHeight = canvasHeight % fillerHeight;

		// Draw Border
		// Top Left
		drawTexturedModalRect(guiGraphics, x, y, u, v, leftBorder, topBorder, zLevel);
		// Top Right
		drawTexturedModalRect(guiGraphics, x + leftBorder + canvasWidth, y, u + leftBorder + fillerWidth, v, rightBorder, topBorder, zLevel);
		// Bottom Left
		drawTexturedModalRect(guiGraphics, x, y + topBorder + canvasHeight, u, v + topBorder + fillerHeight, leftBorder, bottomBorder, zLevel);
		// Bottom Right
		drawTexturedModalRect(guiGraphics, x + leftBorder + canvasWidth, y + topBorder + canvasHeight, u + leftBorder + fillerWidth, v + topBorder + fillerHeight, rightBorder, bottomBorder, zLevel);

		for (int i = 0; i < xPasses + (remainderWidth > 0 ? 1 : 0); i++) {
			// Top Border
			drawTexturedModalRect(guiGraphics, x + leftBorder + (i * fillerWidth), y, u + leftBorder, v, (i == xPasses ? remainderWidth : fillerWidth), topBorder, zLevel);
			// Bottom Border
			drawTexturedModalRect(guiGraphics, x + leftBorder + (i * fillerWidth), y + topBorder + canvasHeight, u + leftBorder, v + topBorder + fillerHeight, (i == xPasses ? remainderWidth : fillerWidth), bottomBorder, zLevel);

			// Throw in some filler for good measure
			for (int j = 0; j < yPasses + (remainderHeight > 0 ? 1 : 0); j++)
				drawTexturedModalRect(guiGraphics, x + leftBorder + (i * fillerWidth), y + topBorder + (j * fillerHeight), u + leftBorder, v + topBorder, (i == xPasses ? remainderWidth : fillerWidth), (j == yPasses ? remainderHeight : fillerHeight), zLevel);
		}

		// Side Borders
		for (int j = 0; j < yPasses + (remainderHeight > 0 ? 1 : 0); j++) {
			// Left Border
			drawTexturedModalRect(guiGraphics, x, y + topBorder + (j * fillerHeight), u, v + topBorder, leftBorder, (j == yPasses ? remainderHeight : fillerHeight), zLevel);
			// Right Border
			drawTexturedModalRect(guiGraphics, x + leftBorder + canvasWidth, y + topBorder + (j * fillerHeight), u + leftBorder + fillerWidth, v + topBorder, rightBorder, (j == yPasses ? remainderHeight : fillerHeight), zLevel);
		}
	}

	public static void drawTexturedModalRect(DrawContext guiGraphics, int x, int y, int u, int v, int width, int height, float zLevel) {
		final float uScale = 1f / 0x100;
		final float vScale = 1f / 0x100;

		Tessellator tessellator = Tessellator.getInstance();
		BufferBuilder wr = tessellator.getBuffer();
		wr.begin(VertexFormat.DrawMode.field_27382, VertexFormats.POSITION_TEXTURE);
		Matrix4f matrix = guiGraphics.getMatrices().peek().getPositionMatrix();
		wr.vertex(matrix, x        , y + height, zLevel).texture( u          * uScale, ((v + height) * vScale)).next();
		wr.vertex(matrix, x + width, y + height, zLevel).texture((u + width) * uScale, ((v + height) * vScale)).next();
		wr.vertex(matrix, x + width, y         , zLevel).texture((u + width) * uScale, ( v           * vScale)).next();
		wr.vertex(matrix, x        , y         , zLevel).texture( u          * uScale, ( v           * vScale)).next();
		tessellator.draw();
	}
}

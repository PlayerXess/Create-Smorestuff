package io.github.fabricators_of_create.porting_lib.extensions.extensions;

import net.minecraft.data.server.tag.TagProvider;
import net.minecraft.registry.tag.TagKey;

public interface TagAppenderExtensions {
	@SuppressWarnings("unchecked")
	default <E> TagProvider.ProvidedTagBuilder<E> addTags(TagKey<E>... values) {
		throw new RuntimeException("this should be overridden via mixin. what?");
	}
}

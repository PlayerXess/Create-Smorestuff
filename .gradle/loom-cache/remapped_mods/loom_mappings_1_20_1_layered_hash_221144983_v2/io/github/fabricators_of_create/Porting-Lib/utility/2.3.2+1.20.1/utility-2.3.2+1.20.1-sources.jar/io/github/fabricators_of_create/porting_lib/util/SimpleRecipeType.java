package io.github.fabricators_of_create.porting_lib.util;

import net.minecraft.recipe.Recipe;
import net.minecraft.recipe.RecipeType;
import net.minecraft.util.Identifier;

public record SimpleRecipeType<T extends Recipe<?>>(Identifier name) implements RecipeType<T> {
	@Override
	public String toString() {
		return name.toString();
	}
}

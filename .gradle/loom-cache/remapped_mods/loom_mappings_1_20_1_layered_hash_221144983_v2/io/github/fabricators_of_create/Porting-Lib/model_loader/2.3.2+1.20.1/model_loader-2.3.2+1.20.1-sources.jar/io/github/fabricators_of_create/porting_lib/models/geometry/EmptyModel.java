package io.github.fabricators_of_create.porting_lib.models.geometry;

import java.util.List;
import java.util.Map;
import java.util.function.Function;
import net.minecraft.client.render.model.BakedModel;
import net.minecraft.client.render.model.Baker;
import net.minecraft.client.render.model.BasicBakedModel;
import net.minecraft.client.render.model.ModelBakeSettings;
import net.minecraft.client.render.model.UnbakedModel;
import net.minecraft.client.render.model.json.JsonUnbakedModel;
import net.minecraft.client.render.model.json.ModelOverrideList;
import net.minecraft.client.render.model.json.ModelTransformation;
import net.minecraft.client.texture.MissingSprite;
import net.minecraft.client.texture.Sprite;
import net.minecraft.client.texture.SpriteAtlasTexture;
import net.minecraft.client.util.SpriteIdentifier;
import net.minecraft.util.Identifier;

/**
 * A completely empty model with no quads or texture dependencies.
 * <p>
 * You can access it as a {@link BakedModel}, an {@link IUnbakedGeometry} or an {@link IGeometryLoader}.
 */
public class EmptyModel implements IUnbakedGeometry<EmptyModel> {
	public static final BakedModel BAKED = new Baked();
	public static final EmptyModel INSTANCE = new EmptyModel();
	public static final IGeometryLoader<EmptyModel> LOADER = (json, ctx) -> INSTANCE;

	private EmptyModel() {}

	@Override
	public BakedModel bake(JsonUnbakedModel context, Baker baker, Function<SpriteIdentifier, Sprite> spriteGetter, ModelBakeSettings modelState, ModelOverrideList overrides, Identifier modelLocation, boolean isGui3d) {
		return BAKED;
	}

	@Override
	public void resolveParents(Function<Identifier, UnbakedModel> modelGetter, JsonUnbakedModel context) {
		// NO-OP
	}

	private static class Baked extends BasicBakedModel {
		private static final SpriteIdentifier MISSING_TEXTURE = new SpriteIdentifier(SpriteAtlasTexture.BLOCK_ATLAS_TEXTURE, MissingSprite.getMissingSpriteId());

		public Baked() {
			super(List.of(), Map.of(), false, false, false, MISSING_TEXTURE.getSprite(), ModelTransformation.NONE, ModelOverrideList.EMPTY);
		}

		@Override
		public Sprite getParticleSprite() {
			return MISSING_TEXTURE.getSprite();
		}
	}
}

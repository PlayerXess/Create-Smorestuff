package io.github.fabricators_of_create.porting_lib.block;

import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.ObserverBlock;
import net.minecraft.block.RedstoneWireBlock;
import net.minecraft.block.RepeaterBlock;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.world.BlockView;
import net.minecraft.world.WorldAccess;
import org.jetbrains.annotations.Nullable;

public interface ConnectableRedstoneBlock {
	/**
	 * Whether redstone dust should visually connect to this block on a given side
	 * <p>
	 * The default implementation is identical to
	 * {@code RedStoneWireBlock#shouldConnectTo(BlockState, Direction)}
	 *
	 * <p>
	 * {@link RedstoneWireBlock} updates its visual connection when
	 * {@link BlockState#getStateForNeighborUpdate(Direction, BlockState, WorldAccess, BlockPos, BlockPos)}
	 * is called, this callback is used during the evaluation of its new shape.
	 *
	 * @param state     The current state
	 * @param level     The level
	 * @param pos       The block position in level
	 * @param direction The coming direction of the redstone dust connection (with respect to the block at pos)
	 * @return True if redstone dust should visually connect on the side passed
	 * <p>
	 * If the return value is evaluated based on level and pos (e.g. from BlockEntity), then the implementation of
	 * this block should notify its neighbors to update their shapes when necessary. Consider using
	 * {@link BlockState#updateNeighbors(WorldAccess, BlockPos, int, int)} or
	 * {@link BlockState#getStateForNeighborUpdate(Direction, BlockState, WorldAccess, BlockPos, BlockPos)}.
	 * <p>
	 * Example:
	 * <p>
	 * 1. {@code yourBlockState.updateNeighbourShapes(level, yourBlockPos, UPDATE_ALL);}
	 * <p>
	 * 2. {@code neighborState.updateShape(fromDirection, stateOfYourBlock, level, neighborBlockPos, yourBlockPos)},
	 * where {@code fromDirection} is defined from the neighbor block's point of view.
	 */
	default boolean canConnectRedstone(BlockState state, BlockView level, BlockPos pos, @Nullable Direction direction) {
		if (state.isOf(Blocks.field_10091)) {
			return true;
		} else if (state.isOf(Blocks.field_10450)) {
			Direction facing = state.get(RepeaterBlock.FACING);
			return facing == direction || facing.getOpposite() == direction;
		} else if (state.isOf(Blocks.field_10282)) {
			return direction == state.get(ObserverBlock.FACING);
		} else {
			return state.emitsRedstonePower() && direction != null;
		}
	}
}

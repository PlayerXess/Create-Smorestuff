package io.github.fabricators_of_create.porting_lib.util.client;

import com.google.common.collect.Maps;
import com.mojang.datafixers.util.Either;

import io.github.fabricators_of_create.porting_lib.item.ArmorTextureItem;
import net.fabricmc.fabric.api.client.render.fluid.v1.FluidRenderHandlerRegistry;
import net.minecraft.block.BlockState;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.tooltip.TooltipComponent;
import net.minecraft.client.item.TooltipData;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.model.BipedEntityModel;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.item.ArmorItem;
import net.minecraft.item.ItemStack;
import net.minecraft.text.StringVisitable;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import net.minecraft.util.Language;
import org.jetbrains.annotations.ApiStatus;

import javax.annotation.Nullable;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class ClientHooks {
	public static final Map<String, Identifier> ARMOR_LOCATION_CACHE = Maps.newHashMap();

	public static String getArmorTexture(Entity entity, ItemStack armor, String _default, EquipmentSlot slot, String type) {
		String result = null;
		if (armor.getItem() instanceof ArmorTextureItem armorTextureItem)
			result = armorTextureItem.getArmorTexture(armor, entity, slot, type);
		return result != null ? result : _default;
	}

	/**
	 * More generic version of the above function, it allows for Items to have more control over what texture they provide.
	 *
	 * @param entity Entity wearing the armor
	 * @param stack ItemStack for the armor
	 * @param slot Slot ID that the item is in
	 * @param type Subtype, can be null or "overlay"
	 * @return ResourceLocation pointing at the armor's texture
	 */
	public static Identifier getArmorResource(net.minecraft.entity.Entity entity, ItemStack stack, EquipmentSlot slot, @Nullable String type) {
		ArmorItem item = (ArmorItem)stack.getItem();
		String texture = item.getMaterial().getName();
		String domain = "minecraft";
		int idx = texture.indexOf(':');
		if (idx != -1) {
			domain = texture.substring(0, idx);
			texture = texture.substring(idx + 1);
		}
		String s1 = String.format(java.util.Locale.ROOT, "%s:textures/models/armor/%s_layer_%d%s.png", domain, texture, slot == EquipmentSlot.field_6172 ? 2 : 1, type == null ? "" : String.format(java.util.Locale.ROOT, "_%s", type));

		s1 = getArmorTexture(entity, stack, s1, slot, type);
		Identifier resourcelocation = ARMOR_LOCATION_CACHE.get(s1);

		if (resourcelocation == null) {
			resourcelocation = new Identifier(s1);
			ARMOR_LOCATION_CACHE.put(s1, resourcelocation);
		}

		return resourcelocation;
	}

	public static void setPartVisibility(BipedEntityModel<?> armorModel, EquipmentSlot slot) {
		armorModel.setVisible(false);
		switch(slot) {
			case field_6169:
				armorModel.head.visible = true;
				armorModel.hat.visible = true;
				break;
			case field_6174:
				armorModel.body.visible = true;
				armorModel.rightArm.visible = true;
				armorModel.leftArm.visible = true;
				break;
			case field_6172:
				armorModel.body.visible = true;
				armorModel.rightLeg.visible = true;
				armorModel.leftLeg.visible = true;
				break;
			case field_6166:
				armorModel.rightLeg.visible = true;
				armorModel.leftLeg.visible = true;
		}
	}

	public static final List<String> MODS_TO_WRAP = new ArrayList<>();

	public static void wrapModTooltips(String modid) {
		MODS_TO_WRAP.add(modid);
	}

	public static List<TooltipComponent> gatherTooltipComponents(ItemStack stack, List<? extends StringVisitable> textElements, Optional<TooltipData> itemComponent, int mouseX, int screenWidth, int screenHeight, TextRenderer font) {
		List<Either<StringVisitable, TooltipData>> elements = textElements.stream()
				.map((Function<StringVisitable, Either<StringVisitable, TooltipData>>) Either::left)
				.collect(Collectors.toCollection(ArrayList::new));
		itemComponent.ifPresent(c -> elements.add(1, Either.right(c)));

		// text wrapping
		int tooltipTextWidth = elements.stream()
				.mapToInt(either -> either.map(font::getWidth, component -> 0))
				.max()
				.orElse(0);

		boolean needsWrap = false;

		int tooltipX = mouseX + 12;
		if (tooltipX + tooltipTextWidth + 4 > screenWidth) {
			tooltipX = mouseX - 16 - tooltipTextWidth;
			if (tooltipX < 4) { // if the tooltip doesn't fit on the screen
				if (mouseX > screenWidth / 2)
					tooltipTextWidth = mouseX - 12 - 8;
				else
					tooltipTextWidth = screenWidth - 16 - mouseX;
				needsWrap = true;
			}
		}

		int tooltipTextWidthF = tooltipTextWidth;
		if (needsWrap) {
			return elements.stream()
					.flatMap(either -> either.map(
							text -> font.wrapLines(text, tooltipTextWidthF).stream().map(TooltipComponent::of),
							component -> Stream.of(TooltipComponent.of(component))
					))
					.toList();
		}
		return elements.stream()
				.map(either -> either.map(
						text -> TooltipComponent.of(text instanceof Text ? ((Text) text).asOrderedText() : Language.getInstance().reorder(text)),
						TooltipComponent::of
				))
				.toList();
	}

	@ApiStatus.Internal
	public static RenderLayer RENDER_TYPE = null;

	/**
	 * Sets the current {@link RenderLayer} to use for rendering a single block in {@link net.minecraft.client.render.block.BlockRenderManager#renderBlockAsEntity(BlockState, MatrixStack, VertexConsumerProvider, int, int)}.
	 * It is very important you set this to null after you have rendered your block(s).
	 * @param renderType The render type you want to render the block in. Ex: {@link RenderLayer#getTranslucent()}
	 */
	public static void setRenderType(RenderLayer renderType) {
		RENDER_TYPE = renderType;
	}
}

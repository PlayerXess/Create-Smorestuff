package io.github.fabricators_of_create.porting_lib.client_events.mixin.client;

import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.LocalCapture;

import io.github.fabricators_of_create.porting_lib.client_events.event.client.ClientPlayerNetworkCloneCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.network.packet.s2c.play.PlayerRespawnS2CPacket;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.world.World;
import net.minecraft.world.dimension.DimensionType;

@Mixin(ClientPlayNetworkHandler.class)
public class ClientPacketListenerMixin {
	@Shadow
	@Final
	private MinecraftClient minecraft;

	@Inject(method = "handleRespawn", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/multiplayer/ClientLevel;addPlayer(ILnet/minecraft/client/player/AbstractClientPlayer;)V"), locals = LocalCapture.CAPTURE_FAILEXCEPTION)
	private void onClientPlayerRespawn(PlayerRespawnS2CPacket clientboundRespawnPacket, CallbackInfo ci, RegistryKey<World> resourceKey, RegistryEntry<DimensionType> holder, ClientPlayerEntity oldPlayer, int i, String string, ClientPlayerEntity newPlayer) {
		ClientPlayerNetworkCloneCallback.EVENT.invoker().onPlayerRespawn(this.minecraft.interactionManager, oldPlayer, newPlayer, newPlayer.networkHandler.getConnection());
	}
}

package io.github.fabricators_of_create.porting_lib.data;

import com.google.gson.JsonElement;
import com.mojang.serialization.JsonOps;

import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricTagProvider;
import net.minecraft.data.DataProvider;
import net.minecraft.data.DataWriter;
import net.minecraft.data.server.tag.TagProvider;
import net.minecraft.registry.Registry;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryWrapper;
import net.minecraft.registry.tag.TagBuilder;
import net.minecraft.registry.tag.TagEntry;
import net.minecraft.registry.tag.TagFile;
import net.minecraft.registry.tag.TagKey;
import net.minecraft.registry.tag.TagManagerLoader;
import net.minecraft.resource.ResourceType;
import net.minecraft.util.Identifier;
import org.jetbrains.annotations.Nullable;

import java.nio.file.Path;
import java.util.List;
import java.util.Locale;
import java.util.Objects;
import java.util.concurrent.CompletableFuture;
import java.util.function.Predicate;
import java.util.stream.Collectors;

public abstract class PortingLibTagsProvider<T> extends FabricTagProvider<T> {
	@Nullable
	protected final ExistingFileHelper existingFileHelper;
	private final ExistingFileHelper.IResourceType resourceType;
	private final ExistingFileHelper.IResourceType elementResourceType; // Resource type for validating required references to datapack registry elements.

	/**
	 * Constructs a new {@link FabricTagProvider} with the default computed path.
	 *
	 * <p>Common implementations of this class are provided.
	 *
	 * @param output           the {@link FabricDataOutput} instance
	 * @param registryKey
	 * @param registriesFuture the backing registry for the tag type
	 */
	public PortingLibTagsProvider(FabricDataOutput output, RegistryKey<? extends Registry<T>> registryKey, CompletableFuture<RegistryWrapper.WrapperLookup> registriesFuture, @Nullable ExistingFileHelper existingFileHelper) {
		super(output, registryKey, registriesFuture);
		this.existingFileHelper = existingFileHelper;
		this.resourceType = new ExistingFileHelper.ResourceType(ResourceType.field_14190, ".json", TagManagerLoader.getPath(registryKey));
		this.elementResourceType = new ExistingFileHelper.ResourceType(ResourceType.field_14190, ".json", DatapackBuiltinEntriesProvider.prefixNamespace(registryKey.getValue()));
	}

	@Nullable
	protected Path getPath(Identifier id) {
		return this.pathResolver.resolveJson(id);
	}

	public CompletableFuture<?> run(DataWriter pOutput) {
		record CombinedData<T>(RegistryWrapper.WrapperLookup contents, TagProvider.TagLookup<T> parent) {
		}
		return this.getRegistryLookupFuture().thenApply((p_275895_) -> {
			this.registryLoadFuture.complete(null);
			return p_275895_;
		}).thenCombineAsync(this.parentTagLookupFuture, CombinedData::new).thenCompose((combinedData) -> {
			RegistryWrapper.Impl<T> registrylookup = combinedData.contents.getOptionalWrapper(this.registryRef).orElseThrow(() -> {
				return new IllegalStateException("Registry " + this.registryRef.getValue() + " not found");
			});
			Predicate<Identifier> predicate = (p_255496_) -> {
				return registrylookup.getOptional(RegistryKey.of(this.registryRef, p_255496_)).isPresent();
			};
			Predicate<Identifier> predicate1 = (p_274776_) -> {
				return this.tagBuilders.containsKey(p_274776_) || combinedData.parent.contains(TagKey.of(this.registryRef, p_274776_));
			};
			return CompletableFuture.allOf(this.tagBuilders.entrySet().stream().map((p_255499_) -> {
				Identifier resourcelocation = p_255499_.getKey();
				TagBuilder tagbuilder = p_255499_.getValue();
				List<TagEntry> list = tagbuilder.build();
				List<TagEntry> list1 = list.stream().filter((tag) -> {
					return !tag.canAdd(predicate, predicate1);
				}).filter(this::missing).toList(); // Forge: Add validation via existing resources
				if (!list1.isEmpty()) {
					throw new IllegalArgumentException(String.format(Locale.ROOT, "Couldn't define tag %s as it is missing following references: %s", resourcelocation, list1.stream().map(Objects::toString).collect(Collectors.joining(","))));
				} else {
					JsonElement jsonelement = TagFile.CODEC.encodeStart(JsonOps.INSTANCE, new TagFile(list, false)).getOrThrow(false, LOGGER::error);
					Path path = this.getPath(resourcelocation);
					if (path == null) return CompletableFuture.completedFuture(null); // Forge: Allow running this data provider without writing it. Recipe provider needs valid tags.
					return DataProvider.writeToPath(pOutput, jsonelement, path);
				}
			}).toArray(CompletableFuture[]::new));
		});
	}

	private boolean missing(TagEntry reference) {
		// Optional tags should not be validated

		if (reference.required) {
			return existingFileHelper == null || !existingFileHelper.exists(reference.id, reference.tag ? resourceType : elementResourceType);
		}
		return false;
	}
}

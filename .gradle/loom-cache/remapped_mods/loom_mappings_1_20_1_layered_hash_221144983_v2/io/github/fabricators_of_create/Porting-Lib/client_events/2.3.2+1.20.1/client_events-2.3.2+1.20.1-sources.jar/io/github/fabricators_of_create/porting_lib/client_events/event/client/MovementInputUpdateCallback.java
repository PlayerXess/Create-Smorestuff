package io.github.fabricators_of_create.porting_lib.client_events.event.client;

import net.fabricmc.fabric.api.event.Event;
import net.fabricmc.fabric.api.event.EventFactory;
import net.minecraft.client.input.Input;
import net.minecraft.entity.player.PlayerEntity;

public interface MovementInputUpdateCallback {
	Event<MovementInputUpdateCallback> EVENT = EventFactory.createArrayBacked(MovementInputUpdateCallback.class, movementInputUpdateCallbacks -> (player, input) -> {
		for (MovementInputUpdateCallback e : movementInputUpdateCallbacks)
			e.onMovementUpdate(player, input);
	});

	void onMovementUpdate(PlayerEntity player, Input input);
}

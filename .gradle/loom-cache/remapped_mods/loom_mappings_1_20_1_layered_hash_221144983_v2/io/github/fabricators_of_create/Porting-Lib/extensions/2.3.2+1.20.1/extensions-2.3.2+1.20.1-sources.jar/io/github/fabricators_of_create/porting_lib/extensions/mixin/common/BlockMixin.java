package io.github.fabricators_of_create.porting_lib.extensions.mixin.common;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;

import io.github.fabricators_of_create.porting_lib.extensions.extensions.BlockExtensions;
import net.minecraft.block.AbstractBlock;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.world.BlockView;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(Block.class)
public abstract class BlockMixin extends AbstractBlock implements BlockExtensions {
	private BlockMixin(AbstractBlock.Settings properties) {
		super(properties);
	}

	@ModifyExpressionValue(
			method = "shouldRenderFace",
			at = @At(
					value = "INVOKE",
					target = "Lnet/minecraft/world/level/block/state/BlockState;skipRendering(Lnet/minecraft/world/level/block/state/BlockState;Lnet/minecraft/core/Direction;)Z"
			)
	)
	private static boolean customFaceHiding(boolean orignial, BlockState pState, BlockView pLevel, BlockPos pOffset, Direction pFace, BlockPos pPos) {
		return orignial || (pState.supportsExternalFaceHiding() && pLevel.getBlockState(pPos).hidesNeighborFace(pLevel, pPos, pState, pFace.getOpposite()));
	}
}

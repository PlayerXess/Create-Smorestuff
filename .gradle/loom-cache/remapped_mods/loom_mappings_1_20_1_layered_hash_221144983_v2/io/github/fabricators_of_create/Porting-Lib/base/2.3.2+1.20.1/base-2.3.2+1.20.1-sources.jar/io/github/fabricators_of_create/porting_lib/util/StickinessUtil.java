package io.github.fabricators_of_create.porting_lib.util;

import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;

public class StickinessUtil {
	public static boolean canStickTo(BlockState state, BlockState other) {
		if (state.getBlock() == Blocks.field_21211 && other.getBlock() == Blocks.field_10030) return false;
		if (state.getBlock() == Blocks.field_10030 && other.getBlock() == Blocks.field_21211) return false;
		return (state.getBlock() == Blocks.field_10030 || state.getBlock() == Blocks.field_21211) ||
				(other.getBlock() == Blocks.field_10030 || other.getBlock() == Blocks.field_21211);
	}
}

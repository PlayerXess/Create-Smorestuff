package io.github.fabricators_of_create.porting_lib.data.extensions;

import net.minecraft.client.RunArgs;
import org.jetbrains.annotations.ApiStatus;

@ApiStatus.Internal
public interface MinecraftExtension {
	RunArgs port_lib$getGameConfig();
}

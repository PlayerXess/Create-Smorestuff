package io.github.fabricators_of_create.porting_lib.client_events;

import com.google.common.collect.ImmutableMap;

import io.github.fabricators_of_create.porting_lib.client_events.event.client.RegisterEntitySpectatorShadersCallback;
import org.jetbrains.annotations.Nullable;

import java.util.HashMap;
import java.util.Map;
import net.minecraft.entity.EntityType;
import net.minecraft.util.Identifier;

public class EntityShaderManager {
	private static final Map<EntityType<?>, Identifier> SHADERS;

	/**
	 * Finds the path to the spectator mode shader used for the specified entity type, or null if none is registered.
	 */
	@Nullable
	public static Identifier get(EntityType<?> entityType) {
		return SHADERS.get(entityType);
	}

	static {
		var shaders = new HashMap<EntityType<?>, Identifier>();
		RegisterEntitySpectatorShadersCallback.EVENT.invoker().registerCustomShaders(shaders);
		SHADERS = ImmutableMap.copyOf(shaders);
	}
}

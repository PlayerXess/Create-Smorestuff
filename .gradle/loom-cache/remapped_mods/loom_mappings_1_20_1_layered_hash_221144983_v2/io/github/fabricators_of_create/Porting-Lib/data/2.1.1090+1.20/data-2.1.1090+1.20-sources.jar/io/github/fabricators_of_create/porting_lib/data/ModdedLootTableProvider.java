package io.github.fabricators_of_create.porting_lib.data;

import java.nio.file.Path;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.CompletableFuture;

import javax.annotation.Nullable;
import net.minecraft.data.DataOutput;
import net.minecraft.data.DataProvider;
import net.minecraft.data.DataWriter;
import net.minecraft.data.server.loottable.LootTableProvider;
import net.minecraft.loot.LootDataKey;
import net.minecraft.loot.LootDataLookup;
import net.minecraft.loot.LootDataType;
import net.minecraft.loot.LootTable;
import net.minecraft.loot.LootTableReporter;
import net.minecraft.loot.context.LootContextTypes;
import net.minecraft.util.Identifier;
import net.minecraft.util.Util;
import net.minecraft.util.math.random.RandomSeed;
import net.minecraft.util.math.random.RandomSequence;
import org.slf4j.Logger;

import com.google.common.collect.Maps;
import com.google.common.collect.Multimap;
import com.google.common.collect.Sets;
import com.mojang.logging.LogUtils;

import it.unimi.dsi.fastutil.objects.Object2ObjectOpenHashMap;

public class ModdedLootTableProvider extends LootTableProvider {
	private static final Logger LOGGER = LogUtils.getLogger();
	private final Set<Identifier> requiredTables;
	private final List<LootTableProvider.LootTypeGenerator> subProviders;

	public ModdedLootTableProvider(DataOutput packOutput, Set<Identifier> requiredTables, List<LootTypeGenerator> subProviders) {
		super(packOutput, requiredTables, subProviders);
		this.requiredTables = requiredTables;
		this.subProviders = subProviders;
	}

	@Override
	public CompletableFuture<?> run(DataWriter pOutput) {
		final Map<Identifier, LootTable> map = Maps.newHashMap();
		Map<RandomSeed.XoroshiroSeed, Identifier> map1 = new Object2ObjectOpenHashMap<>();
		this.getTables().forEach((entry) -> entry.comp_1068().get().accept((key, builder) -> {
			Identifier id = map1.put(RandomSequence.createSeed(key), key);
			if (id != null) {
				Util.error("Loot table random sequence seed collision on " + id + " and " + key);
			}

			builder.randomSequenceId(key);
			if (map.put(key, builder.type(entry.comp_1069()).build()) != null) {
				throw new IllegalStateException("Duplicate loot table " + key);
			}
		}));
		LootTableReporter validationcontext = new LootTableReporter(LootContextTypes.field_1177, new LootDataLookup() {
			@Nullable
			public <T> T getElement(LootDataKey<T> p_279283_) {
				return (T)(p_279283_.comp_1474() == LootDataType.field_44498 ? map.get(p_279283_.id()) : null);
			}
		});

		validate(map, validationcontext);

		Multimap<String, String> multimap = validationcontext.getMessages();
		if (!multimap.isEmpty()) {
			multimap.forEach((p_124446_, p_124447_) -> {
				LOGGER.warn("Found validation problem in {}: {}", p_124446_, p_124447_);
			});
			throw new IllegalStateException("Failed to validate loot tables, see logs");
		} else {
			return CompletableFuture.allOf(map.entrySet().stream().map((lootTableEntry) -> {
				Identifier lootTableId = lootTableEntry.getKey();
				LootTable loottable = lootTableEntry.getValue();
				Path path = this.pathResolver.resolveJson(lootTableId);
				return DataProvider.writeToPath(pOutput, LootDataType.field_44498.getGson().toJsonTree(loottable), path);
			}).toArray(CompletableFuture[]::new));
		}
	}

	public List<LootTableProvider.LootTypeGenerator> getTables() {
		return this.subProviders;
	}

	protected void validate(Map<Identifier, LootTable> map, LootTableReporter validationcontext) {
		for(Identifier resourcelocation : Sets.difference(this.requiredTables, map.keySet())) {
			validationcontext.report("Missing built-in table: " + resourcelocation);
		}

		map.forEach((id, lootTable) -> {
			lootTable.validate(validationcontext.withContextType(lootTable.getType()).makeChild("{" + id + "}", new LootDataKey<>(LootDataType.field_44498, id)));
		});
	}

	public String getName() {
		return "LootTables";
	}
}

package io.github.fabricators_of_create.porting_lib.extensions.extensions;

import net.minecraft.structure.StructurePlacementData;
import net.minecraft.structure.StructureTemplate;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.WorldView;

public interface StructureProcessorExtensions {
	default StructureTemplate.StructureEntityInfo processEntity(WorldView world, BlockPos seedPos, StructureTemplate.StructureEntityInfo rawEntityInfo, StructureTemplate.StructureEntityInfo entityInfo, StructurePlacementData placementSettings, StructureTemplate template) {
		throw new RuntimeException("this should be overridden via mixin. what?");
	}
}

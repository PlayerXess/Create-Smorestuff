
package com.jozufozu.flywheel.core.model;

import com.jozufozu.flywheel.core.virtual.VirtualEmptyBlockGetter;
import com.jozufozu.flywheel.fabric.model.DefaultLayerFilteringBakedModel;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.client.render.OverlayTexture;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.block.BlockModelRenderer;
import net.minecraft.client.render.model.BakedModel;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.random.Random;
import net.minecraft.world.BlockRenderView;

public final class BakedModelBuilder implements Bufferable {
	private final BakedModel model;
	private BlockRenderView renderWorld = VirtualEmptyBlockGetter.INSTANCE;
	private BlockState referenceState = Blocks.field_10124.getDefaultState();
	private MatrixStack poseStack = new MatrixStack();

	public BakedModelBuilder(BakedModel model) {
		this.model = model;
	}

	public BakedModelBuilder withRenderWorld(BlockRenderView renderWorld) {
		this.renderWorld = renderWorld;
		return this;
	}

	public BakedModelBuilder withReferenceState(BlockState referenceState) {
		this.referenceState = referenceState;
		return this;
	}

	public BakedModelBuilder withPoseStack(MatrixStack poseStack) {
		this.poseStack = poseStack;
		return this;
	}

	@Override
	public void bufferInto(VertexConsumer consumer, BlockModelRenderer blockRenderer, Random random) {
		BakedModel model = DefaultLayerFilteringBakedModel.wrap(this.model);
		if (consumer instanceof ShadeSeparatingVertexConsumer shadeSeparatingWrapper) {
			model = shadeSeparatingWrapper.wrapModel(model);
		}
		blockRenderer.render(renderWorld, model, referenceState, BlockPos.ORIGIN, poseStack, consumer, false, random, 42, OverlayTexture.DEFAULT_UV);
	}

	public BlockModel toModel(String name) {
		return BlockModel.of(this, name);
	}

	public BlockModel toModel() {
		return toModel(referenceState.toString());
	}
}

package com.jozufozu.flywheel.core.model;

import java.nio.ByteBuffer;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.BufferBuilder.DrawParameters;
import org.lwjgl.system.MemoryUtil;

import com.jozufozu.flywheel.util.FlwUtil;

public interface ShadeSeparatedBufferedData {
	ByteBuffer vertexBuffer();

	ByteBuffer indexBuffer();

	BufferBuilder.DrawParameters drawState();

	int unshadedStartVertex();

	void release();

	static final class NativeImpl implements ShadeSeparatedBufferedData {
		private final ByteBuffer vertexBuffer;
		private final ByteBuffer indexBuffer;
		private final BufferBuilder.DrawParameters drawState;
		private final int unshadedStartVertex;

		public NativeImpl(ByteBuffer vertexBuffer, ByteBuffer indexBuffer, BufferBuilder.DrawParameters drawState, int unshadedStartVertex) {
			this.vertexBuffer = FlwUtil.copyBuffer(vertexBuffer);
			this.indexBuffer = FlwUtil.copyBuffer(indexBuffer);
			this.drawState = drawState;
			this.unshadedStartVertex = unshadedStartVertex;
		}

		@Override
		public ByteBuffer vertexBuffer() {
			return vertexBuffer;
		}

		@Override
		public ByteBuffer indexBuffer() {
			return indexBuffer;
		}

		@Override
		public DrawParameters drawState() {
			return drawState;
		}

		@Override
		public int unshadedStartVertex() {
			return unshadedStartVertex;
		}

		@Override
		public void release() {
			MemoryUtil.memFree(vertexBuffer);
			MemoryUtil.memFree(indexBuffer);
		}
	}
}

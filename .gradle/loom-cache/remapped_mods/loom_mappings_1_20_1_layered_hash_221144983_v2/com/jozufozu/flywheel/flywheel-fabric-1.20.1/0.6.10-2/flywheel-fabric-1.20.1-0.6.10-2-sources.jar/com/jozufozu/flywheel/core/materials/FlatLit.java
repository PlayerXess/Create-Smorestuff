package com.jozufozu.flywheel.core.materials;

import com.jozufozu.flywheel.api.InstanceData;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.BlockRenderView;
import net.minecraft.world.LightType;

/**
 * An interface that implementors of {@link InstanceData} should also implement
 * if they wish to make use of Flywheel's provided light update methods.
 * <p>
 * This only covers flat lighting, smooth lighting is still TODO.
 *
 * @param <D> The name of the class that implements this interface.
 */
public interface FlatLit<D extends InstanceData & FlatLit<D>> {
	/**
	 * @param blockLight An integer in the range [0, 15] representing the
	 *                   amount of block light this instance should receive.
	 * @return {@code this}
	 */
	D setBlockLight(int blockLight);

	/**
	 * @param skyLight An integer in the range [0, 15] representing the
	 *                 amount of sky light this instance should receive.
	 * @return {@code this}
	 */
	D setSkyLight(int skyLight);

	default D updateLight(BlockRenderView level, BlockPos pos) {
		return setBlockLight(level.getLightLevel(LightType.field_9282, pos))
				.setSkyLight(level.getLightLevel(LightType.field_9284, pos));
	}

	int getPackedLight();
}

package com.jozufozu.flywheel.api;

import com.jozufozu.flywheel.backend.RenderLayer;
import net.minecraft.util.math.Vec3i;

public interface MaterialManager {

	/**
	 * Get a material group that will render in the given layer with the given state.
	 *
	 * @param layer The {@link RenderLayer} you want to draw in.
	 * @param state The {@link net.minecraft.client.render.RenderLayer} you need to draw with.
	 * @return A material group whose children will
	 */
	MaterialGroup state(RenderLayer layer, net.minecraft.client.render.RenderLayer state);

	Vec3i getOriginCoordinate();

	default MaterialGroup solid(net.minecraft.client.render.RenderLayer state) {
		return state(RenderLayer.SOLID, state);
	}

	default MaterialGroup cutout(net.minecraft.client.render.RenderLayer state) {
		return state(RenderLayer.CUTOUT, state);
	}

	default MaterialGroup transparent(net.minecraft.client.render.RenderLayer state) {
		return state(RenderLayer.TRANSPARENT, state);
	}

	default MaterialGroup defaultSolid() {
		return solid(net.minecraft.client.render.RenderLayer.getSolid());
	}

	default MaterialGroup defaultCutout() {
		return cutout(net.minecraft.client.render.RenderLayer.getCutout());
	}

	default MaterialGroup defaultTransparent() {
		return transparent(net.minecraft.client.render.RenderLayer.getTranslucent());
	}
}

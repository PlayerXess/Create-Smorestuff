package com.jozufozu.flywheel.event;

import com.jozufozu.flywheel.fabric.event.EventContext;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.Frustum;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.util.math.Vec3d;

public class BeginFrameEvent extends EventContext {
	private final ClientWorld world;
	private final Camera camera;
	private final Frustum frustum;

	public BeginFrameEvent(ClientWorld world, Camera camera, Frustum frustum) {
		this.world = world;
		this.camera = camera;
		this.frustum = frustum;
	}

	public ClientWorld getWorld() {
		return world;
	}

	public Camera getCamera() {
		return camera;
	}

	public Frustum getFrustum() {
		return frustum;
	}

	public Vec3d getCameraPos() {
		return camera.getPos();
	}
}

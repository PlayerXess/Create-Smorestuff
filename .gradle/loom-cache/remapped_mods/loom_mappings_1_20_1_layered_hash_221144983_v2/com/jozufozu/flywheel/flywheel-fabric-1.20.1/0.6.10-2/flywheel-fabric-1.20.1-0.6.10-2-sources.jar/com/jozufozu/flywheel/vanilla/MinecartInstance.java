package com.jozufozu.flywheel.vanilla;

import com.jozufozu.flywheel.api.MaterialManager;
import com.jozufozu.flywheel.api.instance.DynamicInstance;
import com.jozufozu.flywheel.api.instance.TickableInstance;
import com.jozufozu.flywheel.backend.instancing.entity.EntityInstance;
import com.jozufozu.flywheel.core.Materials;
import com.jozufozu.flywheel.core.hardcoded.ModelPart;
import com.jozufozu.flywheel.core.materials.model.ModelData;
import com.jozufozu.flywheel.core.model.Model;
import com.jozufozu.flywheel.util.AnimationTickHolder;
import com.jozufozu.flywheel.util.transform.TransformStack;
import net.minecraft.block.BlockRenderType;
import net.minecraft.block.BlockState;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.vehicle.AbstractMinecartEntity;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RotationAxis;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.math.Vec3i;

public class MinecartInstance<T extends AbstractMinecartEntity> extends EntityInstance<T> implements DynamicInstance, TickableInstance {

	private static final Identifier MINECART_LOCATION = new Identifier("textures/entity/minecart.png");

	private final MatrixStack stack = new MatrixStack();

	private final ModelData body;
	private ModelData contents;
	private BlockState blockstate;

	public MinecartInstance(MaterialManager materialManager, T entity) {
		super(materialManager, entity);

		blockstate = entity.getContainedBlock();
		contents = getContents();
		body = getBody();
	}

	@Override
	public void tick() {
		BlockState displayBlockState = entity.getContainedBlock();

		if (displayBlockState != blockstate) {
			blockstate = displayBlockState;
			contents.delete();
			contents = getContents();
			updateLight();
		}
	}

	@Override
	public void beginFrame() {
		TransformStack tstack = TransformStack.cast(stack);
		stack.loadIdentity();
		float pt = AnimationTickHolder.getPartialTicks();

		Vec3i originCoordinate = materialManager.getOriginCoordinate();
		tstack.translate(
				MathHelper.lerp(pt, entity.lastRenderX, entity.getX()) - originCoordinate.getX(),
				MathHelper.lerp(pt, entity.lastRenderY, entity.getY()) - originCoordinate.getY(),
				MathHelper.lerp(pt, entity.lastRenderZ, entity.getZ()) - originCoordinate.getZ());

		float yaw = MathHelper.lerp(pt, entity.prevYaw, entity.getYaw());

		long i = (long)entity.getId() * 493286711L;
		i = i * i * 4392167121L + i * 98761L;
		float f = (((float)(i >> 16 & 7L) + 0.5F) / 8 - 0.5F) * 0.004F;
		float f1 = (((float)(i >> 20 & 7L) + 0.5F) / 8 - 0.5F) * 0.004F;
		float f2 = (((float)(i >> 24 & 7L) + 0.5F) / 8 - 0.5F) * 0.004F;
		tstack.translate(f, f1, f2);
		tstack.nudge(entity.getId());
		double d0 = MathHelper.lerp(pt, entity.lastRenderX, entity.getX());
		double d1 = MathHelper.lerp(pt, entity.lastRenderY, entity.getY());
		double d2 = MathHelper.lerp(pt, entity.lastRenderZ, entity.getZ());
		Vec3d vector3d = entity.snapPositionToRail(d0, d1, d2);
		float f3 = MathHelper.lerp(pt, entity.prevPitch, entity.getPitch());
		if (vector3d != null) {
			Vec3d vector3d1 = entity.snapPositionToRailWithOffset(d0, d1, d2, 0.3F);
			Vec3d vector3d2 = entity.snapPositionToRailWithOffset(d0, d1, d2, -0.3F);
			if (vector3d1 == null) {
				vector3d1 = vector3d;
			}

			if (vector3d2 == null) {
				vector3d2 = vector3d;
			}

			tstack.translate(vector3d.x - d0, (vector3d1.y + vector3d2.y) / 2.0D - d1, vector3d.z - d2);
			Vec3d vector3d3 = vector3d2.add(-vector3d1.x, -vector3d1.y, -vector3d1.z);
			if (vector3d3.length() != 0.0D) {
				vector3d3 = vector3d3.normalize();
				yaw = (float)(Math.atan2(vector3d3.z, vector3d3.x) * 180.0D / Math.PI);
				f3 = (float)(Math.atan(vector3d3.y) * 73.0D);
			}
		}

		tstack.translate(0.0D, 0.375D, 0.0D);
		tstack.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(180 - yaw));
		tstack.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(-f3));
		float f5 = (float)entity.getDamageWobbleTicks() - pt;
		float f6 = entity.getDamageWobbleStrength() - pt;
		if (f6 < 0) {
			f6 = 0;
		}

		if (f5 > 0) {
			tstack.multiply(RotationAxis.POSITIVE_X.rotationDegrees(MathHelper.sin(f5) * f5 * f6 / 10 * (float)entity.getDamageWobbleSide()));
		}

		int j = entity.getBlockOffset();
		if (contents != null) {
			tstack.pushPose();
			tstack.scale(0.75F);
			tstack.translate(-0.5D, (float)(j - 8) / 16, 0.5D);
			tstack.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(90));
			contents.setTransform(stack);
			tstack.popPose();
		}

		body.setTransform(stack);
	}

	@Override
	public void updateLight() {
		if (contents == null)
			relight(getWorldPosition(), body);
		else
			relight(getWorldPosition(), body, contents);
	}

	@Override
	public void remove() {
		body.delete();
		if (contents != null) contents.delete();
	}

	private ModelData getContents() {
		if (blockstate.getRenderType() == BlockRenderType.field_11455)
			return null;

		return materialManager.defaultSolid()
				.material(Materials.TRANSFORMED)
				.getModel(blockstate)
				.createInstance();
	}

	private ModelData getBody() {
		return materialManager.solid(RenderLayer.getEntitySolid(MINECART_LOCATION))
				.material(Materials.TRANSFORMED)
				.model(entity.getType(), this::getBodyModel)
				.createInstance();
	}

	private Model getBodyModel() {
		int y = -3;
		return ModelPart.builder("minecart", 64, 32)
				.cuboid().invertYZ().start(-10, -8, -y).size(20, 16, 2).textureOffset(0, 10).rotateZ((float) Math.PI).rotateX(((float)Math.PI / 2F)).endCuboid()
				.cuboid().invertYZ().start(-8, y, -10).size(16, 8, 2).rotateY(((float)Math.PI * 1.5F)).endCuboid()
				.cuboid().invertYZ().start(-8, y, -10).size(16, 8, 2).rotateY(((float)Math.PI / 2F)).endCuboid()
				.cuboid().invertYZ().start(-8, y, -8).size(16, 8, 2).rotateY((float)Math.PI).endCuboid()
				.cuboid().invertYZ().start(-8, y, -8).size(16, 8, 2).endCuboid()
				.build();
	}
}

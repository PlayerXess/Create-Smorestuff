@ParametersAreNonnullByDefault @MethodsReturnNonnullByDefault
package com.jozufozu.flywheel.core.vertex;

import javax.annotation.ParametersAreNonnullByDefault;

package com.jozufozu.flywheel.core;

import com.jozufozu.flywheel.Flywheel;
import net.minecraft.util.Identifier;

public class Programs {
	public static final Identifier TRANSFORMED = Flywheel.rl("model");
	public static final Identifier ORIENTED = Flywheel.rl("oriented");
}

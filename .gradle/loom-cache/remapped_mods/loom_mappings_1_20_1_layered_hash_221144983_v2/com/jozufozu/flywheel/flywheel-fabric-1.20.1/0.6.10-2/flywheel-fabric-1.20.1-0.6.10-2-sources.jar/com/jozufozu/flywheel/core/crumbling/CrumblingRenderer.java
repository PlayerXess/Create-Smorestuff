package com.jozufozu.flywheel.core.crumbling;

import java.util.ArrayList;
import java.util.List;
import java.util.SortedSet;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.BlockBreakingInfo;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.model.ModelLoader;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import com.jozufozu.flywheel.backend.Backend;
import com.jozufozu.flywheel.backend.gl.GlStateTracker;
import com.jozufozu.flywheel.backend.instancing.InstanceManager;
import com.jozufozu.flywheel.backend.instancing.SerialTaskEngine;
import com.jozufozu.flywheel.backend.instancing.instancing.InstancingEngine;
import com.jozufozu.flywheel.core.Contexts;
import com.jozufozu.flywheel.core.shader.WorldProgram;
import com.jozufozu.flywheel.event.ReloadRenderersEvent;
import com.jozufozu.flywheel.event.RenderLayerEvent;
import com.jozufozu.flywheel.mixin.LevelRendererAccessor;
import com.jozufozu.flywheel.util.Lazy;
import com.jozufozu.flywheel.util.Pair;
import it.unimi.dsi.fastutil.ints.Int2ObjectArrayMap;
import it.unimi.dsi.fastutil.ints.Int2ObjectMap;
import it.unimi.dsi.fastutil.longs.Long2ObjectMap;

/**
 * Responsible for rendering the block breaking overlay for instanced block entities.
 */
public class CrumblingRenderer {

	static RenderLayer _currentLayer;

	private static final Lazy<State> STATE;
	private static final Lazy.KillSwitch<State> INVALIDATOR;

	static {
		Pair<Lazy<State>, Lazy.KillSwitch<State>> state = Lazy.ofKillable(State::new, State::kill);

        STATE = state.first();
		INVALIDATOR = state.second();
	}

	public static void render(ClientWorld level, Camera camera, MatrixStack stack) {
		if (!Backend.canUseInstancing(level)) return;

		Int2ObjectMap<List<BlockEntity>> activeStages = getActiveStageBlockEntities(level);
		if (activeStages.isEmpty()) return;

		Vec3d cameraPos = camera.getPos();

		// XXX Restore state
		GlStateTracker.State restoreState = GlStateTracker.getRestoreState();
		renderCrumbling(activeStages, camera, new RenderLayerEvent(level, null, stack, null, cameraPos.x, cameraPos.y, cameraPos.z));
		restoreState.restore();
	}

	private static void renderCrumbling(Int2ObjectMap<List<BlockEntity>> activeStages, Camera camera, RenderLayerEvent event) {
		State state = STATE.get();
		InstanceManager<BlockEntity> instanceManager = state.instanceManager;
		InstancingEngine<WorldProgram> materials = state.materialManager;

		for (Int2ObjectMap.Entry<List<BlockEntity>> stage : activeStages.int2ObjectEntrySet()) {
			_currentLayer = ModelLoader.BLOCK_DESTRUCTION_RENDER_LAYERS.get(stage.getIntKey());

			// something about when we call this means that the textures are not ready for use on the first frame they should appear
			if (_currentLayer != null) {
				stage.getValue().forEach(instanceManager::add);

				instanceManager.beginFrame(SerialTaskEngine.INSTANCE, camera);

				// XXX Each call applies another restore state even though we are already inside of a restore state
				materials.render(SerialTaskEngine.INSTANCE, event);

				instanceManager.invalidate();
			}
		}
	}

	/**
	 * Associate each breaking stage with a list of all block entities at that stage.
	 */
	private static Int2ObjectMap<List<BlockEntity>> getActiveStageBlockEntities(ClientWorld world) {

		Int2ObjectMap<List<BlockEntity>> breakingEntities = new Int2ObjectArrayMap<>();

		for (Long2ObjectMap.Entry<SortedSet<BlockBreakingInfo>> entry : ((LevelRendererAccessor) MinecraftClient.getInstance().worldRenderer).flywheel$getDestructionProgress()
				.long2ObjectEntrySet()) {
			BlockPos breakingPos = BlockPos.fromLong(entry.getLongKey());

			SortedSet<BlockBreakingInfo> progresses = entry.getValue();
			if (progresses != null && !progresses.isEmpty()) {
				int blockDamage = progresses.last()
						.getStage();

				BlockEntity blockEntity = world.getBlockEntity(breakingPos);

				if (blockEntity != null) {
					List<BlockEntity> blockEntities = breakingEntities.computeIfAbsent(blockDamage, $ -> new ArrayList<>());
					blockEntities.add(blockEntity);
				}
			}
		}

		return breakingEntities;
	}

	public static void onReloadRenderers(ReloadRenderersEvent event) {
		ClientWorld world = event.getWorld();
        if (Backend.isOn() && world != null) {
			reset();
		}
	}

	public static void reset() {
		INVALIDATOR.killValue();
	}

	private static class State {
		private final InstancingEngine<WorldProgram> materialManager;
		private final InstanceManager<BlockEntity> instanceManager;

		private State() {
			materialManager = InstancingEngine.builder(Contexts.CRUMBLING)
					.setGroupFactory(CrumblingGroup::new)
					.build();
			instanceManager = new CrumblingInstanceManager(materialManager);
			materialManager.addListener(instanceManager);
		}

		private void kill() {
			materialManager.delete();
			instanceManager.invalidate();
		}
	}
}

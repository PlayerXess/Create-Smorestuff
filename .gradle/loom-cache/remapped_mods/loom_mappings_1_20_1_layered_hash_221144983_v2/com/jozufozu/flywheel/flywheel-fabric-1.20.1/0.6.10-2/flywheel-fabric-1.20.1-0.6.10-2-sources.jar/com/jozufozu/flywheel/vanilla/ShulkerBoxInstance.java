package com.jozufozu.flywheel.vanilla;

import org.joml.Quaternionf;

import com.jozufozu.flywheel.api.MaterialManager;
import com.jozufozu.flywheel.api.instance.DynamicInstance;
import com.jozufozu.flywheel.backend.instancing.blockentity.BlockEntityInstance;
import com.jozufozu.flywheel.core.Materials;
import com.jozufozu.flywheel.core.hardcoded.ModelPart;
import com.jozufozu.flywheel.core.materials.model.ModelData;
import com.jozufozu.flywheel.util.AnimationTickHolder;
import com.jozufozu.flywheel.util.transform.TransformStack;
import net.minecraft.block.ShulkerBoxBlock;
import net.minecraft.block.entity.ShulkerBoxBlockEntity;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.TexturedRenderLayers;
import net.minecraft.client.texture.Sprite;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.DyeColor;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.RotationAxis;

public class ShulkerBoxInstance extends BlockEntityInstance<ShulkerBoxBlockEntity> implements DynamicInstance {

	private final Sprite texture;

	private final ModelData base;
	private final ModelData lid;
	private final MatrixStack stack = new MatrixStack();

	private float lastProgress = Float.NaN;

	public ShulkerBoxInstance(MaterialManager materialManager, ShulkerBoxBlockEntity blockEntity) {
		super(materialManager, blockEntity);

		DyeColor color = blockEntity.getColor();
		if (color == null) {
			texture = TexturedRenderLayers.SHULKER_TEXTURE_ID.getSprite();
		} else {
			texture = TexturedRenderLayers.COLORED_SHULKER_BOXES_TEXTURES.get(color.getId()).getSprite();
		}
		Quaternionf rotation = getDirection().getRotationQuaternion();

		TransformStack tstack = TransformStack.cast(stack);

		tstack.translate(getInstancePosition())
				.scale(0.9995f)
				.translateAll(0.00025)
				.centre()
				.multiply(rotation)
				.unCentre();

		base = makeBaseInstance().setTransform(stack);

		tstack.translateY(0.25);

		lid = makeLidInstance().setTransform(stack);
	}

	@Override
	public void beginFrame() {
		float progress = blockEntity.getAnimationProgress(AnimationTickHolder.getPartialTicks());

		if (progress == lastProgress) return;
		lastProgress = progress;

		Quaternionf spin = RotationAxis.POSITIVE_Y.rotationDegrees(270.0F * progress);

		TransformStack tstack = TransformStack.cast(stack);

		tstack.pushPose()
				.centre()
				.multiply(spin)
				.unCentre()
				.translateY(progress * 0.5f);

		lid.setTransform(stack);

		stack.pop();
	}

	@Override
	public void remove() {
		base.delete();
		lid.delete();
	}

	@Override
	public void updateLight() {
		relight(pos, base, lid);
	}

	private ModelData makeBaseInstance() {
        return materialManager.cutout(RenderLayer.getEntityCutoutNoCull(TexturedRenderLayers.SHULKER_BOXES_ATLAS_TEXTURE))
                .material(Materials.TRANSFORMED)
				.model("base_" + texture.getContents().getId(), this::makeBaseModel)
				.createInstance();
	}

	private ModelData makeLidInstance() {
        return materialManager.cutout(RenderLayer.getEntityCutoutNoCull(TexturedRenderLayers.SHULKER_BOXES_ATLAS_TEXTURE))
                .material(Materials.TRANSFORMED)
				.model("lid_" + texture.getContents().getId(), this::makeLidModel)
				.createInstance();
	}

	private ModelPart makeBaseModel() {
		return ModelPart.builder("shulker_base", 64, 64)
				.sprite(texture)
				.cuboid()
				.textureOffset(0, 28)
				.size(16, 8, 16)
				.invertYZ()
				.endCuboid()
				.build();
	}

	private ModelPart makeLidModel() {
		return ModelPart.builder("shulker_lid", 64, 64)
				.sprite(texture)
				.cuboid()
				.size(16, 12, 16)
				.invertYZ()
				.endCuboid()
				.build();
	}

	private Direction getDirection() {
		if (blockState.getBlock() instanceof ShulkerBoxBlock) {
			return blockState.get(ShulkerBoxBlock.FACING);
		}

		return Direction.field_11036;
	}
}

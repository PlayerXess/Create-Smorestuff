package com.jozufozu.flywheel.util;

import javax.annotation.Nullable;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.util.Identifier;
import org.lwjgl.opengl.GL32;

import com.mojang.blaze3d.systems.RenderSystem;

/**
 * Helper class to keep track of what texture atlases are bound to what texture units.
 *
 * <p>
 *     Works with {@link com.jozufozu.flywheel.mixin.RenderTexturesMixin}.
 * </p>
 */
public class Textures {

	private static final Identifier[] shaderTextures = new Identifier[12];

	@Nullable
	public static Identifier getShaderTexture(int pShaderTexture) {
		return shaderTextures[pShaderTexture];
	}

	public static void _setShaderTexture(int pShaderTexture, Identifier pTextureId) {
		shaderTextures[pShaderTexture] = pTextureId;
	}

	/**
	 * Call this after calling {@link RenderLayer#startDrawing()}.
	 */
	public static void bindActiveTextures() {
		for (int i = 0; i < 12; i++) {
			int shaderTexture = RenderSystem.getShaderTexture(i);
			RenderSystem.activeTexture(GL32.GL_TEXTURE0 + i);
			RenderSystem.bindTexture(shaderTexture);
		}
	}
}

package com.jozufozu.flywheel.util;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.world.ClientWorld;

public interface DiffuseLightCalculator {
	DiffuseLightCalculator DEFAULT = RenderMath::diffuseLight;
	DiffuseLightCalculator NETHER = RenderMath::diffuseLightNether;

	static DiffuseLightCalculator forCurrentLevel() {
		return forLevel(MinecraftClient.getInstance().world);
	}

	static DiffuseLightCalculator forLevel(ClientWorld level) {
		return level.getDimensionEffects().isDarkened() ? NETHER : DEFAULT;
	}

	float getDiffuse(float normalX, float normalY, float normalZ, boolean shaded);
}

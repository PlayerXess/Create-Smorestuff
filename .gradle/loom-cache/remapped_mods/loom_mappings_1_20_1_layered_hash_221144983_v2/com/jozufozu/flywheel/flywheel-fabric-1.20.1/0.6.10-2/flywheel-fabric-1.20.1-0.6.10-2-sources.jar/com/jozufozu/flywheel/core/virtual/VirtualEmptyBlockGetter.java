package com.jozufozu.flywheel.core.virtual;

import org.jetbrains.annotations.Nullable;

import net.fabricmc.fabric.api.rendering.data.v1.RenderAttachedBlockView;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.client.MinecraftClient;
import net.minecraft.fluid.FluidState;
import net.minecraft.fluid.Fluids;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.util.math.ChunkSectionPos;
import net.minecraft.util.math.Direction;
import net.minecraft.world.BlockRenderView;
import net.minecraft.world.BlockView;
import net.minecraft.world.LightType;
import net.minecraft.world.biome.Biome;
import net.minecraft.world.biome.BiomeKeys;
import net.minecraft.world.biome.ColorResolver;
import net.minecraft.world.chunk.ChunkNibbleArray;
import net.minecraft.world.chunk.ChunkProvider;
import net.minecraft.world.chunk.light.ChunkLightingView;
import net.minecraft.world.chunk.light.LightSourceView;
import net.minecraft.world.chunk.light.LightingProvider;

public interface VirtualEmptyBlockGetter extends RenderAttachedBlockView {
	public static final VirtualEmptyBlockGetter INSTANCE = new StaticLightImpl(0, 15);
	public static final VirtualEmptyBlockGetter FULL_BRIGHT = new StaticLightImpl(15, 15);
	public static final VirtualEmptyBlockGetter FULL_DARK = new StaticLightImpl(0, 0);

	public static boolean is(BlockRenderView blockGetter) {
		return blockGetter instanceof VirtualEmptyBlockGetter;
	}

	@Override
	@Nullable
	default BlockEntity getBlockEntity(BlockPos pos) {
		return null;
	}

	@Override
	default BlockState getBlockState(BlockPos pos) {
		return Blocks.field_10124.getDefaultState();
	}

	@Override
	default FluidState getFluidState(BlockPos pos) {
		return Fluids.field_15906.getDefaultState();
	}

	@Override
	default int getHeight() {
		return 1;
	}

	@Override
	default int getBottomY() {
		return 0;
	}

	@Override
	default float getBrightness(Direction direction, boolean shaded) {
		return 1f;
	}

	@Override
	default int getColor(BlockPos pos, ColorResolver resolver) {
		Biome plainsBiome = MinecraftClient.getInstance().getNetworkHandler().getRegistryManager().get(RegistryKeys.BIOME).getOrThrow(BiomeKeys.field_9451);
		return resolver.getColor(plainsBiome, pos.getX(), pos.getZ());
	}

	@Override
	@Nullable
	default Object getBlockEntityRenderAttachment(BlockPos pos) {
		return null;
	}

	public static class StaticLightImpl implements VirtualEmptyBlockGetter {
		private final LightingProvider lightEngine;

		public StaticLightImpl(int blockLight, int skyLight) {
			lightEngine = new LightingProvider(new ChunkProvider() {
				@Override
				@Nullable
				public LightSourceView getChunk(int p_63023_, int p_63024_) {
					return null;
				}

				@Override
				public BlockView getWorld() {
					return StaticLightImpl.this;
				}
			}, false, false) {
				private final ChunkLightingView blockListener = createStaticListener(blockLight);
				private final ChunkLightingView skyListener = createStaticListener(skyLight);

				@Override
				public ChunkLightingView get(LightType layer) {
					return layer == LightType.field_9282 ? blockListener : skyListener;
				}
			};
		}

		private static ChunkLightingView createStaticListener(int light) {
			return new ChunkLightingView() {
				@Override
				public void checkBlock(BlockPos pos) {
				}

				@Override
				public boolean hasUpdates() {
					return false;
				}

				@Override
				public int doLightUpdates() {
					return 0;
				}

				@Override
				public void setSectionStatus(ChunkSectionPos pos, boolean isSectionEmpty) {
				}

				@Override
				public void setColumnEnabled(ChunkPos pos, boolean lightEnabled) {
				}

				@Override
				public void propagateLight(ChunkPos pos) {
				}

				@Override
				public ChunkNibbleArray getLightSection(ChunkSectionPos pos) {
					return null;
				}

				@Override
				public int getLightLevel(BlockPos pos) {
					return light;
				}
			};
		}

		@Override
		public LightingProvider getLightingProvider() {
			return lightEngine;
		}
	}
}

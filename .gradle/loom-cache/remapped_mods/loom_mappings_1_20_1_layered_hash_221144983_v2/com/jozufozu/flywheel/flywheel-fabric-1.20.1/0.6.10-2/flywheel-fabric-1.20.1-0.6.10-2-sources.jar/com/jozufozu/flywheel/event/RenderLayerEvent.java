package com.jozufozu.flywheel.event;

import javax.annotation.Nullable;
import net.minecraft.client.render.BufferBuilderStorage;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.client.world.ClientWorld;
import org.joml.Matrix4f;

import com.jozufozu.flywheel.backend.RenderLayer;
import com.jozufozu.flywheel.fabric.event.EventContext;
import com.mojang.blaze3d.systems.RenderSystem;

public class RenderLayerEvent extends EventContext {
	private final ClientWorld world;
	public final net.minecraft.client.render.RenderLayer type;
	public final MatrixStack stack;
	public final Matrix4f viewProjection;
	public final BufferBuilderStorage buffers;
	public final double camX;
	public final double camY;
	public final double camZ;
	public final RenderLayer layer;

	public RenderLayerEvent(ClientWorld world, net.minecraft.client.render.RenderLayer type, MatrixStack stack, BufferBuilderStorage buffers, double camX, double camY, double camZ) {
		this.world = world;
		this.type = type;
		this.stack = stack;

		viewProjection = new Matrix4f(stack.peek()
				.getPositionMatrix());
        viewProjection.mulLocal(RenderSystem.getProjectionMatrix());

		this.buffers = buffers;
		this.camX = camX;
		this.camY = camY;
		this.camZ = camZ;

		this.layer = RenderLayer.getPrimaryLayer(type);
	}

	@Nullable
	public RenderLayer getLayer() {
		return layer;
	}

	public ClientWorld getWorld() {
		return world;
	}

	public net.minecraft.client.render.RenderLayer getType() {
		return type;
	}

	public Matrix4f getViewProjection() {
		return viewProjection;
	}

	public double getCamX() {
		return camX;
	}

	public double getCamY() {
		return camY;
	}

	public double getCamZ() {
		return camZ;
	}

	@Override
	public String toString() {
		return "RenderLayerEvent[" + layer + "][" + "world=" + world + ", type=" + type + ", stack=" + stack + ", viewProjection=" + viewProjection + ", buffers=" + buffers + ", camX=" + camX + ", camY=" + camY + ", camZ=" + camZ + ']';
	}
}

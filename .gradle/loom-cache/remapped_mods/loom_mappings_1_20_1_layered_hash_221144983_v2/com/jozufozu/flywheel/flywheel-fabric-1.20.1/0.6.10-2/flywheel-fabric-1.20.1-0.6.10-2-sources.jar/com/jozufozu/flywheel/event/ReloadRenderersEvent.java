package com.jozufozu.flywheel.event;

import javax.annotation.Nullable;
import net.minecraft.client.world.ClientWorld;
import com.jozufozu.flywheel.fabric.event.EventContext;

public class ReloadRenderersEvent extends EventContext {
	private final ClientWorld world;

	public ReloadRenderersEvent(ClientWorld world) {
		this.world = world;
	}

	@Nullable
	public ClientWorld getWorld() {
		return world;
	}
}

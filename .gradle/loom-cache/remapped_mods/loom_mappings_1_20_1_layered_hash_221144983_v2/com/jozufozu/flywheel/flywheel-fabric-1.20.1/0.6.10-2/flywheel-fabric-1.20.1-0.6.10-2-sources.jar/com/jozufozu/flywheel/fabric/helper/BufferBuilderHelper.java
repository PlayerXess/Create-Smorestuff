package com.jozufozu.flywheel.fabric.helper;

import java.nio.ByteBuffer;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.VertexFormat;
import com.jozufozu.flywheel.fabric.mixin.BufferBuilderAccessor;

public final class BufferBuilderHelper {
	public static void fixByteOrder(BufferBuilder self, ByteBuffer buffer) {
		buffer.order(((BufferBuilderAccessor) self).getBuffer().order());
	}

	public static VertexFormat getVertexFormat(BufferBuilder self) {
		return ((BufferBuilderAccessor) self).getFormat();
	}
}

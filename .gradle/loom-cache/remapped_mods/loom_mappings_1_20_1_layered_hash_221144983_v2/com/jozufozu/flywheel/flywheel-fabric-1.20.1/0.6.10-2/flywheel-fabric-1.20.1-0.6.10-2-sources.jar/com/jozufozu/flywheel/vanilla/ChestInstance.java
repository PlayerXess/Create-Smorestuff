package com.jozufozu.flywheel.vanilla;

import java.util.Calendar;

import javax.annotation.Nonnull;
import net.minecraft.block.AbstractChestBlock;
import net.minecraft.block.Block;
import net.minecraft.block.ChestBlock;
import net.minecraft.block.DoubleBlockProperties;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.block.entity.ChestBlockEntity;
import net.minecraft.block.entity.LidOpenable;
import net.minecraft.block.enums.ChestType;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.TexturedRenderLayers;
import net.minecraft.client.util.SpriteIdentifier;
import net.minecraft.util.math.RotationAxis;
import org.joml.Quaternionf;

import com.jozufozu.flywheel.api.MaterialManager;
import com.jozufozu.flywheel.api.instance.DynamicInstance;
import com.jozufozu.flywheel.backend.instancing.blockentity.BlockEntityInstance;
import com.jozufozu.flywheel.core.Materials;
import com.jozufozu.flywheel.core.hardcoded.ModelPart;
import com.jozufozu.flywheel.core.materials.model.ModelData;
import com.jozufozu.flywheel.core.materials.oriented.OrientedData;
import com.jozufozu.flywheel.util.AnimationTickHolder;
import it.unimi.dsi.fastutil.floats.Float2FloatFunction;

public class ChestInstance<T extends BlockEntity & LidOpenable> extends BlockEntityInstance<T> implements DynamicInstance {

	private final OrientedData body;
	private final ModelData lid;

	private final Float2FloatFunction lidProgress;
	private final SpriteIdentifier renderMaterial;
	@Nonnull
	private final ChestType chestType;
	private final Quaternionf baseRotation;

	private float lastProgress = Float.NaN;

	public ChestInstance(MaterialManager materialManager, T blockEntity) {
		super(materialManager, blockEntity);

		Block block = blockState.getBlock();

		chestType = blockState.contains(ChestBlock.CHEST_TYPE) ? blockState.get(ChestBlock.CHEST_TYPE) : ChestType.field_12569;
		renderMaterial = TexturedRenderLayers.getChestTextureId(blockEntity, chestType, isChristmas());

		body = baseInstance()
				.setPosition(getInstancePosition());
		lid = lidInstance();

		if (block instanceof AbstractChestBlock<?> chestBlock) {

			float horizontalAngle = blockState.get(ChestBlock.FACING).asRotation();

			baseRotation = RotationAxis.POSITIVE_Y.rotationDegrees(-horizontalAngle);

			body.setRotation(baseRotation);

			DoubleBlockProperties.PropertySource<? extends ChestBlockEntity> wrapper = chestBlock.getBlockEntitySource(blockState, world, getWorldPosition(), true);

			this.lidProgress = wrapper.apply(ChestBlock.getAnimationProgressRetriever(blockEntity));


		} else {
			baseRotation = new Quaternionf();
			lidProgress = $ -> 0f;
		}
	}

	@Override
	public void beginFrame() {
		float progress = lidProgress.get(AnimationTickHolder.getPartialTicks());

		if (lastProgress == progress) return;

		lastProgress = progress;

		progress = 1.0F - progress;
		progress = 1.0F - progress * progress * progress;

		float angleX = -(progress * ((float) Math.PI / 2F));

		lid.loadIdentity()
				.translate(getInstancePosition())
				.translate(0, 9f/16f, 0)
				.centre()
				.multiply(baseRotation)
				.unCentre()
				.translate(0, 0, 1f / 16f)
				.multiply(RotationAxis.POSITIVE_X.rotation(angleX))
				.translate(0, 0, -1f / 16f);
	}

	@Override
	public void updateLight() {
		relight(getWorldPosition(), body, lid);
	}

	@Override
	public void remove() {
		body.delete();
		lid.delete();
	}

	private OrientedData baseInstance() {

		return materialManager.solid(RenderLayer.getEntitySolid(renderMaterial.getAtlasId()))
                .material(Materials.ORIENTED)
				.model("base_" + renderMaterial.getTextureId(), this::getBaseModel)
				.createInstance();
	}

	private ModelData lidInstance() {

		return materialManager.solid(RenderLayer.getEntitySolid(renderMaterial.getAtlasId()))
                .material(Materials.TRANSFORMED)
				.model("lid_" + renderMaterial.getTextureId(), this::getLidModel)
				.createInstance();
	}

	private ModelPart getBaseModel() {

		return switch (chestType) {
			case field_12574 -> ModelPart.builder("chest_base_left", 64, 64)
					.sprite(renderMaterial.getSprite())
					.cuboid()
					.textureOffset(0, 19)
					.start(0, 0, 1)
					.size(15, 10, 14)
					.endCuboid()
					.build();
			case field_12571 -> ModelPart.builder("chest_base_right", 64, 64)
					.sprite(renderMaterial.getSprite())
					.cuboid()
					.textureOffset(0, 19)
					.start(1, 0, 1)
					.size(15, 10, 14)
					.endCuboid()
					.build();
			default -> ModelPart.builder("chest_base", 64, 64)
					.sprite(renderMaterial.getSprite())
					.cuboid()
					.textureOffset(0, 19)
					.start(1, 0, 1)
					.end(15, 10, 15)
					.endCuboid()
					.build();
		};

	}

	private ModelPart getLidModel() {

		return switch (chestType) {
			case field_12574 -> ModelPart.builder("chest_lid_left", 64, 64)
					.sprite(renderMaterial.getSprite())
					.cuboid()
					.textureOffset(0, 0)
					.start(0, 0, 1)
					.size(15, 5, 14)
					.endCuboid()
					.cuboid()
					.start(0, -2, 15)
					.size(1, 4, 1)
					.endCuboid()
					.build();
			case field_12571 -> ModelPart.builder("chest_lid_right", 64, 64)
					.sprite(renderMaterial.getSprite())
					.cuboid()
					.textureOffset(0, 0)
					.start(1, 0, 1)
					.size(15, 5, 14)
					.endCuboid()
					.cuboid()
					.start(15, -2, 15)
					.size(1, 4, 1)
					.endCuboid()
					.build();
			default -> ModelPart.builder("chest_lid", 64, 64)
					.sprite(renderMaterial.getSprite())
					.cuboid()
					.textureOffset(0, 0)
					.start(1, 0, 1)
					.size(14, 5, 14)
					.endCuboid()
					.cuboid()
					.start(7, -2, 15)
					.size(2, 4, 1)
					.endCuboid()
					.build();
		};

	}

	public static boolean isChristmas() {
		Calendar calendar = Calendar.getInstance();
		return calendar.get(Calendar.MONTH) + 1 == 12 && calendar.get(Calendar.DATE) >= 24 && calendar.get(Calendar.DATE) <= 26;
	}
}

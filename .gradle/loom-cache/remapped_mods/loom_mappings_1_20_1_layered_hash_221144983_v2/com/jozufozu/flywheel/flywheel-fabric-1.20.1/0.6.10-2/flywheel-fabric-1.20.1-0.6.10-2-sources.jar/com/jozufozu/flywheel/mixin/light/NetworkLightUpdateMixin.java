package com.jozufozu.flywheel.mixin.light;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import com.jozufozu.flywheel.backend.RenderWork;
import com.jozufozu.flywheel.light.LightUpdater;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.network.packet.s2c.play.ChunkDataS2CPacket;
import net.minecraft.network.packet.s2c.play.LightUpdateS2CPacket;

@Mixin(ClientPlayNetworkHandler.class)
public class NetworkLightUpdateMixin {
	@Shadow
	private ClientWorld level;

	@Inject(method = "handleLevelChunkWithLight(Lnet/minecraft/network/protocol/game/ClientboundLevelChunkWithLightPacket;)V", at = @At("TAIL"))
	private void flywheel$onLevelChunkWithLight(ChunkDataS2CPacket packet, CallbackInfo ci) {
		RenderWork.enqueue(() -> {
			ClientWorld level = this.level;

			if (level == null) return;

			int chunkX = packet.getX();
			int chunkZ = packet.getZ();

			LightUpdater.get(level)
					.onLightPacket(chunkX, chunkZ);
		});
	}

	@Inject(method = "handleLightUpdatePacket(Lnet/minecraft/network/protocol/game/ClientboundLightUpdatePacket;)V", at = @At("TAIL"))
	private void flywheel$onLightUpdatePacket(LightUpdateS2CPacket packet, CallbackInfo ci) {
		RenderWork.enqueue(() -> {
			ClientWorld level = this.level;

			if (level == null) return;

			int chunkX = packet.getChunkX();
			int chunkZ = packet.getChunkZ();

			LightUpdater.get(level)
					.onLightPacket(chunkX, chunkZ);
		});
	}
}

@ParametersAreNonnullByDefault @MethodsReturnNonnullByDefault
package com.jozufozu.flywheel.backend.struct;

import javax.annotation.ParametersAreNonnullByDefault;

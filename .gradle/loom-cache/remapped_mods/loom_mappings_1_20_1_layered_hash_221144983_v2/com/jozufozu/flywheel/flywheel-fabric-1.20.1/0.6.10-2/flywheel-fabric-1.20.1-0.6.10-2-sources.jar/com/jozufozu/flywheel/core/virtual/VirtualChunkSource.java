package com.jozufozu.flywheel.core.virtual;

import java.util.function.BooleanSupplier;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.world.World;
import net.minecraft.world.chunk.Chunk;
import net.minecraft.world.chunk.ChunkManager;
import net.minecraft.world.chunk.ChunkStatus;
import net.minecraft.world.chunk.WorldChunk;
import net.minecraft.world.chunk.light.LightingProvider;
import org.jetbrains.annotations.Nullable;

import it.unimi.dsi.fastutil.longs.Long2ObjectMap;
import it.unimi.dsi.fastutil.longs.Long2ObjectOpenHashMap;

public class VirtualChunkSource extends ChunkManager {
	private final VirtualRenderWorld world;
	private final Long2ObjectMap<VirtualChunk> chunks = new Long2ObjectOpenHashMap<>();

	public VirtualChunkSource(VirtualRenderWorld world) {
		this.world = world;
	}

	@Override
	public World getWorld() {
		return world;
	}

	public Chunk getChunk(int x, int z) {
		long pos = ChunkPos.toLong(x, z);
		return chunks.computeIfAbsent(pos, $ -> new VirtualChunk(world, x, z));
	}

	@Override
	@Nullable
	public WorldChunk getWorldChunk(int x, int z, boolean load) {
		return null;
	}

	@Override
	@Nullable
	public Chunk getChunk(int x, int z, ChunkStatus status, boolean load) {
		return getChunk(x, z);
	}

	@Override
	public void tick(BooleanSupplier hasTimeLeft, boolean tickChunks) {
	}

	@Override
	public String getDebugString() {
		return "VirtualChunkSource";
	}

	@Override
	public int getLoadedChunkCount() {
		return 0;
	}

	@Override
	public LightingProvider getLightingProvider() {
		return world.getLightingProvider();
	}
}

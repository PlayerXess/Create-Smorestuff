package com.jozufozu.flywheel.core.model;

import java.util.function.Supplier;
import net.fabricmc.fabric.api.renderer.v1.model.ForwardingBakedModel;
import net.fabricmc.fabric.api.renderer.v1.render.RenderContext;
import net.fabricmc.fabric.api.renderer.v1.render.RenderContext.QuadTransform;
import net.minecraft.block.BlockState;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.model.BakedModel;
import net.minecraft.client.render.model.BakedQuad;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.random.Random;
import net.minecraft.world.BlockRenderView;

public class ShadeSeparatingVertexConsumer implements VertexConsumer {
	private final ShadeSeparatingBakedModel modelWrapper = new ShadeSeparatingBakedModel();
	protected VertexConsumer shadedConsumer;
	protected VertexConsumer unshadedConsumer;
	protected VertexConsumer activeConsumer;

	public void prepare(VertexConsumer shadedConsumer, VertexConsumer unshadedConsumer) {
		this.shadedConsumer = shadedConsumer;
		this.unshadedConsumer = unshadedConsumer;
	}

	public void clear() {
		shadedConsumer = null;
		unshadedConsumer = null;
		activeConsumer = null;
	}

	public BakedModel wrapModel(BakedModel model) {
		modelWrapper.setWrapped(model);
		return modelWrapper;
	}

	protected void setActiveConsumer(boolean shaded) {
		activeConsumer = shaded ? shadedConsumer : unshadedConsumer;
	}

	@Override
	public void quad(MatrixStack.Entry poseEntry, BakedQuad quad, float[] colorMuls, float red, float green, float blue, int[] combinedLights, int combinedOverlay, boolean mulColor) {
		if (quad.hasShade()) {
			shadedConsumer.quad(poseEntry, quad, colorMuls, red, green, blue, combinedLights, combinedOverlay, mulColor);
		} else {
			unshadedConsumer.quad(poseEntry, quad, colorMuls, red, green, blue, combinedLights, combinedOverlay, mulColor);
		}
	}

	@Override
	public VertexConsumer vertex(double x, double y, double z) {
		activeConsumer.vertex(x, y, z);
		return this;
	}

	@Override
	public VertexConsumer color(int red, int green, int blue, int alpha) {
		activeConsumer.color(red, green, blue, alpha);
		return this;
	}

	@Override
	public VertexConsumer texture(float u, float v) {
		activeConsumer.texture(u, v);
		return this;
	}

	@Override
	public VertexConsumer overlay(int u, int v) {
		activeConsumer.overlay(u, v);
		return this;
	}

	@Override
	public VertexConsumer light(int u, int v) {
		activeConsumer.light(u, v);
		return this;
	}

	@Override
	public VertexConsumer normal(float x, float y, float z) {
		activeConsumer.normal(x, y, z);
		return this;
	}

	@Override
	public void next() {
		activeConsumer.next();
	}

	@Override
	public void fixedColor(int red, int green, int blue, int alpha) {
		activeConsumer.fixedColor(red, green, blue, alpha);
	}

	@Override
	public void unfixColor() {
		activeConsumer.unfixColor();
	}

	private class ShadeSeparatingBakedModel extends ForwardingBakedModel {
		private final QuadTransform quadTransform = quad -> {
			boolean shade = !quad.material().disableDiffuse();
			ShadeSeparatingVertexConsumer.this.setActiveConsumer(shade);
			return true;
		};

		private void setWrapped(BakedModel model) {
			wrapped = model;
		}

		@Override
		public void emitBlockQuads(BlockRenderView blockView, BlockState state, BlockPos pos, Supplier<Random> randomSupplier, RenderContext context) {
			context.pushTransform(quadTransform);
			super.emitBlockQuads(blockView, state, pos, randomSupplier, context);
			context.popTransform();
		}
	}
}

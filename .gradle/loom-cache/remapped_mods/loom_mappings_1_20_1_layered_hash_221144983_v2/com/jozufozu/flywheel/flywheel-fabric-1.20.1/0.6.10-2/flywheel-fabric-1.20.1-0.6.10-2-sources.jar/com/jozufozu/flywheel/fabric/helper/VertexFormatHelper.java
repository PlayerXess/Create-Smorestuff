package com.jozufozu.flywheel.fabric.helper;

import com.jozufozu.flywheel.fabric.mixin.VertexFormatAccessor;
import net.minecraft.client.render.VertexFormat;

public final class VertexFormatHelper {
	public static int getOffset(VertexFormat self, int index) {
		return ((VertexFormatAccessor) self).getOffsets().getInt(index);
	}
}

package com.jozufozu.flywheel.fabric.model;

import java.util.function.Supplier;

import net.fabricmc.fabric.api.renderer.v1.model.ForwardingBakedModel;
import net.fabricmc.fabric.api.renderer.v1.render.RenderContext;
import net.minecraft.block.BlockState;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.RenderLayers;
import net.minecraft.client.render.model.BakedModel;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.random.Random;
import net.minecraft.world.BlockRenderView;

public class LayerFilteringBakedModel extends ForwardingBakedModel {
	private static final ThreadLocal<LayerFilteringBakedModel> THREAD_LOCAL = ThreadLocal.withInitial(LayerFilteringBakedModel::new);

	protected RenderLayer targetLayer;

	public static BakedModel wrap(BakedModel model, RenderLayer layer) {
		LayerFilteringBakedModel wrapper = THREAD_LOCAL.get();
		wrapper.wrapped = model;
		wrapper.targetLayer = layer;
		return wrapper;
	}

	protected LayerFilteringBakedModel() {
	}

	@Override
	public boolean isVanillaAdapter() {
		return false;
	}

	@Override
	public void emitBlockQuads(BlockRenderView blockView, BlockState state, BlockPos pos, Supplier<Random> randomSupplier, RenderContext context) {
		RenderLayer defaultLayer = RenderLayers.getBlockLayer(state);
		if (super.isVanillaAdapter()) {
			if (defaultLayer == targetLayer) {
				super.emitBlockQuads(blockView, state, pos, randomSupplier, context);
			}
		} else {
			context.pushTransform(quad -> {
				RenderLayer quadLayer = quad.material().blendMode().blockRenderLayer;
				if (quadLayer == null) {
					quadLayer = defaultLayer;
				}
				return quadLayer == targetLayer;
			});
			super.emitBlockQuads(blockView, state, pos, randomSupplier, context);
			context.popTransform();
		}
	}
}

package com.jozufozu.flywheel.fabric.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;
import it.unimi.dsi.fastutil.ints.IntList;
import net.minecraft.client.render.VertexFormat;

@Mixin(VertexFormat.class)
public interface VertexFormatAccessor {
	@Accessor("offsets")
	IntList getOffsets();
}

package com.jozufozu.flywheel.mixin;

import java.util.SortedSet;
import net.minecraft.client.render.BlockBreakingInfo;
import net.minecraft.client.render.WorldRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

import it.unimi.dsi.fastutil.longs.Long2ObjectMap;

@Mixin(WorldRenderer.class)
public interface LevelRendererAccessor {
	@Accessor("destructionProgress")
	Long2ObjectMap<SortedSet<BlockBreakingInfo>> flywheel$getDestructionProgress();
}

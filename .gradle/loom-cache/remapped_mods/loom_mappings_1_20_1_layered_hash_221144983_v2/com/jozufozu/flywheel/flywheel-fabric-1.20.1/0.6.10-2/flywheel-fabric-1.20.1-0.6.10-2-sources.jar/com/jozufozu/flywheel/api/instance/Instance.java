package com.jozufozu.flywheel.api.instance;

import net.minecraft.util.math.BlockPos;

public interface Instance {
    BlockPos getWorldPosition();
}

package com.jozufozu.flywheel.mixin.matrix;

import org.joml.Quaternionf;
import org.spongepowered.asm.mixin.Mixin;

import com.jozufozu.flywheel.util.transform.TransformStack;
import net.minecraft.client.util.math.MatrixStack;

@Mixin(MatrixStack.class)
public abstract class PoseStackMixin implements TransformStack {

	@Override
	public TransformStack multiply(Quaternionf quaternion) {
		((MatrixStack)(Object) this).multiply(quaternion);
		return this;
	}

	@Override
	public TransformStack scale(float factorX, float factorY, float factorZ) {
		((MatrixStack)(Object) this).scale(factorX, factorY, factorZ);
		return this;
	}

	@Override
	public TransformStack pushPose() {
		((MatrixStack)(Object) this).push();
		return this;
	}

	@Override
	public TransformStack popPose() {
		((MatrixStack)(Object) this).pop();
		return this;
	}

	@Override
	public TransformStack translate(double x, double y, double z) {
		((MatrixStack)(Object) this).translate(x, y, z);
		return this;
	}
}

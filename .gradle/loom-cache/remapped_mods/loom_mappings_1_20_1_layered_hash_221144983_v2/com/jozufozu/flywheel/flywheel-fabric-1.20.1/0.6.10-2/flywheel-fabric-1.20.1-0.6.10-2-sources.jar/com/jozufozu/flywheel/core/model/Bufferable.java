
package com.jozufozu.flywheel.core.model;

import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.block.BlockModelRenderer;
import net.minecraft.util.math.random.Random;

/**
 * An interface for objects that can buffered into a VertexConsumer.
 */
public interface Bufferable {
	void bufferInto(VertexConsumer consumer, BlockModelRenderer renderer, Random random);

	default ShadeSeparatedBufferedData build() {
		return ModelUtil.getBufferedData(this);
	}
}

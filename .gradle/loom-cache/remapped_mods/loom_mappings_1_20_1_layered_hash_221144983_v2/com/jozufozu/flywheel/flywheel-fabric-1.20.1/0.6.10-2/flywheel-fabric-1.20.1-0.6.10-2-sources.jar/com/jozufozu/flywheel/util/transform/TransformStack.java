package com.jozufozu.flywheel.util.transform;

import net.minecraft.client.util.math.MatrixStack;

public interface TransformStack extends Transform<TransformStack>, TStack<TransformStack> {
	static TransformStack cast(MatrixStack stack) {
		return (TransformStack) stack;
	}
}

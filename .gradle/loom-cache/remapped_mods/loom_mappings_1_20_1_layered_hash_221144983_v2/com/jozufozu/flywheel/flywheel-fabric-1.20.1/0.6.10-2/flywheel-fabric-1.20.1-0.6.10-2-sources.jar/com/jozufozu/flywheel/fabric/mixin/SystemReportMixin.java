package com.jozufozu.flywheel.fabric.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import com.jozufozu.flywheel.backend.Backend;
import net.minecraft.util.SystemDetails;

@Mixin(value = SystemDetails.class, priority = 1100)
public class SystemReportMixin {
	@Inject(method = "<init>()V", at = @At("TAIL"))
	private void onTailInit(CallbackInfo ci) {
		SystemDetails self = (SystemDetails) (Object) this;
		self.addSection("Flywheel Backend", Backend::getBackendDescriptor);
	}
}

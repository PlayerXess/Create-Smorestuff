package com.jozufozu.flywheel.event;

import java.util.List;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.world.ClientWorld;
import com.jozufozu.flywheel.backend.Backend;
import com.jozufozu.flywheel.backend.instancing.InstancedRenderDispatcher;
import com.jozufozu.flywheel.light.LightUpdater;
import com.jozufozu.flywheel.util.WorldAttached;

public class ForgeEvents {

	public static void addToDebugScreen(List<String> right) {
		InstancedRenderDispatcher.getDebugString(right);
	}

	public static void unloadWorld(ClientWorld world) {
		WorldAttached.invalidateWorld(world);
	}

	public static void tickLight(MinecraftClient mc) {
		if (Backend.isGameActive())
			LightUpdater.get(mc.world).tick();
	}

}

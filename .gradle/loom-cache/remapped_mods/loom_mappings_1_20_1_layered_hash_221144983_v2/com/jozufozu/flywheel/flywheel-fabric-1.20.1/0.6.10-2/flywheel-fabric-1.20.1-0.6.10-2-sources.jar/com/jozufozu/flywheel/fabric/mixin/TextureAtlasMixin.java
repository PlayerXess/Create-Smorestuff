package com.jozufozu.flywheel.fabric.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import com.jozufozu.flywheel.core.StitchedSprite;
import net.minecraft.client.texture.SpriteAtlasTexture;
import net.minecraft.client.texture.SpriteLoader;

@Mixin(SpriteAtlasTexture.class)
public class TextureAtlasMixin {
	@Inject(method = "upload(Lnet/minecraft/client/renderer/texture/SpriteLoader$Preparations;)V", at = @At("TAIL"))
	private void onTailReload(SpriteLoader.StitchResult preparations, CallbackInfo ci) {
		StitchedSprite.onTextureStitchPost((SpriteAtlasTexture) (Object) this);
	}
}

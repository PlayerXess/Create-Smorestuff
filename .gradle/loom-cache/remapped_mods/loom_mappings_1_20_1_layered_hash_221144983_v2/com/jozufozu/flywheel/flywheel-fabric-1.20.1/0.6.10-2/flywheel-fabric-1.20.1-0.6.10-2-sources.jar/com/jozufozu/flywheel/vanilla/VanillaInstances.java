package com.jozufozu.flywheel.vanilla;

import static com.jozufozu.flywheel.backend.instancing.InstancedRenderRegistry.configure;

import net.minecraft.block.entity.BlockEntityType;
import net.minecraft.entity.EntityType;

/**
 * TODO:
 * <table>
 * 		<tr><td>{@link BlockEntityType#field_11911}</td><td> {@link net.minecraft.client.render.block.entity.SignBlockEntityRenderer SignRenderer}</td></tr>
 * 		<tr><td>{@link BlockEntityType#field_11897}</td><td> {@link net.minecraft.client.render.block.entity.PistonBlockEntityRenderer PistonHeadRenderer}</td></tr>
 * 		<tr><td>{@link BlockEntityType#field_11902}</td><td> {@link net.minecraft.client.render.block.entity.ConduitBlockEntityRenderer ConduitRenderer}</td></tr>
 * 		<tr><td>{@link BlockEntityType#field_11912}</td><td> {@link net.minecraft.client.render.block.entity.EnchantingTableBlockEntityRenderer EnchantTableRenderer}</td></tr>
 * 		<tr><td>{@link BlockEntityType#field_16412}</td><td> {@link net.minecraft.client.render.block.entity.LecternBlockEntityRenderer LecternRenderer}</td></tr>
 * 		<tr><td>{@link BlockEntityType#field_11889}</td><td> {@link net.minecraft.client.render.block.entity.MobSpawnerBlockEntityRenderer SpawnerRenderer}</td></tr>
 * 		<tr><td>{@link BlockEntityType#field_11910}</td><td> {@link net.minecraft.client.render.block.entity.BedBlockEntityRenderer BedRenderer}</td></tr>
 * 		<tr><td>^^ Interesting - Major vv</td></tr>
 * 		<tr><td>{@link BlockEntityType#field_11898}</td><td> {@link net.minecraft.client.render.block.entity.EndPortalBlockEntityRenderer TheEndPortalRenderer}</td></tr>
 * 		<tr><td>{@link BlockEntityType#field_11906}</td><td> {@link net.minecraft.client.render.block.entity.EndGatewayBlockEntityRenderer TheEndGatewayRenderer}</td></tr>
 * 		<tr><td>{@link BlockEntityType#field_11890}</td><td> {@link net.minecraft.client.render.block.entity.BeaconBlockEntityRenderer BeaconRenderer}</td></tr>
 * 		<tr><td>{@link BlockEntityType#field_11913}</td><td> {@link net.minecraft.client.render.block.entity.SkullBlockEntityRenderer SkullBlockRenderer}</td></tr>
 * 		<tr><td>{@link BlockEntityType#field_11905}</td><td> {@link net.minecraft.client.render.block.entity.BannerBlockEntityRenderer BannerRenderer}</td></tr>
 * 		<tr><td>{@link BlockEntityType#field_11895}</td><td> {@link net.minecraft.client.render.debug.StructureDebugRenderer StructureRenderer}</td></tr>
 * 		<tr><td>{@link BlockEntityType#field_17380}</td><td> {@link net.minecraft.client.render.block.entity.CampfireBlockEntityRenderer CampfireRenderer}</td></tr>
 * </table>
 */
public class VanillaInstances {

	public static void init() {
		configure(BlockEntityType.field_11914)
				.alwaysSkipRender()
				.factory(ChestInstance::new)
				.apply();
		configure(BlockEntityType.field_11901)
				.alwaysSkipRender()
				.factory(ChestInstance::new)
				.apply();
		configure(BlockEntityType.field_11891)
				.alwaysSkipRender()
				.factory(ChestInstance::new)
				.apply();

		configure(BlockEntityType.field_16413)
				.alwaysSkipRender()
				.factory(BellInstance::new)
				.apply();

		configure(BlockEntityType.field_11896)
				.alwaysSkipRender()
				.factory(ShulkerBoxInstance::new)
				.apply();

		configure(EntityType.field_6096)
				.alwaysSkipRender()
				.factory(MinecartInstance::new)
				.apply();
		configure(EntityType.field_6058)
				.alwaysSkipRender()
				.factory(MinecartInstance::new)
				.apply();
		configure(EntityType.field_6080)
				.alwaysSkipRender()
				.factory(MinecartInstance::new)
				.apply();
	}
}

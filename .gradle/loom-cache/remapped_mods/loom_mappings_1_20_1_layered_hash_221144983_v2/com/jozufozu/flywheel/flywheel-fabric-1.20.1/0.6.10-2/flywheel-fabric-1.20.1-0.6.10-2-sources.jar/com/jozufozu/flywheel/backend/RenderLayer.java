package com.jozufozu.flywheel.backend;

import javax.annotation.Nullable;

/**
 * The 3 discrete stages the world is rendered in.
 */
public enum RenderLayer {
	/**
	 * Solid layer:<br>
	 *
	 * All polygons will entirely occlude everything behind them.
	 *
	 * <br><br>
	 * e.g. stone, dirt, solid blocks
	 */
	SOLID,
	/**
	 * Cutout layer:<br>
	 *
	 * <em>Fragments</em> will either occlude or not occlude depending on the texture/material.
	 *
	 * <br><br>
	 * e.g. leaves, cobwebs, tall grass, saplings, glass
	 */
	CUTOUT,
	/**
	 * Transparent layer:<br>
	 *
	 * Nothing is guaranteed to occlude and fragments blend their color with what's behind them.
	 *
	 * <br><br>
	 * e.g. stained glass, water
	 */
	TRANSPARENT,
	;

	@Nullable
	public static RenderLayer getPrimaryLayer(net.minecraft.client.render.RenderLayer type) {
		if (type == net.minecraft.client.render.RenderLayer.getSolid()) {
			return SOLID;
		} else if (type == net.minecraft.client.render.RenderLayer.getCutoutMipped()) {
			return CUTOUT;
		} else if (type == net.minecraft.client.render.RenderLayer.getTranslucent()) {
			return TRANSPARENT;
		}

		return null;
	}

	@Nullable
	public static RenderLayer getLayer(net.minecraft.client.render.RenderLayer type) {
		if (type == net.minecraft.client.render.RenderLayer.getSolid()) {
			return SOLID;
		} else if (type == net.minecraft.client.render.RenderLayer.getCutoutMipped() || type == net.minecraft.client.render.RenderLayer.getCutout()) {
			return CUTOUT;
		} else if (type == net.minecraft.client.render.RenderLayer.getTranslucent()) {
			return TRANSPARENT;
		}

		return null;
	}
}

package com.jozufozu.flywheel.util.transform;

import net.minecraft.util.math.Direction;
import net.minecraft.util.math.RotationAxis;
import org.joml.AxisAngle4f;
import org.joml.Quaternionf;
import org.joml.Vector3f;

public interface Rotate<Self> {

	Self multiply(Quaternionf quaternion);

	default Self rotate(Direction axis, float radians) {
		if (radians == 0)
			return (Self) this;
		return multiply(new Quaternionf().rotationAxis(radians, axis.getUnitVector()));
	}

	default Self rotate(double angle, Direction.Axis axis) {
		RotationAxis vec =
				axis == Direction.Axis.field_11048 ? RotationAxis.POSITIVE_X : axis == Direction.Axis.field_11052 ? RotationAxis.POSITIVE_Y : RotationAxis.POSITIVE_Z;
		return multiply(vec, angle);
	}

	default Self rotateX(double angle) {
		return multiply(RotationAxis.POSITIVE_X, angle);
	}

	default Self rotateY(double angle) {
		return multiply(RotationAxis.POSITIVE_Y, angle);
	}

	default Self rotateZ(double angle) {
		return multiply(RotationAxis.POSITIVE_Z, angle);
	}

	default Self rotateXRadians(double angle) {
		return multiplyRadians(RotationAxis.POSITIVE_X, angle);
	}

	default Self rotateYRadians(double angle) {
		return multiplyRadians(RotationAxis.POSITIVE_Y, angle);
	}

	default Self rotateZRadians(double angle) {
		return multiplyRadians(RotationAxis.POSITIVE_Z, angle);
	}

	default Self multiply(RotationAxis axis, double angle) {
		if (angle == 0)
			return (Self) this;
		return multiply(axis.rotationDegrees((float) angle));
	}

	default Self multiplyRadians(RotationAxis axis, double angle) {
		if (angle == 0)
			return (Self) this;
		return multiply(axis.rotation((float) angle));
	}

	default Self multiply(Vector3f axis, double angle) {
		if (angle == 0)
			return (Self) this;
		return multiply(new Quaternionf(new AxisAngle4f((float) Math.toRadians(angle), axis)));
	}

	default Self multiplyRadians(Vector3f axis, double angle) {
		if (angle == 0)
			return (Self) this;
		return multiply(new Quaternionf(new AxisAngle4f((float) angle, axis)));
	}

	default Self rotateToFace(Direction facing) {
		switch (facing) {
		case field_11035 -> multiply(RotationAxis.POSITIVE_Y.rotationDegrees(180));
		case field_11039 -> multiply(RotationAxis.POSITIVE_Y.rotationDegrees(90));
		case field_11043 -> multiply(RotationAxis.POSITIVE_Y.rotationDegrees(0));
		case field_11034 -> multiply(RotationAxis.POSITIVE_Y.rotationDegrees(270));
		case field_11036 -> multiply(RotationAxis.POSITIVE_X.rotationDegrees(90));
		case field_11033 -> multiply(RotationAxis.NEGATIVE_X.rotationDegrees(90));
		}
		return (Self) this;
	}
}

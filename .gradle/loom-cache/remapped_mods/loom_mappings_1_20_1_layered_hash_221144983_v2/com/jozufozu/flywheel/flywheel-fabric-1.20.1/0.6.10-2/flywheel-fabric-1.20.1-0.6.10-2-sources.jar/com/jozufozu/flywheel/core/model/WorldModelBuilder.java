package com.jozufozu.flywheel.core.model;

import java.util.Collection;
import java.util.Collections;
import net.minecraft.block.BlockRenderType;
import net.minecraft.block.BlockState;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.OverlayTexture;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.RenderLayers;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.block.BlockModelRenderer;
import net.minecraft.client.render.block.BlockRenderManager;
import net.minecraft.client.render.model.BakedModel;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.structure.StructureTemplate;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.random.Random;
import net.minecraft.world.BlockRenderView;
import com.jozufozu.flywheel.core.virtual.VirtualEmptyBlockGetter;
import com.jozufozu.flywheel.fabric.model.LayerFilteringBakedModel;

public final class WorldModelBuilder implements Bufferable {
	private final RenderLayer layer;

	private MatrixStack poseStack = new MatrixStack();
	private BlockRenderView renderWorld = VirtualEmptyBlockGetter.INSTANCE;
	private Collection<StructureTemplate.StructureBlockInfo> blocks = Collections.emptyList();

	public WorldModelBuilder(RenderLayer layer) {
		this.layer = layer;
	}

	@Override
	public void bufferInto(VertexConsumer consumer, BlockModelRenderer modelRenderer, Random random) {
		BlockRenderManager dispatcher = MinecraftClient.getInstance().getBlockRenderManager();

		BlockModelRenderer.enableBrightnessCache();
		for (StructureTemplate.StructureBlockInfo info : this.blocks) {
			BlockState state = info.comp_1342();
			if (state.getRenderType() != BlockRenderType.field_11458) continue;

			BakedModel model = dispatcher.getModel(state);
			if (model.isVanillaAdapter()) {
				if (RenderLayers.getBlockLayer(state) != layer) {
					continue;
				}
			} else {
				model = LayerFilteringBakedModel.wrap(model, layer);
			}
			if (consumer instanceof ShadeSeparatingVertexConsumer shadeSeparatingWrapper) {
				model = shadeSeparatingWrapper.wrapModel(model);
			}

			BlockPos pos = info.comp_1341();

			poseStack.push();
			poseStack.translate(pos.getX(), pos.getY(), pos.getZ());
			modelRenderer.render(this.renderWorld, model, state, pos, poseStack, consumer, true, random, 42, OverlayTexture.DEFAULT_UV);
			poseStack.pop();
		}
		BlockModelRenderer.disableBrightnessCache();
	}

	/**
	 * It is expected that {@code renderWorld.getShade(...)} returns a constant.
	 */
	public WorldModelBuilder withRenderWorld(BlockRenderView renderWorld) {
		this.renderWorld = renderWorld;
		return this;
	}

	public WorldModelBuilder withBlocks(Collection<StructureTemplate.StructureBlockInfo> blocks) {
		this.blocks = blocks;
		return this;
	}

	public WorldModelBuilder withPoseStack(MatrixStack poseStack) {
		this.poseStack = poseStack;
		return this;
	}

	public BlockModel toModel(String name) {
		return BlockModel.of(this, name);
	}
}

@ParametersAreNonnullByDefault @MethodsReturnNonnullByDefault
package com.jozufozu.flywheel.api;

import javax.annotation.ParametersAreNonnullByDefault;

package com.jozufozu.flywheel.util;

import net.minecraft.util.Identifier;

public class ResourceUtil {

	public static Identifier subPath(Identifier root, String subPath) {
		return new Identifier(root.getNamespace(), root.getPath() + subPath);
	}

	public static Identifier removePrefixUnchecked(Identifier full, String root) {
		return new Identifier(full.getNamespace(), full.getPath()
				.substring(root.length()));
	}

	public static Identifier trim(Identifier loc, String prefix, String suffix) {
		String path = loc.getPath();
		return new Identifier(loc.getNamespace(), path.substring(prefix.length(), path.length() - suffix.length()));
	}
}

package com.jozufozu.flywheel.mixin;

import javax.annotation.Nonnull;
import net.minecraft.client.render.RenderLayer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;

import com.jozufozu.flywheel.backend.instancing.DrawBuffer;
import com.jozufozu.flywheel.backend.instancing.RenderTypeExtension;

@Mixin(RenderLayer.class)
public class RenderTypeMixin implements RenderTypeExtension {

	@Unique
	private DrawBuffer flywheel$drawBuffer;

	@Override
	@Nonnull
	public DrawBuffer flywheel$getDrawBuffer() {
		if (flywheel$drawBuffer == null) {
			flywheel$drawBuffer = new DrawBuffer((RenderLayer) (Object) this);
		}
		return flywheel$drawBuffer;
	}
}

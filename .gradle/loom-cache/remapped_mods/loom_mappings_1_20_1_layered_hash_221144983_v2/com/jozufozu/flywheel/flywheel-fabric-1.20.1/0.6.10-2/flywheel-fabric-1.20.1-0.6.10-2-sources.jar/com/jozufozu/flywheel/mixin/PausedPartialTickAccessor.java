package com.jozufozu.flywheel.mixin;

import net.minecraft.client.MinecraftClient;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(MinecraftClient.class)
public interface PausedPartialTickAccessor {
	@Accessor("pausePartialTick")
	float flywheel$getPausePartialTick();
}

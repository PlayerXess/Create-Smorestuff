package com.jozufozu.flywheel.backend.instancing;

import java.util.HashSet;
import java.util.Set;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.RenderLayer;
import com.jozufozu.flywheel.backend.model.BufferBuilderExtension;
import com.jozufozu.flywheel.backend.model.DirectVertexConsumer;
import com.mojang.blaze3d.systems.VertexSorter;

public class BatchDrawingTracker {

	protected final Set<RenderLayer> activeTypes = new HashSet<>();
	private final BufferBuilder scratch;

	public BatchDrawingTracker() {
		scratch = new BufferBuilder(8);

		((BufferBuilderExtension) scratch).flywheel$freeBuffer();
	}

	/**
	 * Get a direct vertex consumer for drawing the given number of vertices to the given RenderType.
	 * @param renderType The RenderType to draw to.
	 * @param vertexCount The number of vertices that will be drawn.
	 * @return A direct vertex consumer.
	 */
	public DirectVertexConsumer getDirectConsumer(RenderLayer renderType, int vertexCount) {
		activeTypes.add(renderType);
		return RenderTypeExtension.getDrawBuffer(renderType)
				.begin(vertexCount);
	}

	/**
	 * Draws all active DrawBuffers and reset them.
	 */
	public void endBatch() {
		// TODO: when/if this causes trouble with shaders, try to inject our BufferBuilders
		//  into the RenderBuffers from context.

		for (RenderLayer renderType : activeTypes) {
			_draw(renderType);
		}

		activeTypes.clear();
	}

	/**
	 * Draw and reset the DrawBuffer for the given RenderType.
	 * @param renderType The RenderType to draw.
	 */
	public void endBatch(RenderLayer renderType) {
		_draw(renderType);

		activeTypes.remove(renderType);
	}

	/**
	 * Resets all DrawBuffers to 0 vertices.
	 */
	public void clear() {
		for (RenderLayer type : activeTypes) {
			RenderTypeExtension.getDrawBuffer(type)
					.reset();
		}
		activeTypes.clear();
	}

	private void _draw(RenderLayer renderType) {
		DrawBuffer drawBuffer = RenderTypeExtension.getDrawBuffer(renderType);

		BufferBuilderExtension scratch = (BufferBuilderExtension) this.scratch;
		if (drawBuffer.hasVertices()) {
			drawBuffer.inject(scratch);

			renderType.draw(this.scratch, VertexSorter.BY_DISTANCE);

			drawBuffer.reset();
		}
	}

}

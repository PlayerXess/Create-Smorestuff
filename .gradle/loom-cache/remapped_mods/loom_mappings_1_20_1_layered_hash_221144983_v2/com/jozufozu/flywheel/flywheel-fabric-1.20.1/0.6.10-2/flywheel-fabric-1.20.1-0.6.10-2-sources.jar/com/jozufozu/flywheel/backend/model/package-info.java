@ParametersAreNonnullByDefault @MethodsReturnNonnullByDefault
package com.jozufozu.flywheel.backend.model;

import javax.annotation.ParametersAreNonnullByDefault;

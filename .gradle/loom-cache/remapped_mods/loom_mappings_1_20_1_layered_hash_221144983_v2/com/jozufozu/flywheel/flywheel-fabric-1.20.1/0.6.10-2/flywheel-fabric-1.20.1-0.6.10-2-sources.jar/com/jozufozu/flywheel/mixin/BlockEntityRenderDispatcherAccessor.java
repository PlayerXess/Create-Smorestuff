package com.jozufozu.flywheel.mixin;

import java.util.Map;
import net.minecraft.block.entity.BlockEntityType;
import net.minecraft.client.render.block.entity.BlockEntityRenderDispatcher;
import net.minecraft.client.render.block.entity.BlockEntityRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(BlockEntityRenderDispatcher.class)
public interface BlockEntityRenderDispatcherAccessor {
	@Accessor("renderers")
	Map<BlockEntityType<?>, BlockEntityRenderer<?>> flywheel$getRenderers();
}

package com.tterrag.registrate.fabric;

import java.util.function.Consumer;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;

public class RegistryUtil {
	public static void forAllRegistries(Consumer<Registry<?>> consumer) {
		// Fluid, Block, and Item need to run first
		consumer.accept(Registries.FLUID);
		consumer.accept(Registries.BLOCK);
		consumer.accept(Registries.ITEM);
		Registries.REGISTRIES.forEach(registry -> {
			if (registry != Registries.FLUID && registry != Registries.BLOCK && registry != Registries.ITEM) {
				consumer.accept(registry);
			}
		});
	}
}

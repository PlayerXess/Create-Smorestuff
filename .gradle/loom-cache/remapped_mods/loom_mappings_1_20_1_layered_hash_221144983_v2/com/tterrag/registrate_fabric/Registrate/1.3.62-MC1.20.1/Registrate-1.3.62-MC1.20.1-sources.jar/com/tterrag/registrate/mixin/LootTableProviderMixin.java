package com.tterrag.registrate.mixin;

import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.function.BiConsumer;
import net.minecraft.data.server.loottable.LootTableProvider;
import net.minecraft.loot.LootTable;
import net.minecraft.loot.LootTableReporter;
import net.minecraft.util.Identifier;
import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import com.llamalad7.mixinextras.injector.WrapWithCondition;
import com.llamalad7.mixinextras.sugar.Local;
import com.tterrag.registrate.fabric.CustomValidationLootProvider;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(LootTableProvider.class)
public class LootTableProviderMixin {
    @ModifyExpressionValue(
            method = "run",
            at = @At(
                    value = "INVOKE",
                    target = "Ljava/util/Set;iterator()Ljava/util/Iterator;" // Sets.difference
            )
    )
    private Iterator<Identifier> runCustomValidation(Iterator<Identifier> original,
                                                        @Local(ordinal = 0) Map<Identifier, LootTable> tables,
                                                        @Local(ordinal = 0)LootTableReporter context) {
        if (this instanceof CustomValidationLootProvider custom) {
            custom.validate(tables, context);
            return Collections.emptyIterator();
        }
        return original;
    }

    @WrapWithCondition(
            method = "run",
                at = @At(
                        value = "INVOKE",
                        target = "Ljava/util/Map;forEach(Ljava/util/function/BiConsumer;)V"
                )
    )
    private boolean preventOtherValidation(Map<Identifier, LootTable> tables, BiConsumer<Identifier, LootTable> consumer) {
        return !(this instanceof CustomValidationLootProvider);
    }
}

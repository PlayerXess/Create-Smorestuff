package com.tterrag.registrate.fabric;

import org.jetbrains.annotations.Nullable;

import java.util.Optional;
import java.util.function.Supplier;
import javax.annotation.Nonnull;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.FluidBlock;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.fluid.FlowableFluid;
import net.minecraft.fluid.Fluid;
import net.minecraft.fluid.FluidState;
import net.minecraft.item.Item;
import net.minecraft.item.Items;
import net.minecraft.registry.tag.FluidTags;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;
import net.minecraft.state.StateManager;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.world.BlockView;
import net.minecraft.world.World;
import net.minecraft.world.WorldAccess;
import net.minecraft.world.WorldView;

public abstract class SimpleFlowableFluid extends FlowableFluid {
	private final Supplier<? extends Fluid> flowing;
	private final Supplier<? extends Fluid> still;
	@Nullable
	private final Supplier<? extends Item> bucket;
	@Nullable
	private final Supplier<? extends FluidBlock> block;
	private final boolean infinite;
	private final int flowSpeed;
	private final int levelDecreasePerBlock;
	private final float blastResistance;
	private final int tickRate;

	protected SimpleFlowableFluid(Properties properties) {
		this.flowing = properties.flowing;
		this.still = properties.still;
		this.infinite = properties.infinite;
		this.bucket = properties.bucket;
		this.block = properties.block;
		this.flowSpeed = properties.flowSpeed;
		this.levelDecreasePerBlock = properties.levelDecreasePerBlock;
		this.blastResistance = properties.blastResistance;
		this.tickRate = properties.tickRate;
	}

	@Nonnull
	@Override
	public Optional<SoundEvent> getBucketFillSound() {
		boolean lava = getDefaultState().isIn(FluidTags.field_15518);
		return Optional.ofNullable(lava ? SoundEvents.field_15202 : SoundEvents.field_15126);
	}

	@Override
	public Fluid getFlowing() {
		return flowing.get();
	}

	@Override
	public Fluid getStill() {
		return still.get();
	}

	@Override
	protected boolean isInfinite(World level) {
		return infinite;
	}

	@Override
	protected void beforeBreakingBlock(WorldAccess world, BlockPos pos, BlockState state) {
		BlockEntity blockEntity = state.hasBlockEntity() ? world.getBlockEntity(pos) : null;
		Block.dropStacks(state, world, pos, blockEntity);
	}

	@Override
	protected int getFlowSpeed(WorldView world) {
		return flowSpeed;
	}

	@Override
	protected int getLevelDecreasePerBlock(WorldView worldIn) {
		return levelDecreasePerBlock;
	}

	@Override
	public Item getBucketItem() {
		return bucket != null ? bucket.get() : Items.AIR;
	}

	@Override
	protected boolean canBeReplacedWith(FluidState state, BlockView world, BlockPos pos, Fluid fluid, Direction direction) {
		return direction == Direction.field_11033 && !matchesType(fluid);
	}

	@Override
	public int getTickRate(WorldView world) {
		return tickRate;
	}

	@Override
	protected float getBlastResistance() {
		return blastResistance;
	}

	@Override
	protected BlockState toBlockState(FluidState state) {
		if (block != null) {
			return block.get().getDefaultState().with(FluidBlock.LEVEL, getBlockStateLevel(state));
		}
		return Blocks.field_10124.getDefaultState();
	}

	@Override
	public boolean matchesType(Fluid fluid) {
		return fluid == still.get() || fluid == flowing.get();
	}

	public static class Flowing extends SimpleFlowableFluid {
		public Flowing(Properties properties) {
			super(properties);
			setDefaultState(getStateManager().getDefaultState().with(LEVEL, 7));
		}

		@Override
		protected void appendProperties(StateManager.Builder<Fluid, FluidState> builder) {
			super.appendProperties(builder);
			builder.add(LEVEL);
		}

		@Override
		public int getLevel(FluidState state) {
			return state.get(LEVEL);
		}

		@Override
		public boolean isStill(FluidState state) {
			return false;
		}
	}

	public static class Source extends SimpleFlowableFluid {
		public Source(Properties properties) {
			super(properties);
		}

		@Override
		public int getLevel(FluidState state) {
			return 8;
		}

		@Override
		public boolean isStill(FluidState state) {
			return true;
		}
	}

	public static class Properties {
		private Supplier<? extends Fluid> still;
		private Supplier<? extends Fluid> flowing;
		private boolean infinite;
		private Supplier<? extends Item> bucket;
		private Supplier<? extends FluidBlock> block;
		private int flowSpeed = 4;
		private int levelDecreasePerBlock = 1;
		private float blastResistance = 1;
		private int tickRate = 5;

		public Properties(Supplier<? extends Fluid> still, Supplier<? extends Fluid> flowing) {
			this.still = still;
			this.flowing = flowing;
		}

		public Properties canMultiply() {
			infinite = true;
			return this;
		}

		public Properties bucket(Supplier<? extends Item> bucket) {
			this.bucket = bucket;
			return this;
		}

		public Properties block(Supplier<? extends FluidBlock> block) {
			this.block = block;
			return this;
		}

		public Properties flowSpeed(int flowSpeed) {
			this.flowSpeed = flowSpeed;
			return this;
		}

		public Properties levelDecreasePerBlock(int levelDecreasePerBlock) {
			this.levelDecreasePerBlock = levelDecreasePerBlock;
			return this;
		}

		public Properties blastResistance(float blastResistance) {
			this.blastResistance = blastResistance;
			return this;
		}

		public Properties tickRate(int tickRate) {
			this.tickRate = tickRate;
			return this;
		}
	}
}

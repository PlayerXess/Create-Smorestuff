package com.tterrag.registrate.providers;

import java.nio.file.Path;
import java.util.HashSet;
import java.util.List;
import java.util.Objects;
import java.util.Set;
import java.util.concurrent.CompletableFuture;
import java.util.function.Consumer;

import com.google.common.collect.Lists;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.tterrag.registrate.AbstractRegistrate;
import lombok.extern.log4j.Log4j2;
import net.fabricmc.api.EnvType;
import net.minecraft.advancement.Advancement;
import net.minecraft.data.DataOutput;
import net.minecraft.data.DataProvider;
import net.minecraft.data.DataWriter;
import net.minecraft.registry.RegistryWrapper;
import net.minecraft.registry.RegistryWrapper.WrapperLookup;
import net.minecraft.text.MutableText;
import net.minecraft.util.Identifier;
import org.jetbrains.annotations.Nullable;

@Log4j2
public class RegistrateAdvancementProvider implements RegistrateProvider, Consumer<Advancement> {

    private static final Gson GSON = (new GsonBuilder()).setPrettyPrinting().create();

    private final AbstractRegistrate<?> owner;
    private final DataOutput packOutput;
    private final CompletableFuture<WrapperLookup> registriesLookup;
    private final List<CompletableFuture<?>> advancementsToSave = Lists.newArrayList();

    public RegistrateAdvancementProvider(AbstractRegistrate<?> owner, DataOutput packOutputIn, CompletableFuture<RegistryWrapper.WrapperLookup> registriesLookupIn) {
        this.owner = owner;
        this.packOutput = packOutputIn;
        this.registriesLookup = registriesLookupIn;
    }

    @Override
    public EnvType getSide() {
        return EnvType.SERVER;
    }

    public MutableText title(String category, String name, String title) {
        return owner.addLang("advancements", new Identifier(category, name), "title", title);
    }

    public MutableText desc(String category, String name, String desc) {
        return owner.addLang("advancements", new Identifier(category, name), "description", desc);
    }

    private @Nullable DataWriter cache;
    private Set<Identifier> seenAdvancements = new HashSet<>();

    @Override
    public CompletableFuture<?> run(DataWriter cache) {
        return registriesLookup.thenCompose(lookup -> {
            advancementsToSave.clear();

            try {
                this.cache = cache;
                this.seenAdvancements.clear();
                owner.genData(ProviderType.ADVANCEMENT, this);
            } finally {
                this.cache = null;
            }

            return CompletableFuture.allOf(advancementsToSave.toArray(CompletableFuture[]::new));
        });
    }

    @Override
    public void accept(@Nullable Advancement t) {
        DataWriter cache = this.cache;
        if (cache == null) {
            throw new IllegalStateException("Cannot accept advancements outside of act");
        }
        Objects.requireNonNull(t, "Cannot accept a null advancement");
        Path path = this.packOutput.getPath();
        if (!seenAdvancements.add(t.getId())) {
            throw new IllegalStateException("Duplicate advancement " + t.getId());
        } else {
            Path path1 = getPath(path, t);
            advancementsToSave.add(DataProvider.writeToPath(cache, t.createTask().toJson(), path1));
        }
    }

    private static Path getPath(Path pathIn, Advancement advancementIn) {
        return pathIn.resolve("data/" + advancementIn.getId().getNamespace() + "/advancements/" + advancementIn.getId().getPath() + ".json");
    }

    public String getName() {
        return "Advancements";
    }
}

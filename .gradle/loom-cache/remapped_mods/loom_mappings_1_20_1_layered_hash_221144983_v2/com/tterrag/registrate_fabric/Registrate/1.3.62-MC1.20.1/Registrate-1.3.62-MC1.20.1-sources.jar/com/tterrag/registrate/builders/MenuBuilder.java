package com.tterrag.registrate.builders;

import com.tterrag.registrate.AbstractRegistrate;
import com.tterrag.registrate.fabric.EnvExecutor;
import com.tterrag.registrate.fabric.RegistryObject;
import com.tterrag.registrate.util.entry.MenuEntry;
import com.tterrag.registrate.util.entry.RegistryEntry;
import com.tterrag.registrate.util.nullness.NonNullSupplier;
import com.tterrag.registrate.util.nullness.NonnullType;

import net.fabricmc.fabric.api.screenhandler.v1.ExtendedScreenHandlerType;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.ingame.HandledScreens;
import net.minecraft.client.gui.screen.ingame.ScreenHandlerProvider;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.resource.featuretoggle.FeatureFlags;
import net.minecraft.screen.ScreenHandler;
import net.minecraft.screen.ScreenHandlerType;
import net.minecraft.text.Text;
import net.fabricmc.api.EnvType;
import org.jetbrains.annotations.Nullable;

public class MenuBuilder<T extends ScreenHandler, S extends Screen & ScreenHandlerProvider<T>,  P> extends AbstractBuilder<ScreenHandlerType<?>, ScreenHandlerType<T>, P, MenuBuilder<T, S, P>> {
    
    public interface MenuFactory<T extends ScreenHandler> {
        
        T create(ScreenHandlerType<T> type, int windowId, PlayerInventory inv);
    }

    public interface ForgeMenuFactory<T extends ScreenHandler> {

        T create(ScreenHandlerType<T> type, int windowId, PlayerInventory inv, @Nullable PacketByteBuf buffer);
    }
    
    public interface ScreenFactory<M extends ScreenHandler, T extends Screen & ScreenHandlerProvider<M>> {
        
        T create(M menu, PlayerInventory inv, Text displayName);
    }

    private final MenuFactory<T> factory;
    private final ForgeMenuFactory<T> forgeFactory;
    private final NonNullSupplier<ScreenFactory<T, S>> screenFactory;

    public MenuBuilder(AbstractRegistrate<?> owner, P parent, String name, BuilderCallback callback, MenuFactory<T> factory, NonNullSupplier<ScreenFactory<T, S>> screenFactory) {
        this(owner, parent, name, callback, (type, windowId, inv, $) -> factory.create(type, windowId, inv), screenFactory);
    }

    public MenuBuilder(AbstractRegistrate<?> owner, P parent, String name, BuilderCallback callback, ForgeMenuFactory<T> factory, NonNullSupplier<ScreenFactory<T, S>> screenFactory) {
        super(owner, parent, name, callback, RegistryKeys.SCREEN_HANDLER);
        this.forgeFactory = factory;
        this.factory = null;
        this.screenFactory = screenFactory;
    }

    @Override
    protected @NonnullType ScreenHandlerType<T> createEntry() {
        NonNullSupplier<ScreenHandlerType<T>> supplier = this.asSupplier();
        ScreenHandlerType<T> ret;
        if (this.factory == null) {
            ForgeMenuFactory<T> factory = this.forgeFactory;
            ret = new ExtendedScreenHandlerType<>((windowId, inv, buf) -> factory.create(supplier.get(), windowId, inv, buf));
        } else {
            MenuFactory<T> factory = this.factory;
            ret = new ScreenHandlerType<>((syncId, inventory) -> factory.create(supplier.get(), syncId, inventory), FeatureFlags.VANILLA_FEATURES);
        }
        EnvExecutor.runWhenOn(EnvType.CLIENT, () -> () -> {
            ScreenFactory<T, S> screenFactory = this.screenFactory.get();
            HandledScreens.register(ret, screenFactory::create);
        });
        return ret;
    }

    @Override
    protected RegistryEntry<ScreenHandlerType<T>> createEntryWrapper(RegistryObject<ScreenHandlerType<T>> delegate) {
        return new MenuEntry<>(getOwner(), delegate);
    }

    @Override
    public MenuEntry<T> register() {
        return (MenuEntry<T>) super.register();
    }
}

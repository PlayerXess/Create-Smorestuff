package com.tterrag.registrate.providers;

import java.util.concurrent.CompletableFuture;
import java.util.function.Function;

import com.tterrag.registrate.AbstractRegistrate;
import net.fabricmc.api.EnvType;
import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricTagProvider;
import net.minecraft.registry.Registry;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryWrapper;
import net.minecraft.registry.RegistryWrapper.WrapperLookup;
import net.minecraft.registry.tag.TagKey;

public interface RegistrateTagsProvider<T> extends RegistrateProvider {
    FabricTagProvider<T>.FabricTagBuilder addTag(TagKey<T> tag);

    class Impl<T> extends FabricTagProvider<T> implements RegistrateTagsProvider<T> {
        private final AbstractRegistrate<?> owner;
        private final ProviderType<? extends Impl<T>> type;
        private final String name;

        public Impl(AbstractRegistrate<?> owner, ProviderType<? extends Impl<T>> type, String name, FabricDataOutput packOutput, RegistryKey<? extends Registry<T>> registryIn, CompletableFuture<RegistryWrapper.WrapperLookup> registriesLookup) {
            super(packOutput, registryIn, registriesLookup);

            this.owner = owner;
            this.type = type;
            this.name = name;
        }

        @Override
        public String getName() {
            return "Tags (%s)".formatted(name);
        }

        @Override
        protected void configure(RegistryWrapper.WrapperLookup provider) {
            owner.genData(type, this);
        }

        @Override
        public EnvType getSide() {
            return EnvType.SERVER;
        }

        @Override
        public FabricTagProvider<T>.FabricTagBuilder addTag(TagKey<T> tag) {
            return super.getOrCreateTagBuilder(tag);
        }
    }

    class IntrinsicImpl<T> extends FabricTagProvider<T> implements RegistrateTagsProvider<T> {
        private final AbstractRegistrate<?> owner;
        private final ProviderType<? extends IntrinsicImpl<T>> type;
        private final String name;

        public IntrinsicImpl(AbstractRegistrate<?> owner, ProviderType<? extends IntrinsicImpl<T>> type, String name, FabricDataOutput packOutput, RegistryKey<? extends Registry<T>> registryIn, CompletableFuture<WrapperLookup> registriesLookup, Function<T, RegistryKey<T>> keyExtractor) {
            super(packOutput, registryIn, registriesLookup);

            this.owner = owner;
            this.type = type;
            this.name = name;
        }

        @Override
        public String getName() {
            return "Tags (%s)".formatted(name);
        }

        @Override
        protected void configure(RegistryWrapper.WrapperLookup provider) {
            owner.genData(type, this);
        }

        @Override
        public EnvType getSide() {
            return EnvType.SERVER;
        }

        @Override
        public FabricTagProvider<T>.FabricTagBuilder addTag(TagKey<T> tag) {
            return super.getOrCreateTagBuilder(tag);
        }
    }
}

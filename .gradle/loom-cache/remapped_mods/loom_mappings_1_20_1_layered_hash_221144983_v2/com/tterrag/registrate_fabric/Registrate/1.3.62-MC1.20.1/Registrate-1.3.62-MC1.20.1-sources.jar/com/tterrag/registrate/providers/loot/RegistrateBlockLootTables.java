package com.tterrag.registrate.providers.loot;

import java.util.function.Consumer;

import javax.annotation.processing.Generated;

import com.tterrag.registrate.AbstractRegistrate;

import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricBlockLootTableProvider;
import net.minecraft.block.Block;
import net.minecraft.data.server.loottable.BlockLootTableGenerator;
import net.minecraft.item.Item;
import net.minecraft.item.ItemConvertible;
import net.minecraft.loot.LootTable;
import net.minecraft.loot.condition.LootCondition;
import net.minecraft.loot.condition.LootConditionConsumingBuilder;
import net.minecraft.loot.entry.LootPoolEntry;
import net.minecraft.loot.function.LootFunctionConsumingBuilder;
import net.minecraft.loot.provider.number.LootNumberProvider;

//@RequiredArgsConstructor
public class RegistrateBlockLootTables extends FabricBlockLootTableProvider implements RegistrateLootTables {
    
    private final AbstractRegistrate<?> parent;
    private final Consumer<RegistrateBlockLootTables> callback;

    public RegistrateBlockLootTables(AbstractRegistrate<?> parent, Consumer<RegistrateBlockLootTables> callback, FabricDataOutput output) {
        super(output);
        this.parent = parent;
        this.callback = callback;
    }

    @Override
    public void generate() {
        callback.accept(this);
    }

    // @formatter:off
    // GENERATED START - DO NOT EDIT BELOW THIS LINE

    /** Generated override to expose protected method: {@link BlockLootTableGenerator#applyExplosionDecay} */
    @Override
    @Generated(value = "com.tterrag.registrate.test.meta.UpdateBlockLootTables", date = "Fri, 9 Jun 2023 03:54:51 GMT")
    public <T extends LootFunctionConsumingBuilder<T>> T applyExplosionDecay(ItemConvertible p_248695_, LootFunctionConsumingBuilder<T> p_248548_) { return super.applyExplosionDecay(p_248695_, p_248548_); }

    /** Generated override to expose protected method: {@link BlockLootTableGenerator#addSurvivesExplosionCondition} */
    @Override
    @Generated(value = "com.tterrag.registrate.test.meta.UpdateBlockLootTables", date = "Fri, 9 Jun 2023 03:54:51 GMT")
    public <T extends LootConditionConsumingBuilder<T>> T addSurvivesExplosionCondition(ItemConvertible p_249717_, LootConditionConsumingBuilder<T> p_248851_) { return super.addSurvivesExplosionCondition(p_249717_, p_248851_); }

    /** Generated override to expose protected method: {@link BlockLootTableGenerator#drops} */
    @Generated(value = "com.tterrag.registrate.test.meta.UpdateBlockLootTables", date = "Fri, 9 Jun 2023 03:54:51 GMT")
    public static LootTable.Builder method_45991(Block p_252253_, LootCondition.Builder p_248764_, LootPoolEntry.Builder<?> p_249146_) { return BlockLootTableGenerator.drops(p_252253_, p_248764_, p_249146_); }

    /** Generated override to expose protected method: {@link BlockLootTableGenerator#dropsWithSilkTouch} */
    @Generated(value = "com.tterrag.registrate.test.meta.UpdateBlockLootTables", date = "Fri, 9 Jun 2023 03:54:51 GMT")
    public static LootTable.Builder dropsWithSilkTouch(Block p_250203_, LootPoolEntry.Builder<?> p_252089_) { return BlockLootTableGenerator.dropsWithSilkTouch(p_250203_, p_252089_); }

    /** Generated override to expose protected method: {@link BlockLootTableGenerator#dropsWithShears} */
    @Generated(value = "com.tterrag.registrate.test.meta.UpdateBlockLootTables", date = "Fri, 9 Jun 2023 03:54:51 GMT")
    public static LootTable.Builder dropsWithShears(Block p_252195_, LootPoolEntry.Builder<?> p_250102_) { return BlockLootTableGenerator.dropsWithShears(p_252195_, p_250102_); }

    /** Generated override to expose protected method: {@link BlockLootTableGenerator#dropsWithSilkTouchOrShears} */
    @Generated(value = "com.tterrag.registrate.test.meta.UpdateBlockLootTables", date = "Fri, 9 Jun 2023 03:54:51 GMT")
    public static LootTable.Builder dropsWithSilkTouchOrShears(Block p_250539_, LootPoolEntry.Builder<?> p_251459_) { return BlockLootTableGenerator.dropsWithSilkTouchOrShears(p_250539_, p_251459_); }

    /** Generated override to expose protected method: {@link BlockLootTableGenerator#drops} */
    @Override
    @Generated(value = "com.tterrag.registrate.test.meta.UpdateBlockLootTables", date = "Fri, 9 Jun 2023 03:54:51 GMT")
    public LootTable.Builder drops(Block p_249305_, ItemConvertible p_251905_) { return super.drops(p_249305_, p_251905_); }

    /** Generated override to expose protected method: {@link BlockLootTableGenerator#drops} */
    @Override
    @Generated(value = "com.tterrag.registrate.test.meta.UpdateBlockLootTables", date = "Fri, 9 Jun 2023 03:54:51 GMT")
    public LootTable.Builder drops(ItemConvertible p_251584_, LootNumberProvider p_249865_) { return super.drops(p_251584_, p_249865_); }

    /** Generated override to expose protected method: {@link BlockLootTableGenerator#drops} */
    @Override
    @Generated(value = "com.tterrag.registrate.test.meta.UpdateBlockLootTables", date = "Fri, 9 Jun 2023 03:54:51 GMT")
    public LootTable.Builder drops(Block p_251449_, ItemConvertible p_248558_, LootNumberProvider p_250047_) { return super.drops(p_251449_, p_248558_, p_250047_); }

    /** Generated override to expose protected method: {@link BlockLootTableGenerator#dropsWithSilkTouch} */
    @Generated(value = "com.tterrag.registrate.test.meta.UpdateBlockLootTables", date = "Fri, 9 Jun 2023 03:54:51 GMT")
    public static LootTable.Builder method_46003(ItemConvertible p_252216_) { return BlockLootTableGenerator.dropsWithSilkTouch(p_252216_); }

    /** Generated override to expose protected method: {@link BlockLootTableGenerator#slabDrops} */
    @Override
    @Generated(value = "com.tterrag.registrate.test.meta.UpdateBlockLootTables", date = "Fri, 9 Jun 2023 03:54:51 GMT")
    public LootTable.Builder slabDrops(Block p_251313_) { return super.slabDrops(p_251313_); }

    /** Generated override to expose protected method: {@link BlockLootTableGenerator#nameableContainerDrops} */
    @Override
    @Generated(value = "com.tterrag.registrate.test.meta.UpdateBlockLootTables", date = "Fri, 9 Jun 2023 03:54:51 GMT")
    public LootTable.Builder nameableContainerDrops(Block p_252291_) { return super.nameableContainerDrops(p_252291_); }

    /** Generated override to expose protected method: {@link BlockLootTableGenerator#shulkerBoxDrops} */
    @Override
    @Generated(value = "com.tterrag.registrate.test.meta.UpdateBlockLootTables", date = "Fri, 9 Jun 2023 03:54:51 GMT")
    public LootTable.Builder shulkerBoxDrops(Block p_252164_) { return super.shulkerBoxDrops(p_252164_); }

    /** Generated override to expose protected method: {@link BlockLootTableGenerator#copperOreDrops} */
    @Override
    @Generated(value = "com.tterrag.registrate.test.meta.UpdateBlockLootTables", date = "Fri, 9 Jun 2023 03:54:51 GMT")
    public LootTable.Builder copperOreDrops(Block p_251306_) { return super.copperOreDrops(p_251306_); }

    /** Generated override to expose protected method: {@link BlockLootTableGenerator#lapisOreDrops} */
    @Override
    @Generated(value = "com.tterrag.registrate.test.meta.UpdateBlockLootTables", date = "Fri, 9 Jun 2023 03:54:51 GMT")
    public LootTable.Builder lapisOreDrops(Block p_251511_) { return super.lapisOreDrops(p_251511_); }

    /** Generated override to expose protected method: {@link BlockLootTableGenerator#redstoneOreDrops} */
    @Override
    @Generated(value = "com.tterrag.registrate.test.meta.UpdateBlockLootTables", date = "Fri, 9 Jun 2023 03:54:51 GMT")
    public LootTable.Builder redstoneOreDrops(Block p_251906_) { return super.redstoneOreDrops(p_251906_); }

    /** Generated override to expose protected method: {@link BlockLootTableGenerator#bannerDrops} */
    @Override
    @Generated(value = "com.tterrag.registrate.test.meta.UpdateBlockLootTables", date = "Fri, 9 Jun 2023 03:54:51 GMT")
    public LootTable.Builder bannerDrops(Block p_249810_) { return super.bannerDrops(p_249810_); }

    /** Generated override to expose protected method: {@link BlockLootTableGenerator#beeNestDrops} */
    @Generated(value = "com.tterrag.registrate.test.meta.UpdateBlockLootTables", date = "Fri, 9 Jun 2023 03:54:51 GMT")
    public static LootTable.Builder beeNestDrops(Block p_250988_) { return BlockLootTableGenerator.beeNestDrops(p_250988_); }

    /** Generated override to expose protected method: {@link BlockLootTableGenerator#beehiveDrops} */
    @Generated(value = "com.tterrag.registrate.test.meta.UpdateBlockLootTables", date = "Fri, 9 Jun 2023 03:54:51 GMT")
    public static LootTable.Builder beehiveDrops(Block p_248770_) { return BlockLootTableGenerator.beehiveDrops(p_248770_); }

    /** Generated override to expose protected method: {@link BlockLootTableGenerator#glowBerryDrops} */
    @Generated(value = "com.tterrag.registrate.test.meta.UpdateBlockLootTables", date = "Fri, 9 Jun 2023 03:54:51 GMT")
    public static LootTable.Builder glowBerryDrops(Block p_251070_) { return BlockLootTableGenerator.glowBerryDrops(p_251070_); }

    /** Generated override to expose protected method: {@link BlockLootTableGenerator#oreDrops} */
    @Override
    @Generated(value = "com.tterrag.registrate.test.meta.UpdateBlockLootTables", date = "Fri, 9 Jun 2023 03:54:51 GMT")
    public LootTable.Builder oreDrops(Block p_250450_, Item p_249745_) { return super.oreDrops(p_250450_, p_249745_); }

    /** Generated override to expose protected method: {@link BlockLootTableGenerator#mushroomBlockDrops} */
    @Override
    @Generated(value = "com.tterrag.registrate.test.meta.UpdateBlockLootTables", date = "Fri, 9 Jun 2023 03:54:51 GMT")
    public LootTable.Builder mushroomBlockDrops(Block p_249959_, ItemConvertible p_249315_) { return super.mushroomBlockDrops(p_249959_, p_249315_); }

    /** Generated override to expose protected method: {@link BlockLootTableGenerator#grassDrops} */
    @Override
    @Generated(value = "com.tterrag.registrate.test.meta.UpdateBlockLootTables", date = "Fri, 9 Jun 2023 03:54:51 GMT")
    public LootTable.Builder grassDrops(Block p_252139_) { return super.grassDrops(p_252139_); }

    /** Generated override to expose protected method: {@link BlockLootTableGenerator#dropsWithShears} */
    @Generated(value = "com.tterrag.registrate.test.meta.UpdateBlockLootTables", date = "Fri, 9 Jun 2023 03:54:51 GMT")
    public static LootTable.Builder dropsWithShears(ItemConvertible p_250684_) { return BlockLootTableGenerator.dropsWithShears(p_250684_); }

    /** Generated override to expose protected method: {@link BlockLootTableGenerator#multifaceGrowthDrops} */
    @Override
    @Generated(value = "com.tterrag.registrate.test.meta.UpdateBlockLootTables", date = "Fri, 9 Jun 2023 03:54:51 GMT")
    public LootTable.Builder multifaceGrowthDrops(Block p_249088_, LootCondition.Builder p_251535_) { return super.multifaceGrowthDrops(p_249088_, p_251535_); }

    /** Generated override to expose protected method: {@link BlockLootTableGenerator#leavesDrops} */
    @Override
    @Generated(value = "com.tterrag.registrate.test.meta.UpdateBlockLootTables", date = "Fri, 9 Jun 2023 03:54:51 GMT")
    public LootTable.Builder leavesDrops(Block p_250088_, Block p_250731_, float... p_248949_) { return super.leavesDrops(p_250088_, p_250731_, p_248949_); }

    /** Generated override to expose protected method: {@link BlockLootTableGenerator#oakLeavesDrops} */
    @Override
    @Generated(value = "com.tterrag.registrate.test.meta.UpdateBlockLootTables", date = "Fri, 9 Jun 2023 03:54:51 GMT")
    public LootTable.Builder oakLeavesDrops(Block p_249535_, Block p_251505_, float... p_250753_) { return super.oakLeavesDrops(p_249535_, p_251505_, p_250753_); }

    /** Generated override to expose protected method: {@link BlockLootTableGenerator#mangroveLeavesDrops} */
    @Override
    @Generated(value = "com.tterrag.registrate.test.meta.UpdateBlockLootTables", date = "Fri, 9 Jun 2023 03:54:51 GMT")
    public LootTable.Builder mangroveLeavesDrops(Block p_251103_) { return super.mangroveLeavesDrops(p_251103_); }

    /** Generated override to expose protected method: {@link BlockLootTableGenerator#cropDrops} */
    @Override
    @Generated(value = "com.tterrag.registrate.test.meta.UpdateBlockLootTables", date = "Fri, 9 Jun 2023 03:54:51 GMT")
    public LootTable.Builder cropDrops(Block p_249457_, Item p_248599_, Item p_251915_, LootCondition.Builder p_252202_) { return super.cropDrops(p_249457_, p_248599_, p_251915_, p_252202_); }

    /** Generated override to expose protected method: {@link BlockLootTableGenerator#seagrassDrops} */
    @Generated(value = "com.tterrag.registrate.test.meta.UpdateBlockLootTables", date = "Fri, 9 Jun 2023 03:54:51 GMT")
    public static LootTable.Builder seagrassDrops(Block p_248678_) { return BlockLootTableGenerator.seagrassDrops(p_248678_); }

    /** Generated override to expose protected method: {@link BlockLootTableGenerator#tallGrassDrops} */
    @Override
    @Generated(value = "com.tterrag.registrate.test.meta.UpdateBlockLootTables", date = "Fri, 9 Jun 2023 03:54:51 GMT")
    public LootTable.Builder tallGrassDrops(Block p_248590_, Block p_248735_) { return super.tallGrassDrops(p_248590_, p_248735_); }

    /** Generated override to expose protected method: {@link BlockLootTableGenerator#candleDrops} */
    @Override
    @Generated(value = "com.tterrag.registrate.test.meta.UpdateBlockLootTables", date = "Fri, 9 Jun 2023 03:54:51 GMT")
    public LootTable.Builder candleDrops(Block p_250896_) { return super.candleDrops(p_250896_); }

    /** Generated override to expose protected method: {@link BlockLootTableGenerator#flowerbedDrops} */
    @Override
    @Generated(value = "com.tterrag.registrate.test.meta.UpdateBlockLootTables", date = "Fri, 9 Jun 2023 03:54:51 GMT")
    public LootTable.Builder flowerbedDrops(Block p_273240_) { return super.flowerbedDrops(p_273240_); }

    /** Generated override to expose protected method: {@link BlockLootTableGenerator#candleCakeDrops} */
    @Generated(value = "com.tterrag.registrate.test.meta.UpdateBlockLootTables", date = "Fri, 9 Jun 2023 03:54:51 GMT")
    public static LootTable.Builder candleCakeDrops(Block p_250280_) { return BlockLootTableGenerator.candleCakeDrops(p_250280_); }

    /** Generated override to expose protected method: {@link BlockLootTableGenerator#addVinePlantDrop} */
    @Override
    @Generated(value = "com.tterrag.registrate.test.meta.UpdateBlockLootTables", date = "Fri, 9 Jun 2023 03:54:51 GMT")
    public void addVinePlantDrop(Block p_252269_, Block p_250696_) { super.addVinePlantDrop(p_252269_, p_250696_); }

    /** Generated override to expose protected method: {@link BlockLootTableGenerator#doorDrops} */
    @Override
    @Generated(value = "com.tterrag.registrate.test.meta.UpdateBlockLootTables", date = "Fri, 9 Jun 2023 03:54:51 GMT")
    public LootTable.Builder doorDrops(Block p_252166_) { return super.doorDrops(p_252166_); }

    /** Generated override to expose protected method: {@link BlockLootTableGenerator#addPottedPlantDrops} */
    @Override
    @Generated(value = "com.tterrag.registrate.test.meta.UpdateBlockLootTables", date = "Fri, 9 Jun 2023 03:54:51 GMT")
    public void addPottedPlantDrops(Block p_251064_) { super.addPottedPlantDrops(p_251064_); }

    /** Generated override to expose protected method: {@link BlockLootTableGenerator#addDropWithSilkTouch} */
    @Override
    @Generated(value = "com.tterrag.registrate.test.meta.UpdateBlockLootTables", date = "Fri, 9 Jun 2023 03:54:51 GMT")
    public void addDropWithSilkTouch(Block p_249932_, Block p_252053_) { super.addDropWithSilkTouch(p_249932_, p_252053_); }

    /** Generated override to expose protected method: {@link BlockLootTableGenerator#addDrop} */
    @Override
    @Generated(value = "com.tterrag.registrate.test.meta.UpdateBlockLootTables", date = "Fri, 9 Jun 2023 03:54:51 GMT")
    public void addDrop(Block p_248885_, ItemConvertible p_251883_) { super.addDrop(p_248885_, p_251883_); }

    /** Generated override to expose protected method: {@link BlockLootTableGenerator#addDropWithSilkTouch} */
    @Override
    @Generated(value = "com.tterrag.registrate.test.meta.UpdateBlockLootTables", date = "Fri, 9 Jun 2023 03:54:51 GMT")
    public void addDropWithSilkTouch(Block p_250855_) { super.addDropWithSilkTouch(p_250855_); }

    /** Generated override to expose protected method: {@link BlockLootTableGenerator#addDrop} */
    @Override
    @Generated(value = "com.tterrag.registrate.test.meta.UpdateBlockLootTables", date = "Fri, 9 Jun 2023 03:54:51 GMT")
    public void addDrop(Block p_249181_) { super.addDrop(p_249181_); }

    /** Generated override to expose protected method: {@link BlockLootTableGenerator#addDrop} */
    @Override
    @Generated(value = "com.tterrag.registrate.test.meta.UpdateBlockLootTables", date = "Fri, 9 Jun 2023 03:54:51 GMT")
    public void addDrop(Block p_250610_, LootTable.Builder p_249817_) { super.addDrop(p_250610_, p_249817_); }

    // GENERATED END
}

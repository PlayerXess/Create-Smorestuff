package com.tterrag.registrate.providers;

import com.tterrag.registrate.AbstractRegistrate;
import io.github.fabricators_of_create.porting_lib.data.ExistingFileHelper;
import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.minecraft.block.Block;
import net.minecraft.data.server.tag.TagProvider;
import net.minecraft.item.Item;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.registry.RegistryWrapper;
import net.minecraft.registry.tag.TagBuilder;
import net.minecraft.registry.tag.TagKey;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.CompletableFuture;

public class RegistrateItemTagsProvider extends RegistrateTagsProvider.IntrinsicImpl<Item> {

    private final CompletableFuture<TagProvider.TagLookup<Block>> blockTags;
    private final Map<TagKey<Block>, TagKey<Item>> tagsToCopy = new HashMap<>();

    public RegistrateItemTagsProvider(AbstractRegistrate<?> owner, ProviderType<RegistrateItemTagsProvider> type, String name, FabricDataOutput output, CompletableFuture<RegistryWrapper.WrapperLookup> registriesLookup, CompletableFuture<TagProvider.TagLookup<Block>> blockTags, ExistingFileHelper existingFileHelper) {
        super(owner, type, name, output, RegistryKeys.field_41197, registriesLookup, item -> item.getRegistryEntry().registryKey());
        this.blockTags = blockTags;
    }

    public void copy(TagKey<Block> p_206422_, TagKey<Item> p_206423_) {
        this.tagsToCopy.put(p_206422_, p_206423_);
    }

    @Override
    protected CompletableFuture<RegistryWrapper.WrapperLookup> getRegistryLookupFuture() {
        return super.getRegistryLookupFuture().thenCombineAsync(this.blockTags, (p_274766_, p_274767_) -> {
            this.tagsToCopy.forEach((p_274763_, p_274764_) -> {
                TagBuilder tagbuilder = this.getTagBuilder(p_274764_);
                Optional<TagBuilder> optional = p_274767_.apply(p_274763_);
                optional.orElseThrow(() -> {
                    return new IllegalStateException("Missing block tag " + p_274764_.id());
                }).build().forEach(tagbuilder::add);
            });
            return p_274766_;
        });
    }
}

package com.tterrag.registrate.providers.loot;

import java.util.Map;
import net.minecraft.data.server.loottable.LootTableGenerator;
import net.minecraft.loot.LootTable;
import net.minecraft.loot.LootTableReporter;
import net.minecraft.util.Identifier;

public interface RegistrateLootTables extends LootTableGenerator
{

    default void validate(Map<Identifier, LootTable> map, LootTableReporter validationresults) {}

}

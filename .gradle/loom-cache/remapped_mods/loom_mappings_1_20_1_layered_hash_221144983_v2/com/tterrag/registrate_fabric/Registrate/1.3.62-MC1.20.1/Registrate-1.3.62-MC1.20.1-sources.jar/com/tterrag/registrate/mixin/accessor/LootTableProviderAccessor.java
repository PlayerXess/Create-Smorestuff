package com.tterrag.registrate.mixin.accessor;

import java.util.List;
import net.minecraft.data.server.loottable.LootTableProvider;
import net.minecraft.data.server.loottable.LootTableProvider.LootTypeGenerator;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Mutable;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(LootTableProvider.class)
public interface LootTableProviderAccessor {
    @Mutable
    @Accessor
    void setSubProviders(List<LootTypeGenerator> entries);
}

package com.tterrag.registrate.fabric;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.resource.ResourceManagerHelper;
import net.minecraft.resource.ResourceType;
import org.spongepowered.asm.mixin.MixinEnvironment;

public class ClientInit implements ClientModInitializer {
	@Override
	public void onInitializeClient() {
		ResourceManagerHelper.get(ResourceType.field_14188).registerReloadListener(FluidSpriteReloadListener.INSTANCE);
//		MixinEnvironment.getCurrentEnvironment().audit();
	}
}

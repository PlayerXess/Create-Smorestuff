package com.tterrag.registrate.mixin.accessor;

import net.minecraft.block.entity.BlockEntity;
import net.minecraft.block.entity.BlockEntityType;
import net.minecraft.client.render.block.entity.BlockEntityRendererFactories;
import net.minecraft.client.render.block.entity.BlockEntityRendererFactory;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(BlockEntityRendererFactories.class)
public interface BlockEntityRenderersAccessor {
	@Invoker("register")
	static <T extends BlockEntity> void invokeRegister(BlockEntityType<? extends T> blockEntityType, BlockEntityRendererFactory<T> blockEntityRendererProvider) {
		throw new RuntimeException("Mixin not applied!");
	}
}

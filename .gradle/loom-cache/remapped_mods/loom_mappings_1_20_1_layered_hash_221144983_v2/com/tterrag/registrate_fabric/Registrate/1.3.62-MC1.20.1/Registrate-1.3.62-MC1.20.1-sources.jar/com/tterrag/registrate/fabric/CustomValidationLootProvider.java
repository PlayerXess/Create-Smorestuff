package com.tterrag.registrate.fabric;

import java.util.Map;
import net.minecraft.loot.LootTable;
import net.minecraft.loot.LootTableReporter;
import net.minecraft.util.Identifier;

public interface CustomValidationLootProvider {
    void validate(Map<Identifier, LootTable> tables, LootTableReporter context);
}

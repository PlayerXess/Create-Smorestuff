package com.tterrag.registrate.providers;

import com.tterrag.registrate.builders.Builder;
import com.tterrag.registrate.util.nullness.NonNullSupplier;
import com.tterrag.registrate.util.nullness.NonnullType;

import lombok.AccessLevel;
import lombok.Getter;
import lombok.Value;
import lombok.experimental.Delegate;
import net.minecraft.registry.Registry;
import net.minecraft.registry.RegistryKey;
import net.minecraft.util.Identifier;

/**
 * A context bean passed to data generator callbacks. Contains the entry that data is being created for, and some metadata about the entry.
 *
 * @param <R>
 *            Type of the registry to which the entry belongs
 * @param <E>
 *            Type of the object for which data is being generated
 */
@Value
public class DataGenContext<R, E extends R> implements NonNullSupplier<E> {

    @Getter(AccessLevel.NONE)
    @Delegate
    NonNullSupplier<E> entry;
    String name;
    Identifier id;

    @SuppressWarnings("null")
    public @NonnullType E getEntry() {
        return entry.get();
    }

    public static <R, E extends R> DataGenContext<R, E> from(Builder<R, E, ?, ?> builder, RegistryKey<? extends Registry<R>> type) {
        return new DataGenContext<R, E>(NonNullSupplier.of(builder.getOwner().<R, E>get(builder.getName(), type)), builder.getName(),
                new Identifier(builder.getOwner().getModid(), builder.getName()));
    }
}

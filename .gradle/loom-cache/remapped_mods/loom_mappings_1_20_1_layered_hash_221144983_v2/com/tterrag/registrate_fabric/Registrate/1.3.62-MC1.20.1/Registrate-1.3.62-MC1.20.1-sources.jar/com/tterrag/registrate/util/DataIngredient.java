package com.tterrag.registrate.util;

import java.util.Arrays;
import java.util.function.Function;
import java.util.function.Supplier;
import java.util.stream.Stream;

import com.google.common.collect.ObjectArrays;
import com.tterrag.registrate.providers.RegistrateRecipeProvider;
import com.tterrag.registrate.util.nullness.NonNullSupplier;

import lombok.Getter;
import lombok.experimental.Delegate;
import net.minecraft.advancement.criterion.InventoryChangedCriterion;
import net.minecraft.item.Item;
import net.minecraft.item.ItemConvertible;
import net.minecraft.item.ItemStack;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.predicate.item.ItemPredicate;
import net.minecraft.recipe.Ingredient;
import net.minecraft.registry.Registries;
import net.minecraft.registry.tag.TagKey;
import net.minecraft.util.Identifier;

/**
 * A helper for data generation when using ingredients as input(s) to recipes.<br>
 * It remembers the name of the primary ingredient for use in creating recipe names/criteria.
 * <p>
 * Create an instance of this class with the various factory methods such as {@link #items(ItemConvertible, ItemConvertible...)} and {@link #tag(TagKey)}.
 * <p>
 * <strong>This class should not be used for any purpose other than data generation</strong>, it will throw an exception if it is serialized to a packet buffer.
 */
public final class DataIngredient extends Ingredient {

    private interface Excludes {

//        IIngredientSerializer<DataIngredient> getSerializer();

        void toNetwork(PacketByteBuf buffer);
        
        boolean checkInvalidation();
        
        void markValid();
        
        boolean isVanilla();
    }

    @Delegate(excludes = Excludes.class)
    private final Ingredient parent;
    @Getter
    private final Identifier id;
    private final Function<RegistrateRecipeProvider, InventoryChangedCriterion.Conditions> criteriaFactory;

    private DataIngredient(Ingredient parent, ItemConvertible item) {
        super(Stream.empty());
        this.parent = parent;
        this.id = Registries.ITEM.getId(item.asItem());
        this.criteriaFactory = prov -> RegistrateRecipeProvider.conditionsFromItem(item);
    }
    
    private DataIngredient(Ingredient parent, TagKey<Item> tag) {
        super(Stream.empty());
        this.parent = parent;
        this.id = tag.id();
        this.criteriaFactory = prov -> RegistrateRecipeProvider.conditionsFromTag(tag);
    }
    
    private DataIngredient(Ingredient parent, Identifier id, ItemPredicate... predicates) {
        super(Stream.empty());
        this.parent = parent;
        this.id = id;
        this.criteriaFactory = prov -> RegistrateRecipeProvider.method_10423(predicates);
    }

//    @Override
//    public IIngredientSerializer<DataIngredient> getSerializer() {
//        throw new UnsupportedOperationException("DataIngredient should only be used for data generation!");
//    }
    
    public InventoryChangedCriterion.Conditions getCritereon(RegistrateRecipeProvider prov) {
        return criteriaFactory.apply(prov);
    }
    
    @SuppressWarnings("unchecked")
    @SafeVarargs
    public static <T extends ItemConvertible> DataIngredient items(NonNullSupplier<? extends T> first, NonNullSupplier<? extends T>... others) {
        return items(first.get(), (T[]) Arrays.stream(others).map(Supplier::get).toArray(ItemConvertible[]::new));
    }

    @SafeVarargs
    public static <T extends ItemConvertible> DataIngredient items(T first, T... others) {
        return ingredient(Ingredient.ofItems(ObjectArrays.concat(first, others)), first);
    }

    public static DataIngredient stacks(ItemStack first, ItemStack... others) {
        return ingredient(Ingredient.ofStacks(ObjectArrays.concat(first, others)), first.getItem());
    }

    public static DataIngredient tag(TagKey<Item> tag) {
        return ingredient(Ingredient.fromTag(tag), tag);
    }
    
    public static DataIngredient ingredient(Ingredient parent, ItemConvertible required) {
        return new DataIngredient(parent, required);
    }
    
    public static DataIngredient ingredient(Ingredient parent, TagKey<Item> required) {
        return new DataIngredient(parent, required);
    }
    
    public static DataIngredient ingredient(Ingredient parent, Identifier id, ItemPredicate... criteria) {
        return new DataIngredient(parent, id, criteria);
    }
}

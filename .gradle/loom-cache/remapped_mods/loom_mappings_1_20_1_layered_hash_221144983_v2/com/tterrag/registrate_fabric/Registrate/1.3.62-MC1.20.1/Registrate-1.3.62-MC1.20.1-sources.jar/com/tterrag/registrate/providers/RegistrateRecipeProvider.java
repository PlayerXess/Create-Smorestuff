package com.tterrag.registrate.providers;

import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.function.Consumer;
import java.util.function.Supplier;

import javax.annotation.processing.Generated;

import com.google.common.collect.ImmutableMap;
import com.tterrag.registrate.AbstractRegistrate;
import com.tterrag.registrate.util.DataIngredient;
import com.tterrag.registrate.util.nullness.NonNullSupplier;

import io.github.fabricators_of_create.porting_lib.tags.Tags;
import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricRecipeProvider;
import net.minecraft.advancement.Advancement;
import net.minecraft.advancement.criterion.EnterBlockCriterion;
import net.minecraft.advancement.criterion.InventoryChangedCriterion;
import net.minecraft.block.Block;
import net.minecraft.data.DataWriter;
import net.minecraft.data.family.BlockFamily;
import net.minecraft.data.server.recipe.CookingRecipeJsonBuilder;
import net.minecraft.data.server.recipe.CraftingRecipeJsonBuilder;
import net.minecraft.data.server.recipe.RecipeJsonProvider;
import net.minecraft.data.server.recipe.RecipeProvider;
import net.minecraft.data.server.recipe.ShapedRecipeJsonBuilder;
import net.minecraft.data.server.recipe.ShapelessRecipeJsonBuilder;
import net.minecraft.data.server.recipe.SingleItemRecipeJsonBuilder;
import net.minecraft.item.Item;
import net.minecraft.item.ItemConvertible;
import net.minecraft.predicate.NumberRange;
import net.minecraft.predicate.item.ItemPredicate;
import net.minecraft.recipe.AbstractCookingRecipe;
import net.minecraft.recipe.Ingredient;
import net.minecraft.recipe.RecipeSerializer;
import net.minecraft.recipe.book.RecipeCategory;
import net.minecraft.registry.Registries;
import net.minecraft.registry.tag.TagKey;
import net.minecraft.util.Identifier;
import net.fabricmc.api.EnvType;
import org.jetbrains.annotations.Nullable;

public class RegistrateRecipeProvider extends FabricRecipeProvider implements RegistrateProvider, Consumer<RecipeJsonProvider> {
    private final AbstractRegistrate<?> owner;

    public RegistrateRecipeProvider(AbstractRegistrate<?> owner, FabricDataOutput output) {
        super(output);
        this.owner = owner;
    }

    @Override
    public EnvType getSide() {
        return EnvType.SERVER;
    }

    @Nullable
    private Consumer<RecipeJsonProvider> callback;

    @Override
    public void accept(@Nullable RecipeJsonProvider t) {
        if (callback == null) {
            throw new IllegalStateException("Cannot accept recipes outside of a call to registerRecipes");
        }
        callback.accept(t);
    }

    @Override
    public void generate(Consumer<RecipeJsonProvider> consumer) {
        this.callback = consumer;
        owner.genData(ProviderType.RECIPE, this);
        this.callback = null;
    }

    public Identifier safeId(Identifier id) {
        return new Identifier(owner.getModid(), safeName(id));
    }

    public Identifier safeId(DataIngredient source) {
        return safeId(source.getId());
    }

    public Identifier safeId(ItemConvertible registryEntry) {
        return safeId(Registries.ITEM.getId(registryEntry.asItem()));
    }

    public String safeName(Identifier id) {
        return id.getPath().replace('/', '_');
    }

    public String safeName(DataIngredient source) {
        return safeName(source.getId());
    }

//    public String safeName(ItemLike registryEntry) {
//        return safeName(ForgeRegistries.ITEMS.getKey(registryEntry.asItem()));
//    }

    public static final int DEFAULT_SMELT_TIME = 200;
    public static final int DEFAULT_BLAST_TIME = DEFAULT_SMELT_TIME / 2;
    public static final int DEFAULT_SMOKE_TIME = DEFAULT_BLAST_TIME;
    public static final int DEFAULT_CAMPFIRE_TIME = DEFAULT_SMELT_TIME * 3;

    private static final String SMELTING_NAME = "smelting";
    @SuppressWarnings("null")
    private static final ImmutableMap<RecipeSerializer<? extends AbstractCookingRecipe>, String> COOKING_TYPE_NAMES = ImmutableMap.<RecipeSerializer<? extends AbstractCookingRecipe>, String>builder()
            .put(RecipeSerializer.SMELTING, SMELTING_NAME)
            .put(RecipeSerializer.BLASTING, "blasting")
            .put(RecipeSerializer.SMOKING, "smoking")
            .put(RecipeSerializer.CAMPFIRE_COOKING, "campfire")
            .build();

    public <T extends ItemConvertible> void cooking(DataIngredient source, RecipeCategory category, Supplier<? extends T> result, float experience, int cookingTime, RecipeSerializer<? extends AbstractCookingRecipe> serializer) {
        cooking(source, category, result, experience, cookingTime, COOKING_TYPE_NAMES.get(serializer), serializer);
    }

    public <T extends ItemConvertible> void cooking(DataIngredient source, RecipeCategory category, Supplier<? extends T> result, float experience, int cookingTime, String typeName, RecipeSerializer<? extends AbstractCookingRecipe> serializer) {
        CookingRecipeJsonBuilder.create(source, category, result.get(), experience, cookingTime, serializer)
            .method_10469("has_" + safeName(source), source.getCritereon(this))
            .method_36443(this, safeId(result.get()) + "_from_" + safeName(source) + "_" + typeName);
    }

    public <T extends ItemConvertible> void smelting(DataIngredient source, RecipeCategory category, Supplier<? extends T> result, float experience) {
        smelting(source, category, result, experience, DEFAULT_SMELT_TIME);
    }

    public <T extends ItemConvertible> void smelting(DataIngredient source, RecipeCategory category, Supplier<? extends T> result, float experience, int cookingTime) {
        cooking(source, category, result, experience, cookingTime, RecipeSerializer.SMELTING);
    }

    public <T extends ItemConvertible> void blasting(DataIngredient source, RecipeCategory category, Supplier<? extends T> result, float experience) {
        blasting(source, category, result, experience, DEFAULT_BLAST_TIME);
    }

    public <T extends ItemConvertible> void blasting(DataIngredient source, RecipeCategory category, Supplier<? extends T> result, float experience, int cookingTime) {
        cooking(source, category, result, experience, cookingTime, RecipeSerializer.BLASTING);
    }

    public <T extends ItemConvertible> void smoking(DataIngredient source, RecipeCategory category, Supplier<? extends T> result, float experience) {
        smoking(source, category, result, experience, DEFAULT_SMOKE_TIME);
    }

    public <T extends ItemConvertible> void smoking(DataIngredient source, RecipeCategory category, Supplier<? extends T> result, float experience, int cookingTime) {
        cooking(source, category, result, experience, cookingTime, RecipeSerializer.SMOKING);
    }

    public <T extends ItemConvertible> void campfire(DataIngredient source, RecipeCategory category, Supplier<? extends T> result, float experience) {
        campfire(source, category, result, experience, DEFAULT_CAMPFIRE_TIME);
    }

    public <T extends ItemConvertible> void campfire(DataIngredient source, RecipeCategory category, Supplier<? extends T> result, float experience, int cookingTime) {
        cooking(source, category, result, experience, cookingTime, RecipeSerializer.CAMPFIRE_COOKING);
    }

    public <T extends ItemConvertible> void stonecutting(DataIngredient source, RecipeCategory category, Supplier<? extends T> result) {
        stonecutting(source, category, result, 1);
    }

    public <T extends ItemConvertible> void stonecutting(DataIngredient source, RecipeCategory category, Supplier<? extends T> result, int resultAmount) {
        SingleItemRecipeJsonBuilder.createStonecutting(source, category, result.get(), resultAmount)
            .method_17970("has_" + safeName(source), source.getCritereon(this))
            .method_36443(this, safeId(result.get()) + "_from_" + safeName(source) + "_stonecutting");
    }

    public <T extends ItemConvertible> void smeltingAndBlasting(DataIngredient source, RecipeCategory category, Supplier<? extends T> result, float xp) {
        smelting(source, category, result, xp);
        blasting(source, category, result, xp);
    }

    public <T extends ItemConvertible> void food(DataIngredient source, RecipeCategory category, Supplier<? extends T> result, float xp) {
        smelting(source, category, result, xp);
        smoking(source, category, result, xp);
        campfire(source, category, result, xp);
    }

    public <T extends ItemConvertible> void square(DataIngredient source, RecipeCategory category, Supplier<? extends T> output, boolean small) {
        ShapedRecipeJsonBuilder builder = ShapedRecipeJsonBuilder.create(category, output.get())
                .input('X', source);
        if (small) {
            builder.pattern("XX").pattern("XX");
        } else {
            builder.pattern("XXX").pattern("XXX").pattern("XXX");
        }
        builder.criterion("has_" + safeName(source), source.getCritereon(this))
            .offerTo(this, safeId(output.get()));
    }

    /**
     * @param <T>
     * @param source
     * @param output
     * @deprecated Broken, use {@link #storage(NonNullSupplier, RecipeCategory, NonNullSupplier)} or {@link #storage(DataIngredient, RecipeCategory, NonNullSupplier, DataIngredient, NonNullSupplier)}.
     */
    @Deprecated
    public <T extends ItemConvertible> void storage(DataIngredient source, RecipeCategory category, NonNullSupplier<? extends T> output) {
        square(source, category, output, false);
        // This is backwards, but leaving in for binary compat
        singleItemUnfinished(source, category, output, 1, 9)
            .offerTo(this, safeId(source) + "_from_" + safeName(Registries.ITEM.getId(output.get().asItem())));
    }

    public <T extends ItemConvertible> void storage(NonNullSupplier<? extends T> source, RecipeCategory category, NonNullSupplier<? extends T> output) {
        storage(DataIngredient.items(source), category, source, DataIngredient.items(output), output);
    }

    public <T extends ItemConvertible> void storage(DataIngredient sourceIngredient, RecipeCategory category, NonNullSupplier<? extends T> source, DataIngredient outputIngredient, NonNullSupplier<? extends T> output) {
        square(sourceIngredient, category, output, false);
        singleItemUnfinished(outputIngredient, category, source, 1, 9)
            .offerTo(this, safeId(sourceIngredient) + "_from_" + safeName(Registries.ITEM.getId(output.get().asItem())));
    }

//    @CheckReturnValue
    public <T extends ItemConvertible> ShapelessRecipeJsonBuilder singleItemUnfinished(DataIngredient source, RecipeCategory category, Supplier<? extends T> result, int required, int amount) {
        return ShapelessRecipeJsonBuilder.create(category, result.get(), amount)
            .input(source, required)
            .method_10442("has_" + safeName(source), source.getCritereon(this));
    }

    public <T extends ItemConvertible> void singleItem(DataIngredient source, RecipeCategory category, Supplier<? extends T> result, int required, int amount) {
        singleItemUnfinished(source, category, result, required, amount).offerTo(this, safeId(result.get()));
    }

    public <T extends ItemConvertible> void planks(DataIngredient source, RecipeCategory category, Supplier<? extends T> result) {
        singleItemUnfinished(source, category, result, 1, 4)
            .group("planks")
            .offerTo(this, safeId(result.get()));
    }

    public <T extends ItemConvertible> void stairs(DataIngredient source, RecipeCategory category, Supplier<? extends T> result, @Nullable String group, boolean stone) {
        ShapedRecipeJsonBuilder.create(category, result.get(), 4)
            .pattern("X  ").pattern("XX ").pattern("XXX")
            .input('X', source)
            .method_10435(group)
            .method_10429("has_" + safeName(source), source.getCritereon(this))
            .method_17972(this, safeId(result.get()));
        if (stone) {
            stonecutting(source, category, result);
        }
    }

    public <T extends ItemConvertible> void slab(DataIngredient source, RecipeCategory category, Supplier<? extends T> result, @Nullable String group, boolean stone) {
        ShapedRecipeJsonBuilder.create(category, result.get(), 6)
            .pattern("XXX")
            .input('X', source)
            .method_10435(group)
            .method_10429("has_" + safeName(source), source.getCritereon(this))
            .method_17972(this, safeId(result.get()));
        if (stone) {
            stonecutting(source, category, result, 2);
        }
    }

    public <T extends ItemConvertible> void fence(DataIngredient source, RecipeCategory category, Supplier<? extends T> result, @Nullable String group) {
        ShapedRecipeJsonBuilder.create(category, result.get(), 3)
            .pattern("W#W").pattern("W#W")
            .input('W', source)
            .method_10433('#', Tags.Items.RODS_WOODEN)
            .method_10435(group)
            .method_10429("has_" + safeName(source), source.getCritereon(this))
            .method_17972(this, safeId(result.get()));
    }

    public <T extends ItemConvertible> void fenceGate(DataIngredient source, RecipeCategory category, Supplier<? extends T> result, @Nullable String group) {
        ShapedRecipeJsonBuilder.create(category, result.get())
            .pattern("#W#").pattern("#W#")
            .input('W', source)
            .method_10433('#', Tags.Items.RODS_WOODEN)
            .method_10435(group)
            .method_10429("has_" + safeName(source), source.getCritereon(this))
            .method_17972(this, safeId(result.get()));
    }

    public <T extends ItemConvertible> void wall(DataIngredient source, RecipeCategory category, Supplier<? extends T> result) {
        ShapedRecipeJsonBuilder.create(category, result.get(), 6)
            .pattern("XXX").pattern("XXX")
            .input('X', source)
            .method_10429("has_" + safeName(source), source.getCritereon(this))
            .method_17972(this, safeId(result.get()));
        stonecutting(source, category, result);
    }

    public <T extends ItemConvertible> void door(DataIngredient source, RecipeCategory category, Supplier<? extends T> result, @Nullable String group) {
        ShapedRecipeJsonBuilder.create(category, result.get(), 3)
            .pattern("XX").pattern("XX").pattern("XX")
            .input('X', source)
            .method_10435(group)
            .method_10429("has_" + safeName(source), source.getCritereon(this))
            .method_17972(this, safeId(result.get()));
    }

    public <T extends ItemConvertible> void trapDoor(DataIngredient source, RecipeCategory category, Supplier<? extends T> result, @Nullable String group) {
        ShapedRecipeJsonBuilder.create(category, result.get(), 2)
            .pattern("XXX").pattern("XXX")
            .input('X', source)
            .method_10435(group)
            .method_10429("has_" + safeName(source), source.getCritereon(this))
            .method_17972(this, safeId(result.get()));
    }

    // @formatter:off
    // GENERATED START - DO NOT EDIT BELOW THIS LINE

    /** Generated override to expose protected method: {@link RecipeProvider#saveRecipeAdvancement} */
    @Override
    @Generated(value = "com.tterrag.registrate.test.meta.UpdateRecipeProvider", date = "Fri, 9 Jun 2023 04:03:23 GMT")
    public CompletableFuture<?> saveRecipeAdvancement(DataWriter p_253674_, Identifier p_254102_, Advancement.Builder p_253712_) { return super.saveRecipeAdvancement(p_253674_, p_254102_, p_253712_); }

    /** Generated override to expose protected method: {@link RecipeProvider#offerSmelting} */
    @Generated(value = "com.tterrag.registrate.test.meta.UpdateRecipeProvider", date = "Fri, 9 Jun 2023 04:03:23 GMT")
    public static void offerSmelting(Consumer<RecipeJsonProvider> p_250654_, List<ItemConvertible> p_250172_, RecipeCategory p_250588_, ItemConvertible p_251868_, float p_250789_, int p_252144_, String p_251687_) { RecipeProvider.offerSmelting(p_250654_, p_250172_, p_250588_, p_251868_, p_250789_, p_252144_, p_251687_); }

    /** Generated override to expose protected method: {@link RecipeProvider#offerBlasting} */
    @Generated(value = "com.tterrag.registrate.test.meta.UpdateRecipeProvider", date = "Fri, 9 Jun 2023 04:03:23 GMT")
    public static void offerBlasting(Consumer<RecipeJsonProvider> p_248775_, List<ItemConvertible> p_251504_, RecipeCategory p_248846_, ItemConvertible p_249735_, float p_248783_, int p_250303_, String p_251984_) { RecipeProvider.offerBlasting(p_248775_, p_251504_, p_248846_, p_249735_, p_248783_, p_250303_, p_251984_); }

    /** Generated override to expose protected method: {@link RecipeProvider#offerMultipleOptions} */
    @Generated(value = "com.tterrag.registrate.test.meta.UpdateRecipeProvider", date = "Fri, 9 Jun 2023 04:03:23 GMT")
    public static void method_36232(Consumer<RecipeJsonProvider> p_250791_, RecipeSerializer<? extends AbstractCookingRecipe> p_251817_, List<ItemConvertible> p_249619_, RecipeCategory p_251154_, ItemConvertible p_250066_, float p_251871_, int p_251316_, String p_251450_, String p_249236_) { RecipeProvider.offerMultipleOptions(p_250791_, p_251817_, p_249619_, p_251154_, p_250066_, p_251871_, p_251316_, p_251450_, p_249236_); }

    /** Generated override to expose protected method: {@link RecipeProvider#offerNetheriteUpgradeRecipe} */
    @Generated(value = "com.tterrag.registrate.test.meta.UpdateRecipeProvider", date = "Fri, 9 Jun 2023 04:03:23 GMT")
    public static void offerNetheriteUpgradeRecipe(Consumer<RecipeJsonProvider> p_251614_, Item p_250046_, RecipeCategory p_248986_, Item p_250389_) { RecipeProvider.offerNetheriteUpgradeRecipe(p_251614_, p_250046_, p_248986_, p_250389_); }

    /** Generated override to expose protected method: {@link RecipeProvider#offerSmithingTrimRecipe} */
    @Generated(value = "com.tterrag.registrate.test.meta.UpdateRecipeProvider", date = "Fri, 9 Jun 2023 04:03:23 GMT")
    public static void offerSmithingTrimRecipe(Consumer<RecipeJsonProvider> p_285086_, Item p_285461_, Identifier p_285044_) { RecipeProvider.offerSmithingTrimRecipe(p_285086_, p_285461_, p_285044_); }

    /** Generated override to expose protected method: {@link RecipeProvider#offer2x2CompactingRecipe} */
    @Generated(value = "com.tterrag.registrate.test.meta.UpdateRecipeProvider", date = "Fri, 9 Jun 2023 04:03:23 GMT")
    public static void offer2x2CompactingRecipe(Consumer<RecipeJsonProvider> p_248860_, RecipeCategory p_250881_, ItemConvertible p_252184_, ItemConvertible p_249710_) { RecipeProvider.offer2x2CompactingRecipe(p_248860_, p_250881_, p_252184_, p_249710_); }

    /** Generated override to expose protected method: {@link RecipeProvider#offerCompactingRecipe} */
    @Generated(value = "com.tterrag.registrate.test.meta.UpdateRecipeProvider", date = "Fri, 9 Jun 2023 04:03:23 GMT")
    public static void offerCompactingRecipe(Consumer<RecipeJsonProvider> p_259036_, RecipeCategory p_259247_, ItemConvertible p_259376_, ItemConvertible p_259717_, String p_260308_) { RecipeProvider.offerCompactingRecipe(p_259036_, p_259247_, p_259376_, p_259717_, p_260308_); }

    /** Generated override to expose protected method: {@link RecipeProvider#offerCompactingRecipe} */
    @Generated(value = "com.tterrag.registrate.test.meta.UpdateRecipeProvider", date = "Fri, 9 Jun 2023 04:03:23 GMT")
    public static void offerCompactingRecipe(Consumer<RecipeJsonProvider> p_260012_, RecipeCategory p_259186_, ItemConvertible p_259360_, ItemConvertible p_259263_) { RecipeProvider.offerCompactingRecipe(p_260012_, p_259186_, p_259360_, p_259263_); }

    /** Generated override to expose protected method: {@link RecipeProvider#offerPlanksRecipe2} */
    @Generated(value = "com.tterrag.registrate.test.meta.UpdateRecipeProvider", date = "Fri, 9 Jun 2023 04:03:23 GMT")
    public static void offerPlanksRecipe2(Consumer<RecipeJsonProvider> p_259712_, ItemConvertible p_259052_, TagKey<Item> p_259045_, int p_259471_) { RecipeProvider.offerPlanksRecipe2(p_259712_, p_259052_, p_259045_, p_259471_); }

    /** Generated override to expose protected method: {@link RecipeProvider#offerPlanksRecipe} */
    @Generated(value = "com.tterrag.registrate.test.meta.UpdateRecipeProvider", date = "Fri, 9 Jun 2023 04:03:23 GMT")
    public static void offerPlanksRecipe(Consumer<RecipeJsonProvider> p_259910_, ItemConvertible p_259193_, TagKey<Item> p_259818_, int p_259807_) { RecipeProvider.offerPlanksRecipe(p_259910_, p_259193_, p_259818_, p_259807_); }

    /** Generated override to expose protected method: {@link RecipeProvider#offerBarkBlockRecipe} */
    @Generated(value = "com.tterrag.registrate.test.meta.UpdateRecipeProvider", date = "Fri, 9 Jun 2023 04:03:23 GMT")
    public static void offerBarkBlockRecipe(Consumer<RecipeJsonProvider> p_126003_, ItemConvertible p_126004_, ItemConvertible p_126005_) { RecipeProvider.offerBarkBlockRecipe(p_126003_, p_126004_, p_126005_); }

    /** Generated override to expose protected method: {@link RecipeProvider#offerBoatRecipe} */
    @Generated(value = "com.tterrag.registrate.test.meta.UpdateRecipeProvider", date = "Fri, 9 Jun 2023 04:03:23 GMT")
    public static void offerBoatRecipe(Consumer<RecipeJsonProvider> p_126022_, ItemConvertible p_126023_, ItemConvertible p_126024_) { RecipeProvider.offerBoatRecipe(p_126022_, p_126023_, p_126024_); }

    /** Generated override to expose protected method: {@link RecipeProvider#offerChestBoatRecipe} */
    @Generated(value = "com.tterrag.registrate.test.meta.UpdateRecipeProvider", date = "Fri, 9 Jun 2023 04:03:23 GMT")
    public static void offerChestBoatRecipe(Consumer<RecipeJsonProvider> p_236372_, ItemConvertible p_236373_, ItemConvertible p_236374_) { RecipeProvider.offerChestBoatRecipe(p_236372_, p_236373_, p_236374_); }

    /** Generated override to expose protected method: {@link RecipeProvider#createTransmutationRecipe} */
    @Generated(value = "com.tterrag.registrate.test.meta.UpdateRecipeProvider", date = "Fri, 9 Jun 2023 04:03:23 GMT")
    public static CraftingRecipeJsonBuilder method_33542(ItemConvertible p_176659_, Ingredient p_176660_) { return RecipeProvider.createTransmutationRecipe(p_176659_, p_176660_); }

    /** Generated override to expose protected method: {@link RecipeProvider#createDoorRecipe} */
    @Generated(value = "com.tterrag.registrate.test.meta.UpdateRecipeProvider", date = "Fri, 9 Jun 2023 04:03:23 GMT")
    public static CraftingRecipeJsonBuilder createDoorRecipe(ItemConvertible p_176671_, Ingredient p_176672_) { return RecipeProvider.createDoorRecipe(p_176671_, p_176672_); }

    /** Generated override to expose protected method: {@link RecipeProvider#createFenceRecipe} */
    @Generated(value = "com.tterrag.registrate.test.meta.UpdateRecipeProvider", date = "Fri, 9 Jun 2023 04:03:23 GMT")
    public static CraftingRecipeJsonBuilder method_33546(ItemConvertible p_176679_, Ingredient p_176680_) { return RecipeProvider.createFenceRecipe(p_176679_, p_176680_); }

    /** Generated override to expose protected method: {@link RecipeProvider#createFenceGateRecipe} */
    @Generated(value = "com.tterrag.registrate.test.meta.UpdateRecipeProvider", date = "Fri, 9 Jun 2023 04:03:23 GMT")
    public static CraftingRecipeJsonBuilder method_33548(ItemConvertible p_176685_, Ingredient p_176686_) { return RecipeProvider.createFenceGateRecipe(p_176685_, p_176686_); }

    /** Generated override to expose protected method: {@link RecipeProvider#offerPressurePlateRecipe} */
    @Generated(value = "com.tterrag.registrate.test.meta.UpdateRecipeProvider", date = "Fri, 9 Jun 2023 04:03:23 GMT")
    public static void offerPressurePlateRecipe(Consumer<RecipeJsonProvider> p_176691_, ItemConvertible p_176692_, ItemConvertible p_176693_) { RecipeProvider.offerPressurePlateRecipe(p_176691_, p_176692_, p_176693_); }

    /** Generated override to expose protected method: {@link RecipeProvider#createPressurePlateRecipe} */
    @Generated(value = "com.tterrag.registrate.test.meta.UpdateRecipeProvider", date = "Fri, 9 Jun 2023 04:03:23 GMT")
    public static CraftingRecipeJsonBuilder method_32806(RecipeCategory p_251447_, ItemConvertible p_251989_, Ingredient p_249211_) { return RecipeProvider.createPressurePlateRecipe(p_251447_, p_251989_, p_249211_); }

    /** Generated override to expose protected method: {@link RecipeProvider#offerSlabRecipe} */
    @Generated(value = "com.tterrag.registrate.test.meta.UpdateRecipeProvider", date = "Fri, 9 Jun 2023 04:03:23 GMT")
    public static void offerSlabRecipe(Consumer<RecipeJsonProvider> p_248880_, RecipeCategory p_251848_, ItemConvertible p_249368_, ItemConvertible p_252133_) { RecipeProvider.offerSlabRecipe(p_248880_, p_251848_, p_249368_, p_252133_); }

    /** Generated override to expose protected method: {@link RecipeProvider#createSlabRecipe} */
    @Generated(value = "com.tterrag.registrate.test.meta.UpdateRecipeProvider", date = "Fri, 9 Jun 2023 04:03:23 GMT")
    public static CraftingRecipeJsonBuilder createSlabRecipe(RecipeCategory p_251707_, ItemConvertible p_251284_, Ingredient p_248824_) { return RecipeProvider.createSlabRecipe(p_251707_, p_251284_, p_248824_); }

    /** Generated override to expose protected method: {@link RecipeProvider#createStairsRecipe} */
    @Generated(value = "com.tterrag.registrate.test.meta.UpdateRecipeProvider", date = "Fri, 9 Jun 2023 04:03:23 GMT")
    public static CraftingRecipeJsonBuilder createStairsRecipe(ItemConvertible p_176711_, Ingredient p_176712_) { return RecipeProvider.createStairsRecipe(p_176711_, p_176712_); }

    /** Generated override to expose protected method: {@link RecipeProvider#createTrapdoorRecipe} */
    @Generated(value = "com.tterrag.registrate.test.meta.UpdateRecipeProvider", date = "Fri, 9 Jun 2023 04:03:23 GMT")
    public static CraftingRecipeJsonBuilder method_33553(ItemConvertible p_176721_, Ingredient p_176722_) { return RecipeProvider.createTrapdoorRecipe(p_176721_, p_176722_); }

    /** Generated override to expose protected method: {@link RecipeProvider#createSignRecipe} */
    @Generated(value = "com.tterrag.registrate.test.meta.UpdateRecipeProvider", date = "Fri, 9 Jun 2023 04:03:23 GMT")
    public static CraftingRecipeJsonBuilder method_33555(ItemConvertible p_176727_, Ingredient p_176728_) { return RecipeProvider.createSignRecipe(p_176727_, p_176728_); }

    /** Generated override to expose protected method: {@link RecipeProvider#offerHangingSignRecipe} */
    @Generated(value = "com.tterrag.registrate.test.meta.UpdateRecipeProvider", date = "Fri, 9 Jun 2023 04:03:23 GMT")
    public static void offerHangingSignRecipe(Consumer<RecipeJsonProvider> p_250663_, ItemConvertible p_252355_, ItemConvertible p_250437_) { RecipeProvider.offerHangingSignRecipe(p_250663_, p_252355_, p_250437_); }

    /** Generated override to expose protected method: {@link RecipeProvider#offerDyeableRecipes} */
    @Generated(value = "com.tterrag.registrate.test.meta.UpdateRecipeProvider", date = "Fri, 9 Jun 2023 04:03:23 GMT")
    public static void offerDyeableRecipes(Consumer<RecipeJsonProvider> p_289666_, List<Item> p_289675_, List<Item> p_289672_, String p_289641_) { RecipeProvider.offerDyeableRecipes(p_289666_, p_289675_, p_289672_, p_289641_); }

    /** Generated override to expose protected method: {@link RecipeProvider#offerCarpetRecipe} */
    @Generated(value = "com.tterrag.registrate.test.meta.UpdateRecipeProvider", date = "Fri, 9 Jun 2023 04:03:23 GMT")
    public static void offerCarpetRecipe(Consumer<RecipeJsonProvider> p_176717_, ItemConvertible p_176718_, ItemConvertible p_176719_) { RecipeProvider.offerCarpetRecipe(p_176717_, p_176718_, p_176719_); }

    /** Generated override to expose protected method: {@link RecipeProvider#offerBedRecipe} */
    @Generated(value = "com.tterrag.registrate.test.meta.UpdateRecipeProvider", date = "Fri, 9 Jun 2023 04:03:23 GMT")
    public static void offerBedRecipe(Consumer<RecipeJsonProvider> p_126074_, ItemConvertible p_126075_, ItemConvertible p_126076_) { RecipeProvider.offerBedRecipe(p_126074_, p_126075_, p_126076_); }

    /** Generated override to expose protected method: {@link RecipeProvider#offerBannerRecipe} */
    @Generated(value = "com.tterrag.registrate.test.meta.UpdateRecipeProvider", date = "Fri, 9 Jun 2023 04:03:23 GMT")
    public static void offerBannerRecipe(Consumer<RecipeJsonProvider> p_126082_, ItemConvertible p_126083_, ItemConvertible p_126084_) { RecipeProvider.offerBannerRecipe(p_126082_, p_126083_, p_126084_); }

    /** Generated override to expose protected method: {@link RecipeProvider#offerStainedGlassDyeingRecipe} */
    @Generated(value = "com.tterrag.registrate.test.meta.UpdateRecipeProvider", date = "Fri, 9 Jun 2023 04:03:23 GMT")
    public static void offerStainedGlassDyeingRecipe(Consumer<RecipeJsonProvider> p_126086_, ItemConvertible p_126087_, ItemConvertible p_126088_) { RecipeProvider.offerStainedGlassDyeingRecipe(p_126086_, p_126087_, p_126088_); }

    /** Generated override to expose protected method: {@link RecipeProvider#offerStainedGlassPaneRecipe} */
    @Generated(value = "com.tterrag.registrate.test.meta.UpdateRecipeProvider", date = "Fri, 9 Jun 2023 04:03:23 GMT")
    public static void offerStainedGlassPaneRecipe(Consumer<RecipeJsonProvider> p_126090_, ItemConvertible p_126091_, ItemConvertible p_126092_) { RecipeProvider.offerStainedGlassPaneRecipe(p_126090_, p_126091_, p_126092_); }

    /** Generated override to expose protected method: {@link RecipeProvider#offerStainedGlassPaneDyeingRecipe} */
    @Generated(value = "com.tterrag.registrate.test.meta.UpdateRecipeProvider", date = "Fri, 9 Jun 2023 04:03:23 GMT")
    public static void offerStainedGlassPaneDyeingRecipe(Consumer<RecipeJsonProvider> p_126094_, ItemConvertible p_126095_, ItemConvertible p_126096_) { RecipeProvider.offerStainedGlassPaneDyeingRecipe(p_126094_, p_126095_, p_126096_); }

    /** Generated override to expose protected method: {@link RecipeProvider#offerTerracottaDyeingRecipe} */
    @Generated(value = "com.tterrag.registrate.test.meta.UpdateRecipeProvider", date = "Fri, 9 Jun 2023 04:03:23 GMT")
    public static void offerTerracottaDyeingRecipe(Consumer<RecipeJsonProvider> p_126098_, ItemConvertible p_126099_, ItemConvertible p_126100_) { RecipeProvider.offerTerracottaDyeingRecipe(p_126098_, p_126099_, p_126100_); }

    /** Generated override to expose protected method: {@link RecipeProvider#offerConcretePowderDyeingRecipe} */
    @Generated(value = "com.tterrag.registrate.test.meta.UpdateRecipeProvider", date = "Fri, 9 Jun 2023 04:03:23 GMT")
    public static void offerConcretePowderDyeingRecipe(Consumer<RecipeJsonProvider> p_126102_, ItemConvertible p_126103_, ItemConvertible p_126104_) { RecipeProvider.offerConcretePowderDyeingRecipe(p_126102_, p_126103_, p_126104_); }

    /** Generated override to expose protected method: {@link RecipeProvider#offerCandleDyeingRecipe} */
    @Generated(value = "com.tterrag.registrate.test.meta.UpdateRecipeProvider", date = "Fri, 9 Jun 2023 04:03:23 GMT")
    public static void offerCandleDyeingRecipe(Consumer<RecipeJsonProvider> p_176543_, ItemConvertible p_176544_, ItemConvertible p_176545_) { RecipeProvider.offerCandleDyeingRecipe(p_176543_, p_176544_, p_176545_); }

    /** Generated override to expose protected method: {@link RecipeProvider#offerWallRecipe} */
    @Generated(value = "com.tterrag.registrate.test.meta.UpdateRecipeProvider", date = "Fri, 9 Jun 2023 04:03:23 GMT")
    public static void offerWallRecipe(Consumer<RecipeJsonProvider> p_251034_, RecipeCategory p_251148_, ItemConvertible p_250499_, ItemConvertible p_249970_) { RecipeProvider.offerWallRecipe(p_251034_, p_251148_, p_250499_, p_249970_); }

    /** Generated override to expose protected method: {@link RecipeProvider#getWallRecipe} */
    @Generated(value = "com.tterrag.registrate.test.meta.UpdateRecipeProvider", date = "Fri, 9 Jun 2023 04:03:23 GMT")
    public static CraftingRecipeJsonBuilder method_33531(RecipeCategory p_249083_, ItemConvertible p_250754_, Ingredient p_250311_) { return RecipeProvider.getWallRecipe(p_249083_, p_250754_, p_250311_); }

    /** Generated override to expose protected method: {@link RecipeProvider#offerPolishedStoneRecipe} */
    @Generated(value = "com.tterrag.registrate.test.meta.UpdateRecipeProvider", date = "Fri, 9 Jun 2023 04:03:23 GMT")
    public static void offerPolishedStoneRecipe(Consumer<RecipeJsonProvider> p_251348_, RecipeCategory p_248719_, ItemConvertible p_250032_, ItemConvertible p_250021_) { RecipeProvider.offerPolishedStoneRecipe(p_251348_, p_248719_, p_250032_, p_250021_); }

    /** Generated override to expose protected method: {@link RecipeProvider#createCondensingRecipe} */
    @Generated(value = "com.tterrag.registrate.test.meta.UpdateRecipeProvider", date = "Fri, 9 Jun 2023 04:03:23 GMT")
    public static CraftingRecipeJsonBuilder method_33537(RecipeCategory p_249131_, ItemConvertible p_251242_, Ingredient p_251412_) { return RecipeProvider.createCondensingRecipe(p_249131_, p_251242_, p_251412_); }

    /** Generated override to expose protected method: {@link RecipeProvider#offerCutCopperRecipe} */
    @Generated(value = "com.tterrag.registrate.test.meta.UpdateRecipeProvider", date = "Fri, 9 Jun 2023 04:03:23 GMT")
    public static void offerCutCopperRecipe(Consumer<RecipeJsonProvider> p_248712_, RecipeCategory p_252306_, ItemConvertible p_249686_, ItemConvertible p_251100_) { RecipeProvider.offerCutCopperRecipe(p_248712_, p_252306_, p_249686_, p_251100_); }

    /** Generated override to expose protected method: {@link RecipeProvider#createCutCopperRecipe} */
    @Generated(value = "com.tterrag.registrate.test.meta.UpdateRecipeProvider", date = "Fri, 9 Jun 2023 04:03:23 GMT")
    public static ShapedRecipeJsonBuilder method_36547(RecipeCategory p_250895_, ItemConvertible p_251147_, Ingredient p_251563_) { return RecipeProvider.createCutCopperRecipe(p_250895_, p_251147_, p_251563_); }

    /** Generated override to expose protected method: {@link RecipeProvider#offerChiseledBlockRecipe} */
    @Generated(value = "com.tterrag.registrate.test.meta.UpdateRecipeProvider", date = "Fri, 9 Jun 2023 04:03:23 GMT")
    public static void offerChiseledBlockRecipe(Consumer<RecipeJsonProvider> p_250120_, RecipeCategory p_251604_, ItemConvertible p_251049_, ItemConvertible p_252267_) { RecipeProvider.offerChiseledBlockRecipe(p_250120_, p_251604_, p_251049_, p_252267_); }

    /** Generated override to expose protected method: {@link RecipeProvider#offerMosaicRecipe} */
    @Generated(value = "com.tterrag.registrate.test.meta.UpdateRecipeProvider", date = "Fri, 9 Jun 2023 04:03:23 GMT")
    public static void offerMosaicRecipe(Consumer<RecipeJsonProvider> p_249200_, RecipeCategory p_248788_, ItemConvertible p_251925_, ItemConvertible p_252242_) { RecipeProvider.offerMosaicRecipe(p_249200_, p_248788_, p_251925_, p_252242_); }

    /** Generated override to expose protected method: {@link RecipeProvider#createChiseledBlockRecipe} */
    @Generated(value = "com.tterrag.registrate.test.meta.UpdateRecipeProvider", date = "Fri, 9 Jun 2023 04:03:23 GMT")
    public static ShapedRecipeJsonBuilder createChiseledBlockRecipe(RecipeCategory p_251755_, ItemConvertible p_249782_, Ingredient p_250087_) { return RecipeProvider.createChiseledBlockRecipe(p_251755_, p_249782_, p_250087_); }

    /** Generated override to expose protected method: {@link RecipeProvider#offerStonecuttingRecipe} */
    @Generated(value = "com.tterrag.registrate.test.meta.UpdateRecipeProvider", date = "Fri, 9 Jun 2023 04:03:23 GMT")
    public static void offerStonecuttingRecipe(Consumer<RecipeJsonProvider> p_251589_, RecipeCategory p_248911_, ItemConvertible p_251265_, ItemConvertible p_250033_) { RecipeProvider.offerStonecuttingRecipe(p_251589_, p_248911_, p_251265_, p_250033_); }

    /** Generated override to expose protected method: {@link RecipeProvider#offerStonecuttingRecipe} */
    @Generated(value = "com.tterrag.registrate.test.meta.UpdateRecipeProvider", date = "Fri, 9 Jun 2023 04:03:23 GMT")
    public static void offerStonecuttingRecipe(Consumer<RecipeJsonProvider> p_249145_, RecipeCategory p_250609_, ItemConvertible p_251254_, ItemConvertible p_249666_, int p_251462_) { RecipeProvider.offerStonecuttingRecipe(p_249145_, p_250609_, p_251254_, p_249666_, p_251462_); }

    /** Generated override to expose protected method: {@link RecipeProvider#offerCrackingRecipe} */
    @Generated(value = "com.tterrag.registrate.test.meta.UpdateRecipeProvider", date = "Fri, 9 Jun 2023 04:03:23 GMT")
    public static void method_34662(Consumer<RecipeJsonProvider> p_176740_, ItemConvertible p_176741_, ItemConvertible p_176742_) { RecipeProvider.offerCrackingRecipe(p_176740_, p_176741_, p_176742_); }

    /** Generated override to expose protected method: {@link RecipeProvider#offerReversibleCompactingRecipes} */
    @Generated(value = "com.tterrag.registrate.test.meta.UpdateRecipeProvider", date = "Fri, 9 Jun 2023 04:03:23 GMT")
    public static void offerReversibleCompactingRecipes(Consumer<RecipeJsonProvider> p_249580_, RecipeCategory p_251203_, ItemConvertible p_251689_, RecipeCategory p_251376_, ItemConvertible p_248771_) { RecipeProvider.offerReversibleCompactingRecipes(p_249580_, p_251203_, p_251689_, p_251376_, p_248771_); }

    /** Generated override to expose protected method: {@link RecipeProvider#offerReversibleCompactingRecipesWithCompactingRecipeGroup} */
    @Generated(value = "com.tterrag.registrate.test.meta.UpdateRecipeProvider", date = "Fri, 9 Jun 2023 04:03:23 GMT")
    public static void offerReversibleCompactingRecipesWithCompactingRecipeGroup(Consumer<RecipeJsonProvider> p_250488_, RecipeCategory p_250885_, ItemConvertible p_251651_, RecipeCategory p_250874_, ItemConvertible p_248576_, String p_250171_, String p_249386_) { RecipeProvider.offerReversibleCompactingRecipesWithCompactingRecipeGroup(p_250488_, p_250885_, p_251651_, p_250874_, p_248576_, p_250171_, p_249386_); }

    /** Generated override to expose protected method: {@link RecipeProvider#offerReversibleCompactingRecipesWithReverseRecipeGroup} */
    @Generated(value = "com.tterrag.registrate.test.meta.UpdateRecipeProvider", date = "Fri, 9 Jun 2023 04:03:23 GMT")
    public static void offerReversibleCompactingRecipesWithReverseRecipeGroup(Consumer<RecipeJsonProvider> p_250320_, RecipeCategory p_248979_, ItemConvertible p_249101_, RecipeCategory p_252036_, ItemConvertible p_250886_, String p_248768_, String p_250847_) { RecipeProvider.offerReversibleCompactingRecipesWithReverseRecipeGroup(p_250320_, p_248979_, p_249101_, p_252036_, p_250886_, p_248768_, p_250847_); }

    /** Generated override to expose protected method: {@link RecipeProvider#offerSmithingTemplateCopyingRecipe} */
    @Generated(value = "com.tterrag.registrate.test.meta.UpdateRecipeProvider", date = "Fri, 9 Jun 2023 04:03:23 GMT")
    public static void offerSmithingTemplateCopyingRecipe(Consumer<RecipeJsonProvider> p_267061_, ItemConvertible p_266974_, TagKey<Item> p_267283_) { RecipeProvider.offerSmithingTemplateCopyingRecipe(p_267061_, p_266974_, p_267283_); }

    /** Generated override to expose protected method: {@link RecipeProvider#offerSmithingTemplateCopyingRecipe} */
    @Generated(value = "com.tterrag.registrate.test.meta.UpdateRecipeProvider", date = "Fri, 9 Jun 2023 04:03:23 GMT")
    public static void offerSmithingTemplateCopyingRecipe(Consumer<RecipeJsonProvider> p_266734_, ItemConvertible p_267133_, ItemConvertible p_267023_) { RecipeProvider.offerSmithingTemplateCopyingRecipe(p_266734_, p_267133_, p_267023_); }

    /** Generated override to expose protected method: {@link RecipeProvider#generateCookingRecipes} */
    @Generated(value = "com.tterrag.registrate.test.meta.UpdateRecipeProvider", date = "Fri, 9 Jun 2023 04:03:23 GMT")
    public static void generateCookingRecipes(Consumer<RecipeJsonProvider> p_126007_, String p_126008_, RecipeSerializer<? extends AbstractCookingRecipe> p_250529_, int p_126010_) { RecipeProvider.generateCookingRecipes(p_126007_, p_126008_, p_250529_, p_126010_); }

    /** Generated override to expose protected method: {@link RecipeProvider#offerFoodCookingRecipe} */
    @Generated(value = "com.tterrag.registrate.test.meta.UpdateRecipeProvider", date = "Fri, 9 Jun 2023 04:03:23 GMT")
    public static void method_36448(Consumer<RecipeJsonProvider> p_249398_, String p_249709_, RecipeSerializer<? extends AbstractCookingRecipe> p_251876_, int p_249258_, ItemConvertible p_250669_, ItemConvertible p_250224_, float p_252138_) { RecipeProvider.offerFoodCookingRecipe(p_249398_, p_249709_, p_251876_, p_249258_, p_250669_, p_250224_, p_252138_); }

    /** Generated override to expose protected method: {@link RecipeProvider#offerWaxingRecipes} */
    @Generated(value = "com.tterrag.registrate.test.meta.UpdateRecipeProvider", date = "Fri, 9 Jun 2023 04:03:23 GMT")
    public static void offerWaxingRecipes(Consumer<RecipeJsonProvider> p_176611_) { RecipeProvider.offerWaxingRecipes(p_176611_); }

    /** Generated override to expose protected method: {@link RecipeProvider#generateFamily} */
    @Generated(value = "com.tterrag.registrate.test.meta.UpdateRecipeProvider", date = "Fri, 9 Jun 2023 04:03:23 GMT")
    public static void generateFamily(Consumer<RecipeJsonProvider> p_176581_, BlockFamily p_176582_) { RecipeProvider.generateFamily(p_176581_, p_176582_); }

    /** Generated override to expose protected method: {@link RecipeProvider#getVariantRecipeInput} */
    @Generated(value = "com.tterrag.registrate.test.meta.UpdateRecipeProvider", date = "Fri, 9 Jun 2023 04:03:23 GMT")
    public static Block method_33533(BlockFamily p_176524_, BlockFamily.Variant p_176525_) { return RecipeProvider.getVariantRecipeInput(p_176524_, p_176525_); }

    /** Generated override to expose protected method: {@link RecipeProvider#requireEnteringFluid} */
    @Generated(value = "com.tterrag.registrate.test.meta.UpdateRecipeProvider", date = "Fri, 9 Jun 2023 04:03:23 GMT")
    public static EnterBlockCriterion.Conditions method_10422(Block p_125980_) { return RecipeProvider.requireEnteringFluid(p_125980_); }

    /** Generated override to expose protected method: {@link RecipeProvider#conditionsFromItem} */
    @Generated(value = "com.tterrag.registrate.test.meta.UpdateRecipeProvider", date = "Fri, 9 Jun 2023 04:03:23 GMT")
    public static InventoryChangedCriterion.Conditions method_35914(NumberRange.IntRange p_176521_, ItemConvertible p_176522_) { return RecipeProvider.conditionsFromItem(p_176521_, p_176522_); }

    /** Generated override to expose protected method: {@link RecipeProvider#conditionsFromItem} */
    @Generated(value = "com.tterrag.registrate.test.meta.UpdateRecipeProvider", date = "Fri, 9 Jun 2023 04:03:23 GMT")
    public static InventoryChangedCriterion.Conditions conditionsFromItem(ItemConvertible p_125978_) { return RecipeProvider.conditionsFromItem(p_125978_); }

    /** Generated override to expose protected method: {@link RecipeProvider#conditionsFromItem} */
    @Generated(value = "com.tterrag.registrate.test.meta.UpdateRecipeProvider", date = "Fri, 9 Jun 2023 04:03:23 GMT")
    public static InventoryChangedCriterion.Conditions conditionsFromTag(TagKey<Item> p_206407_) { return RecipeProvider.conditionsFromTag(p_206407_); }

    /** Generated override to expose protected method: {@link RecipeProvider#conditionsFromItemPredicates} */
    @Generated(value = "com.tterrag.registrate.test.meta.UpdateRecipeProvider", date = "Fri, 9 Jun 2023 04:03:23 GMT")
    public static InventoryChangedCriterion.Conditions method_10423(ItemPredicate... p_126012_) { return RecipeProvider.conditionsFromItemPredicates(p_126012_); }

    /** Generated override to expose protected method: {@link RecipeProvider#hasItem} */
    @Generated(value = "com.tterrag.registrate.test.meta.UpdateRecipeProvider", date = "Fri, 9 Jun 2023 04:03:23 GMT")
    public static String hasItem(ItemConvertible p_176603_) { return RecipeProvider.hasItem(p_176603_); }

    /** Generated override to expose protected method: {@link RecipeProvider#getItemPath} */
    @Generated(value = "com.tterrag.registrate.test.meta.UpdateRecipeProvider", date = "Fri, 9 Jun 2023 04:03:23 GMT")
    public static String getItemPath(ItemConvertible p_176633_) { return RecipeProvider.getItemPath(p_176633_); }

    /** Generated override to expose protected method: {@link RecipeProvider#getRecipeName} */
    @Generated(value = "com.tterrag.registrate.test.meta.UpdateRecipeProvider", date = "Fri, 9 Jun 2023 04:03:23 GMT")
    public static String getRecipeName(ItemConvertible p_176645_) { return RecipeProvider.getRecipeName(p_176645_); }

    /** Generated override to expose protected method: {@link RecipeProvider#convertBetween} */
    @Generated(value = "com.tterrag.registrate.test.meta.UpdateRecipeProvider", date = "Fri, 9 Jun 2023 04:03:23 GMT")
    public static String convertBetween(ItemConvertible p_176518_, ItemConvertible p_176519_) { return RecipeProvider.convertBetween(p_176518_, p_176519_); }

    /** Generated override to expose protected method: {@link RecipeProvider#getSmeltingItemPath} */
    @Generated(value = "com.tterrag.registrate.test.meta.UpdateRecipeProvider", date = "Fri, 9 Jun 2023 04:03:23 GMT")
    public static String getSmeltingItemPath(ItemConvertible p_176657_) { return RecipeProvider.getSmeltingItemPath(p_176657_); }

    /** Generated override to expose protected method: {@link RecipeProvider#getBlastingItemPath} */
    @Generated(value = "com.tterrag.registrate.test.meta.UpdateRecipeProvider", date = "Fri, 9 Jun 2023 04:03:23 GMT")
    public static String getBlastingItemPath(ItemConvertible p_176669_) { return RecipeProvider.getBlastingItemPath(p_176669_); }

    // GENERATED END
}

package com.tterrag.registrate.util;

import org.jetbrains.annotations.ApiStatus;
import java.util.function.BiConsumer;
import java.util.function.BooleanSupplier;
import java.util.function.Supplier;
import net.minecraft.item.ItemConvertible;
import net.minecraft.item.ItemGroup;
import net.minecraft.item.ItemStack;
import net.minecraft.resource.featuretoggle.FeatureSet;

public final class CreativeModeTabModifier implements ItemGroup.Entries {
    private final Supplier<FeatureSet> flags;
    private final BooleanSupplier hasPermissions;
    private final BiConsumer<ItemStack, ItemGroup.StackVisibility> acceptFunc;

    @ApiStatus.Internal
    public CreativeModeTabModifier(Supplier<FeatureSet> flags, BooleanSupplier hasPermissions, BiConsumer<ItemStack, ItemGroup.StackVisibility> acceptFunc) {
        this.flags = flags;
        this.hasPermissions = hasPermissions;
        this.acceptFunc = acceptFunc;
    }

    public FeatureSet getFlags() {
        return flags.get();
    }

    public boolean hasPermissions() {
        return hasPermissions.getAsBoolean();
    }

    @Override
    public void add(ItemStack stack, ItemGroup.StackVisibility visibility) {
        acceptFunc.accept(stack, visibility);
    }

    public void accept(Supplier<? extends ItemConvertible> item, ItemGroup.StackVisibility visibility) {
        add(item.get(), visibility);
    }

    public void accept(Supplier<? extends ItemConvertible> item) {
        add(item.get());
    }
}

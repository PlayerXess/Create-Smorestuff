package com.tterrag.registrate.mixin.accessor;

import com.google.common.collect.BiMap;
import net.minecraft.loot.context.LootContextType;
import net.minecraft.loot.context.LootContextTypes;
import net.minecraft.util.Identifier;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(LootContextTypes.class)
public interface LootContextParamSetsAccessor {
    @Accessor
    static BiMap<Identifier, LootContextType> getREGISTRY() {
        throw new UnsupportedOperationException();
    }
}

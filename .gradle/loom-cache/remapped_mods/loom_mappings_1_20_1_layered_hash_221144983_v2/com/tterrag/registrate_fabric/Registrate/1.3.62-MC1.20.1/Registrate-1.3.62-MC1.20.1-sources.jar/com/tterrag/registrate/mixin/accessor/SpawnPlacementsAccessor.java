package com.tterrag.registrate.mixin.accessor;

import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnRestriction;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.world.Heightmap;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(SpawnRestriction.class)
public interface SpawnPlacementsAccessor {
    @Invoker
    static <T extends MobEntity> void callRegister(EntityType<T> entityType, SpawnRestriction.Location type, Heightmap.Type types, SpawnRestriction.SpawnPredicate<T> spawnPredicate) {
        throw new UnsupportedOperationException();
    }
}

package com.tterrag.registrate.fabric;

import net.fabricmc.fabric.api.transfer.v1.fluid.FluidVariant;
import net.fabricmc.fabric.api.transfer.v1.fluid.FluidVariantAttributes;
import net.minecraft.block.BlockState;
import net.minecraft.fluid.FlowableFluid;
import net.minecraft.fluid.Fluid;
import net.minecraft.fluid.FluidState;
import net.minecraft.registry.Registries;
import net.minecraft.util.Util;

public class FluidHelper {
	public static String getDescriptionId(Fluid fluid) {
		return Util.createTranslationKey("fluid", Registries.FLUID.getId(fluid));
	}

	public static int fluidLuminanceFromBlockState(BlockState fluidBlockState) {
		FluidState state = fluidBlockState.getFluidState();
		if (state.isEmpty()) {
			return 0;
		}
		Fluid fluid = state.getFluid();
		state = fluid.getDefaultState(); // FluidVariant.of checks against this
		if (!fluid.isStill(state)) {
			if (fluid instanceof FlowableFluid flowing) {
				fluid = flowing.getStill();
				state = fluid.getDefaultState();
			}
		}
		if (!fluid.isStill(state)) {
			return 0; // checking will crash
		}
		FluidVariant variant = FluidVariant.of(fluid);
		return FluidVariantAttributes.getLuminance(variant);
	}
}

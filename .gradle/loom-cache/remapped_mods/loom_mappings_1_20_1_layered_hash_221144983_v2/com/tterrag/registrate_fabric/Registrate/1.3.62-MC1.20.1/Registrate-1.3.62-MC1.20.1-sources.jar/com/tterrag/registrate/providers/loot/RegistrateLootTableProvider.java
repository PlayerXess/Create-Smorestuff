package com.tterrag.registrate.providers.loot;

import com.google.common.collect.*;
import com.tterrag.registrate.AbstractRegistrate;
import com.tterrag.registrate.fabric.CustomValidationLootProvider;
import com.tterrag.registrate.fabric.NonNullTriFunction;
import com.tterrag.registrate.mixin.accessor.LootContextParamSetsAccessor;
import com.tterrag.registrate.mixin.accessor.LootTableProviderAccessor;
import com.tterrag.registrate.providers.ProviderType;
import com.tterrag.registrate.providers.RegistrateProvider;
import com.tterrag.registrate.util.nullness.NonNullConsumer;
import net.fabricmc.api.EnvType;
import net.fabricmc.fabric.api.datagen.v1.FabricDataGenerator;
import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.minecraft.data.server.loottable.LootTableGenerator;
import net.minecraft.data.server.loottable.LootTableProvider;
import net.minecraft.loot.LootTable;
import net.minecraft.loot.LootTableReporter;
import net.minecraft.loot.context.LootContextType;
import net.minecraft.loot.context.LootContextTypes;
import net.minecraft.util.Identifier;
import org.jetbrains.annotations.NotNull;
import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.util.function.BiConsumer;
import java.util.function.Consumer;
import java.util.function.Supplier;

public class RegistrateLootTableProvider extends LootTableProvider implements RegistrateProvider, CustomValidationLootProvider {

    public interface LootType<T extends RegistrateLootTables> {

        static LootType<RegistrateBlockLootTables> BLOCK = register("block", LootContextTypes.field_1172, RegistrateBlockLootTables::new);
        static LootType<RegistrateEntityLootTables> ENTITY = register("entity", LootContextTypes.field_1173, RegistrateEntityLootTables::new);

        T getLootCreator(AbstractRegistrate<?> parent, Consumer<T> callback, FabricDataOutput output);
        LootContextType getLootSet();

        static <T extends RegistrateLootTables> LootType<T> register(String name, LootContextType set, NonNullTriFunction<AbstractRegistrate, Consumer<T>, FabricDataOutput, T> factory) {
            LootType<T> type = new LootType<T>() {
                @Override
                public T getLootCreator(AbstractRegistrate<?> parent, Consumer<T> callback, FabricDataOutput output) {
                    return factory.apply(parent, callback, output);
                }

                @Override
                public LootContextType getLootSet() {
                    return set;
                }
            };
            LOOT_TYPES.put(name, type);
            return type;
        }
    }

    private static final Map<String, LootType<?>> LOOT_TYPES = new HashMap<>();

    private final AbstractRegistrate<?> parent;

    private final Multimap<LootType<?>, Consumer<? super RegistrateLootTables>> specialLootActions = HashMultimap.create();
    private final Multimap<LootContextType, Consumer<BiConsumer<Identifier, LootTable.Builder>>> lootActions = HashMultimap.create();
    private final Set<RegistrateLootTables> currentLootCreators = new HashSet<>();

    public RegistrateLootTableProvider(AbstractRegistrate<?> parent, FabricDataOutput output) {
        super(output, Set.of(), List.of());
        this.parent = parent;
        ((LootTableProviderAccessor) this).setSubProviders(getTables(output));
    }

    @Override
    public EnvType getSide() {
        return EnvType.SERVER;
    }

    @Override
    public void validate(Map<Identifier, LootTable> tables, LootTableReporter context) {
        currentLootCreators.forEach(c -> c.validate(tables, context));
    }

    @SuppressWarnings("unchecked")
    public <T extends RegistrateLootTables> void addLootAction(LootType<T> type, NonNullConsumer<? extends RegistrateLootTables> action) {
        this.specialLootActions.put(type, (Consumer<? super RegistrateLootTables>) action);
    }

    public void addLootAction(LootContextType set, Consumer<BiConsumer<Identifier, LootTable.Builder>> action) {
        this.lootActions.put(set, action);
    }

    private Supplier<LootTableGenerator> getLootCreator(AbstractRegistrate<?> parent, LootType<?> type, FabricDataOutput output) {
        return () -> {
            RegistrateLootTables creator = type.getLootCreator(parent, cons -> specialLootActions.get(type).forEach(c -> c.accept(cons)), output);
            currentLootCreators.add(creator);
            return creator;
        };
    }

    private static final BiMap<Identifier, LootContextType> SET_REGISTRY = LootContextParamSetsAccessor.getREGISTRY();

    public List<LootTableProvider.LootTypeGenerator> getTables(FabricDataOutput output) {
        parent.genData(ProviderType.LOOT, this);
        currentLootCreators.clear();
        ImmutableList.Builder<LootTableProvider.LootTypeGenerator> builder = ImmutableList.builder();
        for (LootType<?> type : LOOT_TYPES.values()) {
            builder.add(new LootTypeGenerator(getLootCreator(parent, type, output), type.getLootSet()));
        }
        for (LootContextType set : SET_REGISTRY.values()) {
            builder.add(new LootTypeGenerator(() -> callback -> lootActions.get(set).forEach(a -> a.accept(callback)), set));
        }
        return builder.build();
    }
}

package com.simibubi.create.content.decoration.slidingDoor;

import java.util.Arrays;
import java.util.function.Consumer;

import com.simibubi.create.foundation.gui.widget.Label;
import com.simibubi.create.foundation.gui.widget.ScrollInput;
import com.simibubi.create.foundation.gui.widget.SelectionScrollInput;
import com.simibubi.create.foundation.utility.Components;
import com.simibubi.create.foundation.utility.Lang;
import com.simibubi.create.foundation.utility.Pair;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.Direction;

public enum DoorControl {

	ALL, NORTH, EAST, SOUTH, WEST, NONE;

	private static String[] valuesAsString() {
		DoorControl[] values = values();
		return Arrays.stream(values)
			.map(dc -> Lang.asId(dc.name()))
			.toList()
			.toArray(new String[values.length]);
	}

	public boolean matches(Direction doorDirection) {
		return switch (this) {
		case ALL -> true;
		case NORTH -> doorDirection == Direction.field_11043;
		case EAST -> doorDirection == Direction.field_11034;
		case SOUTH -> doorDirection == Direction.field_11035;
		case WEST -> doorDirection == Direction.field_11039;
		default -> false;
		};
	}

	@Environment(EnvType.CLIENT)
	public static Pair<ScrollInput, Label> createWidget(int x, int y, Consumer<DoorControl> callback,
		DoorControl initial) {

		DoorControl playerFacing = NONE;
		Entity cameraEntity = MinecraftClient.getInstance().cameraEntity;
		if (cameraEntity != null) {
			Direction direction = cameraEntity.getHorizontalFacing();
			if (direction == Direction.field_11034)
				playerFacing = EAST;
			if (direction == Direction.field_11039)
				playerFacing = WEST;
			if (direction == Direction.field_11043)
				playerFacing = NORTH;
			if (direction == Direction.field_11035)
				playerFacing = SOUTH;
		}

		Label label = new Label(x + 4, y + 6, Components.empty()).withShadow();
		ScrollInput input = new SelectionScrollInput(x, y, 53, 16)
			.forOptions(Lang.translatedOptions("contraption.door_control", valuesAsString()))
			.titled(Lang.translateDirect("contraption.door_control"))
			.calling(s -> {
				DoorControl mode = values()[s];
				label.text = Lang.translateDirect("contraption.door_control." + Lang.asId(mode.name()) + ".short");
				callback.accept(mode);
			})
			.addHint(Lang.translateDirect("contraption.door_control.player_facing",
				Lang.translateDirect("contraption.door_control." + Lang.asId(playerFacing.name()) + ".short")))
			.setState(initial.ordinal());
		input.onChanged();
		return Pair.of(input, label);
	}

}

package com.simibubi.create.content.kinetics.belt.transport;

import static net.minecraft.util.math.Direction.AxisDirection.field_11060;
import static net.minecraft.util.math.Direction.AxisDirection.field_11056;
import static net.minecraft.entity.MovementType.field_6308;

import java.util.List;
import net.minecraft.block.BlockState;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.block.piston.PistonBehavior;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.decoration.AbstractDecorationEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.state.property.Properties;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Direction.Axis;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.math.Vec3i;
import net.minecraft.world.World;
import com.simibubi.create.AllBlocks;
import com.simibubi.create.content.kinetics.belt.BeltBlock;
import com.simibubi.create.content.kinetics.belt.BeltBlockEntity;
import com.simibubi.create.content.kinetics.belt.BeltPart;
import com.simibubi.create.content.kinetics.belt.BeltSlope;

public class BeltMovementHandler {

	public static class TransportedEntityInfo {
		int ticksSinceLastCollision;
		BlockPos lastCollidedPos;
		BlockState lastCollidedState;

		public TransportedEntityInfo(BlockPos collision, BlockState belt) {
			refresh(collision, belt);
		}

		public void refresh(BlockPos collision, BlockState belt) {
			ticksSinceLastCollision = 0;
			lastCollidedPos = new BlockPos(collision).toImmutable();
			lastCollidedState = belt;
		}

		public TransportedEntityInfo tick() {
			ticksSinceLastCollision++;
			return this;
		}

		public int getTicksSinceLastCollision() {
			return ticksSinceLastCollision;
		}
	}

	public static boolean canBeTransported(Entity entity) {
		if (!entity.isAlive())
			return false;
		if (entity instanceof PlayerEntity && ((PlayerEntity) entity).isSneaking())
			return false;
		return true;
	}

	public static void transportEntity(BeltBlockEntity beltBE, Entity entityIn, TransportedEntityInfo info) {
		BlockPos pos = info.lastCollidedPos;
		World world = beltBE.getWorld();
		BlockEntity be = world.getBlockEntity(pos);
		BlockEntity blockEntityBelowPassenger = world.getBlockEntity(entityIn.getBlockPos());
		BlockState blockState = info.lastCollidedState;
		Direction movementFacing =
			Direction.from(blockState.get(Properties.HORIZONTAL_FACING)
				.getAxis(), beltBE.getSpeed() < 0 ? field_11056 : field_11060);

		boolean collidedWithBelt = be instanceof BeltBlockEntity;
		boolean betweenBelts = blockEntityBelowPassenger instanceof BeltBlockEntity && blockEntityBelowPassenger != be;

		// Don't fight other Belts
		if (!collidedWithBelt || betweenBelts) {
			return;
		}

		// Too slow
		boolean notHorizontal = beltBE.getCachedState()
			.get(BeltBlock.SLOPE) != BeltSlope.HORIZONTAL;
		if (Math.abs(beltBE.getSpeed()) < 1)
			return;

		// Not on top
		if (entityIn.getY() - .25f < pos.getY())
			return;

		// Lock entities in place
		boolean isPlayer = entityIn instanceof PlayerEntity;
		if (entityIn instanceof LivingEntity && !isPlayer) 
			((LivingEntity) entityIn).addStatusEffect(new StatusEffectInstance(StatusEffects.field_5909, 10, 1, false, false));

		final Direction beltFacing = blockState.get(Properties.HORIZONTAL_FACING);
		final BeltSlope slope = blockState.get(BeltBlock.SLOPE);
		final Axis axis = beltFacing.getAxis();
		float movementSpeed = beltBE.getBeltMovementSpeed();
		final Direction movementDirection = Direction.get(axis == Axis.field_11048 ? field_11060 : field_11056, axis);

		Vec3i centeringDirection = Direction.get(field_11056, beltFacing.rotateYClockwise()
			.getAxis())
			.getVector();
		Vec3d movement = Vec3d.of(movementDirection.getVector())
			.multiply(movementSpeed);

		double diffCenter =
			axis == Axis.field_11051 ? (pos.getX() + .5f - entityIn.getX()) : (pos.getZ() + .5f - entityIn.getZ());
		if (Math.abs(diffCenter) > 48 / 64f)
			return;

		BeltPart part = blockState.get(BeltBlock.PART);
		float top = 13 / 16f;
		boolean onSlope = notHorizontal && (part == BeltPart.MIDDLE || part == BeltPart.PULLEY
			|| part == (slope == BeltSlope.UPWARD ? BeltPart.END : BeltPart.START) && entityIn.getY() - pos.getY() < top
			|| part == (slope == BeltSlope.UPWARD ? BeltPart.START : BeltPart.END)
				&& entityIn.getY() - pos.getY() > top);

		boolean movingDown = onSlope && slope == (movementFacing == beltFacing ? BeltSlope.DOWNWARD : BeltSlope.UPWARD);
		boolean movingUp = onSlope && slope == (movementFacing == beltFacing ? BeltSlope.UPWARD : BeltSlope.DOWNWARD);

		if (beltFacing.getAxis() == Axis.field_11051) {
			boolean b = movingDown;
			movingDown = movingUp;
			movingUp = b;
		}

		if (movingUp)
			movement = movement.add(0, Math.abs(axis.choose(movement.x, movement.y, movement.z)), 0);
		if (movingDown)
			movement = movement.add(0, -Math.abs(axis.choose(movement.x, movement.y, movement.z)), 0);

		Vec3d centering = Vec3d.of(centeringDirection).multiply(diffCenter * Math.min(Math.abs(movementSpeed), .1f) * 4);

		if (!(entityIn instanceof LivingEntity)
			|| ((LivingEntity) entityIn).forwardSpeed == 0 && ((LivingEntity) entityIn).sidewaysSpeed == 0)
			movement = movement.add(centering);

		float step = entityIn.getStepHeight();
		if (!isPlayer) 
			entityIn.setStepHeight(1);

		// Entity Collisions
		if (Math.abs(movementSpeed) < .5f) {
			Vec3d checkDistance = movement.normalize()
				.multiply(0.5);
			Box bb = entityIn.getBoundingBox();
			Box checkBB = new Box(bb.minX, bb.minY, bb.minZ, bb.maxX, bb.maxY, bb.maxZ);
			checkBB = checkBB.offset(checkDistance)
				.expand(-Math.abs(checkDistance.x), -Math.abs(checkDistance.y), -Math.abs(checkDistance.z));
			List<Entity> list = world.getOtherEntities(entityIn, checkBB);
			list.removeIf(e -> shouldIgnoreBlocking(entityIn, e));
			if (!list.isEmpty()) {
				entityIn.setVelocity(0, 0, 0);
				info.ticksSinceLastCollision--;
				return;
			}
		}

		entityIn.fallDistance = 0;

		if (movingUp) {
			float minVelocity = .13f;
			float yMovement = (float) -(Math.max(Math.abs(movement.y), minVelocity));
			entityIn.move(field_6308, new Vec3d(0, yMovement, 0));
			entityIn.move(field_6308, movement.multiply(1, 0, 1));
		} else if (movingDown) {
			entityIn.move(field_6308, movement.multiply(1, 0, 1));
			entityIn.move(field_6308, movement.multiply(0, 1, 0));
		} else {
			entityIn.move(field_6308, movement);
		}
		
		entityIn.setOnGround(true);

		if (!isPlayer)
			entityIn.setStepHeight(step);

		boolean movedPastEndingSlope = onSlope && (AllBlocks.BELT.has(world.getBlockState(entityIn.getBlockPos()))
			|| AllBlocks.BELT.has(world.getBlockState(entityIn.getBlockPos()
				.down())));

		if (movedPastEndingSlope && !movingDown && Math.abs(movementSpeed) > 0)
			entityIn.setPosition(entityIn.getX(), entityIn.getY() + movement.y, entityIn.getZ());
		if (movedPastEndingSlope) {
			entityIn.setVelocity(movement);
			entityIn.velocityModified = true;
		}
		
	}

	public static boolean shouldIgnoreBlocking(Entity me, Entity other) {
		if (other instanceof AbstractDecorationEntity)
			return true;
		if (other.getPistonBehavior() == PistonBehavior.field_15975)
			return true;
		return isRidingOrBeingRiddenBy(me, other);
	}

	public static boolean isRidingOrBeingRiddenBy(Entity me, Entity other) {
		for (Entity entity : me.getPassengerList()) {
			if (entity.equals(other))
				return true;
			if (isRidingOrBeingRiddenBy(entity, other))
				return true;
		}
		return false;
	}

}

package com.simibubi.create.content.equipment.blueprint;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.IdentityHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import com.mojang.blaze3d.systems.RenderSystem;
import com.simibubi.create.AllItems;
import com.simibubi.create.content.equipment.blueprint.BlueprintEntity.BlueprintCraftingInventory;
import com.simibubi.create.content.equipment.blueprint.BlueprintEntity.BlueprintSection;
import com.simibubi.create.content.logistics.filter.AttributeFilterMenu.WhitelistMode;
import com.simibubi.create.content.logistics.filter.FilterItem;
import com.simibubi.create.content.logistics.filter.FilterItemStack;
import com.simibubi.create.content.logistics.filter.ItemAttribute;
import com.simibubi.create.content.trains.track.TrackPlacement.PlacementInfo;
import com.simibubi.create.foundation.gui.AllGuiTextures;
import com.simibubi.create.foundation.gui.element.GuiGameElement;
import com.simibubi.create.foundation.utility.AnimationTickHolder;
import com.simibubi.create.foundation.utility.Pair;

import io.github.fabricators_of_create.porting_lib.transfer.TransferUtil;
import io.github.fabricators_of_create.porting_lib.transfer.item.ItemHandlerHelper;
import io.github.fabricators_of_create.porting_lib.transfer.item.ItemStackHandler;

import net.fabricmc.fabric.api.transfer.v1.item.ItemVariant;
import net.fabricmc.fabric.api.transfer.v1.item.PlayerInventoryStorage;
import net.fabricmc.fabric.api.transfer.v1.storage.StorageUtil;
import net.fabricmc.fabric.api.transfer.v1.storage.base.ResourceAmount;
import net.fabricmc.fabric.api.transfer.v1.transaction.Transaction;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.util.Window;
import net.minecraft.inventory.RecipeInputInventory;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.nbt.NbtList;
import net.minecraft.recipe.CraftingRecipe;
import net.minecraft.recipe.RecipeType;
import net.minecraft.registry.Registries;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.util.Formatting;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.hit.HitResult.Type;
import net.minecraft.world.GameMode;

public class BlueprintOverlayRenderer {

	static boolean active;
	static boolean empty;
	static boolean noOutput;
	static boolean lastSneakState;
	static BlueprintSection lastTargetedSection;

	static Map<ItemStack, ItemStack[]> cachedRenderedFilters = new IdentityHashMap<>();
	static List<Pair<ItemStack, Boolean>> ingredients = new ArrayList<>();
	static ItemStack result = ItemStack.EMPTY;
	static boolean resultCraftable = false;

	public static void tick() {
		MinecraftClient mc = MinecraftClient.getInstance();

		BlueprintSection last = lastTargetedSection;
		lastTargetedSection = null;
		active = false;
		noOutput = false;

		if (mc.interactionManager.getCurrentGameMode() == GameMode.field_9219)
			return;

		HitResult mouseOver = mc.crosshairTarget;
		if (mouseOver == null)
			return;
		if (mouseOver.getType() != Type.field_1331)
			return;

		EntityHitResult entityRay = (EntityHitResult) mouseOver;
		if (!(entityRay.getEntity() instanceof BlueprintEntity))
			return;

		BlueprintEntity blueprintEntity = (BlueprintEntity) entityRay.getEntity();
		BlueprintSection sectionAt = blueprintEntity.getSectionAt(entityRay.getPos()
			.subtract(blueprintEntity.getPos()));

		lastTargetedSection = last;
		active = true;

		boolean sneak = mc.player.isSneaking();
		if (sectionAt != lastTargetedSection || AnimationTickHolder.getTicks() % 10 == 0 || lastSneakState != sneak)
			rebuild(sectionAt, sneak);

		lastTargetedSection = sectionAt;
		lastSneakState = sneak;
	}

	public static void displayTrackRequirements(PlacementInfo info, ItemStack pavementItem) {
		if (active)
			return;

		active = true;
		empty = false;
		noOutput = true;
		ingredients.clear();

		int tracks = info.requiredTracks;
		while (tracks > 0) {
			ingredients.add(Pair.of(new ItemStack(info.trackMaterial.getBlock(), Math.min(64, tracks)), info.hasRequiredTracks));
			tracks -= 64;
		}

		int pavement = info.requiredPavement;
		while (pavement > 0) {
			ingredients.add(Pair.of(ItemHandlerHelper.copyStackWithSize(pavementItem, Math.min(64, pavement)),
				info.hasRequiredPavement));
			pavement -= 64;
		}
	}

	public static void rebuild(BlueprintSection sectionAt, boolean sneak) {
		cachedRenderedFilters.clear();
		ItemStackHandler items = sectionAt.getItems();
		boolean empty = true;
		for (int i = 0; i < 9; i++) {
			if (!items.getStackInSlot(i)
				.isEmpty()) {
				empty = false;
				break;
			}
		}

		BlueprintOverlayRenderer.empty = empty;
		BlueprintOverlayRenderer.result = ItemStack.EMPTY;

		if (empty)
			return;

		boolean firstPass = true;
		boolean success = true;
		MinecraftClient mc = MinecraftClient.getInstance();
		PlayerInventoryStorage playerInv = PlayerInventoryStorage.of(mc.player);

		int amountCrafted = 0;
		Optional<CraftingRecipe> recipe = Optional.empty();
		Map<Integer, ItemStack> craftingGrid = new HashMap<>();
		ingredients.clear();
		ItemStackHandler missingItems = new ItemStackHandler(64);
		ItemStackHandler availableItems = new ItemStackHandler(64);
		List<ItemStack> newlyAdded = new ArrayList<>();
		List<ItemStack> newlyMissing = new ArrayList<>();
		boolean invalid = false;

		try (Transaction t = TransferUtil.getTransaction()) {
			do {
				craftingGrid.clear();
				newlyAdded.clear();
				newlyMissing.clear();

				Search:for (int i = 0; i < 9; i++) {
					FilterItemStack requestedItem = FilterItemStack.of(items.getStackInSlot(i));
					if (requestedItem.isEmpty()) {
						craftingGrid.put(i, ItemStack.EMPTY);
						continue;
					}

					ResourceAmount<ItemVariant> resource = StorageUtil.findExtractableContent(
							playerInv, v -> requestedItem.test(mc.world, v.toStack()), t);
					if (resource != null) {
						ItemStack currentItem = resource.resource().toStack(1);
						craftingGrid.put(i, currentItem);
						newlyAdded.add(currentItem);
						continue Search;
					}

					success = false;
					newlyMissing.add(requestedItem.item());
				}

				if (success) {
					RecipeInputInventory craftingInventory = new BlueprintCraftingInventory(craftingGrid);
					if (!recipe.isPresent())
						recipe = mc.world.getRecipeManager()
								.getFirstMatch(RecipeType.field_17545, craftingInventory, mc.world);
					ItemStack resultFromRecipe = recipe.filter(r -> r.matches(craftingInventory, mc.world))
							.map(r -> r.craft(craftingInventory, mc.world.getRegistryManager()))
							.orElse(ItemStack.EMPTY);

					if (resultFromRecipe.isEmpty()) {
						if (!recipe.isPresent())
							invalid = true;
						success = false;
					} else if (resultFromRecipe.getCount() + amountCrafted > 64) {
						success = false;
					} else {
						amountCrafted += resultFromRecipe.getCount();
						if (result.isEmpty())
							result = resultFromRecipe.copy();
						else
							result.increment(resultFromRecipe.getCount());
						resultCraftable = true;
						firstPass = false;
					}
				}

				if (success || firstPass) {
					newlyAdded.forEach(s -> availableItems.insert(ItemVariant.of(s), s.getCount(), t));
					newlyMissing.forEach(s -> missingItems.insert(ItemVariant.of(s), s.getCount(), t));
				}

				if (!success) {
					if (firstPass) {
						result = invalid ? ItemStack.EMPTY : items.getStackInSlot(9);
						resultCraftable = false;
					}
					break;
				}

				if (!sneak)
					break;

			} while (success);
			t.commit();
		}

		for (int i = 0; i < 9; i++) {
			ItemStack available = availableItems.getStackInSlot(i);
			if (available.isEmpty())
				continue;
			ingredients.add(Pair.of(available, true));
		}
		for (int i = 0; i < 9; i++) {
			ItemStack missing = missingItems.getStackInSlot(i);
			if (missing.isEmpty())
				continue;
			ingredients.add(Pair.of(missing, false));
		}
	}

	public static void renderOverlay(DrawContext graphics, float partialTicks, Window window) {
		MinecraftClient mc = MinecraftClient.getInstance();
		if (mc.options.hudHidden)
			return;
		if (!active || empty)
			return;

		int w = 21 * ingredients.size();

		if (!noOutput)
			w += 51;

		int x = (window.getScaledWidth() - w) / 2;
		int y = (int) (window.getScaledHeight() - 100);

		for (Pair<ItemStack, Boolean> pair : ingredients) {
			RenderSystem.enableBlend();
			(pair.getSecond() ? AllGuiTextures.HOTSLOT_ACTIVE : AllGuiTextures.HOTSLOT).render(graphics, x, y);
			ItemStack itemStack = pair.getFirst();
			String count = pair.getSecond() ? null : Formatting.field_1065.toString() + itemStack.getCount();
			drawItemStack(graphics, mc, x, y, itemStack, count);
			x += 21;
		}

		if (noOutput)
			return;

		x += 5;
		RenderSystem.enableBlend();
		AllGuiTextures.HOTSLOT_ARROW.render(graphics, x, y + 4);
		x += 25;

		if (result.isEmpty()) {
			AllGuiTextures.HOTSLOT.render(graphics, x, y);
			GuiGameElement.of(Items.BARRIER)
				.at(x + 3, y + 3)
				.render(graphics);
		} else {
			(resultCraftable ? AllGuiTextures.HOTSLOT_SUPER_ACTIVE : AllGuiTextures.HOTSLOT).render(graphics,
				resultCraftable ? x - 1 : x, resultCraftable ? y - 1 : y);
			drawItemStack(graphics, mc, x, y, result, null);
		}
		RenderSystem.disableBlend();
	}

	public static void drawItemStack(DrawContext graphics, MinecraftClient mc, int x, int y, ItemStack itemStack, String count) {
		if (itemStack.getItem() instanceof FilterItem) {
			int step = AnimationTickHolder.getTicks(mc.world) / 10;
			ItemStack[] itemsMatchingFilter = getItemsMatchingFilter(itemStack);
			if (itemsMatchingFilter.length > 0)
				itemStack = itemsMatchingFilter[step % itemsMatchingFilter.length];
		}

		GuiGameElement.of(itemStack)
			.at(x + 3, y + 3)
			.render(graphics);
		graphics.drawItemInSlot(mc.textRenderer, itemStack, x + 3, y + 3, count);
	}

	private static ItemStack[] getItemsMatchingFilter(ItemStack filter) {
		return cachedRenderedFilters.computeIfAbsent(filter, itemStack -> {
			NbtCompound tag = itemStack.getOrCreateNbt();

			if (AllItems.FILTER.isIn(itemStack) && !tag.getBoolean("Blacklist")) {
				ItemStackHandler filterItems = FilterItem.getFilterItems(itemStack);
				List<ItemStack> list = new ArrayList<>();
				for (int slot = 0; slot < filterItems.getSlotCount(); slot++) {
					ItemStack stackInSlot = filterItems.getStackInSlot(slot);
					if (!stackInSlot.isEmpty())
						list.add(stackInSlot);
				}
				return list.toArray(new ItemStack[list.size()]);
			}

			if (AllItems.ATTRIBUTE_FILTER.isIn(itemStack)) {
				WhitelistMode whitelistMode = WhitelistMode.values()[tag.getInt("WhitelistMode")];
				NbtList attributes = tag.getList("MatchedAttributes", net.minecraft.nbt.NbtElement.COMPOUND_TYPE);
				if (whitelistMode == WhitelistMode.WHITELIST_DISJ && attributes.size() == 1) {
					ItemAttribute fromNBT = ItemAttribute.fromNBT((NbtCompound) attributes.get(0));
					if (fromNBT instanceof ItemAttribute.InTag inTag) {
						List<ItemStack> stacks = new ArrayList<>();
						for (RegistryEntry<Item> holder : Registries.ITEM.iterateEntries(inTag.tag)) {
							stacks.add(new ItemStack(holder.comp_349()));
						}
						return stacks.toArray(ItemStack[]::new);
					}
				}
			}

			return new ItemStack[0];
		});
	}

}

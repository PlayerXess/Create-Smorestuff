package com.simibubi.create.content.schematics.client.tools;

import com.simibubi.create.content.schematics.client.SchematicTransformation;
import com.simibubi.create.foundation.utility.VecHelper;
import net.minecraft.util.math.Direction.Axis;
import net.minecraft.util.math.Vec3d;

public class MoveTool extends PlacementToolBase {

	@Override
	public void init() {
		super.init();
		renderSelectedFace = true;
	}

	@Override
	public void updateSelection() {
		super.updateSelection();
	}

	@Override
	public boolean handleMouseWheel(double delta) {
		if (!schematicSelected || !selectedFace.getAxis().isHorizontal())
			return true;

		SchematicTransformation transformation = schematicHandler.getTransformation();
		Vec3d vec = Vec3d.of(selectedFace.getVector()).multiply(-Math.signum(delta));
		vec = vec.multiply(transformation.getMirrorModifier(Axis.field_11048), 1, transformation.getMirrorModifier(Axis.field_11051));
		vec = VecHelper.rotate(vec, transformation.getRotationTarget(), Axis.field_11052);
		transformation.move((int) vec.x, 0, (int) vec.z);
		schematicHandler.markDirty();
		
		return true;
	}

}

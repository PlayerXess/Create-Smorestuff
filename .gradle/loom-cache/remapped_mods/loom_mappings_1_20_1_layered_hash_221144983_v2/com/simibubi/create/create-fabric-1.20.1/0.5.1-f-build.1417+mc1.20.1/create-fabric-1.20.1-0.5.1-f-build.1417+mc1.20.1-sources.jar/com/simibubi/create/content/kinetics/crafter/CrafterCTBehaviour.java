package com.simibubi.create.content.kinetics.crafter;

import static com.simibubi.create.content.kinetics.base.HorizontalKineticBlock.HORIZONTAL_FACING;

import org.jetbrains.annotations.Nullable;

import com.simibubi.create.AllSpriteShifts;
import com.simibubi.create.foundation.block.connected.CTSpriteShiftEntry;
import com.simibubi.create.foundation.block.connected.ConnectedTextureBehaviour;
import net.minecraft.block.BlockState;
import net.minecraft.client.texture.Sprite;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Direction.Axis;
import net.minecraft.util.math.Direction.AxisDirection;
import net.minecraft.world.BlockRenderView;

public class CrafterCTBehaviour extends ConnectedTextureBehaviour.Base {

	@Override
	public boolean connectsTo(BlockState state, BlockState other, BlockRenderView reader, BlockPos pos, BlockPos otherPos,
		Direction face) {
		if (state.getBlock() != other.getBlock())
			return false;
		if (state.get(HORIZONTAL_FACING) != other.get(HORIZONTAL_FACING))
			return false;
		return CrafterHelper.areCraftersConnected(reader, pos, otherPos);
	}

	@Override
	protected boolean reverseUVs(BlockState state, Direction direction) {
		if (!direction.getAxis()
			.isVertical())
			return false;
		Direction facing = state.get(HORIZONTAL_FACING);
		if (facing.getAxis() == direction.getAxis())
			return false;

		boolean isNegative = facing.getDirection() == AxisDirection.field_11060;
		if (direction == Direction.field_11033 && facing.getAxis() == Axis.field_11051)
			return !isNegative;
		return isNegative;
	}

	@Override
	public CTSpriteShiftEntry getShift(BlockState state, Direction direction, @Nullable Sprite sprite) {
		Direction facing = state.get(HORIZONTAL_FACING);
		boolean isFront = facing.getAxis() == direction.getAxis();
		boolean isVertical = direction.getAxis()
			.isVertical();
		boolean facingX = facing.getAxis() == Axis.field_11048;
		return isFront ? AllSpriteShifts.BRASS_CASING
			: isVertical && !facingX ? AllSpriteShifts.CRAFTER_OTHERSIDE : AllSpriteShifts.CRAFTER_SIDE;
	}

}

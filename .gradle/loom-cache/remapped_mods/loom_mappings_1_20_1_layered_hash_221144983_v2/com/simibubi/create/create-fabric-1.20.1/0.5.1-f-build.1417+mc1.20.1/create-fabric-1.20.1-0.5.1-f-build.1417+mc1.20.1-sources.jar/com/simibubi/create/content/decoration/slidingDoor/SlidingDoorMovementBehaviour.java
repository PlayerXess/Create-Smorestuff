package com.simibubi.create.content.decoration.slidingDoor;

import java.lang.ref.WeakReference;
import java.util.Map;

import com.simibubi.create.content.contraptions.Contraption;
import com.simibubi.create.content.contraptions.behaviour.MovementBehaviour;
import com.simibubi.create.content.contraptions.behaviour.MovementContext;
import com.simibubi.create.content.contraptions.elevator.ElevatorColumn;
import com.simibubi.create.content.contraptions.elevator.ElevatorColumn.ColumnCoords;
import com.simibubi.create.content.contraptions.elevator.ElevatorContraption;
import com.simibubi.create.content.trains.entity.Carriage;
import com.simibubi.create.content.trains.entity.CarriageContraptionEntity;
import com.simibubi.create.content.trains.station.GlobalStation;
import com.simibubi.create.foundation.blockEntity.behaviour.BlockEntityBehaviour;
import com.simibubi.create.foundation.utility.animation.LerpedFloat.Chaser;
import net.minecraft.block.BlockState;
import net.minecraft.block.DoorBlock;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.block.enums.DoubleBlockHalf;
import net.minecraft.registry.RegistryKey;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.structure.StructureTemplate.StructureBlockInfo;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Direction.AxisDirection;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

public class SlidingDoorMovementBehaviour implements MovementBehaviour {

	@Override
	public boolean renderAsNormalBlockEntity() {
		return true;
	}

	@Override
	public boolean mustTickWhileDisabled() {
		return true;
	}

	@Override
	public void tick(MovementContext context) {
		StructureBlockInfo structureBlockInfo = context.contraption.getBlocks()
			.get(context.localPos);
		if (structureBlockInfo == null)
			return;
		boolean open = SlidingDoorBlockEntity.isOpen(structureBlockInfo.comp_1342());

		if (!context.world.isClient())
			tickOpen(context, open);

		Map<BlockPos, BlockEntity> tes = context.contraption.presentBlockEntities;
		if (!(tes.get(context.localPos) instanceof SlidingDoorBlockEntity sdbe))
			return;
		boolean wasSettled = sdbe.animation.settled();
		sdbe.animation.chase(open ? 1 : 0, .15f, Chaser.LINEAR);
		sdbe.animation.tickChaser();

		if (!wasSettled && sdbe.animation.settled() && !open)
			context.world.playSound(context.position.x, context.position.y, context.position.z,
				SoundEvents.field_14819, SoundCategory.field_15245, .125f, 1, false);
	}

	protected void tickOpen(MovementContext context, boolean currentlyOpen) {
		boolean shouldOpen = shouldOpen(context);
		if (!shouldUpdate(context, shouldOpen))
			return;
		if (currentlyOpen == shouldOpen)
			return;

		BlockPos pos = context.localPos;
		Contraption contraption = context.contraption;

		StructureBlockInfo info = contraption.getBlocks()
			.get(pos);
		if (info == null || !info.comp_1342().contains(DoorBlock.OPEN))
			return;

		toggleDoor(pos, contraption, info);

		if (shouldOpen)
			context.world.playSound(null, BlockPos.ofFloored(context.position), SoundEvents.field_14567,
				SoundCategory.field_15245, .125f, 1);
	}

	private void toggleDoor(BlockPos pos, Contraption contraption, StructureBlockInfo info) {
		BlockState newState = info.comp_1342().cycle(DoorBlock.OPEN);
		contraption.entity.setBlock(pos, new StructureBlockInfo(info.comp_1341(), newState, info.comp_1343()));

		BlockPos otherPos = newState.get(DoorBlock.HALF) == DoubleBlockHalf.field_12607 ? pos.up() : pos.down();
		info = contraption.getBlocks()
			.get(otherPos);
		if (info != null && info.comp_1342().contains(DoorBlock.OPEN)) {
			newState = info.comp_1342().cycle(DoorBlock.OPEN);
			contraption.entity.setBlock(otherPos, new StructureBlockInfo(info.comp_1341(), newState, info.comp_1343()));
			contraption.invalidateColliders();
		}
	}

	protected boolean shouldUpdate(MovementContext context, boolean shouldOpen) {
		if (context.firstMovement && shouldOpen)
			return false;
		if (!context.data.contains("Open")) {
			context.data.putBoolean("Open", shouldOpen);
			return true;
		}
		boolean wasOpen = context.data.getBoolean("Open");
		context.data.putBoolean("Open", shouldOpen);
		return wasOpen != shouldOpen;
	}

	protected boolean shouldOpen(MovementContext context) {
		if (context.disabled)
			return false;
		Contraption contraption = context.contraption;
		boolean canOpen = context.motion.length() < 1 / 128f && !contraption.entity.isStalled()
			|| contraption instanceof ElevatorContraption ec && ec.arrived;

		if (!canOpen) {
			context.temporaryData = null;
			return false;
		}

		if (context.temporaryData instanceof WeakReference<?> wr && wr.get()instanceof DoorControlBehaviour dcb)
			if (dcb.blockEntity != null && !dcb.blockEntity.isRemoved())
				return shouldOpenAt(dcb, context);

		context.temporaryData = null;
		DoorControlBehaviour doorControls = null;

		if (contraption instanceof ElevatorContraption ec)
			doorControls = getElevatorDoorControl(ec, context);
		if (context.contraption.entity instanceof CarriageContraptionEntity cce)
			doorControls = getTrainStationDoorControl(cce, context);

		if (doorControls == null)
			return false;

		context.temporaryData = new WeakReference<>(doorControls);
		return shouldOpenAt(doorControls, context);
	}

	protected boolean shouldOpenAt(DoorControlBehaviour controller, MovementContext context) {
		if (controller.mode == DoorControl.ALL)
			return true;
		if (controller.mode == DoorControl.NONE)
			return false;
		return controller.mode.matches(getDoorFacing(context));
	}

	protected DoorControlBehaviour getElevatorDoorControl(ElevatorContraption ec, MovementContext context) {
		Integer currentTargetY = ec.getCurrentTargetY(context.world);
		if (currentTargetY == null)
			return null;
		ColumnCoords columnCoords = ec.getGlobalColumn();
		if (columnCoords == null)
			return null;
		ElevatorColumn elevatorColumn = ElevatorColumn.get(context.world, columnCoords);
		if (elevatorColumn == null)
			return null;
		return BlockEntityBehaviour.get(context.world, elevatorColumn.contactAt(currentTargetY),
			DoorControlBehaviour.TYPE);
	}

	protected DoorControlBehaviour getTrainStationDoorControl(CarriageContraptionEntity cce, MovementContext context) {
		Carriage carriage = cce.getCarriage();
		if (carriage == null || carriage.train == null)
			return null;
		GlobalStation currentStation = carriage.train.getCurrentStation();
		if (currentStation == null)
			return null;

		BlockPos stationPos = currentStation.getBlockEntityPos();
		RegistryKey<World> stationDim = currentStation.getBlockEntityDimension();
		MinecraftServer server = context.world.getServer();
		if (server == null)
			return null;
		ServerWorld stationLevel = server.getWorld(stationDim);
		if (stationLevel == null || !stationLevel.canSetBlock(stationPos))
			return null;
		return BlockEntityBehaviour.get(stationLevel, stationPos, DoorControlBehaviour.TYPE);
	}

	protected Direction getDoorFacing(MovementContext context) {
		Direction stateFacing = context.state.get(DoorBlock.FACING);
		Direction originalFacing = Direction.get(AxisDirection.field_11056, stateFacing.getAxis());
		Vec3d centerOfContraption = context.contraption.bounds.getCenter();
		Vec3d diff = Vec3d.ofCenter(context.localPos)
			.add(Vec3d.of(stateFacing.getVector())
				.multiply(-.45f))
			.subtract(centerOfContraption);
		if (originalFacing.getAxis()
			.choose(diff.x, diff.y, diff.z) < 0)
			originalFacing = originalFacing.getOpposite();

		Vec3d directionVec = Vec3d.of(originalFacing.getVector());
		directionVec = context.rotation.apply(directionVec);
		return Direction.getFacing(directionVec.x, directionVec.y, directionVec.z);
	}

}

package com.simibubi.create.compat.emi.recipes;

import java.util.List;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.recipe.CraftingRecipe;
import net.minecraft.recipe.Ingredient;
import net.minecraft.recipe.ShapedRecipe;
import net.minecraft.text.Text;
import net.minecraft.util.math.MathHelper;
import com.simibubi.create.compat.emi.CreateEmiAnimations;
import com.simibubi.create.foundation.gui.AllGuiTextures;

import dev.emi.emi.api.recipe.EmiRecipeCategory;
import dev.emi.emi.api.stack.EmiIngredient;
import dev.emi.emi.api.stack.EmiStack;
import dev.emi.emi.api.widget.Bounds;
import dev.emi.emi.api.widget.SlotWidget;
import dev.emi.emi.api.widget.WidgetHolder;

public class MechanicalCraftingEmiRecipe extends CreateEmiRecipe<CraftingRecipe> {
	private static final int MAX_SIZE = 100;
	private int recipeAmount = 0;

	public MechanicalCraftingEmiRecipe(EmiRecipeCategory category, CraftingRecipe recipe) {
		super(category, recipe, 177, 109, c -> {});
		this.input = recipe.getIngredients().stream().map(EmiIngredient::of).toList();
		this.output = List.of(getResultEmi(recipe));
		for (Ingredient ingredient : recipe.getIngredients()) {
			if (!ingredient.isEmpty()) {
				recipeAmount++;
			}
		}
	}

	public float getScale() {
		int w = getWidth();
		int h = getHeight();
		return Math.min(1, MAX_SIZE / (19f * Math.max(w, h)));
	}

	public int getYPadding() {
		return 3 + 50 - (int) (getScale() * getHeight() * 19 * .5);
	}

	public int getXPadding() {
		return 3 + 50 - (int) (getScale() * getWidth() * 19 * .5);
	}

	private int getWidth() {
		return recipe instanceof ShapedRecipe ? ((ShapedRecipe) recipe).getWidth() : 1;
	}

	private int getHeight() {
		return recipe instanceof ShapedRecipe ? ((ShapedRecipe) recipe).getHeight() : 1;
	}

	@Override
	public void addWidgets(WidgetHolder widgets) {
		int x = getXPadding();
		int y = getYPadding();
		float scale = getScale();

		addTexture(widgets, AllGuiTextures.JEI_DOWN_ARROW, 128, 59);
		addTexture(widgets, AllGuiTextures.JEI_SHADOW, 113, 38);


		for (int i = 0; i < input.size(); i++) {
			EmiIngredient ingredient = input.get(i);
			if (ingredient.isEmpty())
				continue;
			float f = 19 * scale;
			int xPosition = (int) (x + 1 + (i % getWidth()) * f);
			int yPosition = (int) (y + 1 + (i / getWidth()) * f);
			widgets.add(new CrafterSlotWidget(ingredient, xPosition, yPosition))
					.backgroundTexture(
							AllGuiTextures.JEI_SLOT.location, AllGuiTextures.JEI_SLOT.startX, AllGuiTextures.JEI_SLOT.startY
					);
		}

		addSlot(widgets, output.get(0), 134, 81).recipeContext(this);

		CreateEmiAnimations.addCrafter(widgets, 132, 38);

		widgets.addText(Text.literal("" + recipeAmount).asOrderedText(), 142, 39, -1, true);
	}

	public class CrafterSlotWidget extends SlotWidget {
		private boolean hideStack;

		public CrafterSlotWidget(EmiIngredient stack, int x, int y) {
			super(stack, x, y);
			int w = MathHelper.ceil(18 * getScale());
			this.bounds = new Bounds(x, y, w, w);
		}

		@Override
		public Bounds getBounds() {
			return bounds;
		}

		@Override
		public EmiIngredient getStack() {
			return hideStack ? EmiStack.EMPTY : super.getStack();
		}

		@Override
		public void render(DrawContext graphics, int mouseX, int mouseY, float delta) {
			MatrixStack matrices = graphics.getMatrices();
			matrices.push();
			hideStack = true;
			super.render(graphics, mouseX, mouseY, delta);
			hideStack = false;

			float scale = getScale();
			matrices.translate(x, y, 0);
			matrices.scale(scale, scale, scale);
			matrices.translate(-x, -y, 0);

			getStack().render(graphics, bounds.x() + 1, bounds.y() + 1, delta);
			matrices.pop();
		}
	}
}

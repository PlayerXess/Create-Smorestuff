package com.simibubi.create.compat.jei.category;

import java.util.List;
import java.util.Optional;
import java.util.function.Supplier;
import java.util.stream.Collectors;

import javax.annotation.ParametersAreNonnullByDefault;

import org.jetbrains.annotations.NotNull;

import com.simibubi.create.AllFluids;
import com.simibubi.create.content.fluids.potion.PotionFluidHandler;
import com.simibubi.create.content.processing.recipe.ProcessingOutput;
import com.simibubi.create.foundation.gui.AllGuiTextures;
import com.simibubi.create.foundation.utility.Lang;
import com.simibubi.create.infrastructure.config.AllConfigs;

import io.github.fabricators_of_create.porting_lib.fluids.FluidStack;
import io.github.fabricators_of_create.porting_lib.util.FluidTextUtil;
import io.github.fabricators_of_create.porting_lib.util.FluidUnit;
import mezz.jei.api.fabric.constants.FabricTypes;
import mezz.jei.api.fabric.ingredients.fluids.IJeiFluidIngredient;
import mezz.jei.api.gui.drawable.IDrawable;
import mezz.jei.api.gui.ingredient.IRecipeSlotTooltipCallback;
import mezz.jei.api.recipe.RecipeType;
import mezz.jei.api.recipe.category.IRecipeCategory;
import mezz.jei.api.registration.IRecipeCatalystRegistration;
import mezz.jei.api.registration.IRecipeRegistration;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.fluid.Fluid;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.recipe.Recipe;
import net.minecraft.text.Text;
import net.minecraft.util.annotation.MethodsReturnNonnullByDefault;

@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
public abstract class CreateRecipeCategory<T extends Recipe<?>> implements IRecipeCategory<T> {
	private static final IDrawable BASIC_SLOT = asDrawable(AllGuiTextures.JEI_SLOT);
	private static final IDrawable CHANCE_SLOT = asDrawable(AllGuiTextures.JEI_CHANCE_SLOT);

	protected final RecipeType<T> type;
	protected final Text title;
	protected final IDrawable background;
	protected final IDrawable icon;

	private final Supplier<List<T>> recipes;
	private final List<Supplier<? extends ItemStack>> catalysts;

	public CreateRecipeCategory(Info<T> info) {
		this.type = info.recipeType();
		this.title = info.title();
		this.background = info.background();
		this.icon = info.icon();
		this.recipes = info.recipes();
		this.catalysts = info.catalysts();
	}

	@NotNull
	@Override
	public RecipeType<T> getRecipeType() {
		return type;
	}

	@Override
	public Text getTitle() {
		return title;
	}

	@Override
	public IDrawable getBackground() {
		return background;
	}

	@Override
	public IDrawable getIcon() {
		return icon;
	}

	public void registerRecipes(IRecipeRegistration registration) {
		registration.addRecipes(type, recipes.get());
	}

	public void registerCatalysts(IRecipeCatalystRegistration registration) {
		catalysts.forEach(s -> registration.addRecipeCatalyst(s.get(), type));
	}

	public static IDrawable getRenderedSlot() {
		return BASIC_SLOT;
	}

	public static IDrawable getRenderedSlot(ProcessingOutput output) {
		return getRenderedSlot(output.getChance());
	}

	public static IDrawable getRenderedSlot(float chance) {
		if (chance == 1)
			return BASIC_SLOT;

		return CHANCE_SLOT;
	}

	public static ItemStack getResultItem(Recipe<?> recipe) {
		ClientWorld level = MinecraftClient.getInstance().world;
		if (level == null)
			return ItemStack.EMPTY;
		return recipe.getOutput(level.getRegistryManager());
	}

	public static IRecipeSlotTooltipCallback addStochasticTooltip(ProcessingOutput output) {
		return (view, tooltip) -> {
			float chance = output.getChance();
			if (chance != 1)
				tooltip.add(1, Lang.translateDirect("recipe.processing.chance", chance < 0.01 ? "<1" : (int) (chance * 100))
					.method_27692(class_124.field_1065));
		};
	}

	public static List<FluidStack> withImprovedVisibility(List<FluidStack> stacks) {
		return stacks.stream()
			.map(CreateRecipeCategory::withImprovedVisibility)
			.collect(Collectors.toList());
	}

	public static FluidStack withImprovedVisibility(FluidStack stack) {
		FluidStack display = stack.copy();
		long displayedAmount = (long) (stack.getAmount() * .75f) + 250;
		display.setAmount(displayedAmount);
		return display;
	}

	public static FluidStack fromJei(IJeiFluidIngredient jei) {
		return new FluidStack(jei.getFluid(), jei.getAmount(), jei.getTag().orElse(null));
	}

	public static IJeiFluidIngredient toJei(FluidStack stack) {
		return new IJeiFluidIngredient() {
			@Override
			public Fluid getFluid() {
				return stack.getFluid();
			}

			@Override
			public long getAmount() {
				return stack.getAmount();
			}

			@Override
			public Optional<NbtCompound> getTag() {
				return Optional.ofNullable(stack.getTag());
			}
		};
	}

	public static List<FluidStack> fromJei(List<IJeiFluidIngredient> stacks) {
		return stacks.stream().map(CreateRecipeCategory::fromJei).toList();
	}

	public static List<IJeiFluidIngredient> toJei(List<FluidStack> stacks) {
		return stacks.stream().map(CreateRecipeCategory::toJei).toList();
	}

	public static IRecipeSlotTooltipCallback addFluidTooltip() {
		return addFluidTooltip(-1);
	}

	public static IRecipeSlotTooltipCallback addFluidTooltip(long mbAmount) {
		return (view, tooltip) -> {
			Optional<IJeiFluidIngredient> displayed = view.getDisplayedIngredient(FabricTypes.FLUID_STACK);
			if (displayed.isEmpty())
				return;

			FluidStack fluidStack = fromJei(displayed.get());

			// fabric: don't need potion tooltip stuff, handled by attribute handler

			long amountToUse = mbAmount == -1 ? fluidStack.getAmount() : mbAmount;
			FluidUnit unit = AllConfigs.client().fluidUnitType.get();
			String amount = FluidTextUtil.getUnicodeMillibuckets(amountToUse, unit, AllConfigs.client().simplifyFluidUnit.get());
			class_2561 text = class_2561.method_43470(String.valueOf(amount)).method_10852(Lang.translateDirect(unit.getTranslationKey())).method_27692(class_124.field_1065);
			if (tooltip.isEmpty())
				tooltip.add(0, text);
			else {
				// fabric: sibling strategy doesn't work some reason
				class_2561 name = tooltip.get(0);
				class_2561 nameWithAmount = name.method_27661().method_27693(" ").method_10852(text);
				tooltip.set(0, nameWithAmount);
			}
		};
	}

	protected static IDrawable asDrawable(AllGuiTextures texture) {
		return new IDrawable() {
			@Override
			public int getWidth() {
				return texture.width;
			}

			@Override
			public int getHeight() {
				return texture.height;
			}

			@Override
			public void draw(DrawContext graphics, int xOffset, int yOffset) {
				texture.render(graphics, xOffset, yOffset);
			}
		};
	}

	public record Info<T extends Recipe<?>>(RecipeType<T> recipeType, Text title, IDrawable background, IDrawable icon, Supplier<List<T>> recipes, List<Supplier<? extends ItemStack>> catalysts) {
	}

	public interface Factory<T extends Recipe<?>> {
		CreateRecipeCategory<T> create(Info<T> info);
	}
}

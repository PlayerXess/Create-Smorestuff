package com.simibubi.create.content.kinetics.simpleRelays.encased;

import static com.simibubi.create.content.kinetics.base.RotatedPillarKineticBlock.AXIS;

import org.jetbrains.annotations.Nullable;

import com.simibubi.create.content.decoration.encasing.EncasedCTBehaviour;
import com.simibubi.create.content.kinetics.base.IRotate;
import com.simibubi.create.content.kinetics.simpleRelays.ICogWheel;
import com.simibubi.create.foundation.block.connected.CTSpriteShiftEntry;
import com.simibubi.create.foundation.utility.Couple;
import net.minecraft.block.BlockState;
import net.minecraft.client.texture.Sprite;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Direction.Axis;
import net.minecraft.util.math.Direction.AxisDirection;
import net.minecraft.world.BlockRenderView;

public class EncasedCogCTBehaviour extends EncasedCTBehaviour {

	private Couple<CTSpriteShiftEntry> sideShifts;
	private boolean large;

	public EncasedCogCTBehaviour(CTSpriteShiftEntry shift) {
		this(shift, null);
	}

	public EncasedCogCTBehaviour(CTSpriteShiftEntry shift, Couple<CTSpriteShiftEntry> sideShifts) {
		super(shift);
		large = sideShifts == null;
		this.sideShifts = sideShifts;
	}

	@Override
	public boolean connectsTo(BlockState state, BlockState other, BlockRenderView reader, BlockPos pos,
		BlockPos otherPos, Direction face) {
		Axis axis = state.get(AXIS);
		if (large || axis == face.getAxis())
			return super.connectsTo(state, other, reader, pos, otherPos, face);

		if (other.getBlock() == state.getBlock() && other.get(AXIS) == state.get(AXIS))
			return true;

		BlockState blockState = reader.getBlockState(otherPos.offset(face));
		if (!ICogWheel.isLargeCog(blockState))
			return false;

		return ((IRotate) blockState.getBlock()).getRotationAxis(blockState) == axis;
	}

	@Override
	protected boolean reverseUVs(BlockState state, Direction face) {
		return state.get(AXIS)
			.isHorizontal()
			&& face.getAxis()
				.isHorizontal()
			&& face.getDirection() == AxisDirection.field_11056;
	}

	@Override
	protected boolean reverseUVsVertically(BlockState state, Direction face) {
		if (!large && state.get(AXIS) == Axis.field_11048 && face.getAxis() == Axis.field_11051)
			return face != Direction.field_11035;
		return super.reverseUVsVertically(state, face);
	}

	@Override
	protected boolean reverseUVsHorizontally(BlockState state, Direction face) {
		if (large)
			return super.reverseUVsHorizontally(state, face);

		if (state.get(AXIS)
			.isVertical()
			&& face.getAxis()
				.isHorizontal())
			return true;

		if (state.get(AXIS) == Axis.field_11051 && face == Direction.field_11033)
			return true;

		return super.reverseUVsHorizontally(state, face);
	}

	@Override
	public CTSpriteShiftEntry getShift(BlockState state, Direction direction, @Nullable Sprite sprite) {
		Axis axis = state.get(AXIS);
		if (large || axis == direction.getAxis()) {
			if (axis == direction.getAxis() && state
				.get(direction.getDirection() == AxisDirection.field_11056 ? EncasedCogwheelBlock.TOP_SHAFT
					: EncasedCogwheelBlock.BOTTOM_SHAFT))
				return null;
			return super.getShift(state, direction, sprite);
		}
		return sideShifts.get(axis == Axis.field_11048 || axis == Axis.field_11051 && direction.getAxis() == Axis.field_11048);
	}

}

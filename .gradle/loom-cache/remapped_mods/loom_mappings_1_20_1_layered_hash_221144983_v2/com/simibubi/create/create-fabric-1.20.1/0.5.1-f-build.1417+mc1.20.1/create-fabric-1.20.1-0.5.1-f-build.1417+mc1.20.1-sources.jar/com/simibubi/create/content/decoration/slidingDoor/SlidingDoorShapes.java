package com.simibubi.create.content.decoration.slidingDoor;

import net.minecraft.block.Block;
import net.minecraft.util.math.Direction;
import net.minecraft.util.shape.VoxelShape;

public class SlidingDoorShapes {

	protected static final VoxelShape SE_AABB = Block.createCuboidShape(0.0D, 0.0D, -13.0D, 3.0D, 16.0D, 3.0D);
	protected static final VoxelShape ES_AABB = Block.createCuboidShape(-13.0D, 0.0D, 0.0D, 3.0D, 16.0D, 3.0D);
	protected static final VoxelShape NW_AABB = Block.createCuboidShape(13.0D, 0.0D, 13.0D, 16.0D, 16.0D, 29.0D);
	protected static final VoxelShape WN_AABB = Block.createCuboidShape(13.0D, 0.0D, 13.0D, 29.0D, 16.0D, 16.0D);
	protected static final VoxelShape SW_AABB = Block.createCuboidShape(13.0D, 0.0D, -13.0D, 16.0D, 16.0D, 3.0D);
	protected static final VoxelShape WS_AABB = Block.createCuboidShape(13.0D, 0.0D, 0.0D, 29.0D, 16.0D, 3.0D);
	protected static final VoxelShape NE_AABB = Block.createCuboidShape(0.0D, 0.0D, 13.0D, 3.0D, 16.0D, 29.0D);
	protected static final VoxelShape EN_AABB = Block.createCuboidShape(-13.0D, 0.0D, 13.0D, 3.0D, 16.0D, 16.0D);

	protected static final VoxelShape SE_AABB_FOLD = Block.createCuboidShape(0.0D, 0.0D, -3.0D, 9.0D, 16.0D, 3.0D);
	protected static final VoxelShape ES_AABB_FOLD = Block.createCuboidShape(-3.0D, 0.0D, 0.0D, 3.0D, 16.0D, 9.0D);
	protected static final VoxelShape NW_AABB_FOLD = Block.createCuboidShape(7.0D, 0.0D, 13.0D, 16.0D, 16.0D, 19.0D);
	protected static final VoxelShape WN_AABB_FOLD = Block.createCuboidShape(13.0D, 0.0D, 7.0D, 19.0D, 16.0D, 16.0D);
	protected static final VoxelShape SW_AABB_FOLD = Block.createCuboidShape(7.0D, 0.0D, -3.0D, 16.0D, 16.0D, 3.0D);
	protected static final VoxelShape WS_AABB_FOLD = Block.createCuboidShape(13.0D, 0.0D, 0.0D, 19.0D, 16.0D, 9.0D);
	protected static final VoxelShape NE_AABB_FOLD = Block.createCuboidShape(0.0D, 0.0D, 13.0D, 9.0D, 16.0D, 19.0D);
	protected static final VoxelShape EN_AABB_FOLD = Block.createCuboidShape(-3.0D, 0.0D, 7.0D, 3.0D, 16.0D, 16.0D);

	public static VoxelShape get(Direction facing, boolean hinge, boolean fold) {
		if (fold)
			return switch (facing) {
			case field_11035 -> (hinge ? ES_AABB_FOLD : WS_AABB_FOLD);
			case field_11039 -> (hinge ? SW_AABB_FOLD : NW_AABB_FOLD);
			case field_11043 -> (hinge ? WN_AABB_FOLD : EN_AABB_FOLD);
			default -> (hinge ? NE_AABB_FOLD : SE_AABB_FOLD);
			};

		return switch (facing) {
		case field_11035 -> (hinge ? ES_AABB : WS_AABB);
		case field_11039 -> (hinge ? SW_AABB : NW_AABB);
		case field_11043 -> (hinge ? WN_AABB : EN_AABB);
		default -> (hinge ? NE_AABB : SE_AABB);
		};
	}

}

/*
 * Decompiled with CFR 0.2.1 (FabricMC 53fa44c9).
 */
package net.minecraft.block;

import net.minecraft.block.AbstractBlock;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.item.ItemStack;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.intprovider.ConstantIntProvider;
import net.minecraft.util.math.intprovider.IntProvider;

public class ExperienceDroppingBlock
extends Block {
    private final IntProvider experienceDropped;

    public ExperienceDroppingBlock(AbstractBlock.Settings settings) {
        this(settings, ConstantIntProvider.create(0));
    }

    public ExperienceDroppingBlock(AbstractBlock.Settings settings, IntProvider intProvider) {
        super(settings);
        this.experienceDropped = intProvider;
    }

    @Override
    public void onStacksDropped(BlockState blockState, ServerWorld serverWorld, BlockPos blockPos, ItemStack itemStack, boolean bl) {
        super.onStacksDropped(blockState, serverWorld, blockPos, itemStack, bl);
        if (bl) {
            this.dropExperienceWhenMined(serverWorld, blockPos, itemStack, this.experienceDropped);
        }
    }
}


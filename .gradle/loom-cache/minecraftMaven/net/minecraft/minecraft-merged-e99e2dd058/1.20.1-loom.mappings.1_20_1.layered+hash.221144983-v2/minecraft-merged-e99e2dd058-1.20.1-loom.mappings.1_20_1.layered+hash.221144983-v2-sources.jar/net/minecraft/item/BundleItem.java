/*
 * Decompiled with CFR 0.2.1 (FabricMC 53fa44c9).
 */
package net.minecraft.item;

import java.util.List;
import java.util.Optional;
import java.util.stream.Stream;
import net.minecraft.client.item.BundleTooltipData;
import net.minecraft.client.item.TooltipContext;
import net.minecraft.client.item.TooltipData;
import net.minecraft.entity.Entity;
import net.minecraft.entity.ItemEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.inventory.StackReference;
import net.minecraft.item.BlockItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemUsage;
import net.minecraft.item.Items;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.nbt.NbtList;
import net.minecraft.screen.slot.Slot;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.sound.SoundEvents;
import net.minecraft.stat.Stats;
import net.minecraft.text.Text;
import net.minecraft.util.ClickType;
import net.minecraft.util.Formatting;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.util.collection.DefaultedList;
import net.minecraft.util.math.MathHelper;
import net.minecraft.world.World;

public class BundleItem
extends Item {
    private static final String ITEMS_KEY = "Items";
    public static final int MAX_STORAGE = 64;
    private static final int BUNDLE_ITEM_OCCUPANCY = 4;
    private static final int ITEM_BAR_COLOR = MathHelper.packRgb(0.4f, 0.4f, 1.0f);

    public BundleItem(Item.Settings settings) {
        super(settings);
    }

    public static float getAmountFilled(ItemStack itemStack) {
        return (float)BundleItem.getBundleOccupancy(itemStack) / 64.0f;
    }

    @Override
    public boolean onStackClicked(ItemStack itemStack, Slot slot, ClickType clickType, PlayerEntity playerEntity) {
        if (clickType != ClickType.RIGHT) {
            return false;
        }
        ItemStack itemStack22 = slot.getStack();
        if (itemStack22.isEmpty()) {
            this.playRemoveOneSound(playerEntity);
            BundleItem.removeFirstStack(itemStack).ifPresent(itemStack2 -> BundleItem.addToBundle(itemStack, slot.insertStack((ItemStack)itemStack2)));
        } else if (itemStack22.getItem().canBeNested()) {
            int i = (64 - BundleItem.getBundleOccupancy(itemStack)) / BundleItem.getItemOccupancy(itemStack22);
            int j = BundleItem.addToBundle(itemStack, slot.takeStackRange(itemStack22.getCount(), i, playerEntity));
            if (j > 0) {
                this.playInsertSound(playerEntity);
            }
        }
        return true;
    }

    @Override
    public boolean onClicked(ItemStack itemStack2, ItemStack itemStack22, Slot slot, ClickType clickType, PlayerEntity playerEntity, StackReference stackReference) {
        if (clickType != ClickType.RIGHT || !slot.canTakePartial(playerEntity)) {
            return false;
        }
        if (itemStack22.isEmpty()) {
            BundleItem.removeFirstStack(itemStack2).ifPresent(itemStack -> {
                this.playRemoveOneSound(playerEntity);
                stackReference.set((ItemStack)itemStack);
            });
        } else {
            int i = BundleItem.addToBundle(itemStack2, itemStack22);
            if (i > 0) {
                this.playInsertSound(playerEntity);
                itemStack22.decrement(i);
            }
        }
        return true;
    }

    @Override
    public TypedActionResult<ItemStack> use(World world, PlayerEntity playerEntity, Hand hand) {
        ItemStack itemStack = playerEntity.getStackInHand(hand);
        if (BundleItem.dropAllBundledItems(itemStack, playerEntity)) {
            this.playDropContentsSound(playerEntity);
            playerEntity.incrementStat(Stats.field_15372.getOrCreateStat(this));
            return TypedActionResult.success(itemStack, world.isClient());
        }
        return TypedActionResult.fail(itemStack);
    }

    @Override
    public boolean isItemBarVisible(ItemStack itemStack) {
        return BundleItem.getBundleOccupancy(itemStack) > 0;
    }

    @Override
    public int getItemBarStep(ItemStack itemStack) {
        return Math.min(1 + 12 * BundleItem.getBundleOccupancy(itemStack) / 64, 13);
    }

    @Override
    public int getItemBarColor(ItemStack itemStack) {
        return ITEM_BAR_COLOR;
    }

    private static int addToBundle(ItemStack itemStack, ItemStack itemStack2) {
        if (itemStack2.isEmpty() || !itemStack2.getItem().canBeNested()) {
            return 0;
        }
        NbtCompound nbtCompound = itemStack.getOrCreateNbt();
        if (!nbtCompound.contains(ITEMS_KEY)) {
            nbtCompound.put(ITEMS_KEY, new NbtList());
        }
        int i = BundleItem.getBundleOccupancy(itemStack);
        int j = BundleItem.getItemOccupancy(itemStack2);
        int k = Math.min(itemStack2.getCount(), (64 - i) / j);
        if (k == 0) {
            return 0;
        }
        NbtList nbtList = nbtCompound.getList(ITEMS_KEY, 10);
        Optional<NbtCompound> optional = BundleItem.canMergeStack(itemStack2, nbtList);
        if (optional.isPresent()) {
            NbtCompound nbtCompound2 = optional.get();
            ItemStack itemStack3 = ItemStack.fromNbt(nbtCompound2);
            itemStack3.increment(k);
            itemStack3.writeNbt(nbtCompound2);
            nbtList.remove(nbtCompound2);
            nbtList.add(0, nbtCompound2);
        } else {
            ItemStack itemStack4 = itemStack2.copyWithCount(k);
            NbtCompound nbtCompound3 = new NbtCompound();
            itemStack4.writeNbt(nbtCompound3);
            nbtList.add(0, nbtCompound3);
        }
        return k;
    }

    private static Optional<NbtCompound> canMergeStack(ItemStack itemStack, NbtList nbtList) {
        if (itemStack.isOf(Items.field_27023)) {
            return Optional.empty();
        }
        return nbtList.stream().filter(NbtCompound.class::isInstance).map(NbtCompound.class::cast).filter(nbtCompound -> ItemStack.canCombine(ItemStack.fromNbt(nbtCompound), itemStack)).findFirst();
    }

    private static int getItemOccupancy(ItemStack itemStack) {
        NbtCompound nbtCompound;
        if (itemStack.isOf(Items.field_27023)) {
            return 4 + BundleItem.getBundleOccupancy(itemStack);
        }
        if ((itemStack.isOf(Items.BEEHIVE) || itemStack.isOf(Items.BEE_NEST)) && itemStack.hasNbt() && (nbtCompound = BlockItem.getBlockEntityNbt(itemStack)) != null && !nbtCompound.getList("Bees", 10).isEmpty()) {
            return 64;
        }
        return 64 / itemStack.getMaxCount();
    }

    private static int getBundleOccupancy(ItemStack itemStack2) {
        return BundleItem.getBundledStacks(itemStack2).mapToInt(itemStack -> BundleItem.getItemOccupancy(itemStack) * itemStack.getCount()).sum();
    }

    private static Optional<ItemStack> removeFirstStack(ItemStack itemStack) {
        NbtCompound nbtCompound = itemStack.getOrCreateNbt();
        if (!nbtCompound.contains(ITEMS_KEY)) {
            return Optional.empty();
        }
        NbtList nbtList = nbtCompound.getList(ITEMS_KEY, 10);
        if (nbtList.isEmpty()) {
            return Optional.empty();
        }
        boolean i = false;
        NbtCompound nbtCompound2 = nbtList.getCompound(0);
        ItemStack itemStack2 = ItemStack.fromNbt(nbtCompound2);
        nbtList.remove(0);
        if (nbtList.isEmpty()) {
            itemStack.removeSubNbt(ITEMS_KEY);
        }
        return Optional.of(itemStack2);
    }

    private static boolean dropAllBundledItems(ItemStack itemStack, PlayerEntity playerEntity) {
        NbtCompound nbtCompound = itemStack.getOrCreateNbt();
        if (!nbtCompound.contains(ITEMS_KEY)) {
            return false;
        }
        if (playerEntity instanceof ServerPlayerEntity) {
            NbtList nbtList = nbtCompound.getList(ITEMS_KEY, 10);
            for (int i = 0; i < nbtList.size(); ++i) {
                NbtCompound nbtCompound2 = nbtList.getCompound(i);
                ItemStack itemStack2 = ItemStack.fromNbt(nbtCompound2);
                playerEntity.dropItem(itemStack2, true);
            }
        }
        itemStack.removeSubNbt(ITEMS_KEY);
        return true;
    }

    private static Stream<ItemStack> getBundledStacks(ItemStack itemStack) {
        NbtCompound nbtCompound = itemStack.getNbt();
        if (nbtCompound == null) {
            return Stream.empty();
        }
        NbtList nbtList = nbtCompound.getList(ITEMS_KEY, 10);
        return nbtList.stream().map(NbtCompound.class::cast).map(ItemStack::fromNbt);
    }

    @Override
    public Optional<TooltipData> getTooltipData(ItemStack itemStack) {
        DefaultedList<ItemStack> defaultedList = DefaultedList.of();
        BundleItem.getBundledStacks(itemStack).forEach(defaultedList::add);
        return Optional.of(new BundleTooltipData(defaultedList, BundleItem.getBundleOccupancy(itemStack)));
    }

    @Override
    public void appendTooltip(ItemStack itemStack, World world, List<Text> list, TooltipContext tooltipContext) {
        list.add(Text.translatable("item.minecraft.bundle.fullness", BundleItem.getBundleOccupancy(itemStack), 64).formatted(Formatting.field_1080));
    }

    @Override
    public void onItemEntityDestroyed(ItemEntity itemEntity) {
        ItemUsage.spawnItemContents(itemEntity, BundleItem.getBundledStacks(itemEntity.getStack()));
    }

    private void playRemoveOneSound(Entity entity) {
        entity.playSound(SoundEvents.field_34377, 0.8f, 0.8f + entity.getWorld().getRandom().nextFloat() * 0.4f);
    }

    private void playInsertSound(Entity entity) {
        entity.playSound(SoundEvents.field_34376, 0.8f, 0.8f + entity.getWorld().getRandom().nextFloat() * 0.4f);
    }

    private void playDropContentsSound(Entity entity) {
        entity.playSound(SoundEvents.field_34375, 0.8f, 0.8f + entity.getWorld().getRandom().nextFloat() * 0.4f);
    }
}


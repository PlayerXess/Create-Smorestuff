/*
 * Decompiled with CFR 0.2.1 (FabricMC 53fa44c9).
 */
package net.minecraft.world;

import java.util.function.IntFunction;
import net.minecraft.entity.player.PlayerAbilities;
import net.minecraft.text.Text;
import net.minecraft.util.StringIdentifiable;
import net.minecraft.util.function.ValueLists;
import org.jetbrains.annotations.Contract;
import org.jetbrains.annotations.Nullable;

public enum GameMode implements StringIdentifiable
{
    field_9215(0, "survival"),
    field_9220(1, "creative"),
    field_9216(2, "adventure"),
    field_9219(3, "spectator");

    public static final GameMode DEFAULT;
    public static final StringIdentifiable.Codec<GameMode> CODEC;
    private static final IntFunction<GameMode> BY_ID;
    private static final int UNKNOWN = -1;
    private final int id;
    private final String name;
    private final Text simpleTranslatableName;
    private final Text translatableName;

    private GameMode(int j, String string2) {
        this.id = j;
        this.name = string2;
        this.simpleTranslatableName = Text.translatable("selectWorld.gameMode." + string2);
        this.translatableName = Text.translatable("gameMode." + string2);
    }

    public int getId() {
        return this.id;
    }

    public String getName() {
        return this.name;
    }

    @Override
    public String asString() {
        return this.name;
    }

    public Text getTranslatableName() {
        return this.translatableName;
    }

    public Text getSimpleTranslatableName() {
        return this.simpleTranslatableName;
    }

    public void setAbilities(PlayerAbilities playerAbilities) {
        if (this == field_9220) {
            playerAbilities.allowFlying = true;
            playerAbilities.creativeMode = true;
            playerAbilities.invulnerable = true;
        } else if (this == field_9219) {
            playerAbilities.allowFlying = true;
            playerAbilities.creativeMode = false;
            playerAbilities.invulnerable = true;
            playerAbilities.flying = true;
        } else {
            playerAbilities.allowFlying = false;
            playerAbilities.creativeMode = false;
            playerAbilities.invulnerable = false;
            playerAbilities.flying = false;
        }
        playerAbilities.allowModifyWorld = !this.isBlockBreakingRestricted();
    }

    public boolean isBlockBreakingRestricted() {
        return this == field_9216 || this == field_9219;
    }

    public boolean isCreative() {
        return this == field_9220;
    }

    public boolean isSurvivalLike() {
        return this == field_9215 || this == field_9216;
    }

    public static GameMode byId(int i) {
        return BY_ID.apply(i);
    }

    public static GameMode byName(String string) {
        return GameMode.byName(string, field_9215);
    }

    @Nullable
    @Contract(value="_,!null->!null;_,null->_")
    public static GameMode byName(String string, @Nullable GameMode gameMode) {
        GameMode gameMode2 = CODEC.byId(string);
        return gameMode2 != null ? gameMode2 : gameMode;
    }

    public static int getId(@Nullable GameMode gameMode) {
        return gameMode != null ? gameMode.id : -1;
    }

    @Nullable
    public static GameMode getOrNull(int i) {
        if (i == -1) {
            return null;
        }
        return GameMode.byId(i);
    }

    static {
        DEFAULT = field_9215;
        CODEC = StringIdentifiable.createCodec(GameMode::values);
        BY_ID = ValueLists.createIdToValueFunction(GameMode::getId, GameMode.values(), ValueLists.OutOfBoundsHandling.field_41664);
    }
}


/*
 * Decompiled with CFR 0.2.1 (FabricMC 53fa44c9).
 */
package net.minecraft.world.biome.source.util;

import com.mojang.datafixers.util.Pair;
import java.util.List;
import java.util.function.Consumer;
import net.minecraft.SharedConstants;
import net.minecraft.registry.BuiltinRegistries;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.registry.RegistryWrapper;
import net.minecraft.util.annotation.Debug;
import net.minecraft.util.function.ToFloatFunction;
import net.minecraft.util.math.Spline;
import net.minecraft.world.biome.Biome;
import net.minecraft.world.biome.BiomeKeys;
import net.minecraft.world.biome.source.util.MultiNoiseUtil;
import net.minecraft.world.biome.source.util.VanillaTerrainParametersCreator;
import net.minecraft.world.gen.densityfunction.DensityFunction;
import net.minecraft.world.gen.densityfunction.DensityFunctionTypes;
import net.minecraft.world.gen.densityfunction.DensityFunctions;

public final class VanillaBiomeParameters {
    private static final float MAX_VALLEY_WEIRDNESS = 0.05f;
    private static final float MAX_LOW_WEIRDNESS = 0.26666668f;
    public static final float MAX_MID_WEIRDNESS = 0.4f;
    private static final float MAX_SECOND_HIGH_WEIRDNESS = 0.93333334f;
    private static final float field_34501 = 0.1f;
    public static final float MAX_HIGH_WEIRDNESS = 0.56666666f;
    private static final float MAX_PEAK_WEIRDNESS = 0.7666667f;
    public static final float field_35042 = -0.11f;
    public static final float field_35043 = 0.03f;
    public static final float field_35044 = 0.3f;
    public static final float field_35045 = -0.78f;
    public static final float field_35046 = -0.375f;
    private static final float field_39134 = -0.225f;
    private static final float field_39135 = 0.9f;
    private final MultiNoiseUtil.ParameterRange defaultParameter = MultiNoiseUtil.ParameterRange.of(-1.0f, 1.0f);
    private final MultiNoiseUtil.ParameterRange[] temperatureParameters = new MultiNoiseUtil.ParameterRange[]{MultiNoiseUtil.ParameterRange.of(-1.0f, -0.45f), MultiNoiseUtil.ParameterRange.of(-0.45f, -0.15f), MultiNoiseUtil.ParameterRange.of(-0.15f, 0.2f), MultiNoiseUtil.ParameterRange.of(0.2f, 0.55f), MultiNoiseUtil.ParameterRange.of(0.55f, 1.0f)};
    private final MultiNoiseUtil.ParameterRange[] humidityParameters = new MultiNoiseUtil.ParameterRange[]{MultiNoiseUtil.ParameterRange.of(-1.0f, -0.35f), MultiNoiseUtil.ParameterRange.of(-0.35f, -0.1f), MultiNoiseUtil.ParameterRange.of(-0.1f, 0.1f), MultiNoiseUtil.ParameterRange.of(0.1f, 0.3f), MultiNoiseUtil.ParameterRange.of(0.3f, 1.0f)};
    private final MultiNoiseUtil.ParameterRange[] erosionParameters = new MultiNoiseUtil.ParameterRange[]{MultiNoiseUtil.ParameterRange.of(-1.0f, -0.78f), MultiNoiseUtil.ParameterRange.of(-0.78f, -0.375f), MultiNoiseUtil.ParameterRange.of(-0.375f, -0.2225f), MultiNoiseUtil.ParameterRange.of(-0.2225f, 0.05f), MultiNoiseUtil.ParameterRange.of(0.05f, 0.45f), MultiNoiseUtil.ParameterRange.of(0.45f, 0.55f), MultiNoiseUtil.ParameterRange.of(0.55f, 1.0f)};
    private final MultiNoiseUtil.ParameterRange frozenTemperature = this.temperatureParameters[0];
    private final MultiNoiseUtil.ParameterRange nonFrozenTemperatureParameters = MultiNoiseUtil.ParameterRange.combine(this.temperatureParameters[1], this.temperatureParameters[4]);
    private final MultiNoiseUtil.ParameterRange mushroomFieldsContinentalness = MultiNoiseUtil.ParameterRange.of(-1.2f, -1.05f);
    private final MultiNoiseUtil.ParameterRange deepOceanContinentalness = MultiNoiseUtil.ParameterRange.of(-1.05f, -0.455f);
    private final MultiNoiseUtil.ParameterRange oceanContinentalness = MultiNoiseUtil.ParameterRange.of(-0.455f, -0.19f);
    private final MultiNoiseUtil.ParameterRange coastContinentalness = MultiNoiseUtil.ParameterRange.of(-0.19f, -0.11f);
    private final MultiNoiseUtil.ParameterRange riverContinentalness = MultiNoiseUtil.ParameterRange.of(-0.11f, 0.55f);
    private final MultiNoiseUtil.ParameterRange nearInlandContinentalness = MultiNoiseUtil.ParameterRange.of(-0.11f, 0.03f);
    private final MultiNoiseUtil.ParameterRange midInlandContinentalness = MultiNoiseUtil.ParameterRange.of(0.03f, 0.3f);
    private final MultiNoiseUtil.ParameterRange farInlandContinentalness = MultiNoiseUtil.ParameterRange.of(0.3f, 1.0f);
    private final RegistryKey<Biome>[][] oceanBiomes = new RegistryKey[][]{{BiomeKeys.field_9418, BiomeKeys.field_9470, BiomeKeys.field_9446, BiomeKeys.field_9439, BiomeKeys.field_9408}, {BiomeKeys.field_9435, BiomeKeys.field_9467, BiomeKeys.field_9423, BiomeKeys.field_9441, BiomeKeys.field_9408}};
    private final RegistryKey<Biome>[][] commonBiomes = new RegistryKey[][]{{BiomeKeys.field_35117, BiomeKeys.field_35117, BiomeKeys.field_35117, BiomeKeys.field_9454, BiomeKeys.field_9420}, {BiomeKeys.field_9451, BiomeKeys.field_9451, BiomeKeys.field_9409, BiomeKeys.field_9420, BiomeKeys.field_35113}, {BiomeKeys.field_9414, BiomeKeys.field_9451, BiomeKeys.field_9409, BiomeKeys.field_9412, BiomeKeys.field_9475}, {BiomeKeys.field_9449, BiomeKeys.field_9449, BiomeKeys.field_9409, BiomeKeys.field_9417, BiomeKeys.field_9417}, {BiomeKeys.field_9424, BiomeKeys.field_9424, BiomeKeys.field_9424, BiomeKeys.field_9424, BiomeKeys.field_9424}};
    private final RegistryKey<Biome>[][] uncommonBiomes = new RegistryKey[][]{{BiomeKeys.field_9453, null, BiomeKeys.field_9454, null, null}, {null, null, null, null, BiomeKeys.field_35119}, {BiomeKeys.field_9455, null, null, BiomeKeys.field_35112, null}, {null, null, BiomeKeys.field_9451, BiomeKeys.field_35118, BiomeKeys.field_9440}, {null, null, null, null, null}};
    private final RegistryKey<Biome>[][] nearMountainBiomes = new RegistryKey[][]{{BiomeKeys.field_35117, BiomeKeys.field_35117, BiomeKeys.field_35117, BiomeKeys.field_9454, BiomeKeys.field_9454}, {BiomeKeys.field_34470, BiomeKeys.field_34470, BiomeKeys.field_9409, BiomeKeys.field_9420, BiomeKeys.field_35113}, {BiomeKeys.field_34470, BiomeKeys.field_34470, BiomeKeys.field_34470, BiomeKeys.field_34470, BiomeKeys.field_9475}, {BiomeKeys.field_9430, BiomeKeys.field_9430, BiomeKeys.field_9409, BiomeKeys.field_9409, BiomeKeys.field_9417}, {BiomeKeys.field_9415, BiomeKeys.field_9415, BiomeKeys.field_9415, BiomeKeys.field_35110, BiomeKeys.field_35110}};
    private final RegistryKey<Biome>[][] specialNearMountainBiomes = new RegistryKey[][]{{BiomeKeys.field_9453, null, null, null, null}, {BiomeKeys.field_42720, null, BiomeKeys.field_34470, BiomeKeys.field_34470, BiomeKeys.field_35119}, {BiomeKeys.field_42720, BiomeKeys.field_42720, BiomeKeys.field_9409, BiomeKeys.field_9412, null}, {null, null, null, null, null}, {BiomeKeys.field_9443, BiomeKeys.field_9443, null, null, null}};
    private final RegistryKey<Biome>[][] windsweptBiomes = new RegistryKey[][]{{BiomeKeys.field_35111, BiomeKeys.field_35111, BiomeKeys.field_35116, BiomeKeys.field_35120, BiomeKeys.field_35120}, {BiomeKeys.field_35111, BiomeKeys.field_35111, BiomeKeys.field_35116, BiomeKeys.field_35120, BiomeKeys.field_35120}, {BiomeKeys.field_35116, BiomeKeys.field_35116, BiomeKeys.field_35116, BiomeKeys.field_35120, BiomeKeys.field_35120}, {null, null, null, null, null}, {null, null, null, null, null}};

    public List<MultiNoiseUtil.NoiseHypercube> getSpawnSuitabilityNoises() {
        MultiNoiseUtil.ParameterRange parameterRange = MultiNoiseUtil.ParameterRange.of(0.0f);
        float f = 0.16f;
        return List.of(new MultiNoiseUtil.NoiseHypercube(this.defaultParameter, this.defaultParameter, MultiNoiseUtil.ParameterRange.combine(this.riverContinentalness, this.defaultParameter), this.defaultParameter, parameterRange, MultiNoiseUtil.ParameterRange.of(-1.0f, -0.16f), 0L), new MultiNoiseUtil.NoiseHypercube(this.defaultParameter, this.defaultParameter, MultiNoiseUtil.ParameterRange.combine(this.riverContinentalness, this.defaultParameter), this.defaultParameter, parameterRange, MultiNoiseUtil.ParameterRange.of(0.16f, 1.0f), 0L));
    }

    protected void writeOverworldBiomeParameters(Consumer<Pair<MultiNoiseUtil.NoiseHypercube, RegistryKey<Biome>>> consumer) {
        if (SharedConstants.DEBUG_BIOME_SOURCE) {
            this.writeDebug(consumer);
            return;
        }
        this.writeOceanBiomes(consumer);
        this.writeLandBiomes(consumer);
        this.writeCaveBiomes(consumer);
    }

    private void writeDebug(Consumer<Pair<MultiNoiseUtil.NoiseHypercube, RegistryKey<Biome>>> consumer) {
        Spline spline2;
        RegistryWrapper.WrapperLookup wrapperLookup = BuiltinRegistries.createWrapperLookup();
        RegistryWrapper.Impl<DensityFunction> registryEntryLookup = wrapperLookup.getWrapperOrThrow(RegistryKeys.DENSITY_FUNCTION);
        DensityFunctionTypes.Spline.DensityFunctionWrapper densityFunctionWrapper = new DensityFunctionTypes.Spline.DensityFunctionWrapper(registryEntryLookup.getOrThrow(DensityFunctions.field_37122));
        DensityFunctionTypes.Spline.DensityFunctionWrapper densityFunctionWrapper2 = new DensityFunctionTypes.Spline.DensityFunctionWrapper(registryEntryLookup.getOrThrow(DensityFunctions.field_37123));
        DensityFunctionTypes.Spline.DensityFunctionWrapper densityFunctionWrapper3 = new DensityFunctionTypes.Spline.DensityFunctionWrapper(registryEntryLookup.getOrThrow(DensityFunctions.field_37693));
        consumer.accept(Pair.of(MultiNoiseUtil.createNoiseHypercube(this.defaultParameter, this.defaultParameter, this.defaultParameter, this.defaultParameter, MultiNoiseUtil.ParameterRange.of(0.0f), this.defaultParameter, 0.01f), BiomeKeys.field_9451));
        Spline spline = VanillaTerrainParametersCreator.createContinentalOffsetSpline(densityFunctionWrapper2, densityFunctionWrapper3, -0.15f, 0.0f, 0.0f, 0.1f, 0.0f, -0.03f, false, false, ToFloatFunction.IDENTITY);
        if (spline instanceof Spline.Implementation) {
            Spline.Implementation implementation = (Spline.Implementation)spline;
            RegistryKey<Biome> registryKey = BiomeKeys.field_9424;
            for (float f : implementation.comp_230()) {
                consumer.accept(Pair.of(MultiNoiseUtil.createNoiseHypercube(this.defaultParameter, this.defaultParameter, this.defaultParameter, MultiNoiseUtil.ParameterRange.of(f), MultiNoiseUtil.ParameterRange.of(0.0f), this.defaultParameter, 0.0f), registryKey));
                registryKey = registryKey == BiomeKeys.field_9424 ? BiomeKeys.field_9415 : BiomeKeys.field_9424;
            }
        }
        if ((spline2 = VanillaTerrainParametersCreator.createOffsetSpline(densityFunctionWrapper, densityFunctionWrapper2, densityFunctionWrapper3, false)) instanceof Spline.Implementation) {
            Spline.Implementation implementation2 = (Spline.Implementation)spline2;
            for (float f : implementation2.comp_230()) {
                consumer.accept(Pair.of(MultiNoiseUtil.createNoiseHypercube(this.defaultParameter, this.defaultParameter, MultiNoiseUtil.ParameterRange.of(f), this.defaultParameter, MultiNoiseUtil.ParameterRange.of(0.0f), this.defaultParameter, 0.0f), BiomeKeys.field_9454));
            }
        }
    }

    private void writeOceanBiomes(Consumer<Pair<MultiNoiseUtil.NoiseHypercube, RegistryKey<Biome>>> consumer) {
        this.writeBiomeParameters(consumer, this.defaultParameter, this.defaultParameter, this.mushroomFieldsContinentalness, this.defaultParameter, this.defaultParameter, 0.0f, BiomeKeys.field_9462);
        for (int i = 0; i < this.temperatureParameters.length; ++i) {
            MultiNoiseUtil.ParameterRange parameterRange = this.temperatureParameters[i];
            this.writeBiomeParameters(consumer, parameterRange, this.defaultParameter, this.deepOceanContinentalness, this.defaultParameter, this.defaultParameter, 0.0f, this.oceanBiomes[0][i]);
            this.writeBiomeParameters(consumer, parameterRange, this.defaultParameter, this.oceanContinentalness, this.defaultParameter, this.defaultParameter, 0.0f, this.oceanBiomes[1][i]);
        }
    }

    private void writeLandBiomes(Consumer<Pair<MultiNoiseUtil.NoiseHypercube, RegistryKey<Biome>>> consumer) {
        this.writeMidBiomes(consumer, MultiNoiseUtil.ParameterRange.of(-1.0f, -0.93333334f));
        this.writeHighBiomes(consumer, MultiNoiseUtil.ParameterRange.of(-0.93333334f, -0.7666667f));
        this.writePeakBiomes(consumer, MultiNoiseUtil.ParameterRange.of(-0.7666667f, -0.56666666f));
        this.writeHighBiomes(consumer, MultiNoiseUtil.ParameterRange.of(-0.56666666f, -0.4f));
        this.writeMidBiomes(consumer, MultiNoiseUtil.ParameterRange.of(-0.4f, -0.26666668f));
        this.writeLowBiomes(consumer, MultiNoiseUtil.ParameterRange.of(-0.26666668f, -0.05f));
        this.writeValleyBiomes(consumer, MultiNoiseUtil.ParameterRange.of(-0.05f, 0.05f));
        this.writeLowBiomes(consumer, MultiNoiseUtil.ParameterRange.of(0.05f, 0.26666668f));
        this.writeMidBiomes(consumer, MultiNoiseUtil.ParameterRange.of(0.26666668f, 0.4f));
        this.writeHighBiomes(consumer, MultiNoiseUtil.ParameterRange.of(0.4f, 0.56666666f));
        this.writePeakBiomes(consumer, MultiNoiseUtil.ParameterRange.of(0.56666666f, 0.7666667f));
        this.writeHighBiomes(consumer, MultiNoiseUtil.ParameterRange.of(0.7666667f, 0.93333334f));
        this.writeMidBiomes(consumer, MultiNoiseUtil.ParameterRange.of(0.93333334f, 1.0f));
    }

    private void writePeakBiomes(Consumer<Pair<MultiNoiseUtil.NoiseHypercube, RegistryKey<Biome>>> consumer, MultiNoiseUtil.ParameterRange parameterRange) {
        for (int i = 0; i < this.temperatureParameters.length; ++i) {
            MultiNoiseUtil.ParameterRange parameterRange2 = this.temperatureParameters[i];
            for (int j = 0; j < this.humidityParameters.length; ++j) {
                MultiNoiseUtil.ParameterRange parameterRange3 = this.humidityParameters[j];
                RegistryKey<Biome> registryKey = this.getRegularBiome(i, j, parameterRange);
                RegistryKey<Biome> registryKey2 = this.getBadlandsOrRegularBiome(i, j, parameterRange);
                RegistryKey<Biome> registryKey3 = this.getMountainStartBiome(i, j, parameterRange);
                RegistryKey<Biome> registryKey4 = this.getNearMountainBiome(i, j, parameterRange);
                RegistryKey<Biome> registryKey5 = this.getWindsweptOrRegularBiome(i, j, parameterRange);
                RegistryKey<Biome> registryKey6 = this.getBiomeOrWindsweptSavanna(i, j, parameterRange, registryKey5);
                RegistryKey<Biome> registryKey7 = this.getPeakBiome(i, j, parameterRange);
                this.writeBiomeParameters(consumer, parameterRange2, parameterRange3, MultiNoiseUtil.ParameterRange.combine(this.coastContinentalness, this.farInlandContinentalness), this.erosionParameters[0], parameterRange, 0.0f, registryKey7);
                this.writeBiomeParameters(consumer, parameterRange2, parameterRange3, MultiNoiseUtil.ParameterRange.combine(this.coastContinentalness, this.nearInlandContinentalness), this.erosionParameters[1], parameterRange, 0.0f, registryKey3);
                this.writeBiomeParameters(consumer, parameterRange2, parameterRange3, MultiNoiseUtil.ParameterRange.combine(this.midInlandContinentalness, this.farInlandContinentalness), this.erosionParameters[1], parameterRange, 0.0f, registryKey7);
                this.writeBiomeParameters(consumer, parameterRange2, parameterRange3, MultiNoiseUtil.ParameterRange.combine(this.coastContinentalness, this.nearInlandContinentalness), MultiNoiseUtil.ParameterRange.combine(this.erosionParameters[2], this.erosionParameters[3]), parameterRange, 0.0f, registryKey);
                this.writeBiomeParameters(consumer, parameterRange2, parameterRange3, MultiNoiseUtil.ParameterRange.combine(this.midInlandContinentalness, this.farInlandContinentalness), this.erosionParameters[2], parameterRange, 0.0f, registryKey4);
                this.writeBiomeParameters(consumer, parameterRange2, parameterRange3, this.midInlandContinentalness, this.erosionParameters[3], parameterRange, 0.0f, registryKey2);
                this.writeBiomeParameters(consumer, parameterRange2, parameterRange3, this.farInlandContinentalness, this.erosionParameters[3], parameterRange, 0.0f, registryKey4);
                this.writeBiomeParameters(consumer, parameterRange2, parameterRange3, MultiNoiseUtil.ParameterRange.combine(this.coastContinentalness, this.farInlandContinentalness), this.erosionParameters[4], parameterRange, 0.0f, registryKey);
                this.writeBiomeParameters(consumer, parameterRange2, parameterRange3, MultiNoiseUtil.ParameterRange.combine(this.coastContinentalness, this.nearInlandContinentalness), this.erosionParameters[5], parameterRange, 0.0f, registryKey6);
                this.writeBiomeParameters(consumer, parameterRange2, parameterRange3, MultiNoiseUtil.ParameterRange.combine(this.midInlandContinentalness, this.farInlandContinentalness), this.erosionParameters[5], parameterRange, 0.0f, registryKey5);
                this.writeBiomeParameters(consumer, parameterRange2, parameterRange3, MultiNoiseUtil.ParameterRange.combine(this.coastContinentalness, this.farInlandContinentalness), this.erosionParameters[6], parameterRange, 0.0f, registryKey);
            }
        }
    }

    private void writeHighBiomes(Consumer<Pair<MultiNoiseUtil.NoiseHypercube, RegistryKey<Biome>>> consumer, MultiNoiseUtil.ParameterRange parameterRange) {
        for (int i = 0; i < this.temperatureParameters.length; ++i) {
            MultiNoiseUtil.ParameterRange parameterRange2 = this.temperatureParameters[i];
            for (int j = 0; j < this.humidityParameters.length; ++j) {
                MultiNoiseUtil.ParameterRange parameterRange3 = this.humidityParameters[j];
                RegistryKey<Biome> registryKey = this.getRegularBiome(i, j, parameterRange);
                RegistryKey<Biome> registryKey2 = this.getBadlandsOrRegularBiome(i, j, parameterRange);
                RegistryKey<Biome> registryKey3 = this.getMountainStartBiome(i, j, parameterRange);
                RegistryKey<Biome> registryKey4 = this.getNearMountainBiome(i, j, parameterRange);
                RegistryKey<Biome> registryKey5 = this.getWindsweptOrRegularBiome(i, j, parameterRange);
                RegistryKey<Biome> registryKey6 = this.getBiomeOrWindsweptSavanna(i, j, parameterRange, registryKey);
                RegistryKey<Biome> registryKey7 = this.getMountainSlopeBiome(i, j, parameterRange);
                RegistryKey<Biome> registryKey8 = this.getPeakBiome(i, j, parameterRange);
                this.writeBiomeParameters(consumer, parameterRange2, parameterRange3, this.coastContinentalness, MultiNoiseUtil.ParameterRange.combine(this.erosionParameters[0], this.erosionParameters[1]), parameterRange, 0.0f, registryKey);
                this.writeBiomeParameters(consumer, parameterRange2, parameterRange3, this.nearInlandContinentalness, this.erosionParameters[0], parameterRange, 0.0f, registryKey7);
                this.writeBiomeParameters(consumer, parameterRange2, parameterRange3, MultiNoiseUtil.ParameterRange.combine(this.midInlandContinentalness, this.farInlandContinentalness), this.erosionParameters[0], parameterRange, 0.0f, registryKey8);
                this.writeBiomeParameters(consumer, parameterRange2, parameterRange3, this.nearInlandContinentalness, this.erosionParameters[1], parameterRange, 0.0f, registryKey3);
                this.writeBiomeParameters(consumer, parameterRange2, parameterRange3, MultiNoiseUtil.ParameterRange.combine(this.midInlandContinentalness, this.farInlandContinentalness), this.erosionParameters[1], parameterRange, 0.0f, registryKey7);
                this.writeBiomeParameters(consumer, parameterRange2, parameterRange3, MultiNoiseUtil.ParameterRange.combine(this.coastContinentalness, this.nearInlandContinentalness), MultiNoiseUtil.ParameterRange.combine(this.erosionParameters[2], this.erosionParameters[3]), parameterRange, 0.0f, registryKey);
                this.writeBiomeParameters(consumer, parameterRange2, parameterRange3, MultiNoiseUtil.ParameterRange.combine(this.midInlandContinentalness, this.farInlandContinentalness), this.erosionParameters[2], parameterRange, 0.0f, registryKey4);
                this.writeBiomeParameters(consumer, parameterRange2, parameterRange3, this.midInlandContinentalness, this.erosionParameters[3], parameterRange, 0.0f, registryKey2);
                this.writeBiomeParameters(consumer, parameterRange2, parameterRange3, this.farInlandContinentalness, this.erosionParameters[3], parameterRange, 0.0f, registryKey4);
                this.writeBiomeParameters(consumer, parameterRange2, parameterRange3, MultiNoiseUtil.ParameterRange.combine(this.coastContinentalness, this.farInlandContinentalness), this.erosionParameters[4], parameterRange, 0.0f, registryKey);
                this.writeBiomeParameters(consumer, parameterRange2, parameterRange3, MultiNoiseUtil.ParameterRange.combine(this.coastContinentalness, this.nearInlandContinentalness), this.erosionParameters[5], parameterRange, 0.0f, registryKey6);
                this.writeBiomeParameters(consumer, parameterRange2, parameterRange3, MultiNoiseUtil.ParameterRange.combine(this.midInlandContinentalness, this.farInlandContinentalness), this.erosionParameters[5], parameterRange, 0.0f, registryKey5);
                this.writeBiomeParameters(consumer, parameterRange2, parameterRange3, MultiNoiseUtil.ParameterRange.combine(this.coastContinentalness, this.farInlandContinentalness), this.erosionParameters[6], parameterRange, 0.0f, registryKey);
            }
        }
    }

    private void writeMidBiomes(Consumer<Pair<MultiNoiseUtil.NoiseHypercube, RegistryKey<Biome>>> consumer, MultiNoiseUtil.ParameterRange parameterRange) {
        this.writeBiomeParameters(consumer, this.defaultParameter, this.defaultParameter, this.coastContinentalness, MultiNoiseUtil.ParameterRange.combine(this.erosionParameters[0], this.erosionParameters[2]), parameterRange, 0.0f, BiomeKeys.field_9419);
        this.writeBiomeParameters(consumer, MultiNoiseUtil.ParameterRange.combine(this.temperatureParameters[1], this.temperatureParameters[2]), this.defaultParameter, MultiNoiseUtil.ParameterRange.combine(this.nearInlandContinentalness, this.farInlandContinentalness), this.erosionParameters[6], parameterRange, 0.0f, BiomeKeys.field_9471);
        this.writeBiomeParameters(consumer, MultiNoiseUtil.ParameterRange.combine(this.temperatureParameters[3], this.temperatureParameters[4]), this.defaultParameter, MultiNoiseUtil.ParameterRange.combine(this.nearInlandContinentalness, this.farInlandContinentalness), this.erosionParameters[6], parameterRange, 0.0f, BiomeKeys.field_38748);
        for (int i = 0; i < this.temperatureParameters.length; ++i) {
            MultiNoiseUtil.ParameterRange parameterRange2 = this.temperatureParameters[i];
            for (int j = 0; j < this.humidityParameters.length; ++j) {
                MultiNoiseUtil.ParameterRange parameterRange3 = this.humidityParameters[j];
                RegistryKey<Biome> registryKey = this.getRegularBiome(i, j, parameterRange);
                RegistryKey<Biome> registryKey2 = this.getBadlandsOrRegularBiome(i, j, parameterRange);
                RegistryKey<Biome> registryKey3 = this.getMountainStartBiome(i, j, parameterRange);
                RegistryKey<Biome> registryKey4 = this.getWindsweptOrRegularBiome(i, j, parameterRange);
                RegistryKey<Biome> registryKey5 = this.getNearMountainBiome(i, j, parameterRange);
                RegistryKey<Biome> registryKey6 = this.getShoreBiome(i, j);
                RegistryKey<Biome> registryKey7 = this.getBiomeOrWindsweptSavanna(i, j, parameterRange, registryKey);
                RegistryKey<Biome> registryKey8 = this.getErodedShoreBiome(i, j, parameterRange);
                RegistryKey<Biome> registryKey9 = this.getMountainSlopeBiome(i, j, parameterRange);
                this.writeBiomeParameters(consumer, parameterRange2, parameterRange3, MultiNoiseUtil.ParameterRange.combine(this.nearInlandContinentalness, this.farInlandContinentalness), this.erosionParameters[0], parameterRange, 0.0f, registryKey9);
                this.writeBiomeParameters(consumer, parameterRange2, parameterRange3, MultiNoiseUtil.ParameterRange.combine(this.nearInlandContinentalness, this.midInlandContinentalness), this.erosionParameters[1], parameterRange, 0.0f, registryKey3);
                this.writeBiomeParameters(consumer, parameterRange2, parameterRange3, this.farInlandContinentalness, this.erosionParameters[1], parameterRange, 0.0f, i == 0 ? registryKey9 : registryKey5);
                this.writeBiomeParameters(consumer, parameterRange2, parameterRange3, this.nearInlandContinentalness, this.erosionParameters[2], parameterRange, 0.0f, registryKey);
                this.writeBiomeParameters(consumer, parameterRange2, parameterRange3, this.midInlandContinentalness, this.erosionParameters[2], parameterRange, 0.0f, registryKey2);
                this.writeBiomeParameters(consumer, parameterRange2, parameterRange3, this.farInlandContinentalness, this.erosionParameters[2], parameterRange, 0.0f, registryKey5);
                this.writeBiomeParameters(consumer, parameterRange2, parameterRange3, MultiNoiseUtil.ParameterRange.combine(this.coastContinentalness, this.nearInlandContinentalness), this.erosionParameters[3], parameterRange, 0.0f, registryKey);
                this.writeBiomeParameters(consumer, parameterRange2, parameterRange3, MultiNoiseUtil.ParameterRange.combine(this.midInlandContinentalness, this.farInlandContinentalness), this.erosionParameters[3], parameterRange, 0.0f, registryKey2);
                if (parameterRange.max() < 0L) {
                    this.writeBiomeParameters(consumer, parameterRange2, parameterRange3, this.coastContinentalness, this.erosionParameters[4], parameterRange, 0.0f, registryKey6);
                    this.writeBiomeParameters(consumer, parameterRange2, parameterRange3, MultiNoiseUtil.ParameterRange.combine(this.nearInlandContinentalness, this.farInlandContinentalness), this.erosionParameters[4], parameterRange, 0.0f, registryKey);
                } else {
                    this.writeBiomeParameters(consumer, parameterRange2, parameterRange3, MultiNoiseUtil.ParameterRange.combine(this.coastContinentalness, this.farInlandContinentalness), this.erosionParameters[4], parameterRange, 0.0f, registryKey);
                }
                this.writeBiomeParameters(consumer, parameterRange2, parameterRange3, this.coastContinentalness, this.erosionParameters[5], parameterRange, 0.0f, registryKey8);
                this.writeBiomeParameters(consumer, parameterRange2, parameterRange3, this.nearInlandContinentalness, this.erosionParameters[5], parameterRange, 0.0f, registryKey7);
                this.writeBiomeParameters(consumer, parameterRange2, parameterRange3, MultiNoiseUtil.ParameterRange.combine(this.midInlandContinentalness, this.farInlandContinentalness), this.erosionParameters[5], parameterRange, 0.0f, registryKey4);
                if (parameterRange.max() < 0L) {
                    this.writeBiomeParameters(consumer, parameterRange2, parameterRange3, this.coastContinentalness, this.erosionParameters[6], parameterRange, 0.0f, registryKey6);
                } else {
                    this.writeBiomeParameters(consumer, parameterRange2, parameterRange3, this.coastContinentalness, this.erosionParameters[6], parameterRange, 0.0f, registryKey);
                }
                if (i != 0) continue;
                this.writeBiomeParameters(consumer, parameterRange2, parameterRange3, MultiNoiseUtil.ParameterRange.combine(this.nearInlandContinentalness, this.farInlandContinentalness), this.erosionParameters[6], parameterRange, 0.0f, registryKey);
            }
        }
    }

    private void writeLowBiomes(Consumer<Pair<MultiNoiseUtil.NoiseHypercube, RegistryKey<Biome>>> consumer, MultiNoiseUtil.ParameterRange parameterRange) {
        this.writeBiomeParameters(consumer, this.defaultParameter, this.defaultParameter, this.coastContinentalness, MultiNoiseUtil.ParameterRange.combine(this.erosionParameters[0], this.erosionParameters[2]), parameterRange, 0.0f, BiomeKeys.field_9419);
        this.writeBiomeParameters(consumer, MultiNoiseUtil.ParameterRange.combine(this.temperatureParameters[1], this.temperatureParameters[2]), this.defaultParameter, MultiNoiseUtil.ParameterRange.combine(this.nearInlandContinentalness, this.farInlandContinentalness), this.erosionParameters[6], parameterRange, 0.0f, BiomeKeys.field_9471);
        this.writeBiomeParameters(consumer, MultiNoiseUtil.ParameterRange.combine(this.temperatureParameters[3], this.temperatureParameters[4]), this.defaultParameter, MultiNoiseUtil.ParameterRange.combine(this.nearInlandContinentalness, this.farInlandContinentalness), this.erosionParameters[6], parameterRange, 0.0f, BiomeKeys.field_38748);
        for (int i = 0; i < this.temperatureParameters.length; ++i) {
            MultiNoiseUtil.ParameterRange parameterRange2 = this.temperatureParameters[i];
            for (int j = 0; j < this.humidityParameters.length; ++j) {
                MultiNoiseUtil.ParameterRange parameterRange3 = this.humidityParameters[j];
                RegistryKey<Biome> registryKey = this.getRegularBiome(i, j, parameterRange);
                RegistryKey<Biome> registryKey2 = this.getBadlandsOrRegularBiome(i, j, parameterRange);
                RegistryKey<Biome> registryKey3 = this.getMountainStartBiome(i, j, parameterRange);
                RegistryKey<Biome> registryKey4 = this.getShoreBiome(i, j);
                RegistryKey<Biome> registryKey5 = this.getBiomeOrWindsweptSavanna(i, j, parameterRange, registryKey);
                RegistryKey<Biome> registryKey6 = this.getErodedShoreBiome(i, j, parameterRange);
                this.writeBiomeParameters(consumer, parameterRange2, parameterRange3, this.nearInlandContinentalness, MultiNoiseUtil.ParameterRange.combine(this.erosionParameters[0], this.erosionParameters[1]), parameterRange, 0.0f, registryKey2);
                this.writeBiomeParameters(consumer, parameterRange2, parameterRange3, MultiNoiseUtil.ParameterRange.combine(this.midInlandContinentalness, this.farInlandContinentalness), MultiNoiseUtil.ParameterRange.combine(this.erosionParameters[0], this.erosionParameters[1]), parameterRange, 0.0f, registryKey3);
                this.writeBiomeParameters(consumer, parameterRange2, parameterRange3, this.nearInlandContinentalness, MultiNoiseUtil.ParameterRange.combine(this.erosionParameters[2], this.erosionParameters[3]), parameterRange, 0.0f, registryKey);
                this.writeBiomeParameters(consumer, parameterRange2, parameterRange3, MultiNoiseUtil.ParameterRange.combine(this.midInlandContinentalness, this.farInlandContinentalness), MultiNoiseUtil.ParameterRange.combine(this.erosionParameters[2], this.erosionParameters[3]), parameterRange, 0.0f, registryKey2);
                this.writeBiomeParameters(consumer, parameterRange2, parameterRange3, this.coastContinentalness, MultiNoiseUtil.ParameterRange.combine(this.erosionParameters[3], this.erosionParameters[4]), parameterRange, 0.0f, registryKey4);
                this.writeBiomeParameters(consumer, parameterRange2, parameterRange3, MultiNoiseUtil.ParameterRange.combine(this.nearInlandContinentalness, this.farInlandContinentalness), this.erosionParameters[4], parameterRange, 0.0f, registryKey);
                this.writeBiomeParameters(consumer, parameterRange2, parameterRange3, this.coastContinentalness, this.erosionParameters[5], parameterRange, 0.0f, registryKey6);
                this.writeBiomeParameters(consumer, parameterRange2, parameterRange3, this.nearInlandContinentalness, this.erosionParameters[5], parameterRange, 0.0f, registryKey5);
                this.writeBiomeParameters(consumer, parameterRange2, parameterRange3, MultiNoiseUtil.ParameterRange.combine(this.midInlandContinentalness, this.farInlandContinentalness), this.erosionParameters[5], parameterRange, 0.0f, registryKey);
                this.writeBiomeParameters(consumer, parameterRange2, parameterRange3, this.coastContinentalness, this.erosionParameters[6], parameterRange, 0.0f, registryKey4);
                if (i != 0) continue;
                this.writeBiomeParameters(consumer, parameterRange2, parameterRange3, MultiNoiseUtil.ParameterRange.combine(this.nearInlandContinentalness, this.farInlandContinentalness), this.erosionParameters[6], parameterRange, 0.0f, registryKey);
            }
        }
    }

    private void writeValleyBiomes(Consumer<Pair<MultiNoiseUtil.NoiseHypercube, RegistryKey<Biome>>> consumer, MultiNoiseUtil.ParameterRange parameterRange) {
        this.writeBiomeParameters(consumer, this.frozenTemperature, this.defaultParameter, this.coastContinentalness, MultiNoiseUtil.ParameterRange.combine(this.erosionParameters[0], this.erosionParameters[1]), parameterRange, 0.0f, parameterRange.max() < 0L ? BiomeKeys.field_9419 : BiomeKeys.field_9463);
        this.writeBiomeParameters(consumer, this.nonFrozenTemperatureParameters, this.defaultParameter, this.coastContinentalness, MultiNoiseUtil.ParameterRange.combine(this.erosionParameters[0], this.erosionParameters[1]), parameterRange, 0.0f, parameterRange.max() < 0L ? BiomeKeys.field_9419 : BiomeKeys.field_9438);
        this.writeBiomeParameters(consumer, this.frozenTemperature, this.defaultParameter, this.nearInlandContinentalness, MultiNoiseUtil.ParameterRange.combine(this.erosionParameters[0], this.erosionParameters[1]), parameterRange, 0.0f, BiomeKeys.field_9463);
        this.writeBiomeParameters(consumer, this.nonFrozenTemperatureParameters, this.defaultParameter, this.nearInlandContinentalness, MultiNoiseUtil.ParameterRange.combine(this.erosionParameters[0], this.erosionParameters[1]), parameterRange, 0.0f, BiomeKeys.field_9438);
        this.writeBiomeParameters(consumer, this.frozenTemperature, this.defaultParameter, MultiNoiseUtil.ParameterRange.combine(this.coastContinentalness, this.farInlandContinentalness), MultiNoiseUtil.ParameterRange.combine(this.erosionParameters[2], this.erosionParameters[5]), parameterRange, 0.0f, BiomeKeys.field_9463);
        this.writeBiomeParameters(consumer, this.nonFrozenTemperatureParameters, this.defaultParameter, MultiNoiseUtil.ParameterRange.combine(this.coastContinentalness, this.farInlandContinentalness), MultiNoiseUtil.ParameterRange.combine(this.erosionParameters[2], this.erosionParameters[5]), parameterRange, 0.0f, BiomeKeys.field_9438);
        this.writeBiomeParameters(consumer, this.frozenTemperature, this.defaultParameter, this.coastContinentalness, this.erosionParameters[6], parameterRange, 0.0f, BiomeKeys.field_9463);
        this.writeBiomeParameters(consumer, this.nonFrozenTemperatureParameters, this.defaultParameter, this.coastContinentalness, this.erosionParameters[6], parameterRange, 0.0f, BiomeKeys.field_9438);
        this.writeBiomeParameters(consumer, MultiNoiseUtil.ParameterRange.combine(this.temperatureParameters[1], this.temperatureParameters[2]), this.defaultParameter, MultiNoiseUtil.ParameterRange.combine(this.riverContinentalness, this.farInlandContinentalness), this.erosionParameters[6], parameterRange, 0.0f, BiomeKeys.field_9471);
        this.writeBiomeParameters(consumer, MultiNoiseUtil.ParameterRange.combine(this.temperatureParameters[3], this.temperatureParameters[4]), this.defaultParameter, MultiNoiseUtil.ParameterRange.combine(this.riverContinentalness, this.farInlandContinentalness), this.erosionParameters[6], parameterRange, 0.0f, BiomeKeys.field_38748);
        this.writeBiomeParameters(consumer, this.frozenTemperature, this.defaultParameter, MultiNoiseUtil.ParameterRange.combine(this.riverContinentalness, this.farInlandContinentalness), this.erosionParameters[6], parameterRange, 0.0f, BiomeKeys.field_9463);
        for (int i = 0; i < this.temperatureParameters.length; ++i) {
            MultiNoiseUtil.ParameterRange parameterRange2 = this.temperatureParameters[i];
            for (int j = 0; j < this.humidityParameters.length; ++j) {
                MultiNoiseUtil.ParameterRange parameterRange3 = this.humidityParameters[j];
                RegistryKey<Biome> registryKey = this.getBadlandsOrRegularBiome(i, j, parameterRange);
                this.writeBiomeParameters(consumer, parameterRange2, parameterRange3, MultiNoiseUtil.ParameterRange.combine(this.midInlandContinentalness, this.farInlandContinentalness), MultiNoiseUtil.ParameterRange.combine(this.erosionParameters[0], this.erosionParameters[1]), parameterRange, 0.0f, registryKey);
            }
        }
    }

    private void writeCaveBiomes(Consumer<Pair<MultiNoiseUtil.NoiseHypercube, RegistryKey<Biome>>> consumer) {
        this.writeCaveBiomeParameters(consumer, this.defaultParameter, this.defaultParameter, MultiNoiseUtil.ParameterRange.of(0.8f, 1.0f), this.defaultParameter, this.defaultParameter, 0.0f, BiomeKeys.field_28107);
        this.writeCaveBiomeParameters(consumer, this.defaultParameter, MultiNoiseUtil.ParameterRange.of(0.7f, 1.0f), this.defaultParameter, this.defaultParameter, this.defaultParameter, 0.0f, BiomeKeys.field_29218);
        this.writeDeepDarkParameters(consumer, this.defaultParameter, this.defaultParameter, this.defaultParameter, MultiNoiseUtil.ParameterRange.combine(this.erosionParameters[0], this.erosionParameters[1]), this.defaultParameter, 0.0f, BiomeKeys.field_37543);
    }

    private RegistryKey<Biome> getRegularBiome(int i, int j, MultiNoiseUtil.ParameterRange parameterRange) {
        if (parameterRange.max() < 0L) {
            return this.commonBiomes[i][j];
        }
        RegistryKey<Biome> registryKey = this.uncommonBiomes[i][j];
        return registryKey == null ? this.commonBiomes[i][j] : registryKey;
    }

    private RegistryKey<Biome> getBadlandsOrRegularBiome(int i, int j, MultiNoiseUtil.ParameterRange parameterRange) {
        return i == 4 ? this.getBadlandsBiome(j, parameterRange) : this.getRegularBiome(i, j, parameterRange);
    }

    private RegistryKey<Biome> getMountainStartBiome(int i, int j, MultiNoiseUtil.ParameterRange parameterRange) {
        return i == 0 ? this.getMountainSlopeBiome(i, j, parameterRange) : this.getBadlandsOrRegularBiome(i, j, parameterRange);
    }

    private RegistryKey<Biome> getBiomeOrWindsweptSavanna(int i, int j, MultiNoiseUtil.ParameterRange parameterRange, RegistryKey<Biome> registryKey) {
        if (i > 1 && j < 4 && parameterRange.max() >= 0L) {
            return BiomeKeys.field_35114;
        }
        return registryKey;
    }

    private RegistryKey<Biome> getErodedShoreBiome(int i, int j, MultiNoiseUtil.ParameterRange parameterRange) {
        RegistryKey<Biome> registryKey = parameterRange.max() >= 0L ? this.getRegularBiome(i, j, parameterRange) : this.getShoreBiome(i, j);
        return this.getBiomeOrWindsweptSavanna(i, j, parameterRange, registryKey);
    }

    private RegistryKey<Biome> getShoreBiome(int i, int j) {
        if (i == 0) {
            return BiomeKeys.field_9478;
        }
        if (i == 4) {
            return BiomeKeys.field_9424;
        }
        return BiomeKeys.field_9434;
    }

    private RegistryKey<Biome> getBadlandsBiome(int i, MultiNoiseUtil.ParameterRange parameterRange) {
        if (i < 2) {
            return parameterRange.max() < 0L ? BiomeKeys.field_9415 : BiomeKeys.field_9443;
        }
        if (i < 3) {
            return BiomeKeys.field_9415;
        }
        return BiomeKeys.field_35110;
    }

    private RegistryKey<Biome> getNearMountainBiome(int i, int j, MultiNoiseUtil.ParameterRange parameterRange) {
        RegistryKey<Biome> registryKey;
        if (parameterRange.max() >= 0L && (registryKey = this.specialNearMountainBiomes[i][j]) != null) {
            return registryKey;
        }
        return this.nearMountainBiomes[i][j];
    }

    private RegistryKey<Biome> getPeakBiome(int i, int j, MultiNoiseUtil.ParameterRange parameterRange) {
        if (i <= 2) {
            return parameterRange.max() < 0L ? BiomeKeys.field_34474 : BiomeKeys.field_35115;
        }
        if (i == 3) {
            return BiomeKeys.field_34475;
        }
        return this.getBadlandsBiome(j, parameterRange);
    }

    private RegistryKey<Biome> getMountainSlopeBiome(int i, int j, MultiNoiseUtil.ParameterRange parameterRange) {
        if (i >= 3) {
            return this.getNearMountainBiome(i, j, parameterRange);
        }
        if (j <= 1) {
            return BiomeKeys.field_34472;
        }
        return BiomeKeys.field_34471;
    }

    private RegistryKey<Biome> getWindsweptOrRegularBiome(int i, int j, MultiNoiseUtil.ParameterRange parameterRange) {
        RegistryKey<Biome> registryKey = this.windsweptBiomes[i][j];
        return registryKey == null ? this.getRegularBiome(i, j, parameterRange) : registryKey;
    }

    private void writeBiomeParameters(Consumer<Pair<MultiNoiseUtil.NoiseHypercube, RegistryKey<Biome>>> consumer, MultiNoiseUtil.ParameterRange parameterRange, MultiNoiseUtil.ParameterRange parameterRange2, MultiNoiseUtil.ParameterRange parameterRange3, MultiNoiseUtil.ParameterRange parameterRange4, MultiNoiseUtil.ParameterRange parameterRange5, float f, RegistryKey<Biome> registryKey) {
        consumer.accept(Pair.of(MultiNoiseUtil.createNoiseHypercube(parameterRange, parameterRange2, parameterRange3, parameterRange4, MultiNoiseUtil.ParameterRange.of(0.0f), parameterRange5, f), registryKey));
        consumer.accept(Pair.of(MultiNoiseUtil.createNoiseHypercube(parameterRange, parameterRange2, parameterRange3, parameterRange4, MultiNoiseUtil.ParameterRange.of(1.0f), parameterRange5, f), registryKey));
    }

    private void writeCaveBiomeParameters(Consumer<Pair<MultiNoiseUtil.NoiseHypercube, RegistryKey<Biome>>> consumer, MultiNoiseUtil.ParameterRange parameterRange, MultiNoiseUtil.ParameterRange parameterRange2, MultiNoiseUtil.ParameterRange parameterRange3, MultiNoiseUtil.ParameterRange parameterRange4, MultiNoiseUtil.ParameterRange parameterRange5, float f, RegistryKey<Biome> registryKey) {
        consumer.accept(Pair.of(MultiNoiseUtil.createNoiseHypercube(parameterRange, parameterRange2, parameterRange3, parameterRange4, MultiNoiseUtil.ParameterRange.of(0.2f, 0.9f), parameterRange5, f), registryKey));
    }

    private void writeDeepDarkParameters(Consumer<Pair<MultiNoiseUtil.NoiseHypercube, RegistryKey<Biome>>> consumer, MultiNoiseUtil.ParameterRange parameterRange, MultiNoiseUtil.ParameterRange parameterRange2, MultiNoiseUtil.ParameterRange parameterRange3, MultiNoiseUtil.ParameterRange parameterRange4, MultiNoiseUtil.ParameterRange parameterRange5, float f, RegistryKey<Biome> registryKey) {
        consumer.accept(Pair.of(MultiNoiseUtil.createNoiseHypercube(parameterRange, parameterRange2, parameterRange3, parameterRange4, MultiNoiseUtil.ParameterRange.of(1.1f), parameterRange5, f), registryKey));
    }

    public static boolean method_43718(DensityFunction densityFunction, DensityFunction densityFunction2, DensityFunction.NoisePos noisePos) {
        return densityFunction.sample(noisePos) < (double)-0.225f && densityFunction2.sample(noisePos) > (double)0.9f;
    }

    public static String getPeaksValleysDescription(double d) {
        if (d < (double)DensityFunctions.getPeaksValleysNoise(0.05f)) {
            return "Valley";
        }
        if (d < (double)DensityFunctions.getPeaksValleysNoise(0.26666668f)) {
            return "Low";
        }
        if (d < (double)DensityFunctions.getPeaksValleysNoise(0.4f)) {
            return "Mid";
        }
        if (d < (double)DensityFunctions.getPeaksValleysNoise(0.56666666f)) {
            return "High";
        }
        return "Peak";
    }

    public String getContinentalnessDescription(double d) {
        double e = MultiNoiseUtil.toLong((float)d);
        if (e < (double)this.mushroomFieldsContinentalness.max()) {
            return "Mushroom fields";
        }
        if (e < (double)this.deepOceanContinentalness.max()) {
            return "Deep ocean";
        }
        if (e < (double)this.oceanContinentalness.max()) {
            return "Ocean";
        }
        if (e < (double)this.coastContinentalness.max()) {
            return "Coast";
        }
        if (e < (double)this.nearInlandContinentalness.max()) {
            return "Near inland";
        }
        if (e < (double)this.midInlandContinentalness.max()) {
            return "Mid inland";
        }
        return "Far inland";
    }

    public String getErosionDescription(double d) {
        return VanillaBiomeParameters.getNoiseRangeIndex(d, this.erosionParameters);
    }

    public String getTemperatureDescription(double d) {
        return VanillaBiomeParameters.getNoiseRangeIndex(d, this.temperatureParameters);
    }

    public String getHumidityDescription(double d) {
        return VanillaBiomeParameters.getNoiseRangeIndex(d, this.humidityParameters);
    }

    private static String getNoiseRangeIndex(double d, MultiNoiseUtil.ParameterRange[] parameterRanges) {
        double e = MultiNoiseUtil.toLong((float)d);
        for (int i = 0; i < parameterRanges.length; ++i) {
            if (!(e < (double)parameterRanges[i].max())) continue;
            return "" + i;
        }
        return "?";
    }

    @Debug
    public MultiNoiseUtil.ParameterRange[] getTemperatureParameters() {
        return this.temperatureParameters;
    }

    @Debug
    public MultiNoiseUtil.ParameterRange[] getHumidityParameters() {
        return this.humidityParameters;
    }

    @Debug
    public MultiNoiseUtil.ParameterRange[] getErosionParameters() {
        return this.erosionParameters;
    }

    @Debug
    public MultiNoiseUtil.ParameterRange[] getContinentalnessParameters() {
        return new MultiNoiseUtil.ParameterRange[]{this.mushroomFieldsContinentalness, this.deepOceanContinentalness, this.oceanContinentalness, this.coastContinentalness, this.nearInlandContinentalness, this.midInlandContinentalness, this.farInlandContinentalness};
    }

    @Debug
    public MultiNoiseUtil.ParameterRange[] getWeirdnessParameters() {
        return new MultiNoiseUtil.ParameterRange[]{MultiNoiseUtil.ParameterRange.of(-2.0f, DensityFunctions.getPeaksValleysNoise(0.05f)), MultiNoiseUtil.ParameterRange.of(DensityFunctions.getPeaksValleysNoise(0.05f), DensityFunctions.getPeaksValleysNoise(0.26666668f)), MultiNoiseUtil.ParameterRange.of(DensityFunctions.getPeaksValleysNoise(0.26666668f), DensityFunctions.getPeaksValleysNoise(0.4f)), MultiNoiseUtil.ParameterRange.of(DensityFunctions.getPeaksValleysNoise(0.4f), DensityFunctions.getPeaksValleysNoise(0.56666666f)), MultiNoiseUtil.ParameterRange.of(DensityFunctions.getPeaksValleysNoise(0.56666666f), 2.0f)};
    }

    @Debug
    public MultiNoiseUtil.ParameterRange[] method_40015() {
        return new MultiNoiseUtil.ParameterRange[]{MultiNoiseUtil.ParameterRange.of(-2.0f, 0.0f), MultiNoiseUtil.ParameterRange.of(0.0f, 2.0f)};
    }
}


/*
 * Decompiled with CFR 0.2.1 (FabricMC 53fa44c9).
 */
package net.minecraft.item;

import com.mojang.authlib.GameProfile;
import net.minecraft.block.Block;
import net.minecraft.block.entity.SkullBlockEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.item.VerticallyAttachableBlockItem;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.nbt.NbtHelper;
import net.minecraft.text.Text;
import net.minecraft.util.Util;
import net.minecraft.util.math.Direction;

public class SkullItem
extends VerticallyAttachableBlockItem {
    public static final String SKULL_OWNER_KEY = "SkullOwner";

    public SkullItem(Block block, Block block2, Item.Settings settings) {
        super(block, block2, settings, Direction.field_11033);
    }

    @Override
    public Text getName(ItemStack itemStack) {
        if (itemStack.isOf(Items.PLAYER_HEAD) && itemStack.hasNbt()) {
            NbtCompound nbtCompound2;
            String string = null;
            NbtCompound nbtCompound = itemStack.getNbt();
            if (nbtCompound.contains(SKULL_OWNER_KEY, 8)) {
                string = nbtCompound.getString(SKULL_OWNER_KEY);
            } else if (nbtCompound.contains(SKULL_OWNER_KEY, 10) && (nbtCompound2 = nbtCompound.getCompound(SKULL_OWNER_KEY)).contains("Name", 8)) {
                string = nbtCompound2.getString("Name");
            }
            if (string != null) {
                return Text.translatable(this.getTranslationKey() + ".named", string);
            }
        }
        return super.getName(itemStack);
    }

    @Override
    public void postProcessNbt(NbtCompound nbtCompound) {
        super.postProcessNbt(nbtCompound);
        if (nbtCompound.contains(SKULL_OWNER_KEY, 8) && !Util.isBlank(nbtCompound.getString(SKULL_OWNER_KEY))) {
            GameProfile gameProfile2 = new GameProfile(null, nbtCompound.getString(SKULL_OWNER_KEY));
            SkullBlockEntity.loadProperties(gameProfile2, gameProfile -> nbtCompound.put(SKULL_OWNER_KEY, NbtHelper.writeGameProfile(new NbtCompound(), gameProfile)));
        }
    }
}


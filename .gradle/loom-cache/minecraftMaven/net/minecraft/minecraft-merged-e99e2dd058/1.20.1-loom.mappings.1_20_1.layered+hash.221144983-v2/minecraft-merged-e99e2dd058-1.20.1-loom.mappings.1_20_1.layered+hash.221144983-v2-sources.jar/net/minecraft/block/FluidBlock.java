/*
 * Decompiled with CFR 0.2.1 (FabricMC 53fa44c9).
 */
package net.minecraft.block;

import com.google.common.collect.ImmutableList;
import com.google.common.collect.Lists;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import net.minecraft.block.AbstractBlock;
import net.minecraft.block.Block;
import net.minecraft.block.BlockRenderType;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.FluidDrainable;
import net.minecraft.block.ShapeContext;
import net.minecraft.entity.ai.pathing.NavigationType;
import net.minecraft.fluid.FlowableFluid;
import net.minecraft.fluid.FluidState;
import net.minecraft.item.ItemStack;
import net.minecraft.loot.context.LootContextParameterSet;
import net.minecraft.registry.tag.FluidTags;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundEvent;
import net.minecraft.state.StateManager;
import net.minecraft.state.property.IntProperty;
import net.minecraft.state.property.Properties;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.random.Random;
import net.minecraft.util.shape.VoxelShape;
import net.minecraft.util.shape.VoxelShapes;
import net.minecraft.world.BlockView;
import net.minecraft.world.World;
import net.minecraft.world.WorldAccess;

public class FluidBlock
extends Block
implements FluidDrainable {
    public static final IntProperty LEVEL = Properties.LEVEL_15;
    protected final FlowableFluid fluid;
    private final List<FluidState> statesByLevel;
    public static final VoxelShape COLLISION_SHAPE = Block.createCuboidShape(0.0, 0.0, 0.0, 16.0, 8.0, 16.0);
    public static final ImmutableList<Direction> FLOW_DIRECTIONS = ImmutableList.of(Direction.field_11033, Direction.field_11035, Direction.field_11043, Direction.field_11034, Direction.field_11039);

    public FluidBlock(FlowableFluid flowableFluid, AbstractBlock.Settings settings) {
        super(settings);
        this.fluid = flowableFluid;
        this.statesByLevel = Lists.newArrayList();
        this.statesByLevel.add(flowableFluid.getStill(false));
        for (int i = 1; i < 8; ++i) {
            this.statesByLevel.add(flowableFluid.getFlowing(8 - i, false));
        }
        this.statesByLevel.add(flowableFluid.getFlowing(8, true));
        this.setDefaultState((BlockState)((BlockState)this.stateManager.getDefaultState()).with(LEVEL, 0));
    }

    @Override
    public VoxelShape getCollisionShape(BlockState blockState, BlockView blockView, BlockPos blockPos, ShapeContext shapeContext) {
        if (shapeContext.isAbove(COLLISION_SHAPE, blockPos, true) && blockState.get(LEVEL) == 0 && shapeContext.canWalkOnFluid(blockView.getFluidState(blockPos.up()), blockState.getFluidState())) {
            return COLLISION_SHAPE;
        }
        return VoxelShapes.empty();
    }

    @Override
    public boolean hasRandomTicks(BlockState blockState) {
        return blockState.getFluidState().hasRandomTicks();
    }

    @Override
    public void randomTick(BlockState blockState, ServerWorld serverWorld, BlockPos blockPos, Random random) {
        blockState.getFluidState().onRandomTick(serverWorld, blockPos, random);
    }

    @Override
    public boolean isTransparent(BlockState blockState, BlockView blockView, BlockPos blockPos) {
        return false;
    }

    @Override
    public boolean canPathfindThrough(BlockState blockState, BlockView blockView, BlockPos blockPos, NavigationType navigationType) {
        return !this.fluid.isIn(FluidTags.field_15518);
    }

    @Override
    public FluidState getFluidState(BlockState blockState) {
        int i = blockState.get(LEVEL);
        return this.statesByLevel.get(Math.min(i, 8));
    }

    @Override
    public boolean isSideInvisible(BlockState blockState, BlockState blockState2, Direction direction) {
        return blockState2.getFluidState().getFluid().matchesType(this.fluid);
    }

    @Override
    public BlockRenderType getRenderType(BlockState blockState) {
        return BlockRenderType.field_11455;
    }

    @Override
    public List<ItemStack> getDroppedStacks(BlockState blockState, LootContextParameterSet.Builder builder) {
        return Collections.emptyList();
    }

    @Override
    public VoxelShape getOutlineShape(BlockState blockState, BlockView blockView, BlockPos blockPos, ShapeContext shapeContext) {
        return VoxelShapes.empty();
    }

    @Override
    public void onBlockAdded(BlockState blockState, World world, BlockPos blockPos, BlockState blockState2, boolean bl) {
        if (this.receiveNeighborFluids(world, blockPos, blockState)) {
            world.scheduleFluidTick(blockPos, blockState.getFluidState().getFluid(), this.fluid.getTickRate(world));
        }
    }

    @Override
    public BlockState getStateForNeighborUpdate(BlockState blockState, Direction direction, BlockState blockState2, WorldAccess worldAccess, BlockPos blockPos, BlockPos blockPos2) {
        if (blockState.getFluidState().isStill() || blockState2.getFluidState().isStill()) {
            worldAccess.scheduleFluidTick(blockPos, blockState.getFluidState().getFluid(), this.fluid.getTickRate(worldAccess));
        }
        return super.getStateForNeighborUpdate(blockState, direction, blockState2, worldAccess, blockPos, blockPos2);
    }

    @Override
    public void neighborUpdate(BlockState blockState, World world, BlockPos blockPos, Block block, BlockPos blockPos2, boolean bl) {
        if (this.receiveNeighborFluids(world, blockPos, blockState)) {
            world.scheduleFluidTick(blockPos, blockState.getFluidState().getFluid(), this.fluid.getTickRate(world));
        }
    }

    private boolean receiveNeighborFluids(World world, BlockPos blockPos, BlockState blockState) {
        if (this.fluid.isIn(FluidTags.field_15518)) {
            boolean bl = world.getBlockState(blockPos.down()).isOf(Blocks.field_22090);
            for (Direction direction : FLOW_DIRECTIONS) {
                BlockPos blockPos2 = blockPos.offset(direction.getOpposite());
                if (world.getFluidState(blockPos2).isIn(FluidTags.field_15517)) {
                    Block block = world.getFluidState(blockPos).isStill() ? Blocks.field_10540 : Blocks.field_10445;
                    world.setBlockState(blockPos, block.getDefaultState());
                    this.playExtinguishSound(world, blockPos);
                    return false;
                }
                if (!bl || !world.getBlockState(blockPos2).isOf(Blocks.field_10384)) continue;
                world.setBlockState(blockPos, Blocks.field_22091.getDefaultState());
                this.playExtinguishSound(world, blockPos);
                return false;
            }
        }
        return true;
    }

    private void playExtinguishSound(WorldAccess worldAccess, BlockPos blockPos) {
        worldAccess.syncWorldEvent(1501, blockPos, 0);
    }

    @Override
    protected void appendProperties(StateManager.Builder<Block, BlockState> builder) {
        builder.add(LEVEL);
    }

    @Override
    public ItemStack tryDrainFluid(WorldAccess worldAccess, BlockPos blockPos, BlockState blockState) {
        if (blockState.get(LEVEL) == 0) {
            worldAccess.setBlockState(blockPos, Blocks.field_10124.getDefaultState(), 11);
            return new ItemStack(this.fluid.getBucketItem());
        }
        return ItemStack.EMPTY;
    }

    @Override
    public Optional<SoundEvent> getBucketFillSound() {
        return this.fluid.getBucketFillSound();
    }
}


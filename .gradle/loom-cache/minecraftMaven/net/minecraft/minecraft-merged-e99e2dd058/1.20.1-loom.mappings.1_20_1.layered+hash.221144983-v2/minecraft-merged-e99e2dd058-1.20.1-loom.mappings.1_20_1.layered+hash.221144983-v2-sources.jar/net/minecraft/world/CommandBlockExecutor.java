/*
 * Decompiled with CFR 0.2.1 (FabricMC 53fa44c9).
 */
package net.minecraft.world;

import java.text.SimpleDateFormat;
import java.util.Date;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.screen.ScreenTexts;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.command.CommandOutput;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.StringHelper;
import net.minecraft.util.crash.CrashException;
import net.minecraft.util.crash.CrashReport;
import net.minecraft.util.crash.CrashReportSection;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.GameRules;
import net.minecraft.world.World;
import org.jetbrains.annotations.Nullable;

public abstract class CommandBlockExecutor
implements CommandOutput {
    private static final SimpleDateFormat DATE_FORMAT = new SimpleDateFormat("HH:mm:ss");
    private static final Text DEFAULT_NAME = Text.literal("@");
    private long lastExecution = -1L;
    private boolean updateLastExecution = true;
    private int successCount;
    private boolean trackOutput = true;
    @Nullable
    private Text lastOutput;
    private String command = "";
    private Text customName = DEFAULT_NAME;

    public int getSuccessCount() {
        return this.successCount;
    }

    public void setSuccessCount(int i) {
        this.successCount = i;
    }

    public Text getLastOutput() {
        return this.lastOutput == null ? ScreenTexts.EMPTY : this.lastOutput;
    }

    public NbtCompound writeNbt(NbtCompound nbtCompound) {
        nbtCompound.putString("Command", this.command);
        nbtCompound.putInt("SuccessCount", this.successCount);
        nbtCompound.putString("CustomName", Text.Serializer.toJson(this.customName));
        nbtCompound.putBoolean("TrackOutput", this.trackOutput);
        if (this.lastOutput != null && this.trackOutput) {
            nbtCompound.putString("LastOutput", Text.Serializer.toJson(this.lastOutput));
        }
        nbtCompound.putBoolean("UpdateLastExecution", this.updateLastExecution);
        if (this.updateLastExecution && this.lastExecution > 0L) {
            nbtCompound.putLong("LastExecution", this.lastExecution);
        }
        return nbtCompound;
    }

    public void readNbt(NbtCompound nbtCompound) {
        this.command = nbtCompound.getString("Command");
        this.successCount = nbtCompound.getInt("SuccessCount");
        if (nbtCompound.contains("CustomName", 8)) {
            this.setCustomName(Text.Serializer.fromJson(nbtCompound.getString("CustomName")));
        }
        if (nbtCompound.contains("TrackOutput", 1)) {
            this.trackOutput = nbtCompound.getBoolean("TrackOutput");
        }
        if (nbtCompound.contains("LastOutput", 8) && this.trackOutput) {
            try {
                this.lastOutput = Text.Serializer.fromJson(nbtCompound.getString("LastOutput"));
            } catch (Throwable throwable) {
                this.lastOutput = Text.literal(throwable.getMessage());
            }
        } else {
            this.lastOutput = null;
        }
        if (nbtCompound.contains("UpdateLastExecution")) {
            this.updateLastExecution = nbtCompound.getBoolean("UpdateLastExecution");
        }
        this.lastExecution = this.updateLastExecution && nbtCompound.contains("LastExecution") ? nbtCompound.getLong("LastExecution") : -1L;
    }

    public void setCommand(String string) {
        this.command = string;
        this.successCount = 0;
    }

    public String getCommand() {
        return this.command;
    }

    public boolean execute(World world) {
        if (world.isClient || world.getTime() == this.lastExecution) {
            return false;
        }
        if ("Searge".equalsIgnoreCase(this.command)) {
            this.lastOutput = Text.literal("#itzlipofutzli");
            this.successCount = 1;
            return true;
        }
        this.successCount = 0;
        MinecraftServer minecraftServer = this.getWorld().getServer();
        if (minecraftServer.areCommandBlocksEnabled() && !StringHelper.isEmpty(this.command)) {
            try {
                this.lastOutput = null;
                ServerCommandSource serverCommandSource = this.getSource().withConsumer((commandContext, bl, i) -> {
                    if (bl) {
                        ++this.successCount;
                    }
                });
                minecraftServer.getCommandManager().executeWithPrefix(serverCommandSource, this.command);
            } catch (Throwable throwable) {
                CrashReport crashReport = CrashReport.create(throwable, "Executing command block");
                CrashReportSection crashReportSection = crashReport.addElement("Command to be executed");
                crashReportSection.add("Command", this::getCommand);
                crashReportSection.add("Name", () -> this.getCustomName().getString());
                throw new CrashException(crashReport);
            }
        }
        this.lastExecution = this.updateLastExecution ? world.getTime() : -1L;
        return true;
    }

    public Text getCustomName() {
        return this.customName;
    }

    public void setCustomName(@Nullable Text text) {
        this.customName = text != null ? text : DEFAULT_NAME;
    }

    @Override
    public void sendMessage(Text text) {
        if (this.trackOutput) {
            this.lastOutput = Text.literal("[" + DATE_FORMAT.format(new Date()) + "] ").append(text);
            this.markDirty();
        }
    }

    public abstract ServerWorld getWorld();

    public abstract void markDirty();

    public void setLastOutput(@Nullable Text text) {
        this.lastOutput = text;
    }

    public void setTrackOutput(boolean bl) {
        this.trackOutput = bl;
    }

    public boolean isTrackingOutput() {
        return this.trackOutput;
    }

    public ActionResult interact(PlayerEntity playerEntity) {
        if (!playerEntity.isCreativeLevelTwoOp()) {
            return ActionResult.PASS;
        }
        if (playerEntity.getEntityWorld().isClient) {
            playerEntity.openCommandBlockMinecartScreen(this);
        }
        return ActionResult.success(playerEntity.getWorld().isClient);
    }

    public abstract Vec3d getPos();

    public abstract ServerCommandSource getSource();

    @Override
    public boolean shouldReceiveFeedback() {
        return this.getWorld().getGameRules().getBoolean(GameRules.field_19400) && this.trackOutput;
    }

    @Override
    public boolean shouldTrackOutput() {
        return this.trackOutput;
    }

    @Override
    public boolean shouldBroadcastConsoleToOps() {
        return this.getWorld().getGameRules().getBoolean(GameRules.field_19394);
    }

    public abstract boolean isEditable();
}


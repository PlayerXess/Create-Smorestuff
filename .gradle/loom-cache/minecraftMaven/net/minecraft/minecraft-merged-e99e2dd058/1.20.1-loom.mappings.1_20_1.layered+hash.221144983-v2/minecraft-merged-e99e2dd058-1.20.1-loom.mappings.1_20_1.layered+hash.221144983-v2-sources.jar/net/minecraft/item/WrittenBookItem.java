/*
 * Decompiled with CFR 0.2.1 (FabricMC 53fa44c9).
 */
package net.minecraft.item;

import java.util.List;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.LecternBlock;
import net.minecraft.client.item.TooltipContext;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemUsageContext;
import net.minecraft.item.WritableBookItem;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.nbt.NbtList;
import net.minecraft.nbt.NbtString;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.stat.Stats;
import net.minecraft.text.MutableText;
import net.minecraft.text.Text;
import net.minecraft.text.Texts;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Formatting;
import net.minecraft.util.Hand;
import net.minecraft.util.StringHelper;
import net.minecraft.util.TypedActionResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import org.jetbrains.annotations.Nullable;

public class WrittenBookItem
extends Item {
    public static final int MAX_TITLE_EDIT_LENGTH = 16;
    public static final int MAX_TITLE_VIEW_LENGTH = 32;
    public static final int MAX_PAGE_EDIT_LENGTH = 1024;
    public static final int MAX_PAGE_VIEW_LENGTH = Short.MAX_VALUE;
    public static final int MAX_PAGES = 100;
    public static final int field_30934 = 2;
    public static final String TITLE_KEY = "title";
    public static final String FILTERED_TITLE_KEY = "filtered_title";
    public static final String AUTHOR_KEY = "author";
    public static final String PAGES_KEY = "pages";
    public static final String FILTERED_PAGES_KEY = "filtered_pages";
    public static final String GENERATION_KEY = "generation";
    public static final String RESOLVED_KEY = "resolved";

    public WrittenBookItem(Item.Settings settings) {
        super(settings);
    }

    public static boolean isValid(@Nullable NbtCompound nbtCompound) {
        if (!WritableBookItem.isValid(nbtCompound)) {
            return false;
        }
        if (!nbtCompound.contains(TITLE_KEY, 8)) {
            return false;
        }
        String string = nbtCompound.getString(TITLE_KEY);
        if (string.length() > 32) {
            return false;
        }
        return nbtCompound.contains(AUTHOR_KEY, 8);
    }

    public static int getGeneration(ItemStack itemStack) {
        return itemStack.getNbt().getInt(GENERATION_KEY);
    }

    public static int getPageCount(ItemStack itemStack) {
        NbtCompound nbtCompound = itemStack.getNbt();
        return nbtCompound != null ? nbtCompound.getList(PAGES_KEY, 8).size() : 0;
    }

    @Override
    public Text getName(ItemStack itemStack) {
        String string;
        NbtCompound nbtCompound = itemStack.getNbt();
        if (nbtCompound != null && !StringHelper.isEmpty(string = nbtCompound.getString(TITLE_KEY))) {
            return Text.literal(string);
        }
        return super.getName(itemStack);
    }

    @Override
    public void appendTooltip(ItemStack itemStack, @Nullable World world, List<Text> list, TooltipContext tooltipContext) {
        if (itemStack.hasNbt()) {
            NbtCompound nbtCompound = itemStack.getNbt();
            String string = nbtCompound.getString(AUTHOR_KEY);
            if (!StringHelper.isEmpty(string)) {
                list.add(Text.translatable("book.byAuthor", string).formatted(Formatting.field_1080));
            }
            list.add(Text.translatable("book.generation." + nbtCompound.getInt(GENERATION_KEY)).formatted(Formatting.field_1080));
        }
    }

    @Override
    public ActionResult useOnBlock(ItemUsageContext itemUsageContext) {
        BlockPos blockPos;
        World world = itemUsageContext.getWorld();
        BlockState blockState = world.getBlockState(blockPos = itemUsageContext.getBlockPos());
        if (blockState.isOf(Blocks.field_16330)) {
            return LecternBlock.putBookIfAbsent(itemUsageContext.getPlayer(), world, blockPos, blockState, itemUsageContext.getStack()) ? ActionResult.success(world.isClient) : ActionResult.PASS;
        }
        return ActionResult.PASS;
    }

    @Override
    public TypedActionResult<ItemStack> use(World world, PlayerEntity playerEntity, Hand hand) {
        ItemStack itemStack = playerEntity.getStackInHand(hand);
        playerEntity.useBook(itemStack, hand);
        playerEntity.incrementStat(Stats.field_15372.getOrCreateStat(this));
        return TypedActionResult.success(itemStack, world.isClient());
    }

    public static boolean resolve(ItemStack itemStack, @Nullable ServerCommandSource serverCommandSource, @Nullable PlayerEntity playerEntity) {
        NbtCompound nbtCompound = itemStack.getNbt();
        if (nbtCompound == null || nbtCompound.getBoolean(RESOLVED_KEY)) {
            return false;
        }
        nbtCompound.putBoolean(RESOLVED_KEY, true);
        if (!WrittenBookItem.isValid(nbtCompound)) {
            return false;
        }
        NbtList nbtList = nbtCompound.getList(PAGES_KEY, 8);
        NbtList nbtList2 = new NbtList();
        for (int i = 0; i < nbtList.size(); ++i) {
            String string = WrittenBookItem.textToJson(serverCommandSource, playerEntity, nbtList.getString(i));
            if (string.length() > Short.MAX_VALUE) {
                return false;
            }
            nbtList2.add(i, NbtString.of(string));
        }
        if (nbtCompound.contains(FILTERED_PAGES_KEY, 10)) {
            NbtCompound nbtCompound2 = nbtCompound.getCompound(FILTERED_PAGES_KEY);
            NbtCompound nbtCompound3 = new NbtCompound();
            for (String string2 : nbtCompound2.getKeys()) {
                String string3 = WrittenBookItem.textToJson(serverCommandSource, playerEntity, nbtCompound2.getString(string2));
                if (string3.length() > Short.MAX_VALUE) {
                    return false;
                }
                nbtCompound3.putString(string2, string3);
            }
            nbtCompound.put(FILTERED_PAGES_KEY, nbtCompound3);
        }
        nbtCompound.put(PAGES_KEY, nbtList2);
        return true;
    }

    private static String textToJson(@Nullable ServerCommandSource serverCommandSource, @Nullable PlayerEntity playerEntity, String string) {
        MutableText text;
        try {
            text = Text.Serializer.fromLenientJson(string);
            text = Texts.parse(serverCommandSource, text, (Entity)playerEntity, 0);
        } catch (Exception exception) {
            text = Text.literal(string);
        }
        return Text.Serializer.toJson(text);
    }

    @Override
    public boolean hasGlint(ItemStack itemStack) {
        return true;
    }
}


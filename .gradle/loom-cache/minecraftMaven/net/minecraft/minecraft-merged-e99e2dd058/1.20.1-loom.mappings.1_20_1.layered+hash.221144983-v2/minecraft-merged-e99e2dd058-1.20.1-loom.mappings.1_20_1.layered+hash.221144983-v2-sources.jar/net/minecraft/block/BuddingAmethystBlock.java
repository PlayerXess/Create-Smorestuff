/*
 * Decompiled with CFR 0.2.1 (FabricMC 53fa44c9).
 */
package net.minecraft.block;

import net.minecraft.block.AbstractBlock;
import net.minecraft.block.AmethystBlock;
import net.minecraft.block.AmethystClusterBlock;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.fluid.Fluids;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.random.Random;

public class BuddingAmethystBlock
extends AmethystBlock {
    public static final int GROW_CHANCE = 5;
    private static final Direction[] DIRECTIONS = Direction.values();

    public BuddingAmethystBlock(AbstractBlock.Settings settings) {
        super(settings);
    }

    @Override
    public void randomTick(BlockState blockState, ServerWorld serverWorld, BlockPos blockPos, Random random) {
        if (random.nextInt(5) != 0) {
            return;
        }
        Direction direction = DIRECTIONS[random.nextInt(DIRECTIONS.length)];
        BlockPos blockPos2 = blockPos.offset(direction);
        BlockState blockState2 = serverWorld.getBlockState(blockPos2);
        Block block = null;
        if (BuddingAmethystBlock.canGrowIn(blockState2)) {
            block = Blocks.field_27164;
        } else if (blockState2.isOf(Blocks.field_27164) && blockState2.get(AmethystClusterBlock.FACING) == direction) {
            block = Blocks.field_27163;
        } else if (blockState2.isOf(Blocks.field_27163) && blockState2.get(AmethystClusterBlock.FACING) == direction) {
            block = Blocks.field_27162;
        } else if (blockState2.isOf(Blocks.field_27162) && blockState2.get(AmethystClusterBlock.FACING) == direction) {
            block = Blocks.field_27161;
        }
        if (block != null) {
            BlockState blockState3 = (BlockState)((BlockState)block.getDefaultState().with(AmethystClusterBlock.FACING, direction)).with(AmethystClusterBlock.WATERLOGGED, blockState2.getFluidState().getFluid() == Fluids.WATER);
            serverWorld.setBlockState(blockPos2, blockState3);
        }
    }

    public static boolean canGrowIn(BlockState blockState) {
        return blockState.isAir() || blockState.isOf(Blocks.field_10382) && blockState.getFluidState().getLevel() == 8;
    }
}


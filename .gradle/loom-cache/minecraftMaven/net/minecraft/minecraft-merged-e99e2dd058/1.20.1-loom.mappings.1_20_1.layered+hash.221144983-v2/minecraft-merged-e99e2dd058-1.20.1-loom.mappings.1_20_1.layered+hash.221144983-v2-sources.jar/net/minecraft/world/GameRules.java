/*
 * Decompiled with CFR 0.2.1 (FabricMC 53fa44c9).
 */
package net.minecraft.world;

import com.google.common.collect.ImmutableMap;
import com.google.common.collect.Maps;
import com.mojang.brigadier.arguments.ArgumentType;
import com.mojang.brigadier.arguments.BoolArgumentType;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.builder.RequiredArgumentBuilder;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.logging.LogUtils;
import com.mojang.serialization.DynamicLike;
import java.util.Comparator;
import java.util.Map;
import java.util.function.BiConsumer;
import java.util.function.Function;
import java.util.function.Supplier;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.network.packet.s2c.play.EntityStatusS2CPacket;
import net.minecraft.network.packet.s2c.play.GameStateChangeS2CPacket;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.network.ServerPlayerEntity;
import org.jetbrains.annotations.Nullable;
import org.slf4j.Logger;

public class GameRules {
    public static final int DEFAULT_RANDOM_TICK_SPEED = 3;
    static final Logger LOGGER = LogUtils.getLogger();
    private static final Map<Key<?>, Type<?>> RULE_TYPES = Maps.newTreeMap(Comparator.comparing(key -> key.name));
    public static final Key<BooleanRule> field_19387 = GameRules.register("doFireTick", Category.field_24098, BooleanRule.create(true));
    public static final Key<BooleanRule> DO_MOB_GRIEFING = GameRules.register("mobGriefing", Category.field_24095, BooleanRule.create(true));
    public static final Key<BooleanRule> KEEP_INVENTORY = GameRules.register("keepInventory", Category.field_24094, BooleanRule.create(false));
    public static final Key<BooleanRule> DO_MOB_SPAWNING = GameRules.register("doMobSpawning", Category.field_24096, BooleanRule.create(true));
    public static final Key<BooleanRule> DO_MOB_LOOT = GameRules.register("doMobLoot", Category.field_24097, BooleanRule.create(true));
    public static final Key<BooleanRule> DO_TILE_DROPS = GameRules.register("doTileDrops", Category.field_24097, BooleanRule.create(true));
    public static final Key<BooleanRule> field_19393 = GameRules.register("doEntityDrops", Category.field_24097, BooleanRule.create(true));
    public static final Key<BooleanRule> field_19394 = GameRules.register("commandBlockOutput", Category.field_24099, BooleanRule.create(true));
    public static final Key<BooleanRule> field_19395 = GameRules.register("naturalRegeneration", Category.field_24094, BooleanRule.create(true));
    public static final Key<BooleanRule> field_19396 = GameRules.register("doDaylightCycle", Category.field_24098, BooleanRule.create(true));
    public static final Key<BooleanRule> field_19397 = GameRules.register("logAdminCommands", Category.field_24099, BooleanRule.create(true));
    public static final Key<BooleanRule> field_19398 = GameRules.register("showDeathMessages", Category.field_24099, BooleanRule.create(true));
    public static final Key<IntRule> field_19399 = GameRules.register("randomTickSpeed", Category.field_24098, IntRule.create(3));
    public static final Key<BooleanRule> field_19400 = GameRules.register("sendCommandFeedback", Category.field_24099, BooleanRule.create(true));
    public static final Key<BooleanRule> REDUCED_DEBUG_INFO = GameRules.register("reducedDebugInfo", Category.field_24100, BooleanRule.create(false, (minecraftServer, booleanRule) -> {
        byte b = booleanRule.get() ? (byte)22 : (byte)23;
        for (ServerPlayerEntity serverPlayerEntity : minecraftServer.getPlayerManager().getPlayerList()) {
            serverPlayerEntity.networkHandler.sendPacket(new EntityStatusS2CPacket(serverPlayerEntity, b));
        }
    }));
    public static final Key<BooleanRule> field_19402 = GameRules.register("spectatorsGenerateChunks", Category.field_24094, BooleanRule.create(true));
    public static final Key<IntRule> field_19403 = GameRules.register("spawnRadius", Category.field_24094, IntRule.create(10));
    public static final Key<BooleanRule> field_19404 = GameRules.register("disableElytraMovementCheck", Category.field_24094, BooleanRule.create(false));
    public static final Key<IntRule> MAX_ENTITY_CRAMMING = GameRules.register("maxEntityCramming", Category.field_24095, IntRule.create(24));
    public static final Key<BooleanRule> field_19406 = GameRules.register("doWeatherCycle", Category.field_24098, BooleanRule.create(true));
    public static final Key<BooleanRule> field_19407 = GameRules.register("doLimitedCrafting", Category.field_24094, BooleanRule.create(false));
    public static final Key<IntRule> field_19408 = GameRules.register("maxCommandChainLength", Category.field_24100, IntRule.create(65536));
    public static final Key<IntRule> field_41766 = GameRules.register("commandModificationBlockLimit", Category.field_24100, IntRule.create(32768));
    public static final Key<BooleanRule> ANNOUNCE_ADVANCEMENTS = GameRules.register("announceAdvancements", Category.field_24099, BooleanRule.create(true));
    public static final Key<BooleanRule> DISABLE_RAIDS = GameRules.register("disableRaids", Category.field_24095, BooleanRule.create(false));
    public static final Key<BooleanRule> field_20637 = GameRules.register("doInsomnia", Category.field_24096, BooleanRule.create(true));
    public static final Key<BooleanRule> DO_IMMEDIATE_RESPAWN = GameRules.register("doImmediateRespawn", Category.field_24094, BooleanRule.create(false, (minecraftServer, booleanRule) -> {
        for (ServerPlayerEntity serverPlayerEntity : minecraftServer.getPlayerManager().getPlayerList()) {
            serverPlayerEntity.networkHandler.sendPacket(new GameStateChangeS2CPacket(GameStateChangeS2CPacket.IMMEDIATE_RESPAWN, booleanRule.get() ? 1.0f : 0.0f));
        }
    }));
    public static final Key<BooleanRule> field_20634 = GameRules.register("drowningDamage", Category.field_24094, BooleanRule.create(true));
    public static final Key<BooleanRule> field_20635 = GameRules.register("fallDamage", Category.field_24094, BooleanRule.create(true));
    public static final Key<BooleanRule> field_20636 = GameRules.register("fireDamage", Category.field_24094, BooleanRule.create(true));
    public static final Key<BooleanRule> field_28044 = GameRules.register("freezeDamage", Category.field_24094, BooleanRule.create(true));
    public static final Key<BooleanRule> field_21831 = GameRules.register("doPatrolSpawning", Category.field_24096, BooleanRule.create(true));
    public static final Key<BooleanRule> field_21832 = GameRules.register("doTraderSpawning", Category.field_24096, BooleanRule.create(true));
    public static final Key<BooleanRule> field_38975 = GameRules.register("doWardenSpawning", Category.field_24096, BooleanRule.create(true));
    public static final Key<BooleanRule> field_25401 = GameRules.register("forgiveDeadPlayers", Category.field_24095, BooleanRule.create(true));
    public static final Key<BooleanRule> field_25402 = GameRules.register("universalAnger", Category.field_24095, BooleanRule.create(false));
    public static final Key<IntRule> field_28357 = GameRules.register("playersSleepingPercentage", Category.field_24094, IntRule.create(100));
    public static final Key<BooleanRule> field_40880 = GameRules.register("blockExplosionDropDecay", Category.field_24097, BooleanRule.create(true));
    public static final Key<BooleanRule> field_40881 = GameRules.register("mobExplosionDropDecay", Category.field_24097, BooleanRule.create(true));
    public static final Key<BooleanRule> field_40882 = GameRules.register("tntExplosionDropDecay", Category.field_24097, BooleanRule.create(false));
    public static final Key<IntRule> field_40883 = GameRules.register("snowAccumulationHeight", Category.field_24098, IntRule.create(1));
    public static final Key<BooleanRule> field_40884 = GameRules.register("waterSourceConversion", Category.field_24098, BooleanRule.create(true));
    public static final Key<BooleanRule> field_40885 = GameRules.register("lavaSourceConversion", Category.field_24098, BooleanRule.create(false));
    public static final Key<BooleanRule> field_40886 = GameRules.register("globalSoundEvents", Category.field_24100, BooleanRule.create(true));
    public static final Key<BooleanRule> field_42474 = GameRules.register("doVinesSpread", Category.field_24098, BooleanRule.create(true));
    private final Map<Key<?>, Rule<?>> rules;

    public static <T extends Rule<T>> Key<T> register(String string, Category category, Type<T> type) {
        Key key = new Key(string, category);
        Type<T> type2 = RULE_TYPES.put(key, type);
        if (type2 != null) {
            throw new IllegalStateException("Duplicate game rule registration for " + string);
        }
        return key;
    }

    public GameRules(DynamicLike<?> dynamicLike) {
        this();
        this.load(dynamicLike);
    }

    public GameRules() {
        this.rules = RULE_TYPES.entrySet().stream().collect(ImmutableMap.toImmutableMap(Map.Entry::getKey, entry -> ((Type)entry.getValue()).createRule()));
    }

    private GameRules(Map<Key<?>, Rule<?>> map) {
        this.rules = map;
    }

    public <T extends Rule<T>> T get(Key<T> key) {
        return (T)this.rules.get(key);
    }

    public NbtCompound toNbt() {
        NbtCompound nbtCompound = new NbtCompound();
        this.rules.forEach((key, rule) -> nbtCompound.putString(key.name, rule.serialize()));
        return nbtCompound;
    }

    private void load(DynamicLike<?> dynamicLike) {
        this.rules.forEach((key, rule) -> dynamicLike.get(key.name).asString().result().ifPresent(rule::deserialize));
    }

    public GameRules copy() {
        return new GameRules((Map)this.rules.entrySet().stream().collect(ImmutableMap.toImmutableMap(Map.Entry::getKey, entry -> ((Rule)entry.getValue()).copy())));
    }

    public static void accept(Visitor visitor) {
        RULE_TYPES.forEach((key, type) -> GameRules.accept(visitor, key, type));
    }

    private static <T extends Rule<T>> void accept(Visitor visitor, Key<?> key, Type<?> type) {
        Key<?> key2 = key;
        Type<?> type2 = type;
        visitor.visit(key2, type2);
        type2.accept(visitor, key2);
    }

    public void setAllValues(GameRules gameRules, @Nullable MinecraftServer minecraftServer) {
        gameRules.rules.keySet().forEach(key -> this.setValue((Key)key, gameRules, minecraftServer));
    }

    private <T extends Rule<T>> void setValue(Key<T> key, GameRules gameRules, @Nullable MinecraftServer minecraftServer) {
        T rule = gameRules.get(key);
        ((Rule)this.get(key)).setValue(rule, minecraftServer);
    }

    public boolean getBoolean(Key<BooleanRule> key) {
        return this.get(key).get();
    }

    public int getInt(Key<IntRule> key) {
        return this.get(key).get();
    }

    public static final class Key<T extends Rule<T>> {
        final String name;
        private final Category category;

        public Key(String string, Category category) {
            this.name = string;
            this.category = category;
        }

        public String toString() {
            return this.name;
        }

        public boolean equals(Object object) {
            if (this == object) {
                return true;
            }
            return object instanceof Key && ((Key)object).name.equals(this.name);
        }

        public int hashCode() {
            return this.name.hashCode();
        }

        public String getName() {
            return this.name;
        }

        public String getTranslationKey() {
            return "gamerule." + this.name;
        }

        public Category getCategory() {
            return this.category;
        }
    }

    public static enum Category {
        field_24094("gamerule.category.player"),
        field_24095("gamerule.category.mobs"),
        field_24096("gamerule.category.spawning"),
        field_24097("gamerule.category.drops"),
        field_24098("gamerule.category.updates"),
        field_24099("gamerule.category.chat"),
        field_24100("gamerule.category.misc");

        private final String category;

        private Category(String string2) {
            this.category = string2;
        }

        public String getCategory() {
            return this.category;
        }
    }

    public static class Type<T extends Rule<T>> {
        private final Supplier<ArgumentType<?>> argumentType;
        private final Function<Type<T>, T> ruleFactory;
        final BiConsumer<MinecraftServer, T> changeCallback;
        private final Acceptor<T> ruleAcceptor;

        Type(Supplier<ArgumentType<?>> supplier, Function<Type<T>, T> function, BiConsumer<MinecraftServer, T> biConsumer, Acceptor<T> acceptor) {
            this.argumentType = supplier;
            this.ruleFactory = function;
            this.changeCallback = biConsumer;
            this.ruleAcceptor = acceptor;
        }

        public RequiredArgumentBuilder<ServerCommandSource, ?> argument(String string) {
            return CommandManager.argument(string, this.argumentType.get());
        }

        public T createRule() {
            return (T)((Rule)this.ruleFactory.apply(this));
        }

        public void accept(Visitor visitor, Key<T> key) {
            this.ruleAcceptor.call(visitor, key, this);
        }
    }

    public static abstract class Rule<T extends Rule<T>> {
        protected final Type<T> type;

        public Rule(Type<T> type) {
            this.type = type;
        }

        protected abstract void setFromArgument(CommandContext<ServerCommandSource> var1, String var2);

        public void set(CommandContext<ServerCommandSource> commandContext, String string) {
            this.setFromArgument(commandContext, string);
            this.changed(commandContext.getSource().getServer());
        }

        protected void changed(@Nullable MinecraftServer minecraftServer) {
            if (minecraftServer != null) {
                this.type.changeCallback.accept(minecraftServer, (MinecraftServer)this.getThis());
            }
        }

        protected abstract void deserialize(String var1);

        public abstract String serialize();

        public String toString() {
            return this.serialize();
        }

        public abstract int getCommandResult();

        protected abstract T getThis();

        protected abstract T copy();

        public abstract void setValue(T var1, @Nullable MinecraftServer var2);
    }

    public static interface Visitor {
        default public <T extends Rule<T>> void visit(Key<T> key, Type<T> type) {
        }

        default public void visitBoolean(Key<BooleanRule> key, Type<BooleanRule> type) {
        }

        default public void visitInt(Key<IntRule> key, Type<IntRule> type) {
        }
    }

    public static class BooleanRule
    extends Rule<BooleanRule> {
        private boolean value;

        public static Type<BooleanRule> create(boolean bl, BiConsumer<MinecraftServer, BooleanRule> biConsumer) {
            return new Type<BooleanRule>(BoolArgumentType::bool, type -> new BooleanRule((Type<BooleanRule>)type, bl), biConsumer, Visitor::visitBoolean);
        }

        public static Type<BooleanRule> create(boolean bl) {
            return BooleanRule.create(bl, (minecraftServer, booleanRule) -> {});
        }

        public BooleanRule(Type<BooleanRule> type, boolean bl) {
            super(type);
            this.value = bl;
        }

        @Override
        protected void setFromArgument(CommandContext<ServerCommandSource> commandContext, String string) {
            this.value = BoolArgumentType.getBool(commandContext, string);
        }

        public boolean get() {
            return this.value;
        }

        public void set(boolean bl, @Nullable MinecraftServer minecraftServer) {
            this.value = bl;
            this.changed(minecraftServer);
        }

        @Override
        public String serialize() {
            return Boolean.toString(this.value);
        }

        @Override
        protected void deserialize(String string) {
            this.value = Boolean.parseBoolean(string);
        }

        @Override
        public int getCommandResult() {
            return this.value ? 1 : 0;
        }

        @Override
        protected BooleanRule getThis() {
            return this;
        }

        @Override
        protected BooleanRule copy() {
            return new BooleanRule(this.type, this.value);
        }

        @Override
        public void setValue(BooleanRule booleanRule, @Nullable MinecraftServer minecraftServer) {
            this.value = booleanRule.value;
            this.changed(minecraftServer);
        }

        @Override
        protected /* synthetic */ Rule copy() {
            return this.copy();
        }

        @Override
        protected /* synthetic */ Rule getThis() {
            return this.getThis();
        }
    }

    public static class IntRule
    extends Rule<IntRule> {
        private int value;

        public static Type<IntRule> create(int i, BiConsumer<MinecraftServer, IntRule> biConsumer) {
            return new Type<IntRule>(IntegerArgumentType::integer, type -> new IntRule((Type<IntRule>)type, i), biConsumer, Visitor::visitInt);
        }

        public static Type<IntRule> create(int i) {
            return IntRule.create(i, (minecraftServer, intRule) -> {});
        }

        public IntRule(Type<IntRule> type, int i) {
            super(type);
            this.value = i;
        }

        @Override
        protected void setFromArgument(CommandContext<ServerCommandSource> commandContext, String string) {
            this.value = IntegerArgumentType.getInteger(commandContext, string);
        }

        public int get() {
            return this.value;
        }

        public void set(int i, @Nullable MinecraftServer minecraftServer) {
            this.value = i;
            this.changed(minecraftServer);
        }

        @Override
        public String serialize() {
            return Integer.toString(this.value);
        }

        @Override
        protected void deserialize(String string) {
            this.value = IntRule.parseInt(string);
        }

        public boolean validate(String string) {
            try {
                this.value = Integer.parseInt(string);
                return true;
            } catch (NumberFormatException numberFormatException) {
                return false;
            }
        }

        private static int parseInt(String string) {
            if (!string.isEmpty()) {
                try {
                    return Integer.parseInt(string);
                } catch (NumberFormatException numberFormatException) {
                    LOGGER.warn("Failed to parse integer {}", (Object)string);
                }
            }
            return 0;
        }

        @Override
        public int getCommandResult() {
            return this.value;
        }

        @Override
        protected IntRule getThis() {
            return this;
        }

        @Override
        protected IntRule copy() {
            return new IntRule(this.type, this.value);
        }

        @Override
        public void setValue(IntRule intRule, @Nullable MinecraftServer minecraftServer) {
            this.value = intRule.value;
            this.changed(minecraftServer);
        }

        @Override
        protected /* synthetic */ Rule copy() {
            return this.copy();
        }

        @Override
        protected /* synthetic */ Rule getThis() {
            return this.getThis();
        }
    }

    static interface Acceptor<T extends Rule<T>> {
        public void call(Visitor var1, Key<T> var2, Type<T> var3);
    }
}


/*
 * Decompiled with CFR 0.2.1 (FabricMC 53fa44c9).
 */
package net.minecraft.enchantment;

import java.util.Map;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.enchantment.EnchantmentTarget;
import net.minecraft.enchantment.Enchantments;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.ArmorItem;
import net.minecraft.item.ItemStack;
import net.minecraft.util.math.random.Random;

public class ThornsEnchantment
extends Enchantment {
    private static final float ATTACK_CHANCE_PER_LEVEL = 0.15f;

    public ThornsEnchantment(Enchantment.Rarity rarity, EquipmentSlot ... equipmentSlots) {
        super(rarity, EnchantmentTarget.field_9071, equipmentSlots);
    }

    @Override
    public int getMinPower(int i) {
        return 10 + 20 * (i - 1);
    }

    @Override
    public int getMaxPower(int i) {
        return super.getMinPower(i) + 50;
    }

    @Override
    public int getMaxLevel() {
        return 3;
    }

    @Override
    public boolean isAcceptableItem(ItemStack itemStack) {
        if (itemStack.getItem() instanceof ArmorItem) {
            return true;
        }
        return super.isAcceptableItem(itemStack);
    }

    @Override
    public void onUserDamaged(LivingEntity livingEntity2, Entity entity, int i) {
        Random random = livingEntity2.getRandom();
        Map.Entry<EquipmentSlot, ItemStack> entry = EnchantmentHelper.chooseEquipmentWith(Enchantments.field_9097, livingEntity2);
        if (ThornsEnchantment.shouldDamageAttacker(i, random)) {
            if (entity != null) {
                entity.damage(livingEntity2.getDamageSources().thorns(livingEntity2), ThornsEnchantment.getDamageAmount(i, random));
            }
            if (entry != null) {
                entry.getValue().damage(2, livingEntity2, livingEntity -> livingEntity.sendEquipmentBreakStatus((EquipmentSlot)((Object)((Object)entry.getKey()))));
            }
        }
    }

    public static boolean shouldDamageAttacker(int i, Random random) {
        if (i <= 0) {
            return false;
        }
        return random.nextFloat() < 0.15f * (float)i;
    }

    public static int getDamageAmount(int i, Random random) {
        if (i > 10) {
            return i - 10;
        }
        return 1 + random.nextInt(4);
    }
}


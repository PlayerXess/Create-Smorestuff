/*
 * Decompiled with CFR 0.2.1 (FabricMC 53fa44c9).
 */
package net.minecraft.block;

import java.util.Optional;
import net.minecraft.block.AbstractBlock;
import net.minecraft.block.Block;
import net.minecraft.block.BlockRenderType;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.FluidDrainable;
import net.minecraft.block.ShapeContext;
import net.minecraft.entity.Entity;
import net.minecraft.fluid.FluidState;
import net.minecraft.fluid.Fluids;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;
import net.minecraft.state.StateManager;
import net.minecraft.state.property.BooleanProperty;
import net.minecraft.state.property.Properties;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.random.Random;
import net.minecraft.util.shape.VoxelShape;
import net.minecraft.util.shape.VoxelShapes;
import net.minecraft.world.BlockView;
import net.minecraft.world.World;
import net.minecraft.world.WorldAccess;
import net.minecraft.world.WorldView;

public class BubbleColumnBlock
extends Block
implements FluidDrainable {
    public static final BooleanProperty DRAG = Properties.DRAG;
    private static final int SCHEDULED_TICK_DELAY = 5;

    public BubbleColumnBlock(AbstractBlock.Settings settings) {
        super(settings);
        this.setDefaultState((BlockState)((BlockState)this.stateManager.getDefaultState()).with(DRAG, true));
    }

    @Override
    public void onEntityCollision(BlockState blockState, World world, BlockPos blockPos, Entity entity) {
        BlockState blockState2 = world.getBlockState(blockPos.up());
        if (blockState2.isAir()) {
            entity.onBubbleColumnSurfaceCollision(blockState.get(DRAG));
            if (!world.isClient) {
                ServerWorld serverWorld = (ServerWorld)world;
                for (int i = 0; i < 2; ++i) {
                    serverWorld.spawnParticles(ParticleTypes.field_11202, (double)blockPos.getX() + world.random.nextDouble(), blockPos.getY() + 1, (double)blockPos.getZ() + world.random.nextDouble(), 1, 0.0, 0.0, 0.0, 1.0);
                    serverWorld.spawnParticles(ParticleTypes.field_11247, (double)blockPos.getX() + world.random.nextDouble(), blockPos.getY() + 1, (double)blockPos.getZ() + world.random.nextDouble(), 1, 0.0, 0.01, 0.0, 0.2);
                }
            }
        } else {
            entity.onBubbleColumnCollision(blockState.get(DRAG));
        }
    }

    @Override
    public void scheduledTick(BlockState blockState, ServerWorld serverWorld, BlockPos blockPos, Random random) {
        BubbleColumnBlock.update(serverWorld, blockPos, blockState, serverWorld.getBlockState(blockPos.down()));
    }

    @Override
    public FluidState getFluidState(BlockState blockState) {
        return Fluids.WATER.getStill(false);
    }

    public static void update(WorldAccess worldAccess, BlockPos blockPos, BlockState blockState) {
        BubbleColumnBlock.update(worldAccess, blockPos, worldAccess.getBlockState(blockPos), blockState);
    }

    public static void update(WorldAccess worldAccess, BlockPos blockPos, BlockState blockState, BlockState blockState2) {
        if (!BubbleColumnBlock.isStillWater(blockState)) {
            return;
        }
        BlockState blockState3 = BubbleColumnBlock.getBubbleState(blockState2);
        worldAccess.setBlockState(blockPos, blockState3, 2);
        BlockPos.Mutable mutable = blockPos.mutableCopy().move(Direction.field_11036);
        while (BubbleColumnBlock.isStillWater(worldAccess.getBlockState(mutable))) {
            if (!worldAccess.setBlockState(mutable, blockState3, 2)) {
                return;
            }
            mutable.move(Direction.field_11036);
        }
    }

    private static boolean isStillWater(BlockState blockState) {
        return blockState.isOf(Blocks.field_10422) || blockState.isOf(Blocks.field_10382) && blockState.getFluidState().getLevel() >= 8 && blockState.getFluidState().isStill();
    }

    private static BlockState getBubbleState(BlockState blockState) {
        if (blockState.isOf(Blocks.field_10422)) {
            return blockState;
        }
        if (blockState.isOf(Blocks.field_10114)) {
            return (BlockState)Blocks.field_10422.getDefaultState().with(DRAG, false);
        }
        if (blockState.isOf(Blocks.field_10092)) {
            return (BlockState)Blocks.field_10422.getDefaultState().with(DRAG, true);
        }
        return Blocks.field_10382.getDefaultState();
    }

    @Override
    public void randomDisplayTick(BlockState blockState, World world, BlockPos blockPos, Random random) {
        double d = blockPos.getX();
        double e = blockPos.getY();
        double f = blockPos.getZ();
        if (blockState.get(DRAG).booleanValue()) {
            world.addImportantParticle(ParticleTypes.field_11243, d + 0.5, e + 0.8, f, 0.0, 0.0, 0.0);
            if (random.nextInt(200) == 0) {
                world.playSound(d, e, f, SoundEvents.field_14650, SoundCategory.field_15245, 0.2f + random.nextFloat() * 0.2f, 0.9f + random.nextFloat() * 0.15f, false);
            }
        } else {
            world.addImportantParticle(ParticleTypes.field_11238, d + 0.5, e, f + 0.5, 0.0, 0.04, 0.0);
            world.addImportantParticle(ParticleTypes.field_11238, d + (double)random.nextFloat(), e + (double)random.nextFloat(), f + (double)random.nextFloat(), 0.0, 0.04, 0.0);
            if (random.nextInt(200) == 0) {
                world.playSound(d, e, f, SoundEvents.field_15161, SoundCategory.field_15245, 0.2f + random.nextFloat() * 0.2f, 0.9f + random.nextFloat() * 0.15f, false);
            }
        }
    }

    @Override
    public BlockState getStateForNeighborUpdate(BlockState blockState, Direction direction, BlockState blockState2, WorldAccess worldAccess, BlockPos blockPos, BlockPos blockPos2) {
        worldAccess.scheduleFluidTick(blockPos, Fluids.WATER, Fluids.WATER.getTickRate(worldAccess));
        if (!blockState.canPlaceAt(worldAccess, blockPos) || direction == Direction.field_11033 || direction == Direction.field_11036 && !blockState2.isOf(Blocks.field_10422) && BubbleColumnBlock.isStillWater(blockState2)) {
            worldAccess.scheduleBlockTick(blockPos, this, 5);
        }
        return super.getStateForNeighborUpdate(blockState, direction, blockState2, worldAccess, blockPos, blockPos2);
    }

    @Override
    public boolean canPlaceAt(BlockState blockState, WorldView worldView, BlockPos blockPos) {
        BlockState blockState2 = worldView.getBlockState(blockPos.down());
        return blockState2.isOf(Blocks.field_10422) || blockState2.isOf(Blocks.field_10092) || blockState2.isOf(Blocks.field_10114);
    }

    @Override
    public VoxelShape getOutlineShape(BlockState blockState, BlockView blockView, BlockPos blockPos, ShapeContext shapeContext) {
        return VoxelShapes.empty();
    }

    @Override
    public BlockRenderType getRenderType(BlockState blockState) {
        return BlockRenderType.field_11455;
    }

    @Override
    protected void appendProperties(StateManager.Builder<Block, BlockState> builder) {
        builder.add(DRAG);
    }

    @Override
    public ItemStack tryDrainFluid(WorldAccess worldAccess, BlockPos blockPos, BlockState blockState) {
        worldAccess.setBlockState(blockPos, Blocks.field_10124.getDefaultState(), 11);
        return new ItemStack(Items.field_8705);
    }

    @Override
    public Optional<SoundEvent> getBucketFillSound() {
        return Fluids.WATER.getBucketFillSound();
    }
}


/*
 * Decompiled with CFR 0.2.1 (FabricMC 53fa44c9).
 */
package net.minecraft.screen;

import net.minecraft.entity.passive.AbstractDonkeyEntity;
import net.minecraft.entity.passive.AbstractHorseEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.inventory.Inventory;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.screen.ScreenHandler;
import net.minecraft.screen.slot.Slot;

public class HorseScreenHandler
extends ScreenHandler {
    private final Inventory inventory;
    private final AbstractHorseEntity entity;

    public HorseScreenHandler(int i, PlayerInventory playerInventory, Inventory inventory, final AbstractHorseEntity abstractHorseEntity) {
        super(null, i);
        int m;
        int l;
        this.inventory = inventory;
        this.entity = abstractHorseEntity;
        int j = 3;
        inventory.onOpen(playerInventory.player);
        int k = -18;
        this.addSlot(new Slot(inventory, 0, 8, 18){

            @Override
            public boolean canInsert(ItemStack itemStack) {
                return itemStack.isOf(Items.field_8175) && !this.hasStack() && abstractHorseEntity.canBeSaddled();
            }

            @Override
            public boolean isEnabled() {
                return abstractHorseEntity.canBeSaddled();
            }
        });
        this.addSlot(new Slot(inventory, 1, 8, 36){

            @Override
            public boolean canInsert(ItemStack itemStack) {
                return abstractHorseEntity.isHorseArmor(itemStack);
            }

            @Override
            public boolean isEnabled() {
                return abstractHorseEntity.hasArmorSlot();
            }

            @Override
            public int getMaxItemCount() {
                return 1;
            }
        });
        if (this.hasChest(abstractHorseEntity)) {
            for (l = 0; l < 3; ++l) {
                for (m = 0; m < ((AbstractDonkeyEntity)abstractHorseEntity).getInventoryColumns(); ++m) {
                    this.addSlot(new Slot(inventory, 2 + m + l * ((AbstractDonkeyEntity)abstractHorseEntity).getInventoryColumns(), 80 + m * 18, 18 + l * 18));
                }
            }
        }
        for (l = 0; l < 3; ++l) {
            for (m = 0; m < 9; ++m) {
                this.addSlot(new Slot(playerInventory, m + l * 9 + 9, 8 + m * 18, 102 + l * 18 + -18));
            }
        }
        for (l = 0; l < 9; ++l) {
            this.addSlot(new Slot(playerInventory, l, 8 + l * 18, 142));
        }
    }

    @Override
    public boolean canUse(PlayerEntity playerEntity) {
        return !this.entity.areInventoriesDifferent(this.inventory) && this.inventory.canPlayerUse(playerEntity) && this.entity.isAlive() && this.entity.distanceTo(playerEntity) < 8.0f;
    }

    private boolean hasChest(AbstractHorseEntity abstractHorseEntity) {
        return abstractHorseEntity instanceof AbstractDonkeyEntity && ((AbstractDonkeyEntity)abstractHorseEntity).hasChest();
    }

    @Override
    public ItemStack quickMove(PlayerEntity playerEntity, int i) {
        ItemStack itemStack = ItemStack.EMPTY;
        Slot slot = (Slot)this.slots.get(i);
        if (slot != null && slot.hasStack()) {
            ItemStack itemStack2 = slot.getStack();
            itemStack = itemStack2.copy();
            int j = this.inventory.size();
            if (i < j) {
                if (!this.insertItem(itemStack2, j, this.slots.size(), true)) {
                    return ItemStack.EMPTY;
                }
            } else if (this.getSlot(1).canInsert(itemStack2) && !this.getSlot(1).hasStack()) {
                if (!this.insertItem(itemStack2, 1, 2, false)) {
                    return ItemStack.EMPTY;
                }
            } else if (this.getSlot(0).canInsert(itemStack2)) {
                if (!this.insertItem(itemStack2, 0, 1, false)) {
                    return ItemStack.EMPTY;
                }
            } else if (j <= 2 || !this.insertItem(itemStack2, 2, j, false)) {
                int l;
                int k = j;
                int m = l = k + 27;
                int n = m + 9;
                if (i >= m && i < n ? !this.insertItem(itemStack2, k, l, false) : (i >= k && i < l ? !this.insertItem(itemStack2, m, n, false) : !this.insertItem(itemStack2, m, l, false))) {
                    return ItemStack.EMPTY;
                }
                return ItemStack.EMPTY;
            }
            if (itemStack2.isEmpty()) {
                slot.setStack(ItemStack.EMPTY);
            } else {
                slot.markDirty();
            }
        }
        return itemStack;
    }

    @Override
    public void onClosed(PlayerEntity playerEntity) {
        super.onClosed(playerEntity);
        this.inventory.onClose(playerEntity);
    }
}


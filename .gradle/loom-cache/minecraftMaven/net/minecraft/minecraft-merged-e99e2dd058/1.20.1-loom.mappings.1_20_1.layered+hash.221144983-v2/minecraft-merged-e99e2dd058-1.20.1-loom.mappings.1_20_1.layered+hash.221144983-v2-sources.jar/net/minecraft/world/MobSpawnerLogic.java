/*
 * Decompiled with CFR 0.2.1 (FabricMC 53fa44c9).
 */
package net.minecraft.world;

import com.mojang.logging.LogUtils;
import java.util.Optional;
import java.util.function.Function;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnReason;
import net.minecraft.entity.SpawnRestriction;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.nbt.NbtList;
import net.minecraft.nbt.NbtOps;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.registry.Registries;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.collection.DataPool;
import net.minecraft.util.collection.Weighted;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.random.Random;
import net.minecraft.world.Difficulty;
import net.minecraft.world.LightType;
import net.minecraft.world.MobSpawnerEntry;
import net.minecraft.world.World;
import net.minecraft.world.event.GameEvent;
import org.jetbrains.annotations.Nullable;
import org.slf4j.Logger;

public abstract class MobSpawnerLogic {
    public static final String SPAWN_DATA_KEY = "SpawnData";
    private static final Logger LOGGER = LogUtils.getLogger();
    private static final int field_30951 = 1;
    private int spawnDelay = 20;
    private DataPool<MobSpawnerEntry> spawnPotentials = DataPool.empty();
    @Nullable
    private MobSpawnerEntry spawnEntry;
    private double rotation;
    private double lastRotation;
    private int minSpawnDelay = 200;
    private int maxSpawnDelay = 800;
    private int spawnCount = 4;
    @Nullable
    private Entity renderedEntity;
    private int maxNearbyEntities = 6;
    private int requiredPlayerRange = 16;
    private int spawnRange = 4;

    public void setEntityId(EntityType<?> entityType, @Nullable World world, Random random, BlockPos blockPos) {
        this.getSpawnEntry(world, random, blockPos).getNbt().putString("id", Registries.ENTITY_TYPE.getId(entityType).toString());
    }

    private boolean isPlayerInRange(World world, BlockPos blockPos) {
        return world.isPlayerInRange((double)blockPos.getX() + 0.5, (double)blockPos.getY() + 0.5, (double)blockPos.getZ() + 0.5, this.requiredPlayerRange);
    }

    public void clientTick(World world, BlockPos blockPos) {
        if (!this.isPlayerInRange(world, blockPos)) {
            this.lastRotation = this.rotation;
        } else if (this.renderedEntity != null) {
            Random random = world.getRandom();
            double d = (double)blockPos.getX() + random.nextDouble();
            double e = (double)blockPos.getY() + random.nextDouble();
            double f = (double)blockPos.getZ() + random.nextDouble();
            world.addParticle(ParticleTypes.field_11251, d, e, f, 0.0, 0.0, 0.0);
            world.addParticle(ParticleTypes.field_11240, d, e, f, 0.0, 0.0, 0.0);
            if (this.spawnDelay > 0) {
                --this.spawnDelay;
            }
            this.lastRotation = this.rotation;
            this.rotation = (this.rotation + (double)(1000.0f / ((float)this.spawnDelay + 200.0f))) % 360.0;
        }
    }

    public void serverTick(ServerWorld serverWorld, BlockPos blockPos) {
        if (!this.isPlayerInRange(serverWorld, blockPos)) {
            return;
        }
        if (this.spawnDelay == -1) {
            this.updateSpawns(serverWorld, blockPos);
        }
        if (this.spawnDelay > 0) {
            --this.spawnDelay;
            return;
        }
        boolean bl = false;
        Random random = serverWorld.getRandom();
        MobSpawnerEntry mobSpawnerEntry = this.getSpawnEntry(serverWorld, random, blockPos);
        for (int i = 0; i < this.spawnCount; ++i) {
            MobSpawnerEntry.CustomSpawnRules customSpawnRules;
            double f;
            NbtCompound nbtCompound = mobSpawnerEntry.getNbt();
            Optional<EntityType<?>> optional = EntityType.fromNbt(nbtCompound);
            if (optional.isEmpty()) {
                this.updateSpawns(serverWorld, blockPos);
                return;
            }
            NbtList nbtList = nbtCompound.getList("Pos", 6);
            int j = nbtList.size();
            double d = j >= 1 ? nbtList.getDouble(0) : (double)blockPos.getX() + (random.nextDouble() - random.nextDouble()) * (double)this.spawnRange + 0.5;
            double e = j >= 2 ? nbtList.getDouble(1) : (double)(blockPos.getY() + random.nextInt(3) - 1);
            double d2 = f = j >= 3 ? nbtList.getDouble(2) : (double)blockPos.getZ() + (random.nextDouble() - random.nextDouble()) * (double)this.spawnRange + 0.5;
            if (!serverWorld.isSpaceEmpty(optional.get().createSimpleBoundingBox(d, e, f))) continue;
            BlockPos blockPos2 = BlockPos.ofFloored(d, e, f);
            if (!mobSpawnerEntry.getCustomSpawnRules().isPresent() ? !SpawnRestriction.canSpawn(optional.get(), serverWorld, SpawnReason.field_16469, blockPos2, serverWorld.getRandom()) : !optional.get().getSpawnGroup().isPeaceful() && serverWorld.getDifficulty() == Difficulty.field_5801 || !(customSpawnRules = mobSpawnerEntry.getCustomSpawnRules().get()).blockLightLimit().contains(serverWorld.getLightLevel(LightType.field_9282, blockPos2)) || !customSpawnRules.skyLightLimit().contains(serverWorld.getLightLevel(LightType.field_9284, blockPos2))) continue;
            Entity entity2 = EntityType.loadEntityWithPassengers(nbtCompound, serverWorld, entity -> {
                entity.refreshPositionAndAngles(d, e, f, entity.getYaw(), entity.getPitch());
                return entity;
            });
            if (entity2 == null) {
                this.updateSpawns(serverWorld, blockPos);
                return;
            }
            int k = serverWorld.getNonSpectatingEntities(entity2.getClass(), new Box(blockPos.getX(), blockPos.getY(), blockPos.getZ(), blockPos.getX() + 1, blockPos.getY() + 1, blockPos.getZ() + 1).expand(this.spawnRange)).size();
            if (k >= this.maxNearbyEntities) {
                this.updateSpawns(serverWorld, blockPos);
                return;
            }
            entity2.refreshPositionAndAngles(entity2.getX(), entity2.getY(), entity2.getZ(), random.nextFloat() * 360.0f, 0.0f);
            if (entity2 instanceof MobEntity) {
                MobEntity mobEntity = (MobEntity)entity2;
                if (mobSpawnerEntry.getCustomSpawnRules().isEmpty() && !mobEntity.canSpawn(serverWorld, SpawnReason.field_16469) || !mobEntity.canSpawn(serverWorld)) continue;
                if (mobSpawnerEntry.getNbt().getSize() == 1 && mobSpawnerEntry.getNbt().contains("id", 8)) {
                    ((MobEntity)entity2).initialize(serverWorld, serverWorld.getLocalDifficulty(entity2.getBlockPos()), SpawnReason.field_16469, null, null);
                }
            }
            if (!serverWorld.spawnNewEntityAndPassengers(entity2)) {
                this.updateSpawns(serverWorld, blockPos);
                return;
            }
            serverWorld.syncWorldEvent(2004, blockPos, 0);
            serverWorld.emitGameEvent(entity2, GameEvent.field_28738, blockPos2);
            if (entity2 instanceof MobEntity) {
                ((MobEntity)entity2).playSpawnEffects();
            }
            bl = true;
        }
        if (bl) {
            this.updateSpawns(serverWorld, blockPos);
        }
    }

    private void updateSpawns(World world, BlockPos blockPos) {
        Random random = world.random;
        this.spawnDelay = this.maxSpawnDelay <= this.minSpawnDelay ? this.minSpawnDelay : this.minSpawnDelay + random.nextInt(this.maxSpawnDelay - this.minSpawnDelay);
        this.spawnPotentials.getOrEmpty(random).ifPresent(present -> this.setSpawnEntry(world, blockPos, (MobSpawnerEntry)present.getData()));
        this.sendStatus(world, blockPos, 1);
    }

    public void readNbt(@Nullable World world, BlockPos blockPos, NbtCompound nbtCompound) {
        boolean bl2;
        this.spawnDelay = nbtCompound.getShort("Delay");
        boolean bl = nbtCompound.contains(SPAWN_DATA_KEY, 10);
        if (bl) {
            MobSpawnerEntry mobSpawnerEntry = MobSpawnerEntry.CODEC.parse(NbtOps.INSTANCE, nbtCompound.getCompound(SPAWN_DATA_KEY)).resultOrPartial(string -> LOGGER.warn("Invalid SpawnData: {}", string)).orElseGet(MobSpawnerEntry::new);
            this.setSpawnEntry(world, blockPos, mobSpawnerEntry);
        }
        if (bl2 = nbtCompound.contains("SpawnPotentials", 9)) {
            NbtList nbtList = nbtCompound.getList("SpawnPotentials", 10);
            this.spawnPotentials = MobSpawnerEntry.DATA_POOL_CODEC.parse(NbtOps.INSTANCE, nbtList).resultOrPartial(string -> LOGGER.warn("Invalid SpawnPotentials list: {}", string)).orElseGet(DataPool::empty);
        } else {
            this.spawnPotentials = DataPool.of(this.spawnEntry != null ? this.spawnEntry : new MobSpawnerEntry());
        }
        if (nbtCompound.contains("MinSpawnDelay", 99)) {
            this.minSpawnDelay = nbtCompound.getShort("MinSpawnDelay");
            this.maxSpawnDelay = nbtCompound.getShort("MaxSpawnDelay");
            this.spawnCount = nbtCompound.getShort("SpawnCount");
        }
        if (nbtCompound.contains("MaxNearbyEntities", 99)) {
            this.maxNearbyEntities = nbtCompound.getShort("MaxNearbyEntities");
            this.requiredPlayerRange = nbtCompound.getShort("RequiredPlayerRange");
        }
        if (nbtCompound.contains("SpawnRange", 99)) {
            this.spawnRange = nbtCompound.getShort("SpawnRange");
        }
        this.renderedEntity = null;
    }

    public NbtCompound writeNbt(NbtCompound nbtCompound) {
        nbtCompound.putShort("Delay", (short)this.spawnDelay);
        nbtCompound.putShort("MinSpawnDelay", (short)this.minSpawnDelay);
        nbtCompound.putShort("MaxSpawnDelay", (short)this.maxSpawnDelay);
        nbtCompound.putShort("SpawnCount", (short)this.spawnCount);
        nbtCompound.putShort("MaxNearbyEntities", (short)this.maxNearbyEntities);
        nbtCompound.putShort("RequiredPlayerRange", (short)this.requiredPlayerRange);
        nbtCompound.putShort("SpawnRange", (short)this.spawnRange);
        if (this.spawnEntry != null) {
            nbtCompound.put(SPAWN_DATA_KEY, MobSpawnerEntry.CODEC.encodeStart(NbtOps.INSTANCE, this.spawnEntry).result().orElseThrow(() -> new IllegalStateException("Invalid SpawnData")));
        }
        nbtCompound.put("SpawnPotentials", MobSpawnerEntry.DATA_POOL_CODEC.encodeStart(NbtOps.INSTANCE, this.spawnPotentials).result().orElseThrow());
        return nbtCompound;
    }

    @Nullable
    public Entity getRenderedEntity(World world, Random random, BlockPos blockPos) {
        if (this.renderedEntity == null) {
            NbtCompound nbtCompound = this.getSpawnEntry(world, random, blockPos).getNbt();
            if (!nbtCompound.contains("id", 8)) {
                return null;
            }
            this.renderedEntity = EntityType.loadEntityWithPassengers(nbtCompound, world, Function.identity());
            if (nbtCompound.getSize() != 1 || this.renderedEntity instanceof MobEntity) {
                // empty if block
            }
        }
        return this.renderedEntity;
    }

    public boolean handleStatus(World world, int i) {
        if (i == 1) {
            if (world.isClient) {
                this.spawnDelay = this.minSpawnDelay;
            }
            return true;
        }
        return false;
    }

    protected void setSpawnEntry(@Nullable World world, BlockPos blockPos, MobSpawnerEntry mobSpawnerEntry) {
        this.spawnEntry = mobSpawnerEntry;
    }

    private MobSpawnerEntry getSpawnEntry(@Nullable World world, Random random, BlockPos blockPos) {
        if (this.spawnEntry != null) {
            return this.spawnEntry;
        }
        this.setSpawnEntry(world, blockPos, this.spawnPotentials.getOrEmpty(random).map(Weighted.Present::getData).orElseGet(MobSpawnerEntry::new));
        return this.spawnEntry;
    }

    public abstract void sendStatus(World var1, BlockPos var2, int var3);

    public double getRotation() {
        return this.rotation;
    }

    public double getLastRotation() {
        return this.lastRotation;
    }
}


/*
 * Decompiled with CFR 0.2.1 (FabricMC 53fa44c9).
 */
package net.minecraft.block;

import java.util.Optional;
import net.minecraft.block.AbstractBlock;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.FireBlock;
import net.minecraft.block.ShapeContext;
import net.minecraft.block.SoulFireBlock;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemPlacementContext;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.random.Random;
import net.minecraft.util.shape.VoxelShape;
import net.minecraft.world.BlockView;
import net.minecraft.world.World;
import net.minecraft.world.dimension.NetherPortal;

public abstract class AbstractFireBlock
extends Block {
    private static final int SET_ON_FIRE_SECONDS = 8;
    private final float damage;
    protected static final float BASE_SOUND_VOLUME = 1.0f;
    protected static final VoxelShape BASE_SHAPE = Block.createCuboidShape(0.0, 0.0, 0.0, 16.0, 1.0, 16.0);

    public AbstractFireBlock(AbstractBlock.Settings settings, float f) {
        super(settings);
        this.damage = f;
    }

    @Override
    public BlockState getPlacementState(ItemPlacementContext itemPlacementContext) {
        return AbstractFireBlock.getState(itemPlacementContext.getWorld(), itemPlacementContext.getBlockPos());
    }

    public static BlockState getState(BlockView blockView, BlockPos blockPos) {
        BlockPos blockPos2 = blockPos.down();
        BlockState blockState = blockView.getBlockState(blockPos2);
        if (SoulFireBlock.isSoulBase(blockState)) {
            return Blocks.field_22089.getDefaultState();
        }
        return ((FireBlock)Blocks.field_10036).getStateForPosition(blockView, blockPos);
    }

    @Override
    public VoxelShape getOutlineShape(BlockState blockState, BlockView blockView, BlockPos blockPos, ShapeContext shapeContext) {
        return BASE_SHAPE;
    }

    @Override
    public void randomDisplayTick(BlockState blockState, World world, BlockPos blockPos, Random random) {
        block12: {
            double f;
            double e;
            double d;
            int i;
            block11: {
                BlockPos blockPos2;
                BlockState blockState2;
                if (random.nextInt(24) == 0) {
                    world.playSound((double)blockPos.getX() + 0.5, (double)blockPos.getY() + 0.5, (double)blockPos.getZ() + 0.5, SoundEvents.field_14993, SoundCategory.field_15245, 1.0f + random.nextFloat(), random.nextFloat() * 0.7f + 0.3f, false);
                }
                if (!this.isFlammable(blockState2 = world.getBlockState(blockPos2 = blockPos.down())) && !blockState2.isSideSolidFullSquare(world, blockPos2, Direction.field_11036)) break block11;
                for (int i2 = 0; i2 < 3; ++i2) {
                    double d2 = (double)blockPos.getX() + random.nextDouble();
                    double e2 = (double)blockPos.getY() + random.nextDouble() * 0.5 + 0.5;
                    double f2 = (double)blockPos.getZ() + random.nextDouble();
                    world.addParticle(ParticleTypes.field_11237, d2, e2, f2, 0.0, 0.0, 0.0);
                }
                break block12;
            }
            if (this.isFlammable(world.getBlockState(blockPos.west()))) {
                for (i = 0; i < 2; ++i) {
                    d = (double)blockPos.getX() + random.nextDouble() * (double)0.1f;
                    e = (double)blockPos.getY() + random.nextDouble();
                    f = (double)blockPos.getZ() + random.nextDouble();
                    world.addParticle(ParticleTypes.field_11237, d, e, f, 0.0, 0.0, 0.0);
                }
            }
            if (this.isFlammable(world.getBlockState(blockPos.east()))) {
                for (i = 0; i < 2; ++i) {
                    d = (double)(blockPos.getX() + 1) - random.nextDouble() * (double)0.1f;
                    e = (double)blockPos.getY() + random.nextDouble();
                    f = (double)blockPos.getZ() + random.nextDouble();
                    world.addParticle(ParticleTypes.field_11237, d, e, f, 0.0, 0.0, 0.0);
                }
            }
            if (this.isFlammable(world.getBlockState(blockPos.north()))) {
                for (i = 0; i < 2; ++i) {
                    d = (double)blockPos.getX() + random.nextDouble();
                    e = (double)blockPos.getY() + random.nextDouble();
                    f = (double)blockPos.getZ() + random.nextDouble() * (double)0.1f;
                    world.addParticle(ParticleTypes.field_11237, d, e, f, 0.0, 0.0, 0.0);
                }
            }
            if (this.isFlammable(world.getBlockState(blockPos.south()))) {
                for (i = 0; i < 2; ++i) {
                    d = (double)blockPos.getX() + random.nextDouble();
                    e = (double)blockPos.getY() + random.nextDouble();
                    f = (double)(blockPos.getZ() + 1) - random.nextDouble() * (double)0.1f;
                    world.addParticle(ParticleTypes.field_11237, d, e, f, 0.0, 0.0, 0.0);
                }
            }
            if (!this.isFlammable(world.getBlockState(blockPos.up()))) break block12;
            for (i = 0; i < 2; ++i) {
                d = (double)blockPos.getX() + random.nextDouble();
                e = (double)(blockPos.getY() + 1) - random.nextDouble() * (double)0.1f;
                f = (double)blockPos.getZ() + random.nextDouble();
                world.addParticle(ParticleTypes.field_11237, d, e, f, 0.0, 0.0, 0.0);
            }
        }
    }

    protected abstract boolean isFlammable(BlockState var1);

    @Override
    public void onEntityCollision(BlockState blockState, World world, BlockPos blockPos, Entity entity) {
        if (!entity.isFireImmune()) {
            entity.setFireTicks(entity.getFireTicks() + 1);
            if (entity.getFireTicks() == 0) {
                entity.setOnFireFor(8);
            }
        }
        entity.damage(world.getDamageSources().inFire(), this.damage);
        super.onEntityCollision(blockState, world, blockPos, entity);
    }

    @Override
    public void onBlockAdded(BlockState blockState, World world, BlockPos blockPos, BlockState blockState2, boolean bl) {
        Optional<NetherPortal> optional;
        if (blockState2.isOf(blockState.getBlock())) {
            return;
        }
        if (AbstractFireBlock.isOverworldOrNether(world) && (optional = NetherPortal.getNewPortal(world, blockPos, Direction.Axis.field_11048)).isPresent()) {
            optional.get().createPortal();
            return;
        }
        if (!blockState.canPlaceAt(world, blockPos)) {
            world.removeBlock(blockPos, false);
        }
    }

    private static boolean isOverworldOrNether(World world) {
        return world.getRegistryKey() == World.OVERWORLD || world.getRegistryKey() == World.NETHER;
    }

    @Override
    protected void spawnBreakParticles(World world, PlayerEntity playerEntity, BlockPos blockPos, BlockState blockState) {
    }

    @Override
    public void onBreak(World world, BlockPos blockPos, BlockState blockState, PlayerEntity playerEntity) {
        if (!world.isClient()) {
            world.syncWorldEvent(null, 1009, blockPos, 0);
        }
        super.onBreak(world, blockPos, blockState, playerEntity);
    }

    public static boolean canPlaceAt(World world, BlockPos blockPos, Direction direction) {
        BlockState blockState = world.getBlockState(blockPos);
        if (!blockState.isAir()) {
            return false;
        }
        return AbstractFireBlock.getState(world, blockPos).canPlaceAt(world, blockPos) || AbstractFireBlock.shouldLightPortalAt(world, blockPos, direction);
    }

    private static boolean shouldLightPortalAt(World world, BlockPos blockPos, Direction direction) {
        if (!AbstractFireBlock.isOverworldOrNether(world)) {
            return false;
        }
        BlockPos.Mutable mutable = blockPos.mutableCopy();
        boolean bl = false;
        for (Direction direction2 : Direction.values()) {
            if (!world.getBlockState(mutable.set(blockPos).move(direction2)).isOf(Blocks.field_10540)) continue;
            bl = true;
            break;
        }
        if (!bl) {
            return false;
        }
        Direction.Axis axis = direction.getAxis().isHorizontal() ? direction.rotateYCounterclockwise().getAxis() : Direction.Type.field_11062.randomAxis(world.random);
        return NetherPortal.getNewPortal(world, blockPos, axis).isPresent();
    }
}


/*
 * Decompiled with CFR 0.2.1 (FabricMC 53fa44c9).
 */
package net.minecraft.item;

import java.util.List;
import net.minecraft.client.item.TooltipContext;
import net.minecraft.entity.Bucketable;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnReason;
import net.minecraft.entity.passive.TropicalFishEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.fluid.Fluid;
import net.minecraft.item.BucketItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvent;
import net.minecraft.text.MutableText;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraft.world.WorldAccess;
import net.minecraft.world.event.GameEvent;
import org.jetbrains.annotations.Nullable;

public class EntityBucketItem
extends BucketItem {
    private final EntityType<?> entityType;
    private final SoundEvent emptyingSound;

    public EntityBucketItem(EntityType<?> entityType, Fluid fluid, SoundEvent soundEvent, Item.Settings settings) {
        super(fluid, settings);
        this.entityType = entityType;
        this.emptyingSound = soundEvent;
    }

    @Override
    public void onEmptied(@Nullable PlayerEntity playerEntity, World world, ItemStack itemStack, BlockPos blockPos) {
        if (world instanceof ServerWorld) {
            this.spawnEntity((ServerWorld)world, itemStack, blockPos);
            world.emitGameEvent((Entity)playerEntity, GameEvent.field_28738, blockPos);
        }
    }

    @Override
    protected void playEmptyingSound(@Nullable PlayerEntity playerEntity, WorldAccess worldAccess, BlockPos blockPos) {
        worldAccess.playSound(playerEntity, blockPos, this.emptyingSound, SoundCategory.field_15254, 1.0f, 1.0f);
    }

    private void spawnEntity(ServerWorld serverWorld, ItemStack itemStack, BlockPos blockPos) {
        Object entity = this.entityType.spawnFromItemStack(serverWorld, itemStack, null, blockPos, SpawnReason.field_16473, true, false);
        if (entity instanceof Bucketable) {
            Bucketable bucketable = (Bucketable)entity;
            bucketable.copyDataFromNbt(itemStack.getOrCreateNbt());
            bucketable.setFromBucket(true);
        }
    }

    @Override
    public void appendTooltip(ItemStack itemStack, @Nullable World world, List<Text> list, TooltipContext tooltipContext) {
        NbtCompound nbtCompound;
        if (this.entityType == EntityType.field_6111 && (nbtCompound = itemStack.getNbt()) != null && nbtCompound.contains("BucketVariantTag", 3)) {
            int i = nbtCompound.getInt("BucketVariantTag");
            Formatting[] formattings = new Formatting[]{Formatting.field_1056, Formatting.field_1080};
            String string = "color.minecraft." + TropicalFishEntity.getBaseDyeColor(i);
            String string2 = "color.minecraft." + TropicalFishEntity.getPatternDyeColor(i);
            for (int j = 0; j < TropicalFishEntity.COMMON_VARIANTS.size(); ++j) {
                if (i != TropicalFishEntity.COMMON_VARIANTS.get(j).getId()) continue;
                list.add(Text.translatable(TropicalFishEntity.getToolTipForVariant(j)).formatted(formattings));
                return;
            }
            list.add(TropicalFishEntity.getVariety(i).getText().copyContentOnly().formatted(formattings));
            MutableText mutableText = Text.translatable(string);
            if (!string.equals(string2)) {
                mutableText.append(", ").append(Text.translatable(string2));
            }
            mutableText.formatted(formattings);
            list.add(mutableText);
        }
    }
}


/*
 * Decompiled with CFR 0.2.1 (FabricMC 53fa44c9).
 */
package net.minecraft.world;

import it.unimi.dsi.fastutil.longs.LongOpenHashSet;
import it.unimi.dsi.fastutil.longs.LongSet;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.world.PersistentState;

public class ForcedChunkState
extends PersistentState {
    public static final String CHUNKS_KEY = "chunks";
    private static final String FORCED_KEY = "Forced";
    private final LongSet chunks;

    private ForcedChunkState(LongSet longSet) {
        this.chunks = longSet;
    }

    public ForcedChunkState() {
        this(new LongOpenHashSet());
    }

    public static ForcedChunkState fromNbt(NbtCompound nbtCompound) {
        return new ForcedChunkState(new LongOpenHashSet(nbtCompound.getLongArray(FORCED_KEY)));
    }

    @Override
    public NbtCompound writeNbt(NbtCompound nbtCompound) {
        nbtCompound.putLongArray(FORCED_KEY, this.chunks.toLongArray());
        return nbtCompound;
    }

    public LongSet getChunks() {
        return this.chunks;
    }
}


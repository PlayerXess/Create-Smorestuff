/*
 * Decompiled with CFR 0.2.1 (FabricMC 53fa44c9).
 */
package net.minecraft.item;

import com.google.common.collect.Iterables;
import com.google.common.collect.Maps;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.FluidBlock;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.block.entity.MobSpawnerBlockEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnReason;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.passive.PassiveEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemUsageContext;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.resource.featuretoggle.FeatureSet;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.stat.Stats;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;
import net.minecraft.world.World;
import net.minecraft.world.event.GameEvent;
import org.jetbrains.annotations.Nullable;

public class SpawnEggItem
extends Item {
    private static final Map<EntityType<? extends MobEntity>, SpawnEggItem> SPAWN_EGGS = Maps.newIdentityHashMap();
    private final int primaryColor;
    private final int secondaryColor;
    private final EntityType<?> type;

    public SpawnEggItem(EntityType<? extends MobEntity> entityType, int i, int j, Item.Settings settings) {
        super(settings);
        this.type = entityType;
        this.primaryColor = i;
        this.secondaryColor = j;
        SPAWN_EGGS.put(entityType, this);
    }

    @Override
    public ActionResult useOnBlock(ItemUsageContext itemUsageContext) {
        BlockEntity blockEntity;
        World world = itemUsageContext.getWorld();
        if (!(world instanceof ServerWorld)) {
            return ActionResult.SUCCESS;
        }
        ItemStack itemStack = itemUsageContext.getStack();
        BlockPos blockPos = itemUsageContext.getBlockPos();
        Direction direction = itemUsageContext.getSide();
        BlockState blockState = world.getBlockState(blockPos);
        if (blockState.isOf(Blocks.field_10260) && (blockEntity = world.getBlockEntity(blockPos)) instanceof MobSpawnerBlockEntity) {
            MobSpawnerBlockEntity mobSpawnerBlockEntity = (MobSpawnerBlockEntity)blockEntity;
            EntityType<?> entityType = this.getEntityType(itemStack.getNbt());
            mobSpawnerBlockEntity.setEntityType(entityType, world.getRandom());
            blockEntity.markDirty();
            world.updateListeners(blockPos, blockState, blockState, 3);
            world.emitGameEvent((Entity)itemUsageContext.getPlayer(), GameEvent.field_28733, blockPos);
            itemStack.decrement(1);
            return ActionResult.CONSUME;
        }
        BlockPos blockPos2 = blockState.getCollisionShape(world, blockPos).isEmpty() ? blockPos : blockPos.offset(direction);
        EntityType<?> entityType2 = this.getEntityType(itemStack.getNbt());
        if (entityType2.spawnFromItemStack((ServerWorld)world, itemStack, itemUsageContext.getPlayer(), blockPos2, SpawnReason.field_16465, true, !Objects.equals(blockPos, blockPos2) && direction == Direction.field_11036) != null) {
            itemStack.decrement(1);
            world.emitGameEvent((Entity)itemUsageContext.getPlayer(), GameEvent.field_28738, blockPos);
        }
        return ActionResult.CONSUME;
    }

    @Override
    public TypedActionResult<ItemStack> use(World world, PlayerEntity playerEntity, Hand hand) {
        ItemStack itemStack = playerEntity.getStackInHand(hand);
        BlockHitResult blockHitResult = SpawnEggItem.raycast(world, playerEntity, RaycastContext.FluidHandling.field_1345);
        if (blockHitResult.getType() != HitResult.Type.field_1332) {
            return TypedActionResult.pass(itemStack);
        }
        if (!(world instanceof ServerWorld)) {
            return TypedActionResult.success(itemStack);
        }
        BlockHitResult blockHitResult2 = blockHitResult;
        BlockPos blockPos = blockHitResult2.getBlockPos();
        if (!(world.getBlockState(blockPos).getBlock() instanceof FluidBlock)) {
            return TypedActionResult.pass(itemStack);
        }
        if (!world.canPlayerModifyAt(playerEntity, blockPos) || !playerEntity.canPlaceOn(blockPos, blockHitResult2.getSide(), itemStack)) {
            return TypedActionResult.fail(itemStack);
        }
        EntityType<?> entityType = this.getEntityType(itemStack.getNbt());
        Object entity = entityType.spawnFromItemStack((ServerWorld)world, itemStack, playerEntity, blockPos, SpawnReason.field_16465, false, false);
        if (entity == null) {
            return TypedActionResult.pass(itemStack);
        }
        if (!playerEntity.getAbilities().creativeMode) {
            itemStack.decrement(1);
        }
        playerEntity.incrementStat(Stats.field_15372.getOrCreateStat(this));
        world.emitGameEvent((Entity)playerEntity, GameEvent.field_28738, ((Entity)entity).getPos());
        return TypedActionResult.consume(itemStack);
    }

    public boolean isOfSameEntityType(@Nullable NbtCompound nbtCompound, EntityType<?> entityType) {
        return Objects.equals(this.getEntityType(nbtCompound), entityType);
    }

    public int getColor(int i) {
        return i == 0 ? this.primaryColor : this.secondaryColor;
    }

    @Nullable
    public static SpawnEggItem forEntity(@Nullable EntityType<?> entityType) {
        return SPAWN_EGGS.get(entityType);
    }

    public static Iterable<SpawnEggItem> getAll() {
        return Iterables.unmodifiableIterable(SPAWN_EGGS.values());
    }

    public EntityType<?> getEntityType(@Nullable NbtCompound nbtCompound) {
        NbtCompound nbtCompound2;
        if (nbtCompound != null && nbtCompound.contains("EntityTag", 10) && (nbtCompound2 = nbtCompound.getCompound("EntityTag")).contains("id", 8)) {
            return EntityType.get(nbtCompound2.getString("id")).orElse(this.type);
        }
        return this.type;
    }

    @Override
    public FeatureSet getRequiredFeatures() {
        return this.type.getRequiredFeatures();
    }

    public Optional<MobEntity> spawnBaby(PlayerEntity playerEntity, MobEntity mobEntity, EntityType<? extends MobEntity> entityType, ServerWorld serverWorld, Vec3d vec3d, ItemStack itemStack) {
        if (!this.isOfSameEntityType(itemStack.getNbt(), entityType)) {
            return Optional.empty();
        }
        MobEntity mobEntity2 = mobEntity instanceof PassiveEntity ? ((PassiveEntity)mobEntity).createChild(serverWorld, (PassiveEntity)mobEntity) : entityType.create(serverWorld);
        if (mobEntity2 == null) {
            return Optional.empty();
        }
        mobEntity2.setBaby(true);
        if (!mobEntity2.isBaby()) {
            return Optional.empty();
        }
        mobEntity2.refreshPositionAndAngles(vec3d.getX(), vec3d.getY(), vec3d.getZ(), 0.0f, 0.0f);
        serverWorld.spawnEntityAndPassengers(mobEntity2);
        if (itemStack.hasCustomName()) {
            mobEntity2.setCustomName(itemStack.getName());
        }
        if (!playerEntity.getAbilities().creativeMode) {
            itemStack.decrement(1);
        }
        return Optional.of(mobEntity2);
    }
}


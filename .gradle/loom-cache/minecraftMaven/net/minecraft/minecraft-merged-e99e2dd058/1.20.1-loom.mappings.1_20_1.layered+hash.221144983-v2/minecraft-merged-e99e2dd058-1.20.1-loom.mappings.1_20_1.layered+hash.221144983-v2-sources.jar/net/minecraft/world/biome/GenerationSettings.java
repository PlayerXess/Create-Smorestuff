/*
 * Decompiled with CFR 0.2.1 (FabricMC 53fa44c9).
 */
package net.minecraft.world.biome;

import com.google.common.base.Suppliers;
import com.google.common.collect.ImmutableList;
import com.google.common.collect.ImmutableMap;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.mojang.datafixers.kinds.Applicative;
import com.mojang.logging.LogUtils;
import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.function.Consumer;
import java.util.function.Supplier;
import java.util.stream.Collectors;
import net.minecraft.registry.RegistryEntryLookup;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.registry.entry.RegistryEntryList;
import net.minecraft.util.StringIdentifiable;
import net.minecraft.util.Util;
import net.minecraft.world.gen.GenerationStep;
import net.minecraft.world.gen.carver.ConfiguredCarver;
import net.minecraft.world.gen.feature.ConfiguredFeature;
import net.minecraft.world.gen.feature.Feature;
import net.minecraft.world.gen.feature.PlacedFeature;
import org.slf4j.Logger;

public class GenerationSettings {
    private static final Logger LOGGER = LogUtils.getLogger();
    public static final GenerationSettings INSTANCE = new GenerationSettings(ImmutableMap.of(), ImmutableList.of());
    public static final MapCodec<GenerationSettings> CODEC = RecordCodecBuilder.mapCodec(instance -> instance.group(Codec.simpleMap(GenerationStep.Carver.CODEC, ConfiguredCarver.LIST_CODEC.promotePartial((Consumer)Util.addPrefix("Carver: ", LOGGER::error)), StringIdentifiable.toKeyable(GenerationStep.Carver.values())).fieldOf("carvers").forGetter(generationSettings -> generationSettings.carvers), ((MapCodec)PlacedFeature.LISTS_CODEC.promotePartial((Consumer)Util.addPrefix("Features: ", LOGGER::error)).fieldOf("features")).forGetter(generationSettings -> generationSettings.features)).apply((Applicative<GenerationSettings, ?>)instance, GenerationSettings::new));
    private final Map<GenerationStep.Carver, RegistryEntryList<ConfiguredCarver<?>>> carvers;
    private final List<RegistryEntryList<PlacedFeature>> features;
    private final Supplier<List<ConfiguredFeature<?, ?>>> flowerFeatures;
    private final Supplier<Set<PlacedFeature>> allowedFeatures;

    GenerationSettings(Map<GenerationStep.Carver, RegistryEntryList<ConfiguredCarver<?>>> map, List<RegistryEntryList<PlacedFeature>> list) {
        this.carvers = map;
        this.features = list;
        this.flowerFeatures = Suppliers.memoize(() -> list.stream().flatMap(RegistryEntryList::stream).map(RegistryEntry::comp_349).flatMap(PlacedFeature::getDecoratedFeatures).filter(configuredFeature -> configuredFeature.feature() == Feature.FLOWER).collect(ImmutableList.toImmutableList()));
        this.allowedFeatures = Suppliers.memoize(() -> list.stream().flatMap(RegistryEntryList::stream).map(RegistryEntry::comp_349).collect(Collectors.toSet()));
    }

    public Iterable<RegistryEntry<ConfiguredCarver<?>>> getCarversForStep(GenerationStep.Carver carver) {
        return Objects.requireNonNullElseGet((Iterable)this.carvers.get(carver), List::of);
    }

    public List<ConfiguredFeature<?, ?>> getFlowerFeatures() {
        return this.flowerFeatures.get();
    }

    public List<RegistryEntryList<PlacedFeature>> getFeatures() {
        return this.features;
    }

    public boolean isFeatureAllowed(PlacedFeature placedFeature) {
        return this.allowedFeatures.get().contains(placedFeature);
    }

    public static class LookupBackedBuilder
    extends Builder {
        private final RegistryEntryLookup<PlacedFeature> placedFeatureLookup;
        private final RegistryEntryLookup<ConfiguredCarver<?>> configuredCarverLookup;

        public LookupBackedBuilder(RegistryEntryLookup<PlacedFeature> registryEntryLookup, RegistryEntryLookup<ConfiguredCarver<?>> registryEntryLookup2) {
            this.placedFeatureLookup = registryEntryLookup;
            this.configuredCarverLookup = registryEntryLookup2;
        }

        public LookupBackedBuilder feature(GenerationStep.Feature feature, RegistryKey<PlacedFeature> registryKey) {
            this.addFeature(feature.ordinal(), this.placedFeatureLookup.getOrThrow(registryKey));
            return this;
        }

        public LookupBackedBuilder carver(GenerationStep.Carver carver, RegistryKey<ConfiguredCarver<?>> registryKey) {
            this.carver(carver, this.configuredCarverLookup.getOrThrow(registryKey));
            return this;
        }
    }

    public static class Builder {
        private final Map<GenerationStep.Carver, List<RegistryEntry<ConfiguredCarver<?>>>> carverStepsToCarvers = Maps.newLinkedHashMap();
        private final List<List<RegistryEntry<PlacedFeature>>> indexedFeaturesList = Lists.newArrayList();

        public Builder feature(GenerationStep.Feature feature, RegistryEntry<PlacedFeature> registryEntry) {
            return this.addFeature(feature.ordinal(), registryEntry);
        }

        public Builder addFeature(int i, RegistryEntry<PlacedFeature> registryEntry) {
            this.fillFeaturesList(i);
            this.indexedFeaturesList.get(i).add(registryEntry);
            return this;
        }

        public Builder carver(GenerationStep.Carver carver2, RegistryEntry<ConfiguredCarver<?>> registryEntry) {
            this.carverStepsToCarvers.computeIfAbsent(carver2, carver -> Lists.newArrayList()).add(registryEntry);
            return this;
        }

        private void fillFeaturesList(int i) {
            while (this.indexedFeaturesList.size() <= i) {
                this.indexedFeaturesList.add(Lists.newArrayList());
            }
        }

        public GenerationSettings build() {
            return new GenerationSettings((Map)this.carverStepsToCarvers.entrySet().stream().collect(ImmutableMap.toImmutableMap(Map.Entry::getKey, entry -> RegistryEntryList.of((List)entry.getValue()))), this.indexedFeaturesList.stream().map(RegistryEntryList::of).collect(ImmutableList.toImmutableList()));
        }
    }
}


/*
 * Decompiled with CFR 0.2.1 (FabricMC 53fa44c9).
 */
package net.minecraft.world.gen.chunk;

import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.world.gen.chunk.BlockColumn;

public final class VerticalBlockSample
implements BlockColumn {
    private final int startY;
    private final BlockState[] states;

    public VerticalBlockSample(int i, BlockState[] blockStates) {
        this.startY = i;
        this.states = blockStates;
    }

    @Override
    public BlockState getState(int i) {
        int j = i - this.startY;
        if (j < 0 || j >= this.states.length) {
            return Blocks.field_10124.getDefaultState();
        }
        return this.states[j];
    }

    @Override
    public void setState(int i, BlockState blockState) {
        int j = i - this.startY;
        if (j < 0 || j >= this.states.length) {
            throw new IllegalArgumentException("Outside of column height: " + i);
        }
        this.states[j] = blockState;
    }
}


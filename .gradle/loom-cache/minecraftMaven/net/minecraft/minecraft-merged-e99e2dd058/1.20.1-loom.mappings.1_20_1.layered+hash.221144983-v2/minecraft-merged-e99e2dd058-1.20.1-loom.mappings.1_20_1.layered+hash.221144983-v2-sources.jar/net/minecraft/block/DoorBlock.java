/*
 * Decompiled with CFR 0.2.1 (FabricMC 53fa44c9).
 */
package net.minecraft.block;

import net.minecraft.block.AbstractBlock;
import net.minecraft.block.Block;
import net.minecraft.block.BlockSetType;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.HorizontalFacingBlock;
import net.minecraft.block.ShapeContext;
import net.minecraft.block.TallPlantBlock;
import net.minecraft.block.enums.DoorHinge;
import net.minecraft.block.enums.DoubleBlockHalf;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.ai.pathing.NavigationType;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemPlacementContext;
import net.minecraft.item.ItemStack;
import net.minecraft.sound.SoundCategory;
import net.minecraft.state.StateManager;
import net.minecraft.state.property.BooleanProperty;
import net.minecraft.state.property.DirectionProperty;
import net.minecraft.state.property.EnumProperty;
import net.minecraft.state.property.Properties;
import net.minecraft.util.ActionResult;
import net.minecraft.util.BlockMirror;
import net.minecraft.util.BlockRotation;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.shape.VoxelShape;
import net.minecraft.world.BlockView;
import net.minecraft.world.World;
import net.minecraft.world.WorldAccess;
import net.minecraft.world.WorldView;
import net.minecraft.world.event.GameEvent;
import org.jetbrains.annotations.Nullable;

public class DoorBlock
extends Block {
    public static final DirectionProperty FACING = HorizontalFacingBlock.FACING;
    public static final BooleanProperty OPEN = Properties.OPEN;
    public static final EnumProperty<DoorHinge> HINGE = Properties.DOOR_HINGE;
    public static final BooleanProperty POWERED = Properties.POWERED;
    public static final EnumProperty<DoubleBlockHalf> HALF = Properties.DOUBLE_BLOCK_HALF;
    protected static final float field_31083 = 3.0f;
    protected static final VoxelShape NORTH_SHAPE = Block.createCuboidShape(0.0, 0.0, 0.0, 16.0, 16.0, 3.0);
    protected static final VoxelShape SOUTH_SHAPE = Block.createCuboidShape(0.0, 0.0, 13.0, 16.0, 16.0, 16.0);
    protected static final VoxelShape EAST_SHAPE = Block.createCuboidShape(13.0, 0.0, 0.0, 16.0, 16.0, 16.0);
    protected static final VoxelShape WEST_SHAPE = Block.createCuboidShape(0.0, 0.0, 0.0, 3.0, 16.0, 16.0);
    private final BlockSetType blockSetType;

    public DoorBlock(AbstractBlock.Settings settings, BlockSetType blockSetType) {
        super(settings.sounds(blockSetType.comp_1290()));
        this.blockSetType = blockSetType;
        this.setDefaultState((BlockState)((BlockState)((BlockState)((BlockState)((BlockState)((BlockState)this.stateManager.getDefaultState()).with(FACING, Direction.field_11043)).with(OPEN, false)).with(HINGE, DoorHinge.field_12588)).with(POWERED, false)).with(HALF, DoubleBlockHalf.field_12607));
    }

    public BlockSetType getBlockSetType() {
        return this.blockSetType;
    }

    @Override
    public VoxelShape getOutlineShape(BlockState blockState, BlockView blockView, BlockPos blockPos, ShapeContext shapeContext) {
        Direction direction = blockState.get(FACING);
        boolean bl = blockState.get(OPEN) == false;
        boolean bl2 = blockState.get(HINGE) == DoorHinge.field_12586;
        switch (direction) {
            default: {
                return bl ? WEST_SHAPE : (bl2 ? SOUTH_SHAPE : NORTH_SHAPE);
            }
            case field_11035: {
                return bl ? NORTH_SHAPE : (bl2 ? WEST_SHAPE : EAST_SHAPE);
            }
            case field_11039: {
                return bl ? EAST_SHAPE : (bl2 ? NORTH_SHAPE : SOUTH_SHAPE);
            }
            case field_11043: 
        }
        return bl ? SOUTH_SHAPE : (bl2 ? EAST_SHAPE : WEST_SHAPE);
    }

    @Override
    public BlockState getStateForNeighborUpdate(BlockState blockState, Direction direction, BlockState blockState2, WorldAccess worldAccess, BlockPos blockPos, BlockPos blockPos2) {
        DoubleBlockHalf doubleBlockHalf = blockState.get(HALF);
        if (direction.getAxis() == Direction.Axis.field_11052 && doubleBlockHalf == DoubleBlockHalf.field_12607 == (direction == Direction.field_11036)) {
            if (blockState2.isOf(this) && blockState2.get(HALF) != doubleBlockHalf) {
                return (BlockState)((BlockState)((BlockState)((BlockState)blockState.with(FACING, blockState2.get(FACING))).with(OPEN, blockState2.get(OPEN))).with(HINGE, blockState2.get(HINGE))).with(POWERED, blockState2.get(POWERED));
            }
            return Blocks.field_10124.getDefaultState();
        }
        if (doubleBlockHalf == DoubleBlockHalf.field_12607 && direction == Direction.field_11033 && !blockState.canPlaceAt(worldAccess, blockPos)) {
            return Blocks.field_10124.getDefaultState();
        }
        return super.getStateForNeighborUpdate(blockState, direction, blockState2, worldAccess, blockPos, blockPos2);
    }

    @Override
    public void onBreak(World world, BlockPos blockPos, BlockState blockState, PlayerEntity playerEntity) {
        if (!world.isClient && playerEntity.isCreative()) {
            TallPlantBlock.onBreakInCreative(world, blockPos, blockState, playerEntity);
        }
        super.onBreak(world, blockPos, blockState, playerEntity);
    }

    @Override
    public boolean canPathfindThrough(BlockState blockState, BlockView blockView, BlockPos blockPos, NavigationType navigationType) {
        switch (navigationType) {
            case field_50: {
                return blockState.get(OPEN);
            }
            case field_48: {
                return false;
            }
            case field_51: {
                return blockState.get(OPEN);
            }
        }
        return false;
    }

    @Override
    @Nullable
    public BlockState getPlacementState(ItemPlacementContext itemPlacementContext) {
        BlockPos blockPos = itemPlacementContext.getBlockPos();
        World world = itemPlacementContext.getWorld();
        if (blockPos.getY() < world.getTopY() - 1 && world.getBlockState(blockPos.up()).canReplace(itemPlacementContext)) {
            boolean bl = world.isReceivingRedstonePower(blockPos) || world.isReceivingRedstonePower(blockPos.up());
            return (BlockState)((BlockState)((BlockState)((BlockState)((BlockState)this.getDefaultState().with(FACING, itemPlacementContext.getHorizontalPlayerFacing())).with(HINGE, this.getHinge(itemPlacementContext))).with(POWERED, bl)).with(OPEN, bl)).with(HALF, DoubleBlockHalf.field_12607);
        }
        return null;
    }

    @Override
    public void onPlaced(World world, BlockPos blockPos, BlockState blockState, LivingEntity livingEntity, ItemStack itemStack) {
        world.setBlockState(blockPos.up(), (BlockState)blockState.with(HALF, DoubleBlockHalf.field_12609), 3);
    }

    private DoorHinge getHinge(ItemPlacementContext itemPlacementContext) {
        boolean bl2;
        World blockView = itemPlacementContext.getWorld();
        BlockPos blockPos = itemPlacementContext.getBlockPos();
        Direction direction = itemPlacementContext.getHorizontalPlayerFacing();
        BlockPos blockPos2 = blockPos.up();
        Direction direction2 = direction.rotateYCounterclockwise();
        BlockPos blockPos3 = blockPos.offset(direction2);
        BlockState blockState = blockView.getBlockState(blockPos3);
        BlockPos blockPos4 = blockPos2.offset(direction2);
        BlockState blockState2 = blockView.getBlockState(blockPos4);
        Direction direction3 = direction.rotateYClockwise();
        BlockPos blockPos5 = blockPos.offset(direction3);
        BlockState blockState3 = blockView.getBlockState(blockPos5);
        BlockPos blockPos6 = blockPos2.offset(direction3);
        BlockState blockState4 = blockView.getBlockState(blockPos6);
        int i = (blockState.isFullCube(blockView, blockPos3) ? -1 : 0) + (blockState2.isFullCube(blockView, blockPos4) ? -1 : 0) + (blockState3.isFullCube(blockView, blockPos5) ? 1 : 0) + (blockState4.isFullCube(blockView, blockPos6) ? 1 : 0);
        boolean bl = blockState.isOf(this) && blockState.get(HALF) == DoubleBlockHalf.field_12607;
        boolean bl3 = bl2 = blockState3.isOf(this) && blockState3.get(HALF) == DoubleBlockHalf.field_12607;
        if (bl && !bl2 || i > 0) {
            return DoorHinge.field_12586;
        }
        if (bl2 && !bl || i < 0) {
            return DoorHinge.field_12588;
        }
        int j = direction.getOffsetX();
        int k = direction.getOffsetZ();
        Vec3d vec3d = itemPlacementContext.getHitPos();
        double d = vec3d.x - (double)blockPos.getX();
        double e = vec3d.z - (double)blockPos.getZ();
        return j < 0 && e < 0.5 || j > 0 && e > 0.5 || k < 0 && d > 0.5 || k > 0 && d < 0.5 ? DoorHinge.field_12586 : DoorHinge.field_12588;
    }

    @Override
    public ActionResult onUse(BlockState blockState, World world, BlockPos blockPos, PlayerEntity playerEntity, Hand hand, BlockHitResult blockHitResult) {
        if (!this.blockSetType.comp_1471()) {
            return ActionResult.PASS;
        }
        blockState = (BlockState)blockState.cycle(OPEN);
        world.setBlockState(blockPos, blockState, 10);
        this.playOpenCloseSound(playerEntity, world, blockPos, blockState.get(OPEN));
        world.emitGameEvent((Entity)playerEntity, this.isOpen(blockState) ? GameEvent.field_28168 : GameEvent.field_28169, blockPos);
        return ActionResult.success(world.isClient);
    }

    public boolean isOpen(BlockState blockState) {
        return blockState.get(OPEN);
    }

    public void setOpen(@Nullable Entity entity, World world, BlockState blockState, BlockPos blockPos, boolean bl) {
        if (!blockState.isOf(this) || blockState.get(OPEN) == bl) {
            return;
        }
        world.setBlockState(blockPos, (BlockState)blockState.with(OPEN, bl), 10);
        this.playOpenCloseSound(entity, world, blockPos, bl);
        world.emitGameEvent(entity, bl ? GameEvent.field_28168 : GameEvent.field_28169, blockPos);
    }

    @Override
    public void neighborUpdate(BlockState blockState, World world, BlockPos blockPos, Block block, BlockPos blockPos2, boolean bl) {
        boolean bl2;
        boolean bl3 = world.isReceivingRedstonePower(blockPos) || world.isReceivingRedstonePower(blockPos.offset(blockState.get(HALF) == DoubleBlockHalf.field_12607 ? Direction.field_11036 : Direction.field_11033)) ? true : (bl2 = false);
        if (!this.getDefaultState().isOf(block) && bl2 != blockState.get(POWERED)) {
            if (bl2 != blockState.get(OPEN)) {
                this.playOpenCloseSound(null, world, blockPos, bl2);
                world.emitGameEvent(null, bl2 ? GameEvent.field_28168 : GameEvent.field_28169, blockPos);
            }
            world.setBlockState(blockPos, (BlockState)((BlockState)blockState.with(POWERED, bl2)).with(OPEN, bl2), 2);
        }
    }

    @Override
    public boolean canPlaceAt(BlockState blockState, WorldView worldView, BlockPos blockPos) {
        BlockPos blockPos2 = blockPos.down();
        BlockState blockState2 = worldView.getBlockState(blockPos2);
        if (blockState.get(HALF) == DoubleBlockHalf.field_12607) {
            return blockState2.isSideSolidFullSquare(worldView, blockPos2, Direction.field_11036);
        }
        return blockState2.isOf(this);
    }

    private void playOpenCloseSound(@Nullable Entity entity, World world, BlockPos blockPos, boolean bl) {
        world.playSound(entity, blockPos, bl ? this.blockSetType.comp_1292() : this.blockSetType.comp_1291(), SoundCategory.field_15245, 1.0f, world.getRandom().nextFloat() * 0.1f + 0.9f);
    }

    @Override
    public BlockState rotate(BlockState blockState, BlockRotation blockRotation) {
        return (BlockState)blockState.with(FACING, blockRotation.rotate(blockState.get(FACING)));
    }

    @Override
    public BlockState mirror(BlockState blockState, BlockMirror blockMirror) {
        if (blockMirror == BlockMirror.field_11302) {
            return blockState;
        }
        return (BlockState)blockState.rotate(blockMirror.getRotation(blockState.get(FACING))).cycle(HINGE);
    }

    @Override
    public long getRenderingSeed(BlockState blockState, BlockPos blockPos) {
        return MathHelper.hashCode(blockPos.getX(), blockPos.down(blockState.get(HALF) == DoubleBlockHalf.field_12607 ? 0 : 1).getY(), blockPos.getZ());
    }

    @Override
    protected void appendProperties(StateManager.Builder<Block, BlockState> builder) {
        builder.add(HALF, FACING, OPEN, HINGE, POWERED);
    }

    public static boolean canOpenByHand(World world, BlockPos blockPos) {
        return DoorBlock.canOpenByHand(world.getBlockState(blockPos));
    }

    public static boolean canOpenByHand(BlockState blockState) {
        DoorBlock doorBlock;
        Block block = blockState.getBlock();
        return block instanceof DoorBlock && (doorBlock = (DoorBlock)block).getBlockSetType().comp_1471();
    }
}


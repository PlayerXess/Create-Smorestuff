/*
 * Decompiled with CFR 0.2.1 (FabricMC 53fa44c9).
 */
package net.minecraft.enchantment;

import net.minecraft.enchantment.Enchantment;
import net.minecraft.enchantment.EnchantmentTarget;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityGroup;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.item.AxeItem;
import net.minecraft.item.ItemStack;

public class DamageEnchantment
extends Enchantment {
    public static final int ALL_INDEX = 0;
    public static final int UNDEAD_INDEX = 1;
    public static final int ARTHROPODS_INDEX = 2;
    private static final String[] TYPE_NAMES = new String[]{"all", "undead", "arthropods"};
    private static final int[] BASE_POWERS = new int[]{1, 5, 5};
    private static final int[] POWERS_PER_LEVEL = new int[]{11, 8, 8};
    private static final int[] MIN_MAX_POWER_DIFFERENCES = new int[]{20, 20, 20};
    public final int typeIndex;

    public DamageEnchantment(Enchantment.Rarity rarity, int i, EquipmentSlot ... equipmentSlots) {
        super(rarity, EnchantmentTarget.field_9074, equipmentSlots);
        this.typeIndex = i;
    }

    @Override
    public int getMinPower(int i) {
        return BASE_POWERS[this.typeIndex] + (i - 1) * POWERS_PER_LEVEL[this.typeIndex];
    }

    @Override
    public int getMaxPower(int i) {
        return this.getMinPower(i) + MIN_MAX_POWER_DIFFERENCES[this.typeIndex];
    }

    @Override
    public int getMaxLevel() {
        return 5;
    }

    @Override
    public float getAttackDamage(int i, EntityGroup entityGroup) {
        if (this.typeIndex == 0) {
            return 1.0f + (float)Math.max(0, i - 1) * 0.5f;
        }
        if (this.typeIndex == 1 && entityGroup == EntityGroup.UNDEAD) {
            return (float)i * 2.5f;
        }
        if (this.typeIndex == 2 && entityGroup == EntityGroup.ARTHROPOD) {
            return (float)i * 2.5f;
        }
        return 0.0f;
    }

    @Override
    public boolean canAccept(Enchantment enchantment) {
        return !(enchantment instanceof DamageEnchantment);
    }

    @Override
    public boolean isAcceptableItem(ItemStack itemStack) {
        if (itemStack.getItem() instanceof AxeItem) {
            return true;
        }
        return super.isAcceptableItem(itemStack);
    }

    @Override
    public void onTargetDamaged(LivingEntity livingEntity, Entity entity, int i) {
        if (entity instanceof LivingEntity) {
            LivingEntity livingEntity2 = (LivingEntity)entity;
            if (this.typeIndex == 2 && i > 0 && livingEntity2.getGroup() == EntityGroup.ARTHROPOD) {
                int j = 20 + livingEntity.getRandom().nextInt(10 * i);
                livingEntity2.addStatusEffect(new StatusEffectInstance(StatusEffects.field_5909, j, 3));
            }
        }
    }
}


/*
 * Decompiled with CFR 0.2.1 (FabricMC 53fa44c9).
 */
package net.minecraft.recipe;

import net.minecraft.recipe.RecipeMatcher;

public interface RecipeInputProvider {
    public void provideRecipeInputs(RecipeMatcher var1);
}


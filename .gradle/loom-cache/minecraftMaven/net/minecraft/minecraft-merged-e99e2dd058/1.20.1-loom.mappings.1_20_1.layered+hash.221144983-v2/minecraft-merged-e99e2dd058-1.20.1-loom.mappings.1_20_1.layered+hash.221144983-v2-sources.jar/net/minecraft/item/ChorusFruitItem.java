/*
 * Decompiled with CFR 0.2.1 (FabricMC 53fa44c9).
 */
package net.minecraft.item;

import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.passive.FoxEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;
import net.minecraft.world.event.GameEvent;

public class ChorusFruitItem
extends Item {
    public ChorusFruitItem(Item.Settings settings) {
        super(settings);
    }

    @Override
    public ItemStack finishUsing(ItemStack itemStack, World world, LivingEntity livingEntity) {
        ItemStack itemStack2 = super.finishUsing(itemStack, world, livingEntity);
        if (!world.isClient) {
            double d = livingEntity.getX();
            double e = livingEntity.getY();
            double f = livingEntity.getZ();
            for (int i = 0; i < 16; ++i) {
                double g = livingEntity.getX() + (livingEntity.getRandom().nextDouble() - 0.5) * 16.0;
                double h = MathHelper.clamp(livingEntity.getY() + (double)(livingEntity.getRandom().nextInt(16) - 8), (double)world.getBottomY(), (double)(world.getBottomY() + ((ServerWorld)world).getLogicalHeight() - 1));
                double j = livingEntity.getZ() + (livingEntity.getRandom().nextDouble() - 0.5) * 16.0;
                if (livingEntity.hasVehicle()) {
                    livingEntity.stopRiding();
                }
                Vec3d vec3d = livingEntity.getPos();
                if (!livingEntity.teleport(g, h, j, true)) continue;
                world.emitGameEvent(GameEvent.field_39446, vec3d, GameEvent.Emitter.of(livingEntity));
                SoundEvent soundEvent = livingEntity instanceof FoxEntity ? SoundEvents.field_24630 : SoundEvents.field_14890;
                world.playSound(null, d, e, f, soundEvent, SoundCategory.field_15248, 1.0f, 1.0f);
                livingEntity.playSound(soundEvent, 1.0f, 1.0f);
                break;
            }
            if (livingEntity instanceof PlayerEntity) {
                ((PlayerEntity)livingEntity).getItemCooldownManager().set(this, 20);
            }
        }
        return itemStack2;
    }
}


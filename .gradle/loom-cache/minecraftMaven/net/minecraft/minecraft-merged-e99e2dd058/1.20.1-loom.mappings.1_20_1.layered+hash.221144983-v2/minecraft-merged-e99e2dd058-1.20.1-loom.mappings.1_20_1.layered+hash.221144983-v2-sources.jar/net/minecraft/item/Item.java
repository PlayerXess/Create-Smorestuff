/*
 * Decompiled with CFR 0.2.1 (FabricMC 53fa44c9).
 */
package net.minecraft.item;

import com.google.common.collect.ImmutableMultimap;
import com.google.common.collect.Maps;
import com.google.common.collect.Multimap;
import com.mojang.logging.LogUtils;
import io.github.fabricators_of_create.porting_lib.extensions.extensions.ItemExtensions;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import net.fabricmc.fabric.api.item.v1.FabricItem;
import net.minecraft.SharedConstants;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.client.item.TooltipContext;
import net.minecraft.client.item.TooltipData;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.ItemEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.attribute.EntityAttribute;
import net.minecraft.entity.attribute.EntityAttributeModifier;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.inventory.StackReference;
import net.minecraft.item.FoodComponent;
import net.minecraft.item.ItemConvertible;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemUsageContext;
import net.minecraft.item.Items;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.registry.Registries;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.registry.tag.DamageTypeTags;
import net.minecraft.resource.featuretoggle.FeatureFlag;
import net.minecraft.resource.featuretoggle.FeatureFlags;
import net.minecraft.resource.featuretoggle.FeatureSet;
import net.minecraft.resource.featuretoggle.ToggleableFeature;
import net.minecraft.screen.slot.Slot;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.ClickType;
import net.minecraft.util.Hand;
import net.minecraft.util.Rarity;
import net.minecraft.util.TypedActionResult;
import net.minecraft.util.UseAction;
import net.minecraft.util.Util;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;
import net.minecraft.world.World;
import org.jetbrains.annotations.Nullable;
import org.slf4j.Logger;

public class Item
implements ToggleableFeature,
ItemConvertible,
FabricItem,
io.github.fabricators_of_create.porting_lib.entity.extensions.ItemExtensions,
ItemExtensions {
    private static final Logger LOGGER = LogUtils.getLogger();
    public static final Map<Block, Item> BLOCK_ITEMS = Maps.newHashMap();
    protected static final UUID ATTACK_DAMAGE_MODIFIER_ID = UUID.fromString("CB3F55D3-645C-4F38-A497-9C13A33DB5CF");
    protected static final UUID ATTACK_SPEED_MODIFIER_ID = UUID.fromString("FA233E1C-4180-4865-B01B-BCCE9785ACA3");
    public static final int DEFAULT_MAX_COUNT = 64;
    public static final int DEFAULT_MAX_USE_TIME = 32;
    public static final int ITEM_BAR_STEPS = 13;
    private final RegistryEntry.Reference<Item> registryEntry = Registries.ITEM.createEntry(this);
    private final Rarity rarity;
    private final int maxCount;
    private final int maxDamage;
    private final boolean fireproof;
    @Nullable
    private final Item recipeRemainder;
    @Nullable
    private String translationKey;
    @Nullable
    private final FoodComponent foodComponent;
    private final FeatureSet requiredFeatures;

    public static int getRawId(Item item) {
        return item == null ? 0 : Registries.ITEM.getRawId(item);
    }

    public static Item byRawId(int i) {
        return Registries.ITEM.get(i);
    }

    @Deprecated
    public static Item fromBlock(Block block) {
        return BLOCK_ITEMS.getOrDefault(block, Items.AIR);
    }

    public Item(Settings settings) {
        String string;
        this.rarity = settings.rarity;
        this.recipeRemainder = settings.recipeRemainder;
        this.maxDamage = settings.maxDamage;
        this.maxCount = settings.maxCount;
        this.foodComponent = settings.foodComponent;
        this.fireproof = settings.fireproof;
        this.requiredFeatures = settings.requiredFeatures;
        if (SharedConstants.isDevelopment && !(string = this.getClass().getSimpleName()).endsWith("Item")) {
            LOGGER.error("Item classes should end with Item and {} doesn't.", (Object)string);
        }
    }

    @Deprecated
    public RegistryEntry.Reference<Item> getRegistryEntry() {
        return this.registryEntry;
    }

    public void usageTick(World world, LivingEntity livingEntity, ItemStack itemStack, int i) {
    }

    public void onItemEntityDestroyed(ItemEntity itemEntity) {
    }

    public void postProcessNbt(NbtCompound nbtCompound) {
    }

    public boolean canMine(BlockState blockState, World world, BlockPos blockPos, PlayerEntity playerEntity) {
        return true;
    }

    @Override
    public Item asItem() {
        return this;
    }

    public ActionResult useOnBlock(ItemUsageContext itemUsageContext) {
        return ActionResult.PASS;
    }

    public float getMiningSpeedMultiplier(ItemStack itemStack, BlockState blockState) {
        return 1.0f;
    }

    public TypedActionResult<ItemStack> use(World world, PlayerEntity playerEntity, Hand hand) {
        if (this.isFood()) {
            ItemStack itemStack = playerEntity.getStackInHand(hand);
            if (playerEntity.canConsume(this.getFoodComponent().isAlwaysEdible())) {
                playerEntity.setCurrentHand(hand);
                return TypedActionResult.consume(itemStack);
            }
            return TypedActionResult.fail(itemStack);
        }
        return TypedActionResult.pass(playerEntity.getStackInHand(hand));
    }

    public ItemStack finishUsing(ItemStack itemStack, World world, LivingEntity livingEntity) {
        if (this.isFood()) {
            return livingEntity.eatFood(world, itemStack);
        }
        return itemStack;
    }

    public final int getMaxCount() {
        return this.maxCount;
    }

    public final int getMaxDamage() {
        return this.maxDamage;
    }

    public boolean isDamageable() {
        return this.maxDamage > 0;
    }

    public boolean isItemBarVisible(ItemStack itemStack) {
        return itemStack.isDamaged();
    }

    public int getItemBarStep(ItemStack itemStack) {
        return Math.round(13.0f - (float)itemStack.getDamage() * 13.0f / (float)this.maxDamage);
    }

    public int getItemBarColor(ItemStack itemStack) {
        float f = Math.max(0.0f, ((float)this.maxDamage - (float)itemStack.getDamage()) / (float)this.maxDamage);
        return MathHelper.hsvToRgb(f / 3.0f, 1.0f, 1.0f);
    }

    public boolean onStackClicked(ItemStack itemStack, Slot slot, ClickType clickType, PlayerEntity playerEntity) {
        return false;
    }

    public boolean onClicked(ItemStack itemStack, ItemStack itemStack2, Slot slot, ClickType clickType, PlayerEntity playerEntity, StackReference stackReference) {
        return false;
    }

    public boolean postHit(ItemStack itemStack, LivingEntity livingEntity, LivingEntity livingEntity2) {
        return false;
    }

    public boolean postMine(ItemStack itemStack, World world, BlockState blockState, BlockPos blockPos, LivingEntity livingEntity) {
        return false;
    }

    public boolean isSuitableFor(BlockState blockState) {
        return false;
    }

    public ActionResult useOnEntity(ItemStack itemStack, PlayerEntity playerEntity, LivingEntity livingEntity, Hand hand) {
        return ActionResult.PASS;
    }

    public Text getName() {
        return Text.translatable(this.getTranslationKey());
    }

    public String toString() {
        return Registries.ITEM.getId(this).getPath();
    }

    protected String getOrCreateTranslationKey() {
        if (this.translationKey == null) {
            this.translationKey = Util.createTranslationKey("item", Registries.ITEM.getId(this));
        }
        return this.translationKey;
    }

    public String getTranslationKey() {
        return this.getOrCreateTranslationKey();
    }

    public String getTranslationKey(ItemStack itemStack) {
        return this.getTranslationKey();
    }

    public boolean isNbtSynced() {
        return true;
    }

    @Nullable
    public final Item getRecipeRemainder() {
        return this.recipeRemainder;
    }

    public boolean hasRecipeRemainder() {
        return this.recipeRemainder != null;
    }

    public void inventoryTick(ItemStack itemStack, World world, Entity entity, int i, boolean bl) {
    }

    public void onCraft(ItemStack itemStack, World world, PlayerEntity playerEntity) {
    }

    public boolean isNetworkSynced() {
        return false;
    }

    public UseAction getUseAction(ItemStack itemStack) {
        return itemStack.getItem().isFood() ? UseAction.field_8950 : UseAction.field_8952;
    }

    public int getMaxUseTime(ItemStack itemStack) {
        if (itemStack.getItem().isFood()) {
            return this.getFoodComponent().isSnack() ? 16 : 32;
        }
        return 0;
    }

    public void onStoppedUsing(ItemStack itemStack, World world, LivingEntity livingEntity, int i) {
    }

    public void appendTooltip(ItemStack itemStack, @Nullable World world, List<Text> list, TooltipContext tooltipContext) {
    }

    public Optional<TooltipData> getTooltipData(ItemStack itemStack) {
        return Optional.empty();
    }

    public Text getName(ItemStack itemStack) {
        return Text.translatable(this.getTranslationKey(itemStack));
    }

    public boolean hasGlint(ItemStack itemStack) {
        return itemStack.hasEnchantments();
    }

    public Rarity getRarity(ItemStack itemStack) {
        if (!itemStack.hasEnchantments()) {
            return this.rarity;
        }
        switch (this.rarity) {
            case field_8906: 
            case field_8907: {
                return Rarity.field_8903;
            }
            case field_8903: {
                return Rarity.field_8904;
            }
        }
        return this.rarity;
    }

    public boolean isEnchantable(ItemStack itemStack) {
        return this.getMaxCount() == 1 && this.isDamageable();
    }

    protected static BlockHitResult raycast(World world, PlayerEntity playerEntity, RaycastContext.FluidHandling fluidHandling) {
        float f = playerEntity.getPitch();
        float g = playerEntity.getYaw();
        Vec3d vec3d = playerEntity.getEyePos();
        float h = MathHelper.cos(-g * ((float)Math.PI / 180) - (float)Math.PI);
        float i = MathHelper.sin(-g * ((float)Math.PI / 180) - (float)Math.PI);
        float j = -MathHelper.cos(-f * ((float)Math.PI / 180));
        float k = MathHelper.sin(-f * ((float)Math.PI / 180));
        float l = i * j;
        float m = k;
        float n = h * j;
        double d = 5.0;
        Vec3d vec3d2 = vec3d.add((double)l * 5.0, (double)m * 5.0, (double)n * 5.0);
        return world.raycast(new RaycastContext(vec3d, vec3d2, RaycastContext.ShapeType.field_17559, fluidHandling, playerEntity));
    }

    public int getEnchantability() {
        return 0;
    }

    public boolean canRepair(ItemStack itemStack, ItemStack itemStack2) {
        return false;
    }

    public Multimap<EntityAttribute, EntityAttributeModifier> getAttributeModifiers(EquipmentSlot equipmentSlot) {
        return ImmutableMultimap.of();
    }

    public boolean isUsedOnRelease(ItemStack itemStack) {
        return false;
    }

    public ItemStack getDefaultStack() {
        return new ItemStack(this);
    }

    public boolean isFood() {
        return this.foodComponent != null;
    }

    @Nullable
    public FoodComponent getFoodComponent() {
        return this.foodComponent;
    }

    public SoundEvent getDrinkSound() {
        return SoundEvents.field_20613;
    }

    public SoundEvent getEatSound() {
        return SoundEvents.field_20614;
    }

    public boolean isFireproof() {
        return this.fireproof;
    }

    public boolean damage(DamageSource damageSource) {
        return !this.fireproof || !damageSource.isIn(DamageTypeTags.field_42246);
    }

    public boolean canBeNested() {
        return true;
    }

    @Override
    public FeatureSet getRequiredFeatures() {
        return this.requiredFeatures;
    }

    public static class Settings {
        int maxCount = 64;
        int maxDamage;
        @Nullable
        Item recipeRemainder;
        Rarity rarity = Rarity.field_8906;
        @Nullable
        FoodComponent foodComponent;
        boolean fireproof;
        FeatureSet requiredFeatures = FeatureFlags.VANILLA_FEATURES;

        public Settings food(FoodComponent foodComponent) {
            this.foodComponent = foodComponent;
            return this;
        }

        public Settings maxCount(int i) {
            if (this.maxDamage > 0) {
                throw new RuntimeException("Unable to have damage AND stack.");
            }
            this.maxCount = i;
            return this;
        }

        public Settings maxDamageIfAbsent(int i) {
            return this.maxDamage == 0 ? this.maxDamage(i) : this;
        }

        public Settings maxDamage(int i) {
            this.maxDamage = i;
            this.maxCount = 1;
            return this;
        }

        public Settings recipeRemainder(Item item) {
            this.recipeRemainder = item;
            return this;
        }

        public Settings rarity(Rarity rarity) {
            this.rarity = rarity;
            return this;
        }

        public Settings fireproof() {
            this.fireproof = true;
            return this;
        }

        public Settings requires(FeatureFlag ... featureFlags) {
            this.requiredFeatures = FeatureFlags.FEATURE_MANAGER.featureSetOf(featureFlags);
            return this;
        }
    }
}


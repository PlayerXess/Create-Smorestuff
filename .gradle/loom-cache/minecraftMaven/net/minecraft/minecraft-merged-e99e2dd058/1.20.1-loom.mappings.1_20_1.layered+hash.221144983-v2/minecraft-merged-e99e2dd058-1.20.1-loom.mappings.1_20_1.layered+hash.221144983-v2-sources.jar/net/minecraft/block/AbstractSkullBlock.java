/*
 * Decompiled with CFR 0.2.1 (FabricMC 53fa44c9).
 */
package net.minecraft.block;

import net.minecraft.block.AbstractBlock;
import net.minecraft.block.BlockState;
import net.minecraft.block.BlockWithEntity;
import net.minecraft.block.Blocks;
import net.minecraft.block.SkullBlock;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.block.entity.BlockEntityTicker;
import net.minecraft.block.entity.BlockEntityType;
import net.minecraft.block.entity.SkullBlockEntity;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.ai.pathing.NavigationType;
import net.minecraft.item.Equipment;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.BlockView;
import net.minecraft.world.World;
import org.jetbrains.annotations.Nullable;

public abstract class AbstractSkullBlock
extends BlockWithEntity
implements Equipment {
    private final SkullBlock.SkullType type;

    public AbstractSkullBlock(SkullBlock.SkullType skullType, AbstractBlock.Settings settings) {
        super(settings);
        this.type = skullType;
    }

    @Override
    public BlockEntity createBlockEntity(BlockPos blockPos, BlockState blockState) {
        return new SkullBlockEntity(blockPos, blockState);
    }

    @Override
    @Nullable
    public <T extends BlockEntity> BlockEntityTicker<T> getTicker(World world, BlockState blockState, BlockEntityType<T> blockEntityType) {
        if (world.isClient) {
            boolean bl;
            boolean bl2 = bl = blockState.isOf(Blocks.field_10337) || blockState.isOf(Blocks.field_10472) || blockState.isOf(Blocks.field_41305) || blockState.isOf(Blocks.field_41306);
            if (bl) {
                return AbstractSkullBlock.checkType(blockEntityType, BlockEntityType.field_11913, SkullBlockEntity::tick);
            }
        }
        return null;
    }

    public SkullBlock.SkullType getSkullType() {
        return this.type;
    }

    @Override
    public boolean canPathfindThrough(BlockState blockState, BlockView blockView, BlockPos blockPos, NavigationType navigationType) {
        return false;
    }

    @Override
    public EquipmentSlot getSlotType() {
        return EquipmentSlot.field_6169;
    }
}


/*
 * Decompiled with CFR 0.2.1 (FabricMC 53fa44c9).
 */
package net.minecraft.screen.slot;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Predicate;
import java.util.stream.Collectors;
import net.minecraft.item.ItemStack;

public class ForgingSlotsManager {
    private final List<ForgingSlot> inputSlots;
    private final ForgingSlot resultSlot;

    ForgingSlotsManager(List<ForgingSlot> list, ForgingSlot forgingSlot) {
        if (list.isEmpty() || forgingSlot.equals(ForgingSlot.DEFAULT)) {
            throw new IllegalArgumentException("Need to define both inputSlots and resultSlot");
        }
        this.inputSlots = list;
        this.resultSlot = forgingSlot;
    }

    public static Builder create() {
        return new Builder();
    }

    public boolean hasSlotIndex(int i) {
        return this.inputSlots.size() >= i;
    }

    public ForgingSlot getInputSlot(int i) {
        return this.inputSlots.get(i);
    }

    public ForgingSlot getResultSlot() {
        return this.resultSlot;
    }

    public List<ForgingSlot> getInputSlots() {
        return this.inputSlots;
    }

    public int getInputSlotCount() {
        return this.inputSlots.size();
    }

    public int getResultSlotIndex() {
        return this.getInputSlotCount();
    }

    public List<Integer> getInputSlotIndices() {
        return this.inputSlots.stream().map(ForgingSlot::slotId).collect(Collectors.toList());
    }

    public record ForgingSlot(int slotId, int comp_1205, int comp_1206, Predicate<ItemStack> comp_1207) {
        static final ForgingSlot DEFAULT = new ForgingSlot(0, 0, 0, itemStack -> true);
    }

    public static class Builder {
        private final List<ForgingSlot> inputSlots = new ArrayList<ForgingSlot>();
        private ForgingSlot resultSlot = ForgingSlot.DEFAULT;

        public Builder input(int i, int j, int k, Predicate<ItemStack> predicate) {
            this.inputSlots.add(new ForgingSlot(i, j, k, predicate));
            return this;
        }

        public Builder output(int i, int j, int k) {
            this.resultSlot = new ForgingSlot(i, j, k, itemStack -> false);
            return this;
        }

        public ForgingSlotsManager build() {
            return new ForgingSlotsManager(this.inputSlots, this.resultSlot);
        }
    }
}


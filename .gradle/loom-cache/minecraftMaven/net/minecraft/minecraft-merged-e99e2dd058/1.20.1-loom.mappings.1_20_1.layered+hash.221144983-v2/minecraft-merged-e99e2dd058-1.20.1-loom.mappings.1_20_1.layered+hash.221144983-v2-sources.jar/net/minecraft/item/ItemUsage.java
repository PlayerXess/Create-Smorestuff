/*
 * Decompiled with CFR 0.2.1 (FabricMC 53fa44c9).
 */
package net.minecraft.item;

import java.util.stream.Stream;
import net.minecraft.entity.ItemEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.world.World;

public class ItemUsage {
    public static TypedActionResult<ItemStack> consumeHeldItem(World world, PlayerEntity playerEntity, Hand hand) {
        playerEntity.setCurrentHand(hand);
        return TypedActionResult.consume(playerEntity.getStackInHand(hand));
    }

    public static ItemStack exchangeStack(ItemStack itemStack, PlayerEntity playerEntity, ItemStack itemStack2, boolean bl) {
        boolean bl2 = playerEntity.getAbilities().creativeMode;
        if (bl && bl2) {
            if (!playerEntity.getInventory().contains(itemStack2)) {
                playerEntity.getInventory().insertStack(itemStack2);
            }
            return itemStack;
        }
        if (!bl2) {
            itemStack.decrement(1);
        }
        if (itemStack.isEmpty()) {
            return itemStack2;
        }
        if (!playerEntity.getInventory().insertStack(itemStack2)) {
            playerEntity.dropItem(itemStack2, false);
        }
        return itemStack;
    }

    public static ItemStack exchangeStack(ItemStack itemStack, PlayerEntity playerEntity, ItemStack itemStack2) {
        return ItemUsage.exchangeStack(itemStack, playerEntity, itemStack2, true);
    }

    public static void spawnItemContents(ItemEntity itemEntity, Stream<ItemStack> stream) {
        World world = itemEntity.getWorld();
        if (world.isClient) {
            return;
        }
        stream.forEach(itemStack -> world.spawnEntity(new ItemEntity(world, itemEntity.getX(), itemEntity.getY(), itemEntity.getZ(), (ItemStack)itemStack)));
    }
}


/*
 * Decompiled with CFR 0.2.1 (FabricMC 53fa44c9).
 */
package net.minecraft.item;

import net.minecraft.entity.EntityType;
import net.minecraft.entity.decoration.AbstractDecorationEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.DecorationItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;

public class ItemFrameItem
extends DecorationItem {
    public ItemFrameItem(EntityType<? extends AbstractDecorationEntity> entityType, Item.Settings settings) {
        super(entityType, settings);
    }

    @Override
    protected boolean canPlaceOn(PlayerEntity playerEntity, Direction direction, ItemStack itemStack, BlockPos blockPos) {
        return !playerEntity.getWorld().isOutOfHeightLimit(blockPos) && playerEntity.canPlaceOn(blockPos, direction, itemStack);
    }
}


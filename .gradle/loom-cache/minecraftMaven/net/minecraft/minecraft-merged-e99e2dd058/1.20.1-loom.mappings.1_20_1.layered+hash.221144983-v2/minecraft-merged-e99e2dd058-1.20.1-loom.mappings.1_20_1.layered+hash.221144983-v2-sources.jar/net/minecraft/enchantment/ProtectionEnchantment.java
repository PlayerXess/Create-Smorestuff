/*
 * Decompiled with CFR 0.2.1 (FabricMC 53fa44c9).
 */
package net.minecraft.enchantment;

import net.minecraft.enchantment.Enchantment;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.enchantment.EnchantmentTarget;
import net.minecraft.enchantment.Enchantments;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.registry.tag.DamageTypeTags;
import net.minecraft.util.math.MathHelper;

public class ProtectionEnchantment
extends Enchantment {
    public final Type protectionType;

    public ProtectionEnchantment(Enchantment.Rarity rarity, Type type, EquipmentSlot ... equipmentSlots) {
        super(rarity, type == Type.field_9140 ? EnchantmentTarget.field_9079 : EnchantmentTarget.field_9068, equipmentSlots);
        this.protectionType = type;
    }

    @Override
    public int getMinPower(int i) {
        return this.protectionType.getBasePower() + (i - 1) * this.protectionType.getPowerPerLevel();
    }

    @Override
    public int getMaxPower(int i) {
        return this.getMinPower(i) + this.protectionType.getPowerPerLevel();
    }

    @Override
    public int getMaxLevel() {
        return 4;
    }

    @Override
    public int getProtectionAmount(int i, DamageSource damageSource) {
        if (damageSource.isIn(DamageTypeTags.field_42242)) {
            return 0;
        }
        if (this.protectionType == Type.field_9138) {
            return i;
        }
        if (this.protectionType == Type.field_9139 && damageSource.isIn(DamageTypeTags.field_42246)) {
            return i * 2;
        }
        if (this.protectionType == Type.field_9140 && damageSource.isIn(DamageTypeTags.field_42250)) {
            return i * 3;
        }
        if (this.protectionType == Type.field_9141 && damageSource.isIn(DamageTypeTags.field_42249)) {
            return i * 2;
        }
        if (this.protectionType == Type.field_9142 && damageSource.isIn(DamageTypeTags.field_42247)) {
            return i * 2;
        }
        return 0;
    }

    @Override
    public boolean canAccept(Enchantment enchantment) {
        if (enchantment instanceof ProtectionEnchantment) {
            ProtectionEnchantment protectionEnchantment = (ProtectionEnchantment)enchantment;
            if (this.protectionType == protectionEnchantment.protectionType) {
                return false;
            }
            return this.protectionType == Type.field_9140 || protectionEnchantment.protectionType == Type.field_9140;
        }
        return super.canAccept(enchantment);
    }

    public static int transformFireDuration(LivingEntity livingEntity, int i) {
        int j = EnchantmentHelper.getEquipmentLevel(Enchantments.field_9095, livingEntity);
        if (j > 0) {
            i -= MathHelper.floor((float)i * ((float)j * 0.15f));
        }
        return i;
    }

    public static double transformExplosionKnockback(LivingEntity livingEntity, double d) {
        int i = EnchantmentHelper.getEquipmentLevel(Enchantments.field_9107, livingEntity);
        if (i > 0) {
            d *= MathHelper.clamp(1.0 - (double)i * 0.15, 0.0, 1.0);
        }
        return d;
    }

    public static enum Type {
        field_9138(1, 11),
        field_9139(10, 8),
        field_9140(5, 6),
        field_9141(5, 8),
        field_9142(3, 6);

        private final int basePower;
        private final int powerPerLevel;

        private Type(int j, int k) {
            this.basePower = j;
            this.powerPerLevel = k;
        }

        public int getBasePower() {
            return this.basePower;
        }

        public int getPowerPerLevel() {
            return this.powerPerLevel;
        }
    }
}


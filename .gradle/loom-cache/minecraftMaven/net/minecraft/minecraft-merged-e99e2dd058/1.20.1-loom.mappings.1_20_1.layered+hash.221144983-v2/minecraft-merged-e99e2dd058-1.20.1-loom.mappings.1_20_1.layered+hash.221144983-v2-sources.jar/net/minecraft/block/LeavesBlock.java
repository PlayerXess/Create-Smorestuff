/*
 * Decompiled with CFR 0.2.1 (FabricMC 53fa44c9).
 */
package net.minecraft.block;

import io.github.fabricators_of_create.porting_lib.extensions.extensions.IShearable;
import java.util.OptionalInt;
import net.minecraft.block.AbstractBlock;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Waterloggable;
import net.minecraft.client.util.ParticleUtil;
import net.minecraft.fluid.FluidState;
import net.minecraft.fluid.Fluids;
import net.minecraft.item.ItemPlacementContext;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.registry.tag.BlockTags;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.state.StateManager;
import net.minecraft.state.property.BooleanProperty;
import net.minecraft.state.property.IntProperty;
import net.minecraft.state.property.Properties;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3i;
import net.minecraft.util.math.random.Random;
import net.minecraft.util.shape.VoxelShape;
import net.minecraft.util.shape.VoxelShapes;
import net.minecraft.world.BlockView;
import net.minecraft.world.World;
import net.minecraft.world.WorldAccess;

public class LeavesBlock
extends Block
implements Waterloggable,
IShearable {
    public static final int MAX_DISTANCE = 7;
    public static final IntProperty DISTANCE = Properties.DISTANCE_1_7;
    public static final BooleanProperty PERSISTENT = Properties.PERSISTENT;
    public static final BooleanProperty WATERLOGGED = Properties.WATERLOGGED;
    private static final int field_31112 = 1;

    public LeavesBlock(AbstractBlock.Settings settings) {
        super(settings);
        this.setDefaultState((BlockState)((BlockState)((BlockState)((BlockState)this.stateManager.getDefaultState()).with(DISTANCE, 7)).with(PERSISTENT, false)).with(WATERLOGGED, false));
    }

    @Override
    public VoxelShape getSidesShape(BlockState blockState, BlockView blockView, BlockPos blockPos) {
        return VoxelShapes.empty();
    }

    @Override
    public boolean hasRandomTicks(BlockState blockState) {
        return blockState.get(DISTANCE) == 7 && blockState.get(PERSISTENT) == false;
    }

    @Override
    public void randomTick(BlockState blockState, ServerWorld serverWorld, BlockPos blockPos, Random random) {
        if (this.shouldDecay(blockState)) {
            LeavesBlock.dropStacks(blockState, serverWorld, blockPos);
            serverWorld.removeBlock(blockPos, false);
        }
    }

    protected boolean shouldDecay(BlockState blockState) {
        return blockState.get(PERSISTENT) == false && blockState.get(DISTANCE) == 7;
    }

    @Override
    public void scheduledTick(BlockState blockState, ServerWorld serverWorld, BlockPos blockPos, Random random) {
        serverWorld.setBlockState(blockPos, LeavesBlock.updateDistanceFromLogs(blockState, serverWorld, blockPos), 3);
    }

    @Override
    public int getOpacity(BlockState blockState, BlockView blockView, BlockPos blockPos) {
        return 1;
    }

    @Override
    public BlockState getStateForNeighborUpdate(BlockState blockState, Direction direction, BlockState blockState2, WorldAccess worldAccess, BlockPos blockPos, BlockPos blockPos2) {
        int i;
        if (blockState.get(WATERLOGGED).booleanValue()) {
            worldAccess.scheduleFluidTick(blockPos, Fluids.WATER, Fluids.WATER.getTickRate(worldAccess));
        }
        if ((i = LeavesBlock.getDistanceFromLog(blockState2) + 1) != 1 || blockState.get(DISTANCE) != i) {
            worldAccess.scheduleBlockTick(blockPos, this, 1);
        }
        return blockState;
    }

    private static BlockState updateDistanceFromLogs(BlockState blockState, WorldAccess worldAccess, BlockPos blockPos) {
        int i = 7;
        BlockPos.Mutable mutable = new BlockPos.Mutable();
        for (Direction direction : Direction.values()) {
            mutable.set((Vec3i)blockPos, direction);
            i = Math.min(i, LeavesBlock.getDistanceFromLog(worldAccess.getBlockState(mutable)) + 1);
            if (i == 1) break;
        }
        return (BlockState)blockState.with(DISTANCE, i);
    }

    private static int getDistanceFromLog(BlockState blockState) {
        return LeavesBlock.getOptionalDistanceFromLog(blockState).orElse(7);
    }

    public static OptionalInt getOptionalDistanceFromLog(BlockState blockState) {
        if (blockState.isIn(BlockTags.field_15475)) {
            return OptionalInt.of(0);
        }
        if (blockState.contains(DISTANCE)) {
            return OptionalInt.of(blockState.get(DISTANCE));
        }
        return OptionalInt.empty();
    }

    @Override
    public FluidState getFluidState(BlockState blockState) {
        if (blockState.get(WATERLOGGED).booleanValue()) {
            return Fluids.WATER.getStill(false);
        }
        return super.getFluidState(blockState);
    }

    @Override
    public void randomDisplayTick(BlockState blockState, World world, BlockPos blockPos, Random random) {
        if (!world.hasRain(blockPos.up())) {
            return;
        }
        if (random.nextInt(15) != 1) {
            return;
        }
        BlockPos blockPos2 = blockPos.down();
        BlockState blockState2 = world.getBlockState(blockPos2);
        if (blockState2.isOpaque() && blockState2.isSideSolidFullSquare(world, blockPos2, Direction.field_11036)) {
            return;
        }
        ParticleUtil.spawnParticle(world, blockPos, random, ParticleTypes.field_11232);
    }

    @Override
    protected void appendProperties(StateManager.Builder<Block, BlockState> builder) {
        builder.add(DISTANCE, PERSISTENT, WATERLOGGED);
    }

    @Override
    public BlockState getPlacementState(ItemPlacementContext itemPlacementContext) {
        FluidState fluidState = itemPlacementContext.getWorld().getFluidState(itemPlacementContext.getBlockPos());
        BlockState blockState = (BlockState)((BlockState)this.getDefaultState().with(PERSISTENT, true)).with(WATERLOGGED, fluidState.getFluid() == Fluids.WATER);
        return LeavesBlock.updateDistanceFromLogs(blockState, itemPlacementContext.getWorld(), itemPlacementContext.getBlockPos());
    }
}


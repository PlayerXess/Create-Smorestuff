/*
 * Decompiled with CFR 0.2.1 (FabricMC 53fa44c9).
 */
package net.minecraft.block;

import net.minecraft.block.AbstractBlock;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.TransparentBlock;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.enchantment.Enchantments;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.random.Random;
import net.minecraft.world.LightType;
import net.minecraft.world.World;
import org.jetbrains.annotations.Nullable;

public class IceBlock
extends TransparentBlock {
    public IceBlock(AbstractBlock.Settings settings) {
        super(settings);
    }

    public static BlockState getMeltedState() {
        return Blocks.field_10382.getDefaultState();
    }

    @Override
    public void afterBreak(World world, PlayerEntity playerEntity, BlockPos blockPos, BlockState blockState, @Nullable BlockEntity blockEntity, ItemStack itemStack) {
        super.afterBreak(world, playerEntity, blockPos, blockState, blockEntity, itemStack);
        if (EnchantmentHelper.getLevel(Enchantments.field_9099, itemStack) == 0) {
            if (world.getDimension().ultrawarm()) {
                world.removeBlock(blockPos, false);
                return;
            }
            BlockState blockState2 = world.getBlockState(blockPos.down());
            if (blockState2.blocksMovement() || blockState2.isLiquid()) {
                world.setBlockState(blockPos, IceBlock.getMeltedState());
            }
        }
    }

    @Override
    public void randomTick(BlockState blockState, ServerWorld serverWorld, BlockPos blockPos, Random random) {
        if (serverWorld.getLightLevel(LightType.field_9282, blockPos) > 11 - blockState.getOpacity(serverWorld, blockPos)) {
            this.melt(blockState, serverWorld, blockPos);
        }
    }

    protected void melt(BlockState blockState, World world, BlockPos blockPos) {
        if (world.getDimension().ultrawarm()) {
            world.removeBlock(blockPos, false);
            return;
        }
        world.setBlockState(blockPos, IceBlock.getMeltedState());
        world.updateNeighbor(blockPos, IceBlock.getMeltedState().getBlock(), blockPos);
    }
}


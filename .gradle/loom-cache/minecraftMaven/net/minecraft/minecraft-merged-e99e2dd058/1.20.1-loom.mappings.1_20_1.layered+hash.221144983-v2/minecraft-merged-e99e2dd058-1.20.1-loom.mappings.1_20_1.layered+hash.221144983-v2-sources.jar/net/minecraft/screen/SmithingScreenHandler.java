/*
 * Decompiled with CFR 0.2.1 (FabricMC 53fa44c9).
 */
package net.minecraft.screen;

import java.util.List;
import java.util.Optional;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.recipe.RecipeType;
import net.minecraft.recipe.SmithingRecipe;
import net.minecraft.screen.ForgingScreenHandler;
import net.minecraft.screen.ScreenHandlerContext;
import net.minecraft.screen.ScreenHandlerType;
import net.minecraft.screen.slot.ForgingSlotsManager;
import net.minecraft.screen.slot.Slot;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import org.jetbrains.annotations.Nullable;

public class SmithingScreenHandler
extends ForgingScreenHandler {
    public static final int TEMPLATE_ID = 0;
    public static final int EQUIPMENT_ID = 1;
    public static final int MATERIAL_ID = 2;
    public static final int OUTPUT_ID = 3;
    public static final int TEMPLATE_X = 8;
    public static final int EQUIPMENT_X = 26;
    public static final int MATERIAL_X = 44;
    private static final int OUTPUT_X = 98;
    public static final int SLOT_Y = 48;
    private final World world;
    @Nullable
    private SmithingRecipe currentRecipe;
    private final List<SmithingRecipe> recipes;

    public SmithingScreenHandler(int i, PlayerInventory playerInventory) {
        this(i, playerInventory, ScreenHandlerContext.EMPTY);
    }

    public SmithingScreenHandler(int i, PlayerInventory playerInventory, ScreenHandlerContext screenHandlerContext) {
        super(ScreenHandlerType.field_22484, i, playerInventory, screenHandlerContext);
        this.world = playerInventory.player.getWorld();
        this.recipes = this.world.getRecipeManager().listAllOfType(RecipeType.field_25388);
    }

    @Override
    protected ForgingSlotsManager getForgingSlotsManager() {
        return ForgingSlotsManager.create().input(0, 8, 48, itemStack -> this.recipes.stream().anyMatch(smithingRecipe -> smithingRecipe.testTemplate((ItemStack)itemStack))).input(1, 26, 48, itemStack -> this.recipes.stream().anyMatch(smithingRecipe -> smithingRecipe.testBase((ItemStack)itemStack))).input(2, 44, 48, itemStack -> this.recipes.stream().anyMatch(smithingRecipe -> smithingRecipe.testAddition((ItemStack)itemStack))).output(3, 98, 48).build();
    }

    @Override
    protected boolean canUse(BlockState blockState) {
        return blockState.isOf(Blocks.field_16329);
    }

    @Override
    protected boolean canTakeOutput(PlayerEntity playerEntity, boolean bl) {
        return this.currentRecipe != null && this.currentRecipe.matches(this.input, this.world);
    }

    @Override
    protected void onTakeOutput(PlayerEntity playerEntity, ItemStack itemStack) {
        itemStack.onCraft(playerEntity.getWorld(), playerEntity, itemStack.getCount());
        this.output.unlockLastRecipe(playerEntity, this.getInputStacks());
        this.decrementStack(0);
        this.decrementStack(1);
        this.decrementStack(2);
        this.context.run((world, blockPos) -> world.syncWorldEvent(1044, (BlockPos)blockPos, 0));
    }

    private List<ItemStack> getInputStacks() {
        return List.of(this.input.getStack(0), this.input.getStack(1), this.input.getStack(2));
    }

    private void decrementStack(int i) {
        ItemStack itemStack = this.input.getStack(i);
        if (!itemStack.isEmpty()) {
            itemStack.decrement(1);
            this.input.setStack(i, itemStack);
        }
    }

    @Override
    public void updateResult() {
        List<SmithingRecipe> list = this.world.getRecipeManager().getAllMatches(RecipeType.field_25388, this.input, this.world);
        if (list.isEmpty()) {
            this.output.setStack(0, ItemStack.EMPTY);
        } else {
            SmithingRecipe smithingRecipe = list.get(0);
            ItemStack itemStack = smithingRecipe.craft(this.input, this.world.getRegistryManager());
            if (itemStack.isItemEnabled(this.world.getEnabledFeatures())) {
                this.currentRecipe = smithingRecipe;
                this.output.setLastRecipe(smithingRecipe);
                this.output.setStack(0, itemStack);
            }
        }
    }

    @Override
    public int getSlotFor(ItemStack itemStack) {
        return this.recipes.stream().map(smithingRecipe -> SmithingScreenHandler.getQuickMoveSlot(smithingRecipe, itemStack)).filter(Optional::isPresent).findFirst().orElse(Optional.of(0)).get();
    }

    private static Optional<Integer> getQuickMoveSlot(SmithingRecipe smithingRecipe, ItemStack itemStack) {
        if (smithingRecipe.testTemplate(itemStack)) {
            return Optional.of(0);
        }
        if (smithingRecipe.testBase(itemStack)) {
            return Optional.of(1);
        }
        if (smithingRecipe.testAddition(itemStack)) {
            return Optional.of(2);
        }
        return Optional.empty();
    }

    @Override
    public boolean canInsertIntoSlot(ItemStack itemStack, Slot slot) {
        return slot.inventory != this.output && super.canInsertIntoSlot(itemStack, slot);
    }

    @Override
    public boolean isValidIngredient(ItemStack itemStack) {
        return this.recipes.stream().map(smithingRecipe -> SmithingScreenHandler.getQuickMoveSlot(smithingRecipe, itemStack)).anyMatch(Optional::isPresent);
    }
}


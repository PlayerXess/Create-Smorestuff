/*
 * Decompiled with CFR 0.2.1 (FabricMC 53fa44c9).
 */
package net.minecraft.item;

import com.google.common.collect.ImmutableMultimap;
import com.google.common.collect.Multimap;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.attribute.EntityAttribute;
import net.minecraft.entity.attribute.EntityAttributeModifier;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ToolItem;
import net.minecraft.item.ToolMaterial;
import net.minecraft.item.Vanishable;
import net.minecraft.registry.tag.BlockTags;
import net.minecraft.registry.tag.TagKey;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

public class MiningToolItem
extends ToolItem
implements Vanishable {
    private final TagKey<Block> effectiveBlocks;
    protected final float miningSpeed;
    private final float attackDamage;
    private final Multimap<EntityAttribute, EntityAttributeModifier> attributeModifiers;

    public MiningToolItem(float f, float g, ToolMaterial toolMaterial, TagKey<Block> tagKey, Item.Settings settings) {
        super(toolMaterial, settings);
        this.effectiveBlocks = tagKey;
        this.miningSpeed = toolMaterial.getMiningSpeedMultiplier();
        this.attackDamage = f + toolMaterial.getAttackDamage();
        ImmutableMultimap.Builder<EntityAttribute, EntityAttributeModifier> builder = ImmutableMultimap.builder();
        builder.put(EntityAttributes.field_23721, new EntityAttributeModifier(ATTACK_DAMAGE_MODIFIER_ID, "Tool modifier", (double)this.attackDamage, EntityAttributeModifier.Operation.ADDITION));
        builder.put(EntityAttributes.field_23723, new EntityAttributeModifier(ATTACK_SPEED_MODIFIER_ID, "Tool modifier", (double)g, EntityAttributeModifier.Operation.ADDITION));
        this.attributeModifiers = builder.build();
    }

    @Override
    public float getMiningSpeedMultiplier(ItemStack itemStack, BlockState blockState) {
        return blockState.isIn(this.effectiveBlocks) ? this.miningSpeed : 1.0f;
    }

    @Override
    public boolean postHit(ItemStack itemStack, LivingEntity livingEntity2, LivingEntity livingEntity22) {
        itemStack.damage(2, livingEntity22, livingEntity -> livingEntity.sendEquipmentBreakStatus(EquipmentSlot.field_6173));
        return true;
    }

    @Override
    public boolean postMine(ItemStack itemStack, World world, BlockState blockState, BlockPos blockPos, LivingEntity livingEntity2) {
        if (!world.isClient && blockState.getHardness(world, blockPos) != 0.0f) {
            itemStack.damage(1, livingEntity2, livingEntity -> livingEntity.sendEquipmentBreakStatus(EquipmentSlot.field_6173));
        }
        return true;
    }

    @Override
    public Multimap<EntityAttribute, EntityAttributeModifier> getAttributeModifiers(EquipmentSlot equipmentSlot) {
        if (equipmentSlot == EquipmentSlot.field_6173) {
            return this.attributeModifiers;
        }
        return super.getAttributeModifiers(equipmentSlot);
    }

    public float getAttackDamage() {
        return this.attackDamage;
    }

    @Override
    public boolean isSuitableFor(BlockState blockState) {
        int i = this.getMaterial().getMiningLevel();
        if (i < 3 && blockState.isIn(BlockTags.field_33717)) {
            return false;
        }
        if (i < 2 && blockState.isIn(BlockTags.field_33718)) {
            return false;
        }
        if (i < 1 && blockState.isIn(BlockTags.field_33719)) {
            return false;
        }
        return blockState.isIn(this.effectiveBlocks);
    }
}


/*
 * Decompiled with CFR 0.2.1 (FabricMC 53fa44c9).
 */
package net.minecraft.world.biome.source;

import com.google.common.collect.ImmutableList;
import com.mojang.datafixers.kinds.Applicative;
import com.mojang.datafixers.util.Pair;
import com.mojang.serialization.Codec;
import com.mojang.serialization.DataResult;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import net.minecraft.registry.RegistryEntryLookup;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.registry.RegistryOps;
import net.minecraft.registry.entry.RegistryElementCodec;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.util.Identifier;
import net.minecraft.world.biome.Biome;
import net.minecraft.world.biome.BiomeKeys;
import net.minecraft.world.biome.source.util.MultiNoiseUtil;
import net.minecraft.world.biome.source.util.VanillaBiomeParameters;

public class MultiNoiseBiomeSourceParameterList {
    public static final Codec<MultiNoiseBiomeSourceParameterList> CODEC = RecordCodecBuilder.create(instance -> instance.group(((MapCodec)Preset.CODEC.fieldOf("preset")).forGetter(multiNoiseBiomeSourceParameterList -> multiNoiseBiomeSourceParameterList.preset), RegistryOps.getEntryLookupCodec(RegistryKeys.BIOME)).apply((Applicative<MultiNoiseBiomeSourceParameterList, ?>)instance, MultiNoiseBiomeSourceParameterList::new));
    public static final Codec<RegistryEntry<MultiNoiseBiomeSourceParameterList>> REGISTRY_CODEC = RegistryElementCodec.of(RegistryKeys.MULTI_NOISE_BIOME_SOURCE_PARAMETER_LIST, CODEC);
    private final Preset preset;
    private final MultiNoiseUtil.Entries<RegistryEntry<Biome>> entries;

    public MultiNoiseBiomeSourceParameterList(Preset preset, RegistryEntryLookup<Biome> registryEntryLookup) {
        this.preset = preset;
        this.entries = preset.biomeSourceFunction.apply(registryEntryLookup::getOrThrow);
    }

    public MultiNoiseUtil.Entries<RegistryEntry<Biome>> getEntries() {
        return this.entries;
    }

    public static Map<Preset, MultiNoiseUtil.Entries<RegistryKey<Biome>>> getPresetToEntriesMap() {
        return Preset.BY_IDENTIFIER.values().stream().collect(Collectors.toMap(preset -> preset, preset -> preset.biomeSourceFunction().apply(registryKey -> registryKey)));
    }

    public record Preset(Identifier id, BiomeSourceFunction biomeSourceFunction) {
        public static final Preset NETHER = new Preset(new Identifier("nether"), new BiomeSourceFunction(){

            @Override
            public <T> MultiNoiseUtil.Entries<T> apply(Function<RegistryKey<Biome>, T> function) {
                return new MultiNoiseUtil.Entries<T>(List.of(Pair.of(MultiNoiseUtil.createNoiseHypercube(0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f), function.apply(BiomeKeys.field_9461)), Pair.of(MultiNoiseUtil.createNoiseHypercube(0.0f, -0.5f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f), function.apply(BiomeKeys.field_22076)), Pair.of(MultiNoiseUtil.createNoiseHypercube(0.4f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f), function.apply(BiomeKeys.field_22077)), Pair.of(MultiNoiseUtil.createNoiseHypercube(0.0f, 0.5f, 0.0f, 0.0f, 0.0f, 0.0f, 0.375f), function.apply(BiomeKeys.field_22075)), Pair.of(MultiNoiseUtil.createNoiseHypercube(-0.5f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 0.175f), function.apply(BiomeKeys.field_23859))));
            }
        });
        public static final Preset OVERWORLD = new Preset(new Identifier("overworld"), new BiomeSourceFunction(){

            @Override
            public <T> MultiNoiseUtil.Entries<T> apply(Function<RegistryKey<Biome>, T> function) {
                return Preset.getOverworldEntries(function);
            }
        });
        static final Map<Identifier, Preset> BY_IDENTIFIER = Stream.of(NETHER, OVERWORLD).collect(Collectors.toMap(Preset::id, preset -> preset));
        public static final Codec<Preset> CODEC = Identifier.CODEC.flatXmap(identifier -> Optional.ofNullable(BY_IDENTIFIER.get(identifier)).map(DataResult::success).orElseGet(() -> DataResult.error(() -> "Unknown preset: " + identifier)), preset -> DataResult.success(preset.id));

        static <T> MultiNoiseUtil.Entries<T> getOverworldEntries(Function<RegistryKey<Biome>, T> function) {
            ImmutableList.Builder builder = ImmutableList.builder();
            new VanillaBiomeParameters().writeOverworldBiomeParameters(pair -> builder.add(pair.mapSecond(function)));
            return new MultiNoiseUtil.Entries(builder.build());
        }

        public Stream<RegistryKey<Biome>> biomeStream() {
            return this.biomeSourceFunction.apply(registryKey -> registryKey).getEntries().stream().map(Pair::getSecond).distinct();
        }

        @FunctionalInterface
        static interface BiomeSourceFunction {
            public <T> MultiNoiseUtil.Entries<T> apply(Function<RegistryKey<Biome>, T> var1);
        }
    }
}


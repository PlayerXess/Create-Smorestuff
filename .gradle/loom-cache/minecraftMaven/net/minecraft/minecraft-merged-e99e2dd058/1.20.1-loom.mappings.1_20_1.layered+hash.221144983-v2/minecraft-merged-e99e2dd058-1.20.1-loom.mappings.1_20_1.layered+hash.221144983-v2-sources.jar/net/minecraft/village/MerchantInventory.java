/*
 * Decompiled with CFR 0.2.1 (FabricMC 53fa44c9).
 */
package net.minecraft.village;

import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.inventory.Inventories;
import net.minecraft.inventory.Inventory;
import net.minecraft.item.ItemStack;
import net.minecraft.util.collection.DefaultedList;
import net.minecraft.village.Merchant;
import net.minecraft.village.TradeOffer;
import net.minecraft.village.TradeOfferList;
import org.jetbrains.annotations.Nullable;

public class MerchantInventory
implements Inventory {
    private final Merchant merchant;
    private final DefaultedList<ItemStack> inventory = DefaultedList.ofSize(3, ItemStack.EMPTY);
    @Nullable
    private TradeOffer tradeOffer;
    private int offerIndex;
    private int merchantRewardedExperience;

    public MerchantInventory(Merchant merchant) {
        this.merchant = merchant;
    }

    @Override
    public int size() {
        return this.inventory.size();
    }

    @Override
    public boolean isEmpty() {
        for (ItemStack itemStack : this.inventory) {
            if (itemStack.isEmpty()) continue;
            return false;
        }
        return true;
    }

    @Override
    public ItemStack getStack(int i) {
        return this.inventory.get(i);
    }

    @Override
    public ItemStack removeStack(int i, int j) {
        ItemStack itemStack = this.inventory.get(i);
        if (i == 2 && !itemStack.isEmpty()) {
            return Inventories.splitStack(this.inventory, i, itemStack.getCount());
        }
        ItemStack itemStack2 = Inventories.splitStack(this.inventory, i, j);
        if (!itemStack2.isEmpty() && this.needsOfferUpdate(i)) {
            this.updateOffers();
        }
        return itemStack2;
    }

    private boolean needsOfferUpdate(int i) {
        return i == 0 || i == 1;
    }

    @Override
    public ItemStack removeStack(int i) {
        return Inventories.removeStack(this.inventory, i);
    }

    @Override
    public void setStack(int i, ItemStack itemStack) {
        this.inventory.set(i, itemStack);
        if (!itemStack.isEmpty() && itemStack.getCount() > this.getMaxCountPerStack()) {
            itemStack.setCount(this.getMaxCountPerStack());
        }
        if (this.needsOfferUpdate(i)) {
            this.updateOffers();
        }
    }

    @Override
    public boolean canPlayerUse(PlayerEntity playerEntity) {
        return this.merchant.getCustomer() == playerEntity;
    }

    @Override
    public void markDirty() {
        this.updateOffers();
    }

    public void updateOffers() {
        ItemStack itemStack2;
        ItemStack itemStack;
        this.tradeOffer = null;
        if (this.inventory.get(0).isEmpty()) {
            itemStack = this.inventory.get(1);
            itemStack2 = ItemStack.EMPTY;
        } else {
            itemStack = this.inventory.get(0);
            itemStack2 = this.inventory.get(1);
        }
        if (itemStack.isEmpty()) {
            this.setStack(2, ItemStack.EMPTY);
            this.merchantRewardedExperience = 0;
            return;
        }
        TradeOfferList tradeOfferList = this.merchant.getOffers();
        if (!tradeOfferList.isEmpty()) {
            TradeOffer tradeOffer = tradeOfferList.getValidOffer(itemStack, itemStack2, this.offerIndex);
            if (tradeOffer == null || tradeOffer.isDisabled()) {
                this.tradeOffer = tradeOffer;
                tradeOffer = tradeOfferList.getValidOffer(itemStack2, itemStack, this.offerIndex);
            }
            if (tradeOffer != null && !tradeOffer.isDisabled()) {
                this.tradeOffer = tradeOffer;
                this.setStack(2, tradeOffer.copySellItem());
                this.merchantRewardedExperience = tradeOffer.getMerchantExperience();
            } else {
                this.setStack(2, ItemStack.EMPTY);
                this.merchantRewardedExperience = 0;
            }
        }
        this.merchant.onSellingItem(this.getStack(2));
    }

    @Nullable
    public TradeOffer getTradeOffer() {
        return this.tradeOffer;
    }

    public void setOfferIndex(int i) {
        this.offerIndex = i;
        this.updateOffers();
    }

    @Override
    public void clear() {
        this.inventory.clear();
    }

    public int getMerchantRewardedExperience() {
        return this.merchantRewardedExperience;
    }
}


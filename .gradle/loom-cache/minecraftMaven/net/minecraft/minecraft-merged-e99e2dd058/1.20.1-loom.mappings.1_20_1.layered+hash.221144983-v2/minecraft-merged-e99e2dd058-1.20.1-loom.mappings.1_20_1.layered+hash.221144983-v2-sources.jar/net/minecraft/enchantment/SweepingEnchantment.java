/*
 * Decompiled with CFR 0.2.1 (FabricMC 53fa44c9).
 */
package net.minecraft.enchantment;

import net.minecraft.enchantment.Enchantment;
import net.minecraft.enchantment.EnchantmentTarget;
import net.minecraft.entity.EquipmentSlot;

public class SweepingEnchantment
extends Enchantment {
    public SweepingEnchantment(Enchantment.Rarity rarity, EquipmentSlot ... equipmentSlots) {
        super(rarity, EnchantmentTarget.field_9074, equipmentSlots);
    }

    @Override
    public int getMinPower(int i) {
        return 5 + (i - 1) * 9;
    }

    @Override
    public int getMaxPower(int i) {
        return this.getMinPower(i) + 15;
    }

    @Override
    public int getMaxLevel() {
        return 3;
    }

    public static float getMultiplier(int i) {
        return 1.0f - 1.0f / (float)(i + 1);
    }
}


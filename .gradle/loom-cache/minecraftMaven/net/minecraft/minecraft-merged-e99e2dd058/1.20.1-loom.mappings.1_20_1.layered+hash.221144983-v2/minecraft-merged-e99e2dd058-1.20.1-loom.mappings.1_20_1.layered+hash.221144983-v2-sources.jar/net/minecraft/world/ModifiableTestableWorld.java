/*
 * Decompiled with CFR 0.2.1 (FabricMC 53fa44c9).
 */
package net.minecraft.world;

import net.minecraft.world.ModifiableWorld;
import net.minecraft.world.TestableWorld;

public interface ModifiableTestableWorld
extends TestableWorld,
ModifiableWorld {
}


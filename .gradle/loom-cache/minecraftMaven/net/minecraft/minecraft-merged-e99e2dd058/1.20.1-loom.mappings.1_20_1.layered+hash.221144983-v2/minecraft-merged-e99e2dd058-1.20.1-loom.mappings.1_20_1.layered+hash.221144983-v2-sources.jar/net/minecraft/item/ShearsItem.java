/*
 * Decompiled with CFR 0.2.1 (FabricMC 53fa44c9).
 */
package net.minecraft.item;

import net.minecraft.advancement.criterion.Criteria;
import net.minecraft.block.AbstractPlantStemBlock;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemUsageContext;
import net.minecraft.registry.tag.BlockTags;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.ActionResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraft.world.event.GameEvent;

public class ShearsItem
extends Item {
    public ShearsItem(Item.Settings settings) {
        super(settings);
    }

    @Override
    public boolean postMine(ItemStack itemStack, World world, BlockState blockState, BlockPos blockPos, LivingEntity livingEntity2) {
        if (!world.isClient && !blockState.isIn(BlockTags.field_21952)) {
            itemStack.damage(1, livingEntity2, livingEntity -> livingEntity.sendEquipmentBreakStatus(EquipmentSlot.field_6173));
        }
        if (blockState.isIn(BlockTags.field_15503) || blockState.isOf(Blocks.field_10343) || blockState.isOf(Blocks.field_10479) || blockState.isOf(Blocks.field_10112) || blockState.isOf(Blocks.field_10428) || blockState.isOf(Blocks.field_28686) || blockState.isOf(Blocks.field_10597) || blockState.isOf(Blocks.field_10589) || blockState.isIn(BlockTags.field_15481)) {
            return true;
        }
        return super.postMine(itemStack, world, blockState, blockPos, livingEntity2);
    }

    @Override
    public boolean isSuitableFor(BlockState blockState) {
        return blockState.isOf(Blocks.field_10343) || blockState.isOf(Blocks.field_10091) || blockState.isOf(Blocks.field_10589);
    }

    @Override
    public float getMiningSpeedMultiplier(ItemStack itemStack, BlockState blockState) {
        if (blockState.isOf(Blocks.field_10343) || blockState.isIn(BlockTags.field_15503)) {
            return 15.0f;
        }
        if (blockState.isIn(BlockTags.field_15481)) {
            return 5.0f;
        }
        if (blockState.isOf(Blocks.field_10597) || blockState.isOf(Blocks.field_28411)) {
            return 2.0f;
        }
        return super.getMiningSpeedMultiplier(itemStack, blockState);
    }

    @Override
    public ActionResult useOnBlock(ItemUsageContext itemUsageContext) {
        AbstractPlantStemBlock abstractPlantStemBlock;
        BlockPos blockPos;
        World world = itemUsageContext.getWorld();
        BlockState blockState = world.getBlockState(blockPos = itemUsageContext.getBlockPos());
        Block block = blockState.getBlock();
        if (block instanceof AbstractPlantStemBlock && !(abstractPlantStemBlock = (AbstractPlantStemBlock)block).hasMaxAge(blockState)) {
            PlayerEntity playerEntity2 = itemUsageContext.getPlayer();
            ItemStack itemStack = itemUsageContext.getStack();
            if (playerEntity2 instanceof ServerPlayerEntity) {
                Criteria.ITEM_USED_ON_BLOCK.trigger((ServerPlayerEntity)playerEntity2, blockPos, itemStack);
            }
            world.playSound(playerEntity2, blockPos, SoundEvents.field_34896, SoundCategory.field_15245, 1.0f, 1.0f);
            BlockState blockState2 = abstractPlantStemBlock.withMaxAge(blockState);
            world.setBlockState(blockPos, blockState2);
            world.emitGameEvent(GameEvent.field_28733, blockPos, GameEvent.Emitter.of(itemUsageContext.getPlayer(), blockState2));
            if (playerEntity2 != null) {
                itemStack.damage(1, playerEntity2, playerEntity -> playerEntity.sendToolBreakStatus(itemUsageContext.getHand()));
            }
            return ActionResult.success(world.isClient);
        }
        return super.useOnBlock(itemUsageContext);
    }
}


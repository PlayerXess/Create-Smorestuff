/*
 * Decompiled with CFR 0.2.1 (FabricMC 53fa44c9).
 */
package net.minecraft.world;

import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.ChunkSectionPos;

public interface HeightLimitView {
    public int getHeight();

    public int getBottomY();

    default public int getTopY() {
        return this.getBottomY() + this.getHeight();
    }

    default public int countVerticalSections() {
        return this.getTopSectionCoord() - this.getBottomSectionCoord();
    }

    default public int getBottomSectionCoord() {
        return ChunkSectionPos.getSectionCoord(this.getBottomY());
    }

    default public int getTopSectionCoord() {
        return ChunkSectionPos.getSectionCoord(this.getTopY() - 1) + 1;
    }

    default public boolean isOutOfHeightLimit(BlockPos blockPos) {
        return this.isOutOfHeightLimit(blockPos.getY());
    }

    default public boolean isOutOfHeightLimit(int i) {
        return i < this.getBottomY() || i >= this.getTopY();
    }

    default public int getSectionIndex(int i) {
        return this.sectionCoordToIndex(ChunkSectionPos.getSectionCoord(i));
    }

    default public int sectionCoordToIndex(int i) {
        return i - this.getBottomSectionCoord();
    }

    default public int sectionIndexToCoord(int i) {
        return i + this.getBottomSectionCoord();
    }

    public static HeightLimitView create(final int i, final int j) {
        return new HeightLimitView(){

            @Override
            public int getHeight() {
                return j;
            }

            @Override
            public int getBottomY() {
                return i;
            }
        };
    }
}


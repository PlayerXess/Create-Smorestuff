/*
 * Decompiled with CFR 0.2.1 (FabricMC 53fa44c9).
 */
package net.minecraft.screen;

import java.util.List;
import net.minecraft.block.BlockState;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.inventory.CraftingResultInventory;
import net.minecraft.inventory.Inventory;
import net.minecraft.inventory.SimpleInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.screen.ScreenHandler;
import net.minecraft.screen.ScreenHandlerContext;
import net.minecraft.screen.ScreenHandlerType;
import net.minecraft.screen.slot.ForgingSlotsManager;
import net.minecraft.screen.slot.Slot;
import net.minecraft.util.math.BlockPos;
import org.jetbrains.annotations.Nullable;

public abstract class ForgingScreenHandler
extends ScreenHandler {
    private static final int field_41901 = 9;
    private static final int field_41902 = 3;
    protected final ScreenHandlerContext context;
    protected final PlayerEntity player;
    protected final Inventory input;
    private final List<Integer> inputSlotIndices;
    protected final CraftingResultInventory output = new CraftingResultInventory();
    private final int resultSlotIndex;

    protected abstract boolean canTakeOutput(PlayerEntity var1, boolean var2);

    protected abstract void onTakeOutput(PlayerEntity var1, ItemStack var2);

    protected abstract boolean canUse(BlockState var1);

    public ForgingScreenHandler(@Nullable ScreenHandlerType<?> screenHandlerType, int i, PlayerInventory playerInventory, ScreenHandlerContext screenHandlerContext) {
        super(screenHandlerType, i);
        this.context = screenHandlerContext;
        this.player = playerInventory.player;
        ForgingSlotsManager forgingSlotsManager = this.getForgingSlotsManager();
        this.input = this.createInputInventory(forgingSlotsManager.getInputSlotCount());
        this.inputSlotIndices = forgingSlotsManager.getInputSlotIndices();
        this.resultSlotIndex = forgingSlotsManager.getResultSlotIndex();
        this.addInputSlots(forgingSlotsManager);
        this.addResultSlot(forgingSlotsManager);
        this.addPlayerInventorySlots(playerInventory);
    }

    private void addInputSlots(ForgingSlotsManager forgingSlotsManager) {
        for (final ForgingSlotsManager.ForgingSlot forgingSlot : forgingSlotsManager.getInputSlots()) {
            this.addSlot(new Slot(this.input, forgingSlot.slotId(), forgingSlot.comp_1205(), forgingSlot.comp_1206()){

                @Override
                public boolean canInsert(ItemStack itemStack) {
                    return forgingSlot.comp_1207().test(itemStack);
                }
            });
        }
    }

    private void addResultSlot(ForgingSlotsManager forgingSlotsManager) {
        this.addSlot(new Slot(this.output, forgingSlotsManager.getResultSlot().slotId(), forgingSlotsManager.getResultSlot().comp_1205(), forgingSlotsManager.getResultSlot().comp_1206()){

            @Override
            public boolean canInsert(ItemStack itemStack) {
                return false;
            }

            @Override
            public boolean canTakeItems(PlayerEntity playerEntity) {
                return ForgingScreenHandler.this.canTakeOutput(playerEntity, this.hasStack());
            }

            @Override
            public void onTakeItem(PlayerEntity playerEntity, ItemStack itemStack) {
                ForgingScreenHandler.this.onTakeOutput(playerEntity, itemStack);
            }
        });
    }

    private void addPlayerInventorySlots(PlayerInventory playerInventory) {
        int i;
        for (i = 0; i < 3; ++i) {
            for (int j = 0; j < 9; ++j) {
                this.addSlot(new Slot(playerInventory, j + i * 9 + 9, 8 + j * 18, 84 + i * 18));
            }
        }
        for (i = 0; i < 9; ++i) {
            this.addSlot(new Slot(playerInventory, i, 8 + i * 18, 142));
        }
    }

    public abstract void updateResult();

    protected abstract ForgingSlotsManager getForgingSlotsManager();

    private SimpleInventory createInputInventory(int i) {
        return new SimpleInventory(i){

            @Override
            public void markDirty() {
                super.markDirty();
                ForgingScreenHandler.this.onContentChanged(this);
            }
        };
    }

    @Override
    public void onContentChanged(Inventory inventory) {
        super.onContentChanged(inventory);
        if (inventory == this.input) {
            this.updateResult();
        }
    }

    @Override
    public void onClosed(PlayerEntity playerEntity) {
        super.onClosed(playerEntity);
        this.context.run((world, blockPos) -> this.dropInventory(playerEntity, this.input));
    }

    @Override
    public boolean canUse(PlayerEntity playerEntity) {
        return this.context.get((world, blockPos) -> {
            if (!this.canUse(world.getBlockState((BlockPos)blockPos))) {
                return false;
            }
            return playerEntity.squaredDistanceTo((double)blockPos.getX() + 0.5, (double)blockPos.getY() + 0.5, (double)blockPos.getZ() + 0.5) <= 64.0;
        }, true);
    }

    @Override
    public ItemStack quickMove(PlayerEntity playerEntity, int i) {
        ItemStack itemStack = ItemStack.EMPTY;
        Slot slot = (Slot)this.slots.get(i);
        if (slot != null && slot.hasStack()) {
            int l;
            ItemStack itemStack2 = slot.getStack();
            itemStack = itemStack2.copy();
            int j = this.getPlayerInventoryStartIndex();
            int k = this.getPlayerHotbarEndIndex();
            if (i == this.getResultSlotIndex()) {
                if (!this.insertItem(itemStack2, j, k, true)) {
                    return ItemStack.EMPTY;
                }
                slot.onQuickTransfer(itemStack2, itemStack);
            } else if (this.inputSlotIndices.contains(i) ? !this.insertItem(itemStack2, j, k, false) : (this.isValidIngredient(itemStack2) && i >= this.getPlayerInventoryStartIndex() && i < this.getPlayerHotbarEndIndex() ? !this.insertItem(itemStack2, l = this.getSlotFor(itemStack), this.getResultSlotIndex(), false) : (i >= this.getPlayerInventoryStartIndex() && i < this.getPlayerInventoryEndIndex() ? !this.insertItem(itemStack2, this.getPlayerHotbarStartIndex(), this.getPlayerHotbarEndIndex(), false) : i >= this.getPlayerHotbarStartIndex() && i < this.getPlayerHotbarEndIndex() && !this.insertItem(itemStack2, this.getPlayerInventoryStartIndex(), this.getPlayerInventoryEndIndex(), false)))) {
                return ItemStack.EMPTY;
            }
            if (itemStack2.isEmpty()) {
                slot.setStack(ItemStack.EMPTY);
            } else {
                slot.markDirty();
            }
            if (itemStack2.getCount() == itemStack.getCount()) {
                return ItemStack.EMPTY;
            }
            slot.onTakeItem(playerEntity, itemStack2);
        }
        return itemStack;
    }

    protected boolean isValidIngredient(ItemStack itemStack) {
        return true;
    }

    public int getSlotFor(ItemStack itemStack) {
        return this.input.isEmpty() ? 0 : this.inputSlotIndices.get(0);
    }

    public int getResultSlotIndex() {
        return this.resultSlotIndex;
    }

    private int getPlayerInventoryStartIndex() {
        return this.getResultSlotIndex() + 1;
    }

    private int getPlayerInventoryEndIndex() {
        return this.getPlayerInventoryStartIndex() + 27;
    }

    private int getPlayerHotbarStartIndex() {
        return this.getPlayerInventoryEndIndex();
    }

    private int getPlayerHotbarEndIndex() {
        return this.getPlayerHotbarStartIndex() + 9;
    }
}


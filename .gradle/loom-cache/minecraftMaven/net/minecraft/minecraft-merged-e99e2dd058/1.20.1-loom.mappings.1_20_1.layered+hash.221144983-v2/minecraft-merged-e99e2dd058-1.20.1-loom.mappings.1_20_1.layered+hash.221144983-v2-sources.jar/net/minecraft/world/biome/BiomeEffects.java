/*
 * Decompiled with CFR 0.2.1 (FabricMC 53fa44c9).
 */
package net.minecraft.world.biome;

import com.mojang.datafixers.kinds.Applicative;
import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import java.util.Optional;
import java.util.OptionalInt;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.sound.BiomeAdditionsSound;
import net.minecraft.sound.BiomeMoodSound;
import net.minecraft.sound.MusicSound;
import net.minecraft.sound.SoundEvent;
import net.minecraft.util.StringIdentifiable;
import net.minecraft.world.biome.Biome;
import net.minecraft.world.biome.BiomeParticleConfig;
import org.jetbrains.annotations.Nullable;

public class BiomeEffects {
    public static final Codec<BiomeEffects> CODEC = RecordCodecBuilder.create(instance -> instance.group(((MapCodec)Codec.INT.fieldOf("fog_color")).forGetter(biomeEffects -> biomeEffects.fogColor), ((MapCodec)Codec.INT.fieldOf("water_color")).forGetter(biomeEffects -> biomeEffects.waterColor), ((MapCodec)Codec.INT.fieldOf("water_fog_color")).forGetter(biomeEffects -> biomeEffects.waterFogColor), ((MapCodec)Codec.INT.fieldOf("sky_color")).forGetter(biomeEffects -> biomeEffects.skyColor), Codec.INT.optionalFieldOf("foliage_color").forGetter(biomeEffects -> biomeEffects.foliageColor), Codec.INT.optionalFieldOf("grass_color").forGetter(biomeEffects -> biomeEffects.grassColor), GrassColorModifier.CODEC.optionalFieldOf("grass_color_modifier", GrassColorModifier.field_26426).forGetter(biomeEffects -> biomeEffects.grassColorModifier), BiomeParticleConfig.CODEC.optionalFieldOf("particle").forGetter(biomeEffects -> biomeEffects.particleConfig), SoundEvent.ENTRY_CODEC.optionalFieldOf("ambient_sound").forGetter(biomeEffects -> biomeEffects.loopSound), BiomeMoodSound.CODEC.optionalFieldOf("mood_sound").forGetter(biomeEffects -> biomeEffects.moodSound), BiomeAdditionsSound.CODEC.optionalFieldOf("additions_sound").forGetter(biomeEffects -> biomeEffects.additionsSound), MusicSound.CODEC.optionalFieldOf("music").forGetter(biomeEffects -> biomeEffects.music)).apply((Applicative<BiomeEffects, ?>)instance, BiomeEffects::new));
    private final int fogColor;
    private final int waterColor;
    private final int waterFogColor;
    private final int skyColor;
    private final Optional<Integer> foliageColor;
    private final Optional<Integer> grassColor;
    private final GrassColorModifier grassColorModifier;
    private final Optional<BiomeParticleConfig> particleConfig;
    private final Optional<RegistryEntry<SoundEvent>> loopSound;
    private final Optional<BiomeMoodSound> moodSound;
    private final Optional<BiomeAdditionsSound> additionsSound;
    private final Optional<MusicSound> music;

    BiomeEffects(int i, int j, int k, int l, Optional<Integer> optional, Optional<Integer> optional2, GrassColorModifier grassColorModifier, Optional<BiomeParticleConfig> optional3, Optional<RegistryEntry<SoundEvent>> optional4, Optional<BiomeMoodSound> optional5, Optional<BiomeAdditionsSound> optional6, Optional<MusicSound> optional7) {
        this.fogColor = i;
        this.waterColor = j;
        this.waterFogColor = k;
        this.skyColor = l;
        this.foliageColor = optional;
        this.grassColor = optional2;
        this.grassColorModifier = grassColorModifier;
        this.particleConfig = optional3;
        this.loopSound = optional4;
        this.moodSound = optional5;
        this.additionsSound = optional6;
        this.music = optional7;
    }

    public int getFogColor() {
        return this.fogColor;
    }

    public int getWaterColor() {
        return this.waterColor;
    }

    public int getWaterFogColor() {
        return this.waterFogColor;
    }

    public int getSkyColor() {
        return this.skyColor;
    }

    public Optional<Integer> getFoliageColor() {
        return this.foliageColor;
    }

    public Optional<Integer> getGrassColor() {
        return this.grassColor;
    }

    public GrassColorModifier getGrassColorModifier() {
        return this.grassColorModifier;
    }

    public Optional<BiomeParticleConfig> getParticleConfig() {
        return this.particleConfig;
    }

    public Optional<RegistryEntry<SoundEvent>> getLoopSound() {
        return this.loopSound;
    }

    public Optional<BiomeMoodSound> getMoodSound() {
        return this.moodSound;
    }

    public Optional<BiomeAdditionsSound> getAdditionsSound() {
        return this.additionsSound;
    }

    public Optional<MusicSound> getMusic() {
        return this.music;
    }

    /*
     * Uses 'sealed' constructs - enablewith --sealed true
     */
    public static enum GrassColorModifier implements StringIdentifiable
    {
        field_26426("none"){

            @Override
            public int getModifiedGrassColor(double d, double e, int i) {
                return i;
            }
        }
        ,
        field_26427("dark_forest"){

            @Override
            public int getModifiedGrassColor(double d, double e, int i) {
                return (i & 0xFEFEFE) + 2634762 >> 1;
            }
        }
        ,
        field_26428("swamp"){

            @Override
            public int getModifiedGrassColor(double d, double e, int i) {
                double f = Biome.FOLIAGE_NOISE.sample(d * 0.0225, e * 0.0225, false);
                if (f < -0.1) {
                    return 5011004;
                }
                return 6975545;
            }
        };

        private final String name;
        public static final Codec<GrassColorModifier> CODEC;

        public abstract int getModifiedGrassColor(double var1, double var3, int var5);

        GrassColorModifier(String string2) {
            this.name = string2;
        }

        public String getName() {
            return this.name;
        }

        @Override
        public String asString() {
            return this.name;
        }

        static {
            CODEC = StringIdentifiable.createCodec(GrassColorModifier::values);
        }
    }

    public static class Builder {
        private OptionalInt fogColor = OptionalInt.empty();
        private OptionalInt waterColor = OptionalInt.empty();
        private OptionalInt waterFogColor = OptionalInt.empty();
        private OptionalInt skyColor = OptionalInt.empty();
        private Optional<Integer> foliageColor = Optional.empty();
        private Optional<Integer> grassColor = Optional.empty();
        private GrassColorModifier grassColorModifier = GrassColorModifier.field_26426;
        private Optional<BiomeParticleConfig> particleConfig = Optional.empty();
        private Optional<RegistryEntry<SoundEvent>> loopSound = Optional.empty();
        private Optional<BiomeMoodSound> moodSound = Optional.empty();
        private Optional<BiomeAdditionsSound> additionsSound = Optional.empty();
        private Optional<MusicSound> musicSound = Optional.empty();

        public Builder fogColor(int i) {
            this.fogColor = OptionalInt.of(i);
            return this;
        }

        public Builder waterColor(int i) {
            this.waterColor = OptionalInt.of(i);
            return this;
        }

        public Builder waterFogColor(int i) {
            this.waterFogColor = OptionalInt.of(i);
            return this;
        }

        public Builder skyColor(int i) {
            this.skyColor = OptionalInt.of(i);
            return this;
        }

        public Builder foliageColor(int i) {
            this.foliageColor = Optional.of(i);
            return this;
        }

        public Builder grassColor(int i) {
            this.grassColor = Optional.of(i);
            return this;
        }

        public Builder grassColorModifier(GrassColorModifier grassColorModifier) {
            this.grassColorModifier = grassColorModifier;
            return this;
        }

        public Builder particleConfig(BiomeParticleConfig biomeParticleConfig) {
            this.particleConfig = Optional.of(biomeParticleConfig);
            return this;
        }

        public Builder loopSound(RegistryEntry<SoundEvent> registryEntry) {
            this.loopSound = Optional.of(registryEntry);
            return this;
        }

        public Builder moodSound(BiomeMoodSound biomeMoodSound) {
            this.moodSound = Optional.of(biomeMoodSound);
            return this;
        }

        public Builder additionsSound(BiomeAdditionsSound biomeAdditionsSound) {
            this.additionsSound = Optional.of(biomeAdditionsSound);
            return this;
        }

        public Builder music(@Nullable MusicSound musicSound) {
            this.musicSound = Optional.ofNullable(musicSound);
            return this;
        }

        public BiomeEffects build() {
            return new BiomeEffects(this.fogColor.orElseThrow(() -> new IllegalStateException("Missing 'fog' color.")), this.waterColor.orElseThrow(() -> new IllegalStateException("Missing 'water' color.")), this.waterFogColor.orElseThrow(() -> new IllegalStateException("Missing 'water fog' color.")), this.skyColor.orElseThrow(() -> new IllegalStateException("Missing 'sky' color.")), this.foliageColor, this.grassColor, this.grassColorModifier, this.particleConfig, this.loopSound, this.moodSound, this.additionsSound, this.musicSound);
        }
    }
}


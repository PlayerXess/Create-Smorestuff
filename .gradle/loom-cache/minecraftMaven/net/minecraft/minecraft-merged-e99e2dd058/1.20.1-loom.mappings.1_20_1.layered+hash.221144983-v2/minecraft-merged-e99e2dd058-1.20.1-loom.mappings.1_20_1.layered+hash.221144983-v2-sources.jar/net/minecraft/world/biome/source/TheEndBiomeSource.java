/*
 * Decompiled with CFR 0.2.1 (FabricMC 53fa44c9).
 */
package net.minecraft.world.biome.source;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import java.util.stream.Stream;
import net.minecraft.registry.RegistryEntryLookup;
import net.minecraft.registry.RegistryOps;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.util.math.ChunkSectionPos;
import net.minecraft.world.biome.Biome;
import net.minecraft.world.biome.BiomeKeys;
import net.minecraft.world.biome.source.BiomeCoords;
import net.minecraft.world.biome.source.BiomeSource;
import net.minecraft.world.biome.source.util.MultiNoiseUtil;
import net.minecraft.world.gen.densityfunction.DensityFunction;

public class TheEndBiomeSource
extends BiomeSource {
    public static final Codec<TheEndBiomeSource> CODEC = RecordCodecBuilder.create(instance -> instance.group(RegistryOps.getEntryCodec(BiomeKeys.field_9411), RegistryOps.getEntryCodec(BiomeKeys.field_9442), RegistryOps.getEntryCodec(BiomeKeys.field_9447), RegistryOps.getEntryCodec(BiomeKeys.field_9457), RegistryOps.getEntryCodec(BiomeKeys.field_9465)).apply(instance, instance.stable(TheEndBiomeSource::new)));
    private final RegistryEntry<Biome> centerBiome;
    private final RegistryEntry<Biome> highlandsBiome;
    private final RegistryEntry<Biome> midlandsBiome;
    private final RegistryEntry<Biome> smallIslandsBiome;
    private final RegistryEntry<Biome> barrensBiome;

    public static TheEndBiomeSource createVanilla(RegistryEntryLookup<Biome> registryEntryLookup) {
        return new TheEndBiomeSource(registryEntryLookup.getOrThrow(BiomeKeys.field_9411), registryEntryLookup.getOrThrow(BiomeKeys.field_9442), registryEntryLookup.getOrThrow(BiomeKeys.field_9447), registryEntryLookup.getOrThrow(BiomeKeys.field_9457), registryEntryLookup.getOrThrow(BiomeKeys.field_9465));
    }

    private TheEndBiomeSource(RegistryEntry<Biome> registryEntry, RegistryEntry<Biome> registryEntry2, RegistryEntry<Biome> registryEntry3, RegistryEntry<Biome> registryEntry4, RegistryEntry<Biome> registryEntry5) {
        this.centerBiome = registryEntry;
        this.highlandsBiome = registryEntry2;
        this.midlandsBiome = registryEntry3;
        this.smallIslandsBiome = registryEntry4;
        this.barrensBiome = registryEntry5;
    }

    @Override
    protected Stream<RegistryEntry<Biome>> biomeStream() {
        return Stream.of(this.centerBiome, this.highlandsBiome, this.midlandsBiome, this.smallIslandsBiome, this.barrensBiome);
    }

    @Override
    protected Codec<? extends BiomeSource> getCodec() {
        return CODEC;
    }

    @Override
    public RegistryEntry<Biome> getBiome(int i, int j, int k, MultiNoiseUtil.MultiNoiseSampler multiNoiseSampler) {
        int p;
        int l = BiomeCoords.toBlock(i);
        int m = BiomeCoords.toBlock(j);
        int n = BiomeCoords.toBlock(k);
        int o = ChunkSectionPos.getSectionCoord(l);
        if ((long)o * (long)o + (long)(p = ChunkSectionPos.getSectionCoord(n)) * (long)p <= 4096L) {
            return this.centerBiome;
        }
        int q = (ChunkSectionPos.getSectionCoord(l) * 2 + 1) * 8;
        int r = (ChunkSectionPos.getSectionCoord(n) * 2 + 1) * 8;
        double d = multiNoiseSampler.comp_367().sample(new DensityFunction.UnblendedNoisePos(q, m, r));
        if (d > 0.25) {
            return this.highlandsBiome;
        }
        if (d >= -0.0625) {
            return this.midlandsBiome;
        }
        if (d < -0.21875) {
            return this.smallIslandsBiome;
        }
        return this.barrensBiome;
    }
}


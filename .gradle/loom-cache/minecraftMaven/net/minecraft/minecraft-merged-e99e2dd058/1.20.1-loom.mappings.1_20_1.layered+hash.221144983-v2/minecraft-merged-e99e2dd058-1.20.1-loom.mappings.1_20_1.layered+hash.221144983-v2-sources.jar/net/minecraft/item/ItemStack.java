/*
 * Decompiled with CFR 0.2.1 (FabricMC 53fa44c9).
 */
package net.minecraft.item;

import com.google.common.collect.HashMultimap;
import com.google.common.collect.Lists;
import com.google.common.collect.Multimap;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.mojang.datafixers.kinds.Applicative;
import com.mojang.logging.LogUtils;
import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import io.github.fabricators_of_create.porting_lib.extensions.extensions.INBTSerializableCompound;
import io.github.fabricators_of_create.porting_lib.tool.extensions.ItemStackExtensions;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.function.Consumer;
import java.util.function.Predicate;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import net.fabricmc.fabric.api.item.v1.FabricItemStack;
import net.minecraft.advancement.criterion.Criteria;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.pattern.CachedBlockPosition;
import net.minecraft.client.item.TooltipContext;
import net.minecraft.client.item.TooltipData;
import net.minecraft.command.argument.BlockArgumentParser;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.enchantment.Enchantments;
import net.minecraft.enchantment.UnbreakingEnchantment;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityGroup;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.ItemEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.attribute.EntityAttribute;
import net.minecraft.entity.attribute.EntityAttributeModifier;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.decoration.ItemFrameEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.inventory.StackReference;
import net.minecraft.item.BlockPredicatesChecker;
import net.minecraft.item.FilledMapItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemConvertible;
import net.minecraft.item.ItemUsageContext;
import net.minecraft.item.Items;
import net.minecraft.item.trim.ArmorTrim;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.nbt.NbtElement;
import net.minecraft.nbt.NbtList;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.registry.tag.TagKey;
import net.minecraft.resource.featuretoggle.FeatureSet;
import net.minecraft.screen.ScreenTexts;
import net.minecraft.screen.slot.Slot;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.sound.SoundEvent;
import net.minecraft.stat.Stats;
import net.minecraft.text.HoverEvent;
import net.minecraft.text.MutableText;
import net.minecraft.text.Style;
import net.minecraft.text.Text;
import net.minecraft.text.Texts;
import net.minecraft.util.ActionResult;
import net.minecraft.util.ClickType;
import net.minecraft.util.Formatting;
import net.minecraft.util.Hand;
import net.minecraft.util.Identifier;
import net.minecraft.util.Rarity;
import net.minecraft.util.TypedActionResult;
import net.minecraft.util.UseAction;
import net.minecraft.util.Util;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.random.Random;
import net.minecraft.world.World;
import org.jetbrains.annotations.Nullable;
import org.slf4j.Logger;

public final class ItemStack
implements FabricItemStack,
io.github.fabricators_of_create.porting_lib.extensions.extensions.ItemStackExtensions,
INBTSerializableCompound,
ItemStackExtensions {
    public static final Codec<ItemStack> CODEC = RecordCodecBuilder.create(instance -> instance.group(((MapCodec)Registries.ITEM.getCodec().fieldOf("id")).forGetter(ItemStack::getItem), ((MapCodec)Codec.INT.fieldOf("Count")).forGetter(ItemStack::getCount), NbtCompound.CODEC.optionalFieldOf("tag").forGetter(itemStack -> Optional.ofNullable(itemStack.getNbt()))).apply((Applicative<ItemStack, ?>)instance, ItemStack::new));
    private static final Logger LOGGER = LogUtils.getLogger();
    public static final ItemStack EMPTY = new ItemStack((Void)null);
    public static final DecimalFormat MODIFIER_FORMAT = Util.make(new DecimalFormat("#.##"), decimalFormat -> decimalFormat.setDecimalFormatSymbols(DecimalFormatSymbols.getInstance(Locale.ROOT)));
    public static final String ENCHANTMENTS_KEY = "Enchantments";
    public static final String DISPLAY_KEY = "display";
    public static final String NAME_KEY = "Name";
    public static final String LORE_KEY = "Lore";
    public static final String DAMAGE_KEY = "Damage";
    public static final String COLOR_KEY = "color";
    private static final String UNBREAKABLE_KEY = "Unbreakable";
    private static final String REPAIR_COST_KEY = "RepairCost";
    private static final String CAN_DESTROY_KEY = "CanDestroy";
    private static final String CAN_PLACE_ON_KEY = "CanPlaceOn";
    private static final String HIDE_FLAGS_KEY = "HideFlags";
    private static final Text DISABLED_TEXT = Text.translatable("item.disabled").formatted(Formatting.field_1061);
    private static final int field_30903 = 0;
    private static final Style LORE_STYLE = Style.EMPTY.withColor(Formatting.field_1064).withItalic(true);
    private int count;
    private int bobbingAnimationTime;
    @Deprecated
    @Nullable
    private final Item item;
    @Nullable
    private NbtCompound nbt;
    @Nullable
    private Entity holder;
    @Nullable
    private BlockPredicatesChecker destroyChecker;
    @Nullable
    private BlockPredicatesChecker placeChecker;

    public Optional<TooltipData> getTooltipData() {
        return this.getItem().getTooltipData(this);
    }

    public ItemStack(ItemConvertible itemConvertible) {
        this(itemConvertible, 1);
    }

    public ItemStack(RegistryEntry<Item> registryEntry) {
        this(registryEntry.comp_349(), 1);
    }

    private ItemStack(ItemConvertible itemConvertible, int i, Optional<NbtCompound> optional) {
        this(itemConvertible, i);
        optional.ifPresent(this::setNbt);
    }

    public ItemStack(RegistryEntry<Item> registryEntry, int i) {
        this(registryEntry.comp_349(), i);
    }

    public ItemStack(ItemConvertible itemConvertible, int i) {
        this.item = itemConvertible.asItem();
        this.count = i;
        if (this.item.isDamageable()) {
            this.setDamage(this.getDamage());
        }
    }

    private ItemStack(@Nullable Void void_) {
        this.item = null;
    }

    private ItemStack(NbtCompound nbtCompound) {
        this.item = Registries.ITEM.get(new Identifier(nbtCompound.getString("id")));
        this.count = nbtCompound.getByte("Count");
        if (nbtCompound.contains("tag", 10)) {
            this.nbt = nbtCompound.getCompound("tag");
            this.getItem().postProcessNbt(this.nbt);
        }
        if (this.getItem().isDamageable()) {
            this.setDamage(this.getDamage());
        }
    }

    public static ItemStack fromNbt(NbtCompound nbtCompound) {
        try {
            return new ItemStack(nbtCompound);
        } catch (RuntimeException runtimeException) {
            LOGGER.debug("Tried to load invalid item: {}", (Object)nbtCompound, (Object)runtimeException);
            return EMPTY;
        }
    }

    public boolean isEmpty() {
        return this == EMPTY || this.item == Items.AIR || this.count <= 0;
    }

    public boolean isItemEnabled(FeatureSet featureSet) {
        return this.isEmpty() || this.getItem().isEnabled(featureSet);
    }

    public ItemStack split(int i) {
        int j = Math.min(i, this.getCount());
        ItemStack itemStack = this.copyWithCount(j);
        this.decrement(j);
        return itemStack;
    }

    public ItemStack copyAndEmpty() {
        if (this.isEmpty()) {
            return EMPTY;
        }
        ItemStack itemStack = this.copy();
        this.setCount(0);
        return itemStack;
    }

    public Item getItem() {
        return this.isEmpty() ? Items.AIR : this.item;
    }

    public RegistryEntry<Item> getRegistryEntry() {
        return this.getItem().getRegistryEntry();
    }

    public boolean isIn(TagKey<Item> tagKey) {
        return this.getItem().getRegistryEntry().isIn(tagKey);
    }

    public boolean isOf(Item item) {
        return this.getItem() == item;
    }

    public boolean itemMatches(Predicate<RegistryEntry<Item>> predicate) {
        return predicate.test(this.getItem().getRegistryEntry());
    }

    public boolean itemMatches(RegistryEntry<Item> registryEntry) {
        return this.getItem().getRegistryEntry() == registryEntry;
    }

    public Stream<TagKey<Item>> streamTags() {
        return this.getItem().getRegistryEntry().streamTags();
    }

    public ActionResult useOnBlock(ItemUsageContext itemUsageContext) {
        PlayerEntity playerEntity = itemUsageContext.getPlayer();
        BlockPos blockPos = itemUsageContext.getBlockPos();
        CachedBlockPosition cachedBlockPosition = new CachedBlockPosition(itemUsageContext.getWorld(), blockPos, false);
        if (playerEntity != null && !playerEntity.getAbilities().allowModifyWorld && !this.canPlaceOn(itemUsageContext.getWorld().getRegistryManager().get(RegistryKeys.field_41254), cachedBlockPosition)) {
            return ActionResult.PASS;
        }
        Item item = this.getItem();
        ActionResult actionResult = item.useOnBlock(itemUsageContext);
        if (playerEntity != null && actionResult.shouldIncrementStat()) {
            playerEntity.incrementStat(Stats.field_15372.getOrCreateStat(item));
        }
        return actionResult;
    }

    public float getMiningSpeedMultiplier(BlockState blockState) {
        return this.getItem().getMiningSpeedMultiplier(this, blockState);
    }

    public TypedActionResult<ItemStack> use(World world, PlayerEntity playerEntity, Hand hand) {
        return this.getItem().use(world, playerEntity, hand);
    }

    public ItemStack finishUsing(World world, LivingEntity livingEntity) {
        return this.getItem().finishUsing(this, world, livingEntity);
    }

    public NbtCompound writeNbt(NbtCompound nbtCompound) {
        Identifier identifier = Registries.ITEM.getId(this.getItem());
        nbtCompound.putString("id", identifier == null ? "minecraft:air" : identifier.toString());
        nbtCompound.putByte("Count", (byte)this.count);
        if (this.nbt != null) {
            nbtCompound.put("tag", this.nbt.copy());
        }
        return nbtCompound;
    }

    public int getMaxCount() {
        return this.getItem().getMaxCount();
    }

    public boolean isStackable() {
        return this.getMaxCount() > 1 && (!this.isDamageable() || !this.isDamaged());
    }

    public boolean isDamageable() {
        if (this.isEmpty() || this.getItem().getMaxDamage() <= 0) {
            return false;
        }
        NbtCompound nbtCompound = this.getNbt();
        return nbtCompound == null || !nbtCompound.getBoolean(UNBREAKABLE_KEY);
    }

    public boolean isDamaged() {
        return this.isDamageable() && this.getDamage() > 0;
    }

    public int getDamage() {
        return this.nbt == null ? 0 : this.nbt.getInt(DAMAGE_KEY);
    }

    public void setDamage(int i) {
        this.getOrCreateNbt().putInt(DAMAGE_KEY, Math.max(0, i));
    }

    public int getMaxDamage() {
        return this.getItem().getMaxDamage();
    }

    public boolean damage(int i, Random random, @Nullable ServerPlayerEntity serverPlayerEntity) {
        int j;
        if (!this.isDamageable()) {
            return false;
        }
        if (i > 0) {
            j = EnchantmentHelper.getLevel(Enchantments.field_9119, this);
            int k = 0;
            for (int l = 0; j > 0 && l < i; ++l) {
                if (!UnbreakingEnchantment.shouldPreventDamage(this, j, random)) continue;
                ++k;
            }
            if ((i -= k) <= 0) {
                return false;
            }
        }
        if (serverPlayerEntity != null && i != 0) {
            Criteria.ITEM_DURABILITY_CHANGED.trigger(serverPlayerEntity, this, this.getDamage() + i);
        }
        j = this.getDamage() + i;
        this.setDamage(j);
        return j >= this.getMaxDamage();
    }

    public <T extends LivingEntity> void damage(int i, T livingEntity, Consumer<T> consumer) {
        if (livingEntity.getWorld().isClient || livingEntity instanceof PlayerEntity && ((PlayerEntity)livingEntity).getAbilities().creativeMode) {
            return;
        }
        if (!this.isDamageable()) {
            return;
        }
        if (this.damage(i, livingEntity.getRandom(), livingEntity instanceof ServerPlayerEntity ? (ServerPlayerEntity)livingEntity : null)) {
            consumer.accept(livingEntity);
            Item item = this.getItem();
            this.decrement(1);
            if (livingEntity instanceof PlayerEntity) {
                ((PlayerEntity)livingEntity).incrementStat(Stats.field_15383.getOrCreateStat(item));
            }
            this.setDamage(0);
        }
    }

    public boolean isItemBarVisible() {
        return this.getItem().isItemBarVisible(this);
    }

    public int getItemBarStep() {
        return this.getItem().getItemBarStep(this);
    }

    public int getItemBarColor() {
        return this.getItem().getItemBarColor(this);
    }

    public boolean onStackClicked(Slot slot, ClickType clickType, PlayerEntity playerEntity) {
        return this.getItem().onStackClicked(this, slot, clickType, playerEntity);
    }

    public boolean onClicked(ItemStack itemStack, Slot slot, ClickType clickType, PlayerEntity playerEntity, StackReference stackReference) {
        return this.getItem().onClicked(this, itemStack, slot, clickType, playerEntity, stackReference);
    }

    public void postHit(LivingEntity livingEntity, PlayerEntity playerEntity) {
        Item item = this.getItem();
        if (item.postHit(this, livingEntity, playerEntity)) {
            playerEntity.incrementStat(Stats.field_15372.getOrCreateStat(item));
        }
    }

    public void postMine(World world, BlockState blockState, BlockPos blockPos, PlayerEntity playerEntity) {
        Item item = this.getItem();
        if (item.postMine(this, world, blockState, blockPos, playerEntity)) {
            playerEntity.incrementStat(Stats.field_15372.getOrCreateStat(item));
        }
    }

    public boolean isSuitableFor(BlockState blockState) {
        return this.getItem().isSuitableFor(blockState);
    }

    public ActionResult useOnEntity(PlayerEntity playerEntity, LivingEntity livingEntity, Hand hand) {
        return this.getItem().useOnEntity(this, playerEntity, livingEntity, hand);
    }

    public ItemStack copy() {
        if (this.isEmpty()) {
            return EMPTY;
        }
        ItemStack itemStack = new ItemStack(this.getItem(), this.count);
        itemStack.setBobbingAnimationTime(this.getBobbingAnimationTime());
        if (this.nbt != null) {
            itemStack.nbt = this.nbt.copy();
        }
        return itemStack;
    }

    public ItemStack copyWithCount(int i) {
        if (this.isEmpty()) {
            return EMPTY;
        }
        ItemStack itemStack = this.copy();
        itemStack.setCount(i);
        return itemStack;
    }

    public static boolean areEqual(ItemStack itemStack, ItemStack itemStack2) {
        if (itemStack == itemStack2) {
            return true;
        }
        if (itemStack.getCount() != itemStack2.getCount()) {
            return false;
        }
        return ItemStack.canCombine(itemStack, itemStack2);
    }

    public static boolean areItemsEqual(ItemStack itemStack, ItemStack itemStack2) {
        return itemStack.isOf(itemStack2.getItem());
    }

    public static boolean canCombine(ItemStack itemStack, ItemStack itemStack2) {
        if (!itemStack.isOf(itemStack2.getItem())) {
            return false;
        }
        if (itemStack.isEmpty() && itemStack2.isEmpty()) {
            return true;
        }
        return Objects.equals(itemStack.nbt, itemStack2.nbt);
    }

    public String getTranslationKey() {
        return this.getItem().getTranslationKey(this);
    }

    public String toString() {
        return this.getCount() + " " + this.getItem();
    }

    public void inventoryTick(World world, Entity entity, int i, boolean bl) {
        if (this.bobbingAnimationTime > 0) {
            --this.bobbingAnimationTime;
        }
        if (this.getItem() != null) {
            this.getItem().inventoryTick(this, world, entity, i, bl);
        }
    }

    public void onCraft(World world, PlayerEntity playerEntity, int i) {
        playerEntity.increaseStat(Stats.field_15370.getOrCreateStat(this.getItem()), i);
        this.getItem().onCraft(this, world, playerEntity);
    }

    public int getMaxUseTime() {
        return this.getItem().getMaxUseTime(this);
    }

    public UseAction getUseAction() {
        return this.getItem().getUseAction(this);
    }

    public void onStoppedUsing(World world, LivingEntity livingEntity, int i) {
        this.getItem().onStoppedUsing(this, world, livingEntity, i);
    }

    public boolean isUsedOnRelease() {
        return this.getItem().isUsedOnRelease(this);
    }

    public boolean hasNbt() {
        return !this.isEmpty() && this.nbt != null && !this.nbt.isEmpty();
    }

    @Nullable
    public NbtCompound getNbt() {
        return this.nbt;
    }

    public NbtCompound getOrCreateNbt() {
        if (this.nbt == null) {
            this.setNbt(new NbtCompound());
        }
        return this.nbt;
    }

    public NbtCompound getOrCreateSubNbt(String string) {
        if (this.nbt == null || !this.nbt.contains(string, 10)) {
            NbtCompound nbtCompound = new NbtCompound();
            this.setSubNbt(string, nbtCompound);
            return nbtCompound;
        }
        return this.nbt.getCompound(string);
    }

    @Nullable
    public NbtCompound getSubNbt(String string) {
        if (this.nbt == null || !this.nbt.contains(string, 10)) {
            return null;
        }
        return this.nbt.getCompound(string);
    }

    public void removeSubNbt(String string) {
        if (this.nbt != null && this.nbt.contains(string)) {
            this.nbt.remove(string);
            if (this.nbt.isEmpty()) {
                this.nbt = null;
            }
        }
    }

    public NbtList getEnchantments() {
        if (this.nbt != null) {
            return this.nbt.getList(ENCHANTMENTS_KEY, 10);
        }
        return new NbtList();
    }

    public void setNbt(@Nullable NbtCompound nbtCompound) {
        this.nbt = nbtCompound;
        if (this.getItem().isDamageable()) {
            this.setDamage(this.getDamage());
        }
        if (nbtCompound != null) {
            this.getItem().postProcessNbt(nbtCompound);
        }
    }

    public Text getName() {
        NbtCompound nbtCompound = this.getSubNbt(DISPLAY_KEY);
        if (nbtCompound != null && nbtCompound.contains(NAME_KEY, 8)) {
            try {
                MutableText text = Text.Serializer.fromJson(nbtCompound.getString(NAME_KEY));
                if (text != null) {
                    return text;
                }
                nbtCompound.remove(NAME_KEY);
            } catch (Exception exception) {
                nbtCompound.remove(NAME_KEY);
            }
        }
        return this.getItem().getName(this);
    }

    public ItemStack setCustomName(@Nullable Text text) {
        NbtCompound nbtCompound = this.getOrCreateSubNbt(DISPLAY_KEY);
        if (text != null) {
            nbtCompound.putString(NAME_KEY, Text.Serializer.toJson(text));
        } else {
            nbtCompound.remove(NAME_KEY);
        }
        return this;
    }

    public void removeCustomName() {
        NbtCompound nbtCompound = this.getSubNbt(DISPLAY_KEY);
        if (nbtCompound != null) {
            nbtCompound.remove(NAME_KEY);
            if (nbtCompound.isEmpty()) {
                this.removeSubNbt(DISPLAY_KEY);
            }
        }
        if (this.nbt != null && this.nbt.isEmpty()) {
            this.nbt = null;
        }
    }

    public boolean hasCustomName() {
        NbtCompound nbtCompound = this.getSubNbt(DISPLAY_KEY);
        return nbtCompound != null && nbtCompound.contains(NAME_KEY, 8);
    }

    public List<Text> getTooltip(@Nullable PlayerEntity playerEntity, TooltipContext tooltipContext) {
        int i;
        Integer integer;
        ArrayList<Text> list = Lists.newArrayList();
        MutableText mutableText = Text.empty().append(this.getName()).formatted(this.getRarity().formatting);
        if (this.hasCustomName()) {
            mutableText.formatted(Formatting.field_1056);
        }
        list.add(mutableText);
        if (!tooltipContext.isAdvanced() && !this.hasCustomName() && this.isOf(Items.field_8204) && (integer = FilledMapItem.getMapId(this)) != null) {
            list.add(Text.literal("#" + integer).formatted(Formatting.field_1080));
        }
        if (ItemStack.isSectionVisible(i = this.getHideFlags(), TooltipSection.field_25773)) {
            this.getItem().appendTooltip(this, playerEntity == null ? null : playerEntity.getWorld(), list, tooltipContext);
        }
        if (this.hasNbt()) {
            if (ItemStack.isSectionVisible(i, TooltipSection.field_41945) && playerEntity != null) {
                ArmorTrim.appendTooltip(this, playerEntity.getWorld().getRegistryManager(), list);
            }
            if (ItemStack.isSectionVisible(i, TooltipSection.field_25768)) {
                ItemStack.appendEnchantments(list, this.getEnchantments());
            }
            if (this.nbt.contains(DISPLAY_KEY, 10)) {
                NbtCompound nbtCompound = this.nbt.getCompound(DISPLAY_KEY);
                if (ItemStack.isSectionVisible(i, TooltipSection.field_25774) && nbtCompound.contains(COLOR_KEY, 99)) {
                    if (tooltipContext.isAdvanced()) {
                        list.add(Text.translatable("item.color", String.format(Locale.ROOT, "#%06X", nbtCompound.getInt(COLOR_KEY))).formatted(Formatting.field_1080));
                    } else {
                        list.add(Text.translatable("item.dyed").formatted(Formatting.field_1080, Formatting.field_1056));
                    }
                }
                if (nbtCompound.getType(LORE_KEY) == 9) {
                    NbtList nbtList = nbtCompound.getList(LORE_KEY, 8);
                    for (int j = 0; j < nbtList.size(); ++j) {
                        String string = nbtList.getString(j);
                        try {
                            MutableText mutableText2 = Text.Serializer.fromJson(string);
                            if (mutableText2 == null) continue;
                            list.add(Texts.setStyleIfAbsent(mutableText2, LORE_STYLE));
                            continue;
                        } catch (Exception exception) {
                            nbtCompound.remove(LORE_KEY);
                        }
                    }
                }
            }
        }
        if (ItemStack.isSectionVisible(i, TooltipSection.field_25769)) {
            for (EquipmentSlot equipmentSlot : EquipmentSlot.values()) {
                Multimap<EntityAttribute, EntityAttributeModifier> multimap = this.getAttributeModifiers(equipmentSlot);
                if (multimap.isEmpty()) continue;
                list.add(ScreenTexts.EMPTY);
                list.add(Text.translatable("item.modifiers." + equipmentSlot.getName()).formatted(Formatting.field_1080));
                for (Map.Entry<EntityAttribute, EntityAttributeModifier> entry : multimap.entries()) {
                    EntityAttributeModifier entityAttributeModifier = entry.getValue();
                    double d = entityAttributeModifier.getValue();
                    boolean bl = false;
                    if (playerEntity != null) {
                        if (entityAttributeModifier.getId() == Item.ATTACK_DAMAGE_MODIFIER_ID) {
                            d += playerEntity.getAttributeBaseValue(EntityAttributes.field_23721);
                            d += (double)EnchantmentHelper.getAttackDamage(this, EntityGroup.DEFAULT);
                            bl = true;
                        } else if (entityAttributeModifier.getId() == Item.ATTACK_SPEED_MODIFIER_ID) {
                            d += playerEntity.getAttributeBaseValue(EntityAttributes.field_23723);
                            bl = true;
                        }
                    }
                    double e = entityAttributeModifier.getOperation() == EntityAttributeModifier.Operation.MULTIPLY_BASE || entityAttributeModifier.getOperation() == EntityAttributeModifier.Operation.MULTIPLY_TOTAL ? d * 100.0 : (entry.getKey().equals(EntityAttributes.field_23718) ? d * 10.0 : d);
                    if (bl) {
                        list.add(ScreenTexts.space().append(Text.translatable("attribute.modifier.equals." + entityAttributeModifier.getOperation().getId(), MODIFIER_FORMAT.format(e), Text.translatable(entry.getKey().getTranslationKey()))).formatted(Formatting.field_1077));
                        continue;
                    }
                    if (d > 0.0) {
                        list.add(Text.translatable("attribute.modifier.plus." + entityAttributeModifier.getOperation().getId(), MODIFIER_FORMAT.format(e), Text.translatable(entry.getKey().getTranslationKey())).formatted(Formatting.field_1078));
                        continue;
                    }
                    if (!(d < 0.0)) continue;
                    list.add(Text.translatable("attribute.modifier.take." + entityAttributeModifier.getOperation().getId(), MODIFIER_FORMAT.format(e *= -1.0), Text.translatable(entry.getKey().getTranslationKey())).formatted(Formatting.field_1061));
                }
            }
        }
        if (this.hasNbt()) {
            NbtList nbtList2;
            if (ItemStack.isSectionVisible(i, TooltipSection.field_25770) && this.nbt.getBoolean(UNBREAKABLE_KEY)) {
                list.add(Text.translatable("item.unbreakable").formatted(Formatting.field_1078));
            }
            if (ItemStack.isSectionVisible(i, TooltipSection.field_25771) && this.nbt.contains(CAN_DESTROY_KEY, 9) && !(nbtList2 = this.nbt.getList(CAN_DESTROY_KEY, 8)).isEmpty()) {
                list.add(ScreenTexts.EMPTY);
                list.add(Text.translatable("item.canBreak").formatted(Formatting.field_1080));
                for (int k = 0; k < nbtList2.size(); ++k) {
                    list.addAll(ItemStack.parseBlockTag(nbtList2.getString(k)));
                }
            }
            if (ItemStack.isSectionVisible(i, TooltipSection.field_25772) && this.nbt.contains(CAN_PLACE_ON_KEY, 9) && !(nbtList2 = this.nbt.getList(CAN_PLACE_ON_KEY, 8)).isEmpty()) {
                list.add(ScreenTexts.EMPTY);
                list.add(Text.translatable("item.canPlace").formatted(Formatting.field_1080));
                for (int k = 0; k < nbtList2.size(); ++k) {
                    list.addAll(ItemStack.parseBlockTag(nbtList2.getString(k)));
                }
            }
        }
        if (tooltipContext.isAdvanced()) {
            if (this.isDamaged()) {
                list.add(Text.translatable("item.durability", this.getMaxDamage() - this.getDamage(), this.getMaxDamage()));
            }
            list.add(Text.literal(Registries.ITEM.getId(this.getItem()).toString()).formatted(Formatting.field_1063));
            if (this.hasNbt()) {
                list.add(Text.translatable("item.nbt_tags", this.nbt.getKeys().size()).formatted(Formatting.field_1063));
            }
        }
        if (playerEntity != null && !this.getItem().isEnabled(playerEntity.getWorld().getEnabledFeatures())) {
            list.add(DISABLED_TEXT);
        }
        return list;
    }

    private static boolean isSectionVisible(int i, TooltipSection tooltipSection) {
        return (i & tooltipSection.getFlag()) == 0;
    }

    private int getHideFlags() {
        if (this.hasNbt() && this.nbt.contains(HIDE_FLAGS_KEY, 99)) {
            return this.nbt.getInt(HIDE_FLAGS_KEY);
        }
        return 0;
    }

    public void addHideFlag(TooltipSection tooltipSection) {
        NbtCompound nbtCompound = this.getOrCreateNbt();
        nbtCompound.putInt(HIDE_FLAGS_KEY, nbtCompound.getInt(HIDE_FLAGS_KEY) | tooltipSection.getFlag());
    }

    public static void appendEnchantments(List<Text> list, NbtList nbtList) {
        for (int i = 0; i < nbtList.size(); ++i) {
            NbtCompound nbtCompound = nbtList.getCompound(i);
            Registries.ENCHANTMENT.getOrEmpty(EnchantmentHelper.getIdFromNbt(nbtCompound)).ifPresent(enchantment -> list.add(enchantment.getName(EnchantmentHelper.getLevelFromNbt(nbtCompound))));
        }
    }

    private static Collection<Text> parseBlockTag(String string) {
        try {
            return BlockArgumentParser.blockOrTag(Registries.BLOCK.getReadOnlyWrapper(), string, true).map(blockResult -> Lists.newArrayList(blockResult.comp_622().getBlock().getName().formatted(Formatting.field_1063)), tagResult -> tagResult.comp_625().stream().map(registryEntry -> ((Block)registryEntry.comp_349()).getName().formatted(Formatting.field_1063)).collect(Collectors.toList()));
        } catch (CommandSyntaxException commandSyntaxException) {
            return Lists.newArrayList(Text.literal("missingno").formatted(Formatting.field_1063));
        }
    }

    public boolean hasGlint() {
        return this.getItem().hasGlint(this);
    }

    public Rarity getRarity() {
        return this.getItem().getRarity(this);
    }

    public boolean isEnchantable() {
        if (!this.getItem().isEnchantable(this)) {
            return false;
        }
        return !this.hasEnchantments();
    }

    public void addEnchantment(Enchantment enchantment, int i) {
        this.getOrCreateNbt();
        if (!this.nbt.contains(ENCHANTMENTS_KEY, 9)) {
            this.nbt.put(ENCHANTMENTS_KEY, new NbtList());
        }
        NbtList nbtList = this.nbt.getList(ENCHANTMENTS_KEY, 10);
        nbtList.add(EnchantmentHelper.createNbt(EnchantmentHelper.getEnchantmentId(enchantment), (byte)i));
    }

    public boolean hasEnchantments() {
        if (this.nbt != null && this.nbt.contains(ENCHANTMENTS_KEY, 9)) {
            return !this.nbt.getList(ENCHANTMENTS_KEY, 10).isEmpty();
        }
        return false;
    }

    public void setSubNbt(String string, NbtElement nbtElement) {
        this.getOrCreateNbt().put(string, nbtElement);
    }

    public boolean isInFrame() {
        return this.holder instanceof ItemFrameEntity;
    }

    public void setHolder(@Nullable Entity entity) {
        this.holder = entity;
    }

    @Nullable
    public ItemFrameEntity getFrame() {
        return this.holder instanceof ItemFrameEntity ? (ItemFrameEntity)this.getHolder() : null;
    }

    @Nullable
    public Entity getHolder() {
        return !this.isEmpty() ? this.holder : null;
    }

    public int getRepairCost() {
        if (this.hasNbt() && this.nbt.contains(REPAIR_COST_KEY, 3)) {
            return this.nbt.getInt(REPAIR_COST_KEY);
        }
        return 0;
    }

    public void setRepairCost(int i) {
        this.getOrCreateNbt().putInt(REPAIR_COST_KEY, i);
    }

    public Multimap<EntityAttribute, EntityAttributeModifier> getAttributeModifiers(EquipmentSlot equipmentSlot) {
        Multimap<EntityAttribute, EntityAttributeModifier> multimap;
        if (this.hasNbt() && this.nbt.contains("AttributeModifiers", 9)) {
            multimap = HashMultimap.create();
            NbtList nbtList = this.nbt.getList("AttributeModifiers", 10);
            for (int i = 0; i < nbtList.size(); ++i) {
                EntityAttributeModifier entityAttributeModifier;
                Optional<EntityAttribute> optional;
                NbtCompound nbtCompound = nbtList.getCompound(i);
                if (nbtCompound.contains("Slot", 8) && !nbtCompound.getString("Slot").equals(equipmentSlot.getName()) || !(optional = Registries.ATTRIBUTE.getOrEmpty(Identifier.tryParse(nbtCompound.getString("AttributeName")))).isPresent() || (entityAttributeModifier = EntityAttributeModifier.fromNbt(nbtCompound)) == null || entityAttributeModifier.getId().getLeastSignificantBits() == 0L || entityAttributeModifier.getId().getMostSignificantBits() == 0L) continue;
                multimap.put(optional.get(), entityAttributeModifier);
            }
        } else {
            multimap = this.getItem().getAttributeModifiers(equipmentSlot);
        }
        return multimap;
    }

    public void addAttributeModifier(EntityAttribute entityAttribute, EntityAttributeModifier entityAttributeModifier, @Nullable EquipmentSlot equipmentSlot) {
        this.getOrCreateNbt();
        if (!this.nbt.contains("AttributeModifiers", 9)) {
            this.nbt.put("AttributeModifiers", new NbtList());
        }
        NbtList nbtList = this.nbt.getList("AttributeModifiers", 10);
        NbtCompound nbtCompound = entityAttributeModifier.toNbt();
        nbtCompound.putString("AttributeName", Registries.ATTRIBUTE.getId(entityAttribute).toString());
        if (equipmentSlot != null) {
            nbtCompound.putString("Slot", equipmentSlot.getName());
        }
        nbtList.add(nbtCompound);
    }

    public Text toHoverableText() {
        MutableText mutableText = Text.empty().append(this.getName());
        if (this.hasCustomName()) {
            mutableText.formatted(Formatting.field_1056);
        }
        MutableText mutableText2 = Texts.bracketed(mutableText);
        if (!this.isEmpty()) {
            mutableText2.formatted(this.getRarity().formatting).styled(style -> style.withHoverEvent(new HoverEvent(HoverEvent.Action.field_24343, new HoverEvent.ItemStackContent(this))));
        }
        return mutableText2;
    }

    public boolean canPlaceOn(Registry<Block> registry, CachedBlockPosition cachedBlockPosition) {
        if (this.placeChecker == null) {
            this.placeChecker = new BlockPredicatesChecker(CAN_PLACE_ON_KEY);
        }
        return this.placeChecker.check(this, registry, cachedBlockPosition);
    }

    public boolean canDestroy(Registry<Block> registry, CachedBlockPosition cachedBlockPosition) {
        if (this.destroyChecker == null) {
            this.destroyChecker = new BlockPredicatesChecker(CAN_DESTROY_KEY);
        }
        return this.destroyChecker.check(this, registry, cachedBlockPosition);
    }

    public int getBobbingAnimationTime() {
        return this.bobbingAnimationTime;
    }

    public void setBobbingAnimationTime(int i) {
        this.bobbingAnimationTime = i;
    }

    public int getCount() {
        return this.isEmpty() ? 0 : this.count;
    }

    public void setCount(int i) {
        this.count = i;
    }

    public void increment(int i) {
        this.setCount(this.getCount() + i);
    }

    public void decrement(int i) {
        this.increment(-i);
    }

    public void usageTick(World world, LivingEntity livingEntity, int i) {
        this.getItem().usageTick(world, livingEntity, this, i);
    }

    public void onItemEntityDestroyed(ItemEntity itemEntity) {
        this.getItem().onItemEntityDestroyed(itemEntity);
    }

    public boolean isFood() {
        return this.getItem().isFood();
    }

    public SoundEvent getDrinkSound() {
        return this.getItem().getDrinkSound();
    }

    public SoundEvent getEatSound() {
        return this.getItem().getEatSound();
    }

    public static enum TooltipSection {
        field_25768,
        field_25769,
        field_25770,
        field_25771,
        field_25772,
        field_25773,
        field_25774,
        field_41945;

        private final int flag = 1 << this.ordinal();

        public int getFlag() {
            return this.flag;
        }
    }
}


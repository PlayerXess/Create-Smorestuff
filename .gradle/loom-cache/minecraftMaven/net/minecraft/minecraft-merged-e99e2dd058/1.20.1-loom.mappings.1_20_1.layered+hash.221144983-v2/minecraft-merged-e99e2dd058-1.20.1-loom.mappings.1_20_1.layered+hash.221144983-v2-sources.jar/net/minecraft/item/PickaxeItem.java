/*
 * Decompiled with CFR 0.2.1 (FabricMC 53fa44c9).
 */
package net.minecraft.item;

import net.minecraft.item.Item;
import net.minecraft.item.MiningToolItem;
import net.minecraft.item.ToolMaterial;
import net.minecraft.registry.tag.BlockTags;

public class PickaxeItem
extends MiningToolItem {
    public PickaxeItem(ToolMaterial toolMaterial, int i, float f, Item.Settings settings) {
        super(i, f, toolMaterial, BlockTags.field_33715, settings);
    }
}


/*
 * Decompiled with CFR 0.2.1 (FabricMC 53fa44c9).
 */
package net.minecraft.item;

import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.BlockItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemPlacementContext;
import org.jetbrains.annotations.Nullable;

public class OperatorOnlyBlockItem
extends BlockItem {
    public OperatorOnlyBlockItem(Block block, Item.Settings settings) {
        super(block, settings);
    }

    @Override
    @Nullable
    protected BlockState getPlacementState(ItemPlacementContext itemPlacementContext) {
        PlayerEntity playerEntity = itemPlacementContext.getPlayer();
        return playerEntity == null || playerEntity.isCreativeLevelTwoOp() ? super.getPlacementState(itemPlacementContext) : null;
    }
}


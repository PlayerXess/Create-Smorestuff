/*
 * Decompiled with CFR 0.2.1 (FabricMC 53fa44c9).
 */
package net.minecraft.block;

import java.util.List;
import net.minecraft.block.AbstractBlock;
import net.minecraft.block.AbstractRedstoneGateBlock;
import net.minecraft.block.Block;
import net.minecraft.block.BlockEntityProvider;
import net.minecraft.block.BlockState;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.block.entity.ComparatorBlockEntity;
import net.minecraft.block.enums.ComparatorMode;
import net.minecraft.entity.decoration.ItemFrameEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.state.StateManager;
import net.minecraft.state.property.EnumProperty;
import net.minecraft.state.property.Properties;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.random.Random;
import net.minecraft.world.BlockView;
import net.minecraft.world.World;
import net.minecraft.world.tick.TickPriority;
import org.jetbrains.annotations.Nullable;

public class ComparatorBlock
extends AbstractRedstoneGateBlock
implements BlockEntityProvider {
    public static final EnumProperty<ComparatorMode> MODE = Properties.COMPARATOR_MODE;

    public ComparatorBlock(AbstractBlock.Settings settings) {
        super(settings);
        this.setDefaultState((BlockState)((BlockState)((BlockState)((BlockState)this.stateManager.getDefaultState()).with(FACING, Direction.field_11043)).with(POWERED, false)).with(MODE, ComparatorMode.field_12576));
    }

    @Override
    protected int getUpdateDelayInternal(BlockState blockState) {
        return 2;
    }

    @Override
    protected int getOutputLevel(BlockView blockView, BlockPos blockPos, BlockState blockState) {
        BlockEntity blockEntity = blockView.getBlockEntity(blockPos);
        if (blockEntity instanceof ComparatorBlockEntity) {
            return ((ComparatorBlockEntity)blockEntity).getOutputSignal();
        }
        return 0;
    }

    private int calculateOutputSignal(World world, BlockPos blockPos, BlockState blockState) {
        int i = this.getPower(world, blockPos, blockState);
        if (i == 0) {
            return 0;
        }
        int j = this.getMaxInputLevelSides(world, blockPos, blockState);
        if (j > i) {
            return 0;
        }
        if (blockState.get(MODE) == ComparatorMode.field_12578) {
            return i - j;
        }
        return i;
    }

    @Override
    protected boolean hasPower(World world, BlockPos blockPos, BlockState blockState) {
        int i = this.getPower(world, blockPos, blockState);
        if (i == 0) {
            return false;
        }
        int j = this.getMaxInputLevelSides(world, blockPos, blockState);
        if (i > j) {
            return true;
        }
        return i == j && blockState.get(MODE) == ComparatorMode.field_12576;
    }

    @Override
    protected int getPower(World world, BlockPos blockPos, BlockState blockState) {
        int i = super.getPower(world, blockPos, blockState);
        Direction direction = blockState.get(FACING);
        BlockPos blockPos2 = blockPos.offset(direction);
        BlockState blockState2 = world.getBlockState(blockPos2);
        if (blockState2.hasComparatorOutput()) {
            i = blockState2.getComparatorOutput(world, blockPos2);
        } else if (i < 15 && blockState2.isSolidBlock(world, blockPos2)) {
            blockPos2 = blockPos2.offset(direction);
            blockState2 = world.getBlockState(blockPos2);
            ItemFrameEntity itemFrameEntity = this.getAttachedItemFrame(world, direction, blockPos2);
            int j = Math.max(itemFrameEntity == null ? Integer.MIN_VALUE : itemFrameEntity.getComparatorPower(), blockState2.hasComparatorOutput() ? blockState2.getComparatorOutput(world, blockPos2) : Integer.MIN_VALUE);
            if (j != Integer.MIN_VALUE) {
                i = j;
            }
        }
        return i;
    }

    @Nullable
    private ItemFrameEntity getAttachedItemFrame(World world, Direction direction, BlockPos blockPos) {
        List<ItemFrameEntity> list = world.getEntitiesByClass(ItemFrameEntity.class, new Box(blockPos.getX(), blockPos.getY(), blockPos.getZ(), blockPos.getX() + 1, blockPos.getY() + 1, blockPos.getZ() + 1), itemFrameEntity -> itemFrameEntity != null && itemFrameEntity.getHorizontalFacing() == direction);
        if (list.size() == 1) {
            return list.get(0);
        }
        return null;
    }

    @Override
    public ActionResult onUse(BlockState blockState, World world, BlockPos blockPos, PlayerEntity playerEntity, Hand hand, BlockHitResult blockHitResult) {
        if (!playerEntity.getAbilities().allowModifyWorld) {
            return ActionResult.PASS;
        }
        float f = (blockState = (BlockState)blockState.cycle(MODE)).get(MODE) == ComparatorMode.field_12578 ? 0.55f : 0.5f;
        world.playSound(playerEntity, blockPos, SoundEvents.field_14762, SoundCategory.field_15245, 0.3f, f);
        world.setBlockState(blockPos, blockState, 2);
        this.update(world, blockPos, blockState);
        return ActionResult.success(world.isClient);
    }

    @Override
    protected void updatePowered(World world, BlockPos blockPos, BlockState blockState) {
        int j;
        if (world.getBlockTickScheduler().isTicking(blockPos, this)) {
            return;
        }
        int i = this.calculateOutputSignal(world, blockPos, blockState);
        BlockEntity blockEntity = world.getBlockEntity(blockPos);
        int n = j = blockEntity instanceof ComparatorBlockEntity ? ((ComparatorBlockEntity)blockEntity).getOutputSignal() : 0;
        if (i != j || blockState.get(POWERED).booleanValue() != this.hasPower(world, blockPos, blockState)) {
            TickPriority tickPriority = this.isTargetNotAligned(world, blockPos, blockState) ? TickPriority.field_9310 : TickPriority.field_9314;
            world.scheduleBlockTick(blockPos, this, 2, tickPriority);
        }
    }

    private void update(World world, BlockPos blockPos, BlockState blockState) {
        int i = this.calculateOutputSignal(world, blockPos, blockState);
        BlockEntity blockEntity = world.getBlockEntity(blockPos);
        int j = 0;
        if (blockEntity instanceof ComparatorBlockEntity) {
            ComparatorBlockEntity comparatorBlockEntity = (ComparatorBlockEntity)blockEntity;
            j = comparatorBlockEntity.getOutputSignal();
            comparatorBlockEntity.setOutputSignal(i);
        }
        if (j != i || blockState.get(MODE) == ComparatorMode.field_12576) {
            boolean bl = this.hasPower(world, blockPos, blockState);
            boolean bl2 = blockState.get(POWERED);
            if (bl2 && !bl) {
                world.setBlockState(blockPos, (BlockState)blockState.with(POWERED, false), 2);
            } else if (!bl2 && bl) {
                world.setBlockState(blockPos, (BlockState)blockState.with(POWERED, true), 2);
            }
            this.updateTarget(world, blockPos, blockState);
        }
    }

    @Override
    public void scheduledTick(BlockState blockState, ServerWorld serverWorld, BlockPos blockPos, Random random) {
        this.update(serverWorld, blockPos, blockState);
    }

    @Override
    public boolean onSyncedBlockEvent(BlockState blockState, World world, BlockPos blockPos, int i, int j) {
        super.onSyncedBlockEvent(blockState, world, blockPos, i, j);
        BlockEntity blockEntity = world.getBlockEntity(blockPos);
        return blockEntity != null && blockEntity.onSyncedBlockEvent(i, j);
    }

    @Override
    public BlockEntity createBlockEntity(BlockPos blockPos, BlockState blockState) {
        return new ComparatorBlockEntity(blockPos, blockState);
    }

    @Override
    protected void appendProperties(StateManager.Builder<Block, BlockState> builder) {
        builder.add(FACING, MODE, POWERED);
    }
}


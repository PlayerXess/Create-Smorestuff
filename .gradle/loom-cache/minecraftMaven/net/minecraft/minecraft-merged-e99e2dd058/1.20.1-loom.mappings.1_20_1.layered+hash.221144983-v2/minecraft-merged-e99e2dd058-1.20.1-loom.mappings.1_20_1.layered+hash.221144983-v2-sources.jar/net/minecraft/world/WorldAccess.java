/*
 * Decompiled with CFR 0.2.1 (FabricMC 53fa44c9).
 */
package net.minecraft.world;

import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.fluid.Fluid;
import net.minecraft.particle.ParticleEffect;
import net.minecraft.server.MinecraftServer;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvent;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.math.random.Random;
import net.minecraft.world.Difficulty;
import net.minecraft.world.LocalDifficulty;
import net.minecraft.world.LunarWorldView;
import net.minecraft.world.RegistryWorldView;
import net.minecraft.world.WorldProperties;
import net.minecraft.world.block.NeighborUpdater;
import net.minecraft.world.chunk.ChunkManager;
import net.minecraft.world.event.GameEvent;
import net.minecraft.world.tick.OrderedTick;
import net.minecraft.world.tick.QueryableTickScheduler;
import net.minecraft.world.tick.TickPriority;
import org.jetbrains.annotations.Nullable;

public interface WorldAccess
extends RegistryWorldView,
LunarWorldView {
    @Override
    default public long getLunarTime() {
        return this.getLevelProperties().getTimeOfDay();
    }

    public long getTickOrder();

    public QueryableTickScheduler<Block> getBlockTickScheduler();

    private <T> OrderedTick<T> createOrderedTick(BlockPos blockPos, T object, int i, TickPriority tickPriority) {
        return new OrderedTick<T>(object, blockPos, this.getLevelProperties().getTime() + (long)i, tickPriority, this.getTickOrder());
    }

    private <T> OrderedTick<T> createOrderedTick(BlockPos blockPos, T object, int i) {
        return new OrderedTick<T>(object, blockPos, this.getLevelProperties().getTime() + (long)i, this.getTickOrder());
    }

    default public void scheduleBlockTick(BlockPos blockPos, Block block, int i, TickPriority tickPriority) {
        this.getBlockTickScheduler().scheduleTick(this.createOrderedTick(blockPos, block, i, tickPriority));
    }

    default public void scheduleBlockTick(BlockPos blockPos, Block block, int i) {
        this.getBlockTickScheduler().scheduleTick(this.createOrderedTick(blockPos, block, i));
    }

    public QueryableTickScheduler<Fluid> getFluidTickScheduler();

    default public void scheduleFluidTick(BlockPos blockPos, Fluid fluid, int i, TickPriority tickPriority) {
        this.getFluidTickScheduler().scheduleTick(this.createOrderedTick(blockPos, fluid, i, tickPriority));
    }

    default public void scheduleFluidTick(BlockPos blockPos, Fluid fluid, int i) {
        this.getFluidTickScheduler().scheduleTick(this.createOrderedTick(blockPos, fluid, i));
    }

    public WorldProperties getLevelProperties();

    public LocalDifficulty getLocalDifficulty(BlockPos var1);

    @Nullable
    public MinecraftServer getServer();

    default public Difficulty getDifficulty() {
        return this.getLevelProperties().getDifficulty();
    }

    public ChunkManager getChunkManager();

    @Override
    default public boolean isChunkLoaded(int i, int j) {
        return this.getChunkManager().isChunkLoaded(i, j);
    }

    public Random getRandom();

    default public void updateNeighbors(BlockPos blockPos, Block block) {
    }

    default public void replaceWithStateForNeighborUpdate(Direction direction, BlockState blockState, BlockPos blockPos, BlockPos blockPos2, int i, int j) {
        NeighborUpdater.replaceWithStateForNeighborUpdate(this, direction, blockState, blockPos, blockPos2, i, j - 1);
    }

    default public void playSound(@Nullable PlayerEntity playerEntity, BlockPos blockPos, SoundEvent soundEvent, SoundCategory soundCategory) {
        this.playSound(playerEntity, blockPos, soundEvent, soundCategory, 1.0f, 1.0f);
    }

    public void playSound(@Nullable PlayerEntity var1, BlockPos var2, SoundEvent var3, SoundCategory var4, float var5, float var6);

    public void addParticle(ParticleEffect var1, double var2, double var4, double var6, double var8, double var10, double var12);

    public void syncWorldEvent(@Nullable PlayerEntity var1, int var2, BlockPos var3, int var4);

    default public void syncWorldEvent(int i, BlockPos blockPos, int j) {
        this.syncWorldEvent(null, i, blockPos, j);
    }

    public void emitGameEvent(GameEvent var1, Vec3d var2, GameEvent.Emitter var3);

    default public void emitGameEvent(@Nullable Entity entity, GameEvent gameEvent, Vec3d vec3d) {
        this.emitGameEvent(gameEvent, vec3d, new GameEvent.Emitter(entity, null));
    }

    default public void emitGameEvent(@Nullable Entity entity, GameEvent gameEvent, BlockPos blockPos) {
        this.emitGameEvent(gameEvent, blockPos, new GameEvent.Emitter(entity, null));
    }

    default public void emitGameEvent(GameEvent gameEvent, BlockPos blockPos, GameEvent.Emitter emitter) {
        this.emitGameEvent(gameEvent, Vec3d.ofCenter(blockPos), emitter);
    }
}


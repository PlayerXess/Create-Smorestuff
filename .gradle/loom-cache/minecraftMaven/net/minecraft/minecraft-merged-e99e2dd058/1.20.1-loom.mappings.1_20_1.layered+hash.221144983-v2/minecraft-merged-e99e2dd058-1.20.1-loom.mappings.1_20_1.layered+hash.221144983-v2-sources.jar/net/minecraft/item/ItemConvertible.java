/*
 * Decompiled with CFR 0.2.1 (FabricMC 53fa44c9).
 */
package net.minecraft.item;

import net.minecraft.item.Item;

public interface ItemConvertible {
    public Item asItem();
}


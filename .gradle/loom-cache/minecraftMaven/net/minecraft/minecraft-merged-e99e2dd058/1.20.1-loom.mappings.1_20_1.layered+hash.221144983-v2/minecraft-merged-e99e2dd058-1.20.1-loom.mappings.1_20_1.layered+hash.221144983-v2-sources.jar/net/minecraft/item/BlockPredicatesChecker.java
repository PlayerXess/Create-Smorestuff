/*
 * Decompiled with CFR 0.2.1 (FabricMC 53fa44c9).
 */
package net.minecraft.item;

import com.mojang.brigadier.StringReader;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import java.util.Objects;
import net.minecraft.block.Block;
import net.minecraft.block.pattern.CachedBlockPosition;
import net.minecraft.command.argument.BlockPredicateArgumentType;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.nbt.NbtList;
import net.minecraft.registry.Registry;
import org.jetbrains.annotations.Nullable;

public class BlockPredicatesChecker {
    private final String key;
    @Nullable
    private CachedBlockPosition cachedPos;
    private boolean lastResult;
    private boolean nbtAware;

    public BlockPredicatesChecker(String string) {
        this.key = string;
    }

    private static boolean canUseCache(CachedBlockPosition cachedBlockPosition, @Nullable CachedBlockPosition cachedBlockPosition2, boolean bl) {
        if (cachedBlockPosition2 == null || cachedBlockPosition.getBlockState() != cachedBlockPosition2.getBlockState()) {
            return false;
        }
        if (!bl) {
            return true;
        }
        if (cachedBlockPosition.getBlockEntity() == null && cachedBlockPosition2.getBlockEntity() == null) {
            return true;
        }
        if (cachedBlockPosition.getBlockEntity() == null || cachedBlockPosition2.getBlockEntity() == null) {
            return false;
        }
        return Objects.equals(cachedBlockPosition.getBlockEntity().createNbtWithId(), cachedBlockPosition2.getBlockEntity().createNbtWithId());
    }

    public boolean check(ItemStack itemStack, Registry<Block> registry, CachedBlockPosition cachedBlockPosition) {
        if (BlockPredicatesChecker.canUseCache(cachedBlockPosition, this.cachedPos, this.nbtAware)) {
            return this.lastResult;
        }
        this.cachedPos = cachedBlockPosition;
        this.nbtAware = false;
        NbtCompound nbtCompound = itemStack.getNbt();
        if (nbtCompound != null && nbtCompound.contains(this.key, 9)) {
            NbtList nbtList = nbtCompound.getList(this.key, 8);
            for (int i = 0; i < nbtList.size(); ++i) {
                String string = nbtList.getString(i);
                try {
                    BlockPredicateArgumentType.BlockPredicate blockPredicate = BlockPredicateArgumentType.parse(registry.getReadOnlyWrapper(), new StringReader(string));
                    this.nbtAware |= blockPredicate.hasNbt();
                    if (blockPredicate.test(cachedBlockPosition)) {
                        this.lastResult = true;
                        return true;
                    }
                    continue;
                } catch (CommandSyntaxException commandSyntaxException) {
                    // empty catch block
                }
            }
        }
        this.lastResult = false;
        return false;
    }
}


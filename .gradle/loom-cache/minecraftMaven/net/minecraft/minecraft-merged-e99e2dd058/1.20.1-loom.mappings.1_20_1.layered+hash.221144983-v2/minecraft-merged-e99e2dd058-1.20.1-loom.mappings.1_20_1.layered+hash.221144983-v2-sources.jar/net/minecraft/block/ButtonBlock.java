/*
 * Decompiled with CFR 0.2.1 (FabricMC 53fa44c9).
 */
package net.minecraft.block;

import net.minecraft.block.AbstractBlock;
import net.minecraft.block.Block;
import net.minecraft.block.BlockSetType;
import net.minecraft.block.BlockState;
import net.minecraft.block.ShapeContext;
import net.minecraft.block.WallMountedBlock;
import net.minecraft.block.enums.WallMountLocation;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.projectile.PersistentProjectileEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvent;
import net.minecraft.state.StateManager;
import net.minecraft.state.property.BooleanProperty;
import net.minecraft.state.property.Properties;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.random.Random;
import net.minecraft.util.shape.VoxelShape;
import net.minecraft.world.BlockView;
import net.minecraft.world.World;
import net.minecraft.world.WorldAccess;
import net.minecraft.world.event.GameEvent;
import org.jetbrains.annotations.Nullable;

public class ButtonBlock
extends WallMountedBlock {
    public static final BooleanProperty POWERED = Properties.POWERED;
    private static final int field_31040 = 1;
    private static final int field_31041 = 2;
    protected static final int field_31042 = 2;
    protected static final int field_31043 = 3;
    protected static final VoxelShape CEILING_X_SHAPE = Block.createCuboidShape(6.0, 14.0, 5.0, 10.0, 16.0, 11.0);
    protected static final VoxelShape CEILING_Z_SHAPE = Block.createCuboidShape(5.0, 14.0, 6.0, 11.0, 16.0, 10.0);
    protected static final VoxelShape FLOOR_X_SHAPE = Block.createCuboidShape(6.0, 0.0, 5.0, 10.0, 2.0, 11.0);
    protected static final VoxelShape FLOOR_Z_SHAPE = Block.createCuboidShape(5.0, 0.0, 6.0, 11.0, 2.0, 10.0);
    protected static final VoxelShape NORTH_SHAPE = Block.createCuboidShape(5.0, 6.0, 14.0, 11.0, 10.0, 16.0);
    protected static final VoxelShape SOUTH_SHAPE = Block.createCuboidShape(5.0, 6.0, 0.0, 11.0, 10.0, 2.0);
    protected static final VoxelShape WEST_SHAPE = Block.createCuboidShape(14.0, 6.0, 5.0, 16.0, 10.0, 11.0);
    protected static final VoxelShape EAST_SHAPE = Block.createCuboidShape(0.0, 6.0, 5.0, 2.0, 10.0, 11.0);
    protected static final VoxelShape CEILING_X_PRESSED_SHAPE = Block.createCuboidShape(6.0, 15.0, 5.0, 10.0, 16.0, 11.0);
    protected static final VoxelShape CEILING_Z_PRESSED_SHAPE = Block.createCuboidShape(5.0, 15.0, 6.0, 11.0, 16.0, 10.0);
    protected static final VoxelShape FLOOR_X_PRESSED_SHAPE = Block.createCuboidShape(6.0, 0.0, 5.0, 10.0, 1.0, 11.0);
    protected static final VoxelShape FLOOR_Z_PRESSED_SHAPE = Block.createCuboidShape(5.0, 0.0, 6.0, 11.0, 1.0, 10.0);
    protected static final VoxelShape NORTH_PRESSED_SHAPE = Block.createCuboidShape(5.0, 6.0, 15.0, 11.0, 10.0, 16.0);
    protected static final VoxelShape SOUTH_PRESSED_SHAPE = Block.createCuboidShape(5.0, 6.0, 0.0, 11.0, 10.0, 1.0);
    protected static final VoxelShape WEST_PRESSED_SHAPE = Block.createCuboidShape(15.0, 6.0, 5.0, 16.0, 10.0, 11.0);
    protected static final VoxelShape EAST_PRESSED_SHAPE = Block.createCuboidShape(0.0, 6.0, 5.0, 1.0, 10.0, 11.0);
    private final BlockSetType blockSetType;
    private final int pressTicks;
    private final boolean wooden;

    public ButtonBlock(AbstractBlock.Settings settings, BlockSetType blockSetType, int i, boolean bl) {
        super(settings.sounds(blockSetType.comp_1290()));
        this.blockSetType = blockSetType;
        this.setDefaultState((BlockState)((BlockState)((BlockState)((BlockState)this.stateManager.getDefaultState()).with(FACING, Direction.field_11043)).with(POWERED, false)).with(FACE, WallMountLocation.field_12471));
        this.pressTicks = i;
        this.wooden = bl;
    }

    @Override
    public VoxelShape getOutlineShape(BlockState blockState, BlockView blockView, BlockPos blockPos, ShapeContext shapeContext) {
        Direction direction = blockState.get(FACING);
        boolean bl = blockState.get(POWERED);
        switch ((WallMountLocation)blockState.get(FACE)) {
            case field_12475: {
                if (direction.getAxis() == Direction.Axis.field_11048) {
                    return bl ? FLOOR_X_PRESSED_SHAPE : FLOOR_X_SHAPE;
                }
                return bl ? FLOOR_Z_PRESSED_SHAPE : FLOOR_Z_SHAPE;
            }
            case field_12471: {
                return switch (direction) {
                    default -> throw new IncompatibleClassChangeError();
                    case Direction.field_11034 -> {
                        if (bl) {
                            yield EAST_PRESSED_SHAPE;
                        }
                        yield EAST_SHAPE;
                    }
                    case Direction.field_11039 -> {
                        if (bl) {
                            yield WEST_PRESSED_SHAPE;
                        }
                        yield WEST_SHAPE;
                    }
                    case Direction.field_11035 -> {
                        if (bl) {
                            yield SOUTH_PRESSED_SHAPE;
                        }
                        yield SOUTH_SHAPE;
                    }
                    case Direction.field_11043, Direction.field_11036, Direction.field_11033 -> bl ? NORTH_PRESSED_SHAPE : NORTH_SHAPE;
                };
            }
        }
        if (direction.getAxis() == Direction.Axis.field_11048) {
            return bl ? CEILING_X_PRESSED_SHAPE : CEILING_X_SHAPE;
        }
        return bl ? CEILING_Z_PRESSED_SHAPE : CEILING_Z_SHAPE;
    }

    @Override
    public ActionResult onUse(BlockState blockState, World world, BlockPos blockPos, PlayerEntity playerEntity, Hand hand, BlockHitResult blockHitResult) {
        if (blockState.get(POWERED).booleanValue()) {
            return ActionResult.CONSUME;
        }
        this.powerOn(blockState, world, blockPos);
        this.playClickSound(playerEntity, world, blockPos, true);
        world.emitGameEvent((Entity)playerEntity, GameEvent.field_28174, blockPos);
        return ActionResult.success(world.isClient);
    }

    public void powerOn(BlockState blockState, World world, BlockPos blockPos) {
        world.setBlockState(blockPos, (BlockState)blockState.with(POWERED, true), 3);
        this.updateNeighbors(blockState, world, blockPos);
        world.scheduleBlockTick(blockPos, this, this.pressTicks);
    }

    protected void playClickSound(@Nullable PlayerEntity playerEntity, WorldAccess worldAccess, BlockPos blockPos, boolean bl) {
        worldAccess.playSound(bl ? playerEntity : null, blockPos, this.getClickSound(bl), SoundCategory.field_15245);
    }

    protected SoundEvent getClickSound(boolean bl) {
        return bl ? this.blockSetType.comp_1298() : this.blockSetType.comp_1297();
    }

    @Override
    public void onStateReplaced(BlockState blockState, World world, BlockPos blockPos, BlockState blockState2, boolean bl) {
        if (bl || blockState.isOf(blockState2.getBlock())) {
            return;
        }
        if (blockState.get(POWERED).booleanValue()) {
            this.updateNeighbors(blockState, world, blockPos);
        }
        super.onStateReplaced(blockState, world, blockPos, blockState2, bl);
    }

    @Override
    public int getWeakRedstonePower(BlockState blockState, BlockView blockView, BlockPos blockPos, Direction direction) {
        return blockState.get(POWERED) != false ? 15 : 0;
    }

    @Override
    public int getStrongRedstonePower(BlockState blockState, BlockView blockView, BlockPos blockPos, Direction direction) {
        if (blockState.get(POWERED).booleanValue() && ButtonBlock.getDirection(blockState) == direction) {
            return 15;
        }
        return 0;
    }

    @Override
    public boolean emitsRedstonePower(BlockState blockState) {
        return true;
    }

    @Override
    public void scheduledTick(BlockState blockState, ServerWorld serverWorld, BlockPos blockPos, Random random) {
        if (!blockState.get(POWERED).booleanValue()) {
            return;
        }
        this.tryPowerWithProjectiles(blockState, serverWorld, blockPos);
    }

    @Override
    public void onEntityCollision(BlockState blockState, World world, BlockPos blockPos, Entity entity) {
        if (world.isClient || !this.wooden || blockState.get(POWERED).booleanValue()) {
            return;
        }
        this.tryPowerWithProjectiles(blockState, world, blockPos);
    }

    protected void tryPowerWithProjectiles(BlockState blockState, World world, BlockPos blockPos) {
        boolean bl2;
        PersistentProjectileEntity persistentProjectileEntity = this.wooden ? (PersistentProjectileEntity)world.getNonSpectatingEntities(PersistentProjectileEntity.class, blockState.getOutlineShape(world, blockPos).getBoundingBox().offset(blockPos)).stream().findFirst().orElse(null) : null;
        boolean bl = persistentProjectileEntity != null;
        if (bl != (bl2 = blockState.get(POWERED).booleanValue())) {
            world.setBlockState(blockPos, (BlockState)blockState.with(POWERED, bl), 3);
            this.updateNeighbors(blockState, world, blockPos);
            this.playClickSound(null, world, blockPos, bl);
            world.emitGameEvent((Entity)persistentProjectileEntity, bl ? GameEvent.field_28174 : GameEvent.field_28175, blockPos);
        }
        if (bl) {
            world.scheduleBlockTick(new BlockPos(blockPos), this, this.pressTicks);
        }
    }

    private void updateNeighbors(BlockState blockState, World world, BlockPos blockPos) {
        world.updateNeighborsAlways(blockPos, this);
        world.updateNeighborsAlways(blockPos.offset(ButtonBlock.getDirection(blockState).getOpposite()), this);
    }

    @Override
    protected void appendProperties(StateManager.Builder<Block, BlockState> builder) {
        builder.add(FACING, POWERED, FACE);
    }
}


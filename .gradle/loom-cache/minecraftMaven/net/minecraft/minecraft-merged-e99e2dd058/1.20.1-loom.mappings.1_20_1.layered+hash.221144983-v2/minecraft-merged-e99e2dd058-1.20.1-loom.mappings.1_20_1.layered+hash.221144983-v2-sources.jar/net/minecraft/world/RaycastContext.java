/*
 * Decompiled with CFR 0.2.1 (FabricMC 53fa44c9).
 */
package net.minecraft.world;

import java.util.function.Predicate;
import net.minecraft.block.AbstractBlock;
import net.minecraft.block.BlockState;
import net.minecraft.block.ShapeContext;
import net.minecraft.entity.Entity;
import net.minecraft.fluid.FluidState;
import net.minecraft.registry.tag.BlockTags;
import net.minecraft.registry.tag.FluidTags;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.shape.VoxelShape;
import net.minecraft.util.shape.VoxelShapes;
import net.minecraft.world.BlockView;

public class RaycastContext {
    private final Vec3d start;
    private final Vec3d end;
    private final ShapeType shapeType;
    private final FluidHandling fluid;
    private final ShapeContext entityPosition;

    public RaycastContext(Vec3d vec3d, Vec3d vec3d2, ShapeType shapeType, FluidHandling fluidHandling, Entity entity) {
        this.start = vec3d;
        this.end = vec3d2;
        this.shapeType = shapeType;
        this.fluid = fluidHandling;
        this.entityPosition = ShapeContext.of(entity);
    }

    public Vec3d getEnd() {
        return this.end;
    }

    public Vec3d getStart() {
        return this.start;
    }

    public VoxelShape getBlockShape(BlockState blockState, BlockView blockView, BlockPos blockPos) {
        return this.shapeType.get(blockState, blockView, blockPos, this.entityPosition);
    }

    public VoxelShape getFluidShape(FluidState fluidState, BlockView blockView, BlockPos blockPos) {
        return this.fluid.handled(fluidState) ? fluidState.getShape(blockView, blockPos) : VoxelShapes.empty();
    }

    public static enum ShapeType implements ShapeProvider
    {
        field_17558(AbstractBlock.AbstractBlockState::getCollisionShape),
        field_17559(AbstractBlock.AbstractBlockState::getOutlineShape),
        field_23142(AbstractBlock.AbstractBlockState::getCameraCollisionShape),
        field_36337((blockState, blockView, blockPos, shapeContext) -> {
            if (blockState.isIn(BlockTags.field_36327)) {
                return VoxelShapes.fullCube();
            }
            return VoxelShapes.empty();
        });

        private final ShapeProvider provider;

        private ShapeType(ShapeProvider shapeProvider) {
            this.provider = shapeProvider;
        }

        @Override
        public VoxelShape get(BlockState blockState, BlockView blockView, BlockPos blockPos, ShapeContext shapeContext) {
            return this.provider.get(blockState, blockView, blockPos, shapeContext);
        }
    }

    public static enum FluidHandling {
        field_1348(fluidState -> false),
        field_1345(FluidState::isStill),
        field_1347(fluidState -> !fluidState.isEmpty()),
        field_36338(fluidState -> fluidState.isIn(FluidTags.field_15517));

        private final Predicate<FluidState> predicate;

        private FluidHandling(Predicate<FluidState> predicate) {
            this.predicate = predicate;
        }

        public boolean handled(FluidState fluidState) {
            return this.predicate.test(fluidState);
        }
    }

    public static interface ShapeProvider {
        public VoxelShape get(BlockState var1, BlockView var2, BlockPos var3, ShapeContext var4);
    }
}


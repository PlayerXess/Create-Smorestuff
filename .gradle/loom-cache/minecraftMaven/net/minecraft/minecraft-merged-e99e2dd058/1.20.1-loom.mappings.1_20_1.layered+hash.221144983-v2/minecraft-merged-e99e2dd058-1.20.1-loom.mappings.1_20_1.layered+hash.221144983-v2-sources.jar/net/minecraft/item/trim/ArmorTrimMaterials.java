/*
 * Decompiled with CFR 0.2.1 (FabricMC 53fa44c9).
 */
package net.minecraft.item.trim;

import java.util.Map;
import java.util.Optional;
import net.minecraft.item.ArmorMaterials;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.item.trim.ArmorTrimMaterial;
import net.minecraft.registry.DynamicRegistryManager;
import net.minecraft.registry.Registerable;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.text.Style;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import net.minecraft.util.Util;

public class ArmorTrimMaterials {
    public static final RegistryKey<ArmorTrimMaterial> field_42004 = ArmorTrimMaterials.of("quartz");
    public static final RegistryKey<ArmorTrimMaterial> field_42005 = ArmorTrimMaterials.of("iron");
    public static final RegistryKey<ArmorTrimMaterial> field_42006 = ArmorTrimMaterials.of("netherite");
    public static final RegistryKey<ArmorTrimMaterial> field_42007 = ArmorTrimMaterials.of("redstone");
    public static final RegistryKey<ArmorTrimMaterial> field_42008 = ArmorTrimMaterials.of("copper");
    public static final RegistryKey<ArmorTrimMaterial> field_42009 = ArmorTrimMaterials.of("gold");
    public static final RegistryKey<ArmorTrimMaterial> field_42010 = ArmorTrimMaterials.of("emerald");
    public static final RegistryKey<ArmorTrimMaterial> field_42011 = ArmorTrimMaterials.of("diamond");
    public static final RegistryKey<ArmorTrimMaterial> field_42012 = ArmorTrimMaterials.of("lapis");
    public static final RegistryKey<ArmorTrimMaterial> field_42013 = ArmorTrimMaterials.of("amethyst");

    public static void bootstrap(Registerable<ArmorTrimMaterial> registerable) {
        ArmorTrimMaterials.register(registerable, field_42004, Items.field_8155, Style.EMPTY.withColor(14931140), 0.1f);
        ArmorTrimMaterials.register(registerable, field_42005, Items.field_8620, Style.EMPTY.withColor(0xECECEC), 0.2f, Map.of(ArmorMaterials.field_7892, "iron_darker"));
        ArmorTrimMaterials.register(registerable, field_42006, Items.field_22020, Style.EMPTY.withColor(6445145), 0.3f, Map.of(ArmorMaterials.field_21977, "netherite_darker"));
        ArmorTrimMaterials.register(registerable, field_42007, Items.field_8725, Style.EMPTY.withColor(9901575), 0.4f);
        ArmorTrimMaterials.register(registerable, field_42008, Items.field_27022, Style.EMPTY.withColor(11823181), 0.5f);
        ArmorTrimMaterials.register(registerable, field_42009, Items.field_8695, Style.EMPTY.withColor(14594349), 0.6f, Map.of(ArmorMaterials.field_7895, "gold_darker"));
        ArmorTrimMaterials.register(registerable, field_42010, Items.field_8687, Style.EMPTY.withColor(1155126), 0.7f);
        ArmorTrimMaterials.register(registerable, field_42011, Items.field_8477, Style.EMPTY.withColor(7269586), 0.8f, Map.of(ArmorMaterials.field_7889, "diamond_darker"));
        ArmorTrimMaterials.register(registerable, field_42012, Items.field_8759, Style.EMPTY.withColor(4288151), 0.9f);
        ArmorTrimMaterials.register(registerable, field_42013, Items.field_27063, Style.EMPTY.withColor(10116294), 1.0f);
    }

    public static Optional<RegistryEntry.Reference<ArmorTrimMaterial>> get(DynamicRegistryManager dynamicRegistryManager, ItemStack itemStack) {
        return dynamicRegistryManager.get(RegistryKeys.field_42083).streamEntries().filter(reference -> itemStack.itemMatches(((ArmorTrimMaterial)reference.comp_349()).comp_1209())).findFirst();
    }

    private static void register(Registerable<ArmorTrimMaterial> registerable, RegistryKey<ArmorTrimMaterial> registryKey, Item item, Style style, float f) {
        ArmorTrimMaterials.register(registerable, registryKey, item, style, f, Map.of());
    }

    private static void register(Registerable<ArmorTrimMaterial> registerable, RegistryKey<ArmorTrimMaterial> registryKey, Item item, Style style, float f, Map<ArmorMaterials, String> map) {
        ArmorTrimMaterial armorTrimMaterial = ArmorTrimMaterial.of(registryKey.getValue().getPath(), item, f, Text.translatable(Util.createTranslationKey("trim_material", registryKey.getValue())).fillStyle(style), map);
        registerable.register(registryKey, armorTrimMaterial);
    }

    private static RegistryKey<ArmorTrimMaterial> of(String string) {
        return RegistryKey.of(RegistryKeys.field_42083, new Identifier(string));
    }
}


/*
 * Decompiled with CFR 0.2.1 (FabricMC 53fa44c9).
 */
package net.minecraft.world.biome.source.util;

import com.google.common.annotations.VisibleForTesting;
import com.google.common.collect.ImmutableList;
import com.google.common.collect.Lists;
import com.mojang.datafixers.kinds.Applicative;
import com.mojang.datafixers.util.Pair;
import com.mojang.serialization.Codec;
import com.mojang.serialization.DataResult;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.stream.Collectors;
import net.minecraft.util.dynamic.Codecs;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.world.biome.source.BiomeCoords;
import net.minecraft.world.gen.densityfunction.DensityFunction;
import net.minecraft.world.gen.densityfunction.DensityFunctionTypes;
import org.jetbrains.annotations.Nullable;

public class MultiNoiseUtil {
    private static final boolean field_34477 = false;
    private static final float TO_LONG_FACTOR = 10000.0f;
    @VisibleForTesting
    protected static final int HYPERCUBE_DIMENSION = 7;

    public static NoiseValuePoint createNoiseValuePoint(float f, float g, float h, float i, float j, float k) {
        return new NoiseValuePoint(MultiNoiseUtil.toLong(f), MultiNoiseUtil.toLong(g), MultiNoiseUtil.toLong(h), MultiNoiseUtil.toLong(i), MultiNoiseUtil.toLong(j), MultiNoiseUtil.toLong(k));
    }

    public static NoiseHypercube createNoiseHypercube(float f, float g, float h, float i, float j, float k, float l) {
        return new NoiseHypercube(ParameterRange.of(f), ParameterRange.of(g), ParameterRange.of(h), ParameterRange.of(i), ParameterRange.of(j), ParameterRange.of(k), MultiNoiseUtil.toLong(l));
    }

    public static NoiseHypercube createNoiseHypercube(ParameterRange parameterRange, ParameterRange parameterRange2, ParameterRange parameterRange3, ParameterRange parameterRange4, ParameterRange parameterRange5, ParameterRange parameterRange6, float f) {
        return new NoiseHypercube(parameterRange, parameterRange2, parameterRange3, parameterRange4, parameterRange5, parameterRange6, MultiNoiseUtil.toLong(f));
    }

    public static long toLong(float f) {
        return (long)(f * 10000.0f);
    }

    public static float toFloat(long l) {
        return (float)l / 10000.0f;
    }

    public static MultiNoiseSampler createEmptyMultiNoiseSampler() {
        DensityFunction densityFunction = DensityFunctionTypes.zero();
        return new MultiNoiseSampler(densityFunction, densityFunction, densityFunction, densityFunction, densityFunction, densityFunction, List.of());
    }

    public static BlockPos findFittestPosition(List<NoiseHypercube> list, MultiNoiseSampler multiNoiseSampler) {
        return new FittestPositionFinder(list, (MultiNoiseSampler)multiNoiseSampler).bestResult.location();
    }

    public record NoiseValuePoint(long temperatureNoise, long humidityNoise, long continentalnessNoise, long erosionNoise, long depth, long weirdnessNoise) {
        @VisibleForTesting
        protected long[] getNoiseValueList() {
            return new long[]{this.temperatureNoise, this.humidityNoise, this.continentalnessNoise, this.erosionNoise, this.depth, this.weirdnessNoise, 0L};
        }
    }

    public record NoiseHypercube(ParameterRange temperature, ParameterRange humidity, ParameterRange continentalness, ParameterRange erosion, ParameterRange depth, ParameterRange weirdness, long offset) {
        public static final Codec<NoiseHypercube> CODEC = RecordCodecBuilder.create(instance -> instance.group(((MapCodec)ParameterRange.CODEC.fieldOf("temperature")).forGetter(noiseHypercube -> noiseHypercube.temperature), ((MapCodec)ParameterRange.CODEC.fieldOf("humidity")).forGetter(noiseHypercube -> noiseHypercube.humidity), ((MapCodec)ParameterRange.CODEC.fieldOf("continentalness")).forGetter(noiseHypercube -> noiseHypercube.continentalness), ((MapCodec)ParameterRange.CODEC.fieldOf("erosion")).forGetter(noiseHypercube -> noiseHypercube.erosion), ((MapCodec)ParameterRange.CODEC.fieldOf("depth")).forGetter(noiseHypercube -> noiseHypercube.depth), ((MapCodec)ParameterRange.CODEC.fieldOf("weirdness")).forGetter(noiseHypercube -> noiseHypercube.weirdness), ((MapCodec)Codec.floatRange(0.0f, 1.0f).fieldOf("offset")).xmap(MultiNoiseUtil::toLong, MultiNoiseUtil::toFloat).forGetter(noiseHypercube -> noiseHypercube.offset)).apply((Applicative<NoiseHypercube, ?>)instance, NoiseHypercube::new));

        long getSquaredDistance(NoiseValuePoint noiseValuePoint) {
            return MathHelper.square(this.temperature.getDistance(noiseValuePoint.temperatureNoise)) + MathHelper.square(this.humidity.getDistance(noiseValuePoint.humidityNoise)) + MathHelper.square(this.continentalness.getDistance(noiseValuePoint.continentalnessNoise)) + MathHelper.square(this.erosion.getDistance(noiseValuePoint.erosionNoise)) + MathHelper.square(this.depth.getDistance(noiseValuePoint.depth)) + MathHelper.square(this.weirdness.getDistance(noiseValuePoint.weirdnessNoise)) + MathHelper.square(this.offset);
        }

        protected List<ParameterRange> getParameters() {
            return ImmutableList.of(this.temperature, this.humidity, this.continentalness, this.erosion, this.depth, this.weirdness, new ParameterRange(this.offset, this.offset));
        }
    }

    public record ParameterRange(long min, long max) {
        public static final Codec<ParameterRange> CODEC = Codecs.createCodecForPairObject(Codec.floatRange(-2.0f, 2.0f), "min", "max", (float_, float2) -> {
            if (float_.compareTo((Float)float2) > 0) {
                return DataResult.error(() -> "Cannon construct interval, min > max (" + float_ + " > " + float2 + ")");
            }
            return DataResult.success(new ParameterRange(MultiNoiseUtil.toLong(float_.floatValue()), MultiNoiseUtil.toLong(float2.floatValue())));
        }, parameterRange -> Float.valueOf(MultiNoiseUtil.toFloat(parameterRange.min())), parameterRange -> Float.valueOf(MultiNoiseUtil.toFloat(parameterRange.max())));

        public static ParameterRange of(float f) {
            return ParameterRange.of(f, f);
        }

        public static ParameterRange of(float f, float g) {
            if (f > g) {
                throw new IllegalArgumentException("min > max: " + f + " " + g);
            }
            return new ParameterRange(MultiNoiseUtil.toLong(f), MultiNoiseUtil.toLong(g));
        }

        public static ParameterRange combine(ParameterRange parameterRange, ParameterRange parameterRange2) {
            if (parameterRange.min() > parameterRange2.max()) {
                throw new IllegalArgumentException("min > max: " + parameterRange + " " + parameterRange2);
            }
            return new ParameterRange(parameterRange.min(), parameterRange2.max());
        }

        @Override
        public String toString() {
            return this.min == this.max ? String.format(Locale.ROOT, "%d", this.min) : String.format(Locale.ROOT, "[%d-%d]", this.min, this.max);
        }

        public long getDistance(long l) {
            long m = l - this.max;
            long n = this.min - l;
            if (m > 0L) {
                return m;
            }
            return Math.max(n, 0L);
        }

        public long getDistance(ParameterRange parameterRange) {
            long l = parameterRange.min() - this.max;
            long m = this.min - parameterRange.max();
            if (l > 0L) {
                return l;
            }
            return Math.max(m, 0L);
        }

        public ParameterRange combine(@Nullable ParameterRange parameterRange) {
            return parameterRange == null ? this : new ParameterRange(Math.min(this.min, parameterRange.min()), Math.max(this.max, parameterRange.max()));
        }
    }

    public record MultiNoiseSampler(DensityFunction comp_364, DensityFunction comp_365, DensityFunction comp_366, DensityFunction comp_367, DensityFunction comp_368, DensityFunction comp_369, List<NoiseHypercube> comp_370) {
        public NoiseValuePoint sample(int i, int j, int k) {
            int l = BiomeCoords.toBlock(i);
            int m = BiomeCoords.toBlock(j);
            int n = BiomeCoords.toBlock(k);
            DensityFunction.UnblendedNoisePos unblendedNoisePos = new DensityFunction.UnblendedNoisePos(l, m, n);
            return MultiNoiseUtil.createNoiseValuePoint((float)this.comp_364.sample(unblendedNoisePos), (float)this.comp_365.sample(unblendedNoisePos), (float)this.comp_366.sample(unblendedNoisePos), (float)this.comp_367.sample(unblendedNoisePos), (float)this.comp_368.sample(unblendedNoisePos), (float)this.comp_369.sample(unblendedNoisePos));
        }

        public BlockPos findBestSpawnPosition() {
            if (this.comp_370.isEmpty()) {
                return BlockPos.ORIGIN;
            }
            return MultiNoiseUtil.findFittestPosition(this.comp_370, this);
        }
    }

    static class FittestPositionFinder {
        Result bestResult;

        FittestPositionFinder(List<NoiseHypercube> list, MultiNoiseSampler multiNoiseSampler) {
            this.bestResult = FittestPositionFinder.calculateFitness(list, multiNoiseSampler, 0, 0);
            this.findFittest(list, multiNoiseSampler, 2048.0f, 512.0f);
            this.findFittest(list, multiNoiseSampler, 512.0f, 32.0f);
        }

        private void findFittest(List<NoiseHypercube> list, MultiNoiseSampler multiNoiseSampler, float f, float g) {
            float h = 0.0f;
            float i = g;
            BlockPos blockPos = this.bestResult.location();
            while (i <= f) {
                int k;
                int j = blockPos.getX() + (int)(Math.sin(h) * (double)i);
                Result result = FittestPositionFinder.calculateFitness(list, multiNoiseSampler, j, k = blockPos.getZ() + (int)(Math.cos(h) * (double)i));
                if (result.fitness() < this.bestResult.fitness()) {
                    this.bestResult = result;
                }
                if (!((double)(h += g / i) > Math.PI * 2)) continue;
                h = 0.0f;
                i += g;
            }
        }

        private static Result calculateFitness(List<NoiseHypercube> list, MultiNoiseSampler multiNoiseSampler, int i, int j) {
            double d = MathHelper.square(2500.0);
            int k = 2;
            long l = (long)((double)MathHelper.square(10000.0f) * Math.pow((double)(MathHelper.square((long)i) + MathHelper.square((long)j)) / d, 2.0));
            NoiseValuePoint noiseValuePoint = multiNoiseSampler.sample(BiomeCoords.fromBlock(i), 0, BiomeCoords.fromBlock(j));
            NoiseValuePoint noiseValuePoint2 = new NoiseValuePoint(noiseValuePoint.temperatureNoise(), noiseValuePoint.humidityNoise(), noiseValuePoint.continentalnessNoise(), noiseValuePoint.erosionNoise(), 0L, noiseValuePoint.weirdnessNoise());
            long m = Long.MAX_VALUE;
            for (NoiseHypercube noiseHypercube : list) {
                m = Math.min(m, noiseHypercube.getSquaredDistance(noiseValuePoint2));
            }
            return new Result(new BlockPos(i, 0, j), l + m);
        }

        record Result(BlockPos location, long fitness) {
        }
    }

    public static class Entries<T> {
        private final List<Pair<NoiseHypercube, T>> entries;
        private final SearchTree<T> tree;

        public static <T> Codec<Entries<T>> createCodec(MapCodec<T> mapCodec) {
            return Codecs.nonEmptyList(RecordCodecBuilder.create(instance -> instance.group(((MapCodec)NoiseHypercube.CODEC.fieldOf("parameters")).forGetter(Pair::getFirst), mapCodec.forGetter(Pair::getSecond)).apply((Applicative<Pair, ?>)instance, Pair::of)).listOf()).xmap(Entries::new, Entries::getEntries);
        }

        public Entries(List<Pair<NoiseHypercube, T>> list) {
            this.entries = list;
            this.tree = SearchTree.create(list);
        }

        public List<Pair<NoiseHypercube, T>> getEntries() {
            return this.entries;
        }

        public T get(NoiseValuePoint noiseValuePoint) {
            return this.getValue(noiseValuePoint);
        }

        @VisibleForTesting
        public T getValueSimple(NoiseValuePoint noiseValuePoint) {
            Iterator<Pair<NoiseHypercube, T>> iterator = this.getEntries().iterator();
            Pair<NoiseHypercube, T> pair = iterator.next();
            long l = pair.getFirst().getSquaredDistance(noiseValuePoint);
            T object = pair.getSecond();
            while (iterator.hasNext()) {
                Pair<NoiseHypercube, T> pair2 = iterator.next();
                long m = pair2.getFirst().getSquaredDistance(noiseValuePoint);
                if (m >= l) continue;
                l = m;
                object = pair2.getSecond();
            }
            return object;
        }

        public T getValue(NoiseValuePoint noiseValuePoint) {
            return this.getValue(noiseValuePoint, SearchTree.TreeNode::getSquaredDistance);
        }

        protected T getValue(NoiseValuePoint noiseValuePoint, NodeDistanceFunction<T> nodeDistanceFunction) {
            return this.tree.get(noiseValuePoint, nodeDistanceFunction);
        }
    }

    protected static final class SearchTree<T> {
        private static final int MAX_NODES_FOR_SIMPLE_TREE = 6;
        private final TreeNode<T> firstNode;
        private final ThreadLocal<TreeLeafNode<T>> previousResultNode = new ThreadLocal();

        private SearchTree(TreeNode<T> treeNode) {
            this.firstNode = treeNode;
        }

        public static <T> SearchTree<T> create(List<Pair<NoiseHypercube, T>> list) {
            if (list.isEmpty()) {
                throw new IllegalArgumentException("Need at least one value to build the search tree.");
            }
            int i = list.get(0).getFirst().getParameters().size();
            if (i != 7) {
                throw new IllegalStateException("Expecting parameter space to be 7, got " + i);
            }
            List list2 = list.stream().map(pair -> new TreeLeafNode((NoiseHypercube)pair.getFirst(), pair.getSecond())).collect(Collectors.toCollection(ArrayList::new));
            return new SearchTree<T>(SearchTree.createNode(i, list2));
        }

        private static <T> TreeNode<T> createNode(int i, List<? extends TreeNode<T>> list) {
            if (list.isEmpty()) {
                throw new IllegalStateException("Need at least one child to build a node");
            }
            if (list.size() == 1) {
                return list.get(0);
            }
            if (list.size() <= 6) {
                list.sort(Comparator.comparingLong(treeNode -> {
                    long l = 0L;
                    for (int j = 0; j < i; ++j) {
                        ParameterRange parameterRange = treeNode.parameters[j];
                        l += Math.abs((parameterRange.min() + parameterRange.max()) / 2L);
                    }
                    return l;
                }));
                return new TreeBranchNode(list);
            }
            long l = Long.MAX_VALUE;
            int j = -1;
            List<TreeBranchNode<T>> list2 = null;
            for (int k = 0; k < i; ++k) {
                SearchTree.sortTree(list, i, k, false);
                List<TreeBranchNode<T>> list3 = SearchTree.getBatchedTree(list);
                long m = 0L;
                for (TreeBranchNode<T> treeBranchNode2 : list3) {
                    m += SearchTree.getRangeLengthSum(treeBranchNode2.parameters);
                }
                if (l <= m) continue;
                l = m;
                j = k;
                list2 = list3;
            }
            SearchTree.sortTree(list2, i, j, true);
            return new TreeBranchNode(list2.stream().map(treeBranchNode -> SearchTree.createNode(i, Arrays.asList(treeBranchNode.subTree))).collect(Collectors.toList()));
        }

        private static <T> void sortTree(List<? extends TreeNode<T>> list, int i, int j, boolean bl) {
            Comparator<TreeNode<TreeNode<T>>> comparator = SearchTree.createNodeComparator(j, bl);
            for (int k = 1; k < i; ++k) {
                comparator = comparator.thenComparing(SearchTree.createNodeComparator((j + k) % i, bl));
            }
            list.sort(comparator);
        }

        private static <T> Comparator<TreeNode<T>> createNodeComparator(int i, boolean bl) {
            return Comparator.comparingLong(treeNode -> {
                ParameterRange parameterRange = treeNode.parameters[i];
                long l = (parameterRange.min() + parameterRange.max()) / 2L;
                return bl ? Math.abs(l) : l;
            });
        }

        private static <T> List<TreeBranchNode<T>> getBatchedTree(List<? extends TreeNode<T>> list) {
            ArrayList<TreeBranchNode<T>> list2 = Lists.newArrayList();
            ArrayList<TreeNode<T>> list3 = Lists.newArrayList();
            int i = (int)Math.pow(6.0, Math.floor(Math.log((double)list.size() - 0.01) / Math.log(6.0)));
            for (TreeNode<T> treeNode : list) {
                list3.add(treeNode);
                if (list3.size() < i) continue;
                list2.add(new TreeBranchNode(list3));
                list3 = Lists.newArrayList();
            }
            if (!list3.isEmpty()) {
                list2.add(new TreeBranchNode(list3));
            }
            return list2;
        }

        private static long getRangeLengthSum(ParameterRange[] parameterRanges) {
            long l = 0L;
            for (ParameterRange parameterRange : parameterRanges) {
                l += Math.abs(parameterRange.max() - parameterRange.min());
            }
            return l;
        }

        static <T> List<ParameterRange> getEnclosingParameters(List<? extends TreeNode<T>> list) {
            if (list.isEmpty()) {
                throw new IllegalArgumentException("SubTree needs at least one child");
            }
            int i = 7;
            ArrayList<ParameterRange> list2 = Lists.newArrayList();
            for (int j = 0; j < 7; ++j) {
                list2.add(null);
            }
            for (TreeNode<T> treeNode : list) {
                for (int k = 0; k < 7; ++k) {
                    list2.set(k, treeNode.parameters[k].combine((ParameterRange)list2.get(k)));
                }
            }
            return list2;
        }

        public T get(NoiseValuePoint noiseValuePoint, NodeDistanceFunction<T> nodeDistanceFunction) {
            long[] ls = noiseValuePoint.getNoiseValueList();
            TreeLeafNode<T> treeLeafNode = this.firstNode.getResultingNode(ls, this.previousResultNode.get(), nodeDistanceFunction);
            this.previousResultNode.set(treeLeafNode);
            return treeLeafNode.value;
        }

        static abstract class TreeNode<T> {
            protected final ParameterRange[] parameters;

            protected TreeNode(List<ParameterRange> list) {
                this.parameters = list.toArray(new ParameterRange[0]);
            }

            protected abstract TreeLeafNode<T> getResultingNode(long[] var1, @Nullable TreeLeafNode<T> var2, NodeDistanceFunction<T> var3);

            protected long getSquaredDistance(long[] ls) {
                long l = 0L;
                for (int i = 0; i < 7; ++i) {
                    l += MathHelper.square(this.parameters[i].getDistance(ls[i]));
                }
                return l;
            }

            public String toString() {
                return Arrays.toString(this.parameters);
            }
        }

        static final class TreeBranchNode<T>
        extends TreeNode<T> {
            final TreeNode<T>[] subTree;

            protected TreeBranchNode(List<? extends TreeNode<T>> list) {
                this(SearchTree.getEnclosingParameters(list), list);
            }

            protected TreeBranchNode(List<ParameterRange> list, List<? extends TreeNode<T>> list2) {
                super(list);
                this.subTree = list2.toArray(new TreeNode[0]);
            }

            @Override
            protected TreeLeafNode<T> getResultingNode(long[] ls, @Nullable TreeLeafNode<T> treeLeafNode, NodeDistanceFunction<T> nodeDistanceFunction) {
                long l = treeLeafNode == null ? Long.MAX_VALUE : nodeDistanceFunction.getDistance(treeLeafNode, ls);
                TreeLeafNode<T> treeLeafNode2 = treeLeafNode;
                for (TreeNode<T> treeNode : this.subTree) {
                    long n;
                    long m = nodeDistanceFunction.getDistance(treeNode, ls);
                    if (l <= m) continue;
                    TreeLeafNode<T> treeLeafNode3 = treeNode.getResultingNode(ls, treeLeafNode2, nodeDistanceFunction);
                    long l2 = n = treeNode == treeLeafNode3 ? m : nodeDistanceFunction.getDistance(treeLeafNode3, ls);
                    if (l <= n) continue;
                    l = n;
                    treeLeafNode2 = treeLeafNode3;
                }
                return treeLeafNode2;
            }
        }

        static final class TreeLeafNode<T>
        extends TreeNode<T> {
            final T value;

            TreeLeafNode(NoiseHypercube noiseHypercube, T object) {
                super(noiseHypercube.getParameters());
                this.value = object;
            }

            @Override
            protected TreeLeafNode<T> getResultingNode(long[] ls, @Nullable TreeLeafNode<T> treeLeafNode, NodeDistanceFunction<T> nodeDistanceFunction) {
                return this;
            }
        }
    }

    static interface NodeDistanceFunction<T> {
        public long getDistance(SearchTree.TreeNode<T> var1, long[] var2);
    }
}


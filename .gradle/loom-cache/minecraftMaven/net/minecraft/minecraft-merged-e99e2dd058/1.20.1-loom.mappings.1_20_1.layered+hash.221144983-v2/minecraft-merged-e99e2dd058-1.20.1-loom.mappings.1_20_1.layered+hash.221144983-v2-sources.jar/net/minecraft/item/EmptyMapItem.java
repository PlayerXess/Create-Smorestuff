/*
 * Decompiled with CFR 0.2.1 (FabricMC 53fa44c9).
 */
package net.minecraft.item;

import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.FilledMapItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.NetworkSyncedItem;
import net.minecraft.sound.SoundEvents;
import net.minecraft.stat.Stats;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.world.World;

public class EmptyMapItem
extends NetworkSyncedItem {
    public EmptyMapItem(Item.Settings settings) {
        super(settings);
    }

    @Override
    public TypedActionResult<ItemStack> use(World world, PlayerEntity playerEntity, Hand hand) {
        ItemStack itemStack = playerEntity.getStackInHand(hand);
        if (world.isClient) {
            return TypedActionResult.success(itemStack);
        }
        if (!playerEntity.getAbilities().creativeMode) {
            itemStack.decrement(1);
        }
        playerEntity.incrementStat(Stats.field_15372.getOrCreateStat(this));
        playerEntity.getWorld().playSoundFromEntity(null, playerEntity, SoundEvents.field_17484, playerEntity.getSoundCategory(), 1.0f, 1.0f);
        ItemStack itemStack2 = FilledMapItem.createMap(world, playerEntity.getBlockX(), playerEntity.getBlockZ(), (byte)0, true, false);
        if (itemStack.isEmpty()) {
            return TypedActionResult.consume(itemStack2);
        }
        if (!playerEntity.getInventory().insertStack(itemStack2.copy())) {
            playerEntity.dropItem(itemStack2, false);
        }
        return TypedActionResult.consume(itemStack);
    }
}


/*
 * Decompiled with CFR 0.2.1 (FabricMC 53fa44c9).
 */
package net.minecraft.client.color.world;

public class FoliageColors {
    private static int[] colorMap = new int[65536];

    public static void setColorMap(int[] is) {
        colorMap = is;
    }

    public static int getColor(double d, double e) {
        int j = (int)((1.0 - (e *= d)) * 255.0);
        int i = (int)((1.0 - d) * 255.0);
        int k = j << 8 | i;
        if (k >= colorMap.length) {
            return FoliageColors.getDefaultColor();
        }
        return colorMap[k];
    }

    public static int getSpruceColor() {
        return 0x619961;
    }

    public static int getBirchColor() {
        return 8431445;
    }

    public static int getDefaultColor() {
        return 4764952;
    }

    public static int getMangroveColor() {
        return 9619016;
    }
}


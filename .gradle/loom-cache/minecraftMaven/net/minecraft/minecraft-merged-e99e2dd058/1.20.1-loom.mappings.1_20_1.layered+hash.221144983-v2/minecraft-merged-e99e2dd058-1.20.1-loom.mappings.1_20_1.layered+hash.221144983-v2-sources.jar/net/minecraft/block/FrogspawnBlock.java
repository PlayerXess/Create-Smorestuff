/*
 * Decompiled with CFR 0.2.1 (FabricMC 53fa44c9).
 */
package net.minecraft.block;

import com.google.common.annotations.VisibleForTesting;
import net.minecraft.block.AbstractBlock;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.ShapeContext;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.passive.TadpoleEntity;
import net.minecraft.fluid.FluidState;
import net.minecraft.fluid.Fluids;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.random.Random;
import net.minecraft.util.shape.VoxelShape;
import net.minecraft.world.BlockView;
import net.minecraft.world.World;
import net.minecraft.world.WorldAccess;
import net.minecraft.world.WorldView;

public class FrogspawnBlock
extends Block {
    private static final int MIN_TADPOLES = 2;
    private static final int MAX_TADPOLES = 5;
    private static final int MIN_HATCH_TIME = 3600;
    private static final int MAX_HATCH_TIME = 12000;
    protected static final VoxelShape SHAPE = Block.createCuboidShape(0.0, 0.0, 0.0, 16.0, 1.5, 16.0);
    private static int minHatchTime = 3600;
    private static int maxHatchTime = 12000;

    public FrogspawnBlock(AbstractBlock.Settings settings) {
        super(settings);
    }

    @Override
    public VoxelShape getOutlineShape(BlockState blockState, BlockView blockView, BlockPos blockPos, ShapeContext shapeContext) {
        return SHAPE;
    }

    @Override
    public boolean canPlaceAt(BlockState blockState, WorldView worldView, BlockPos blockPos) {
        return FrogspawnBlock.canLayAt(worldView, blockPos.down());
    }

    @Override
    public void onBlockAdded(BlockState blockState, World world, BlockPos blockPos, BlockState blockState2, boolean bl) {
        world.scheduleBlockTick(blockPos, this, FrogspawnBlock.getHatchTime(world.getRandom()));
    }

    private static int getHatchTime(Random random) {
        return random.nextBetweenExclusive(minHatchTime, maxHatchTime);
    }

    @Override
    public BlockState getStateForNeighborUpdate(BlockState blockState, Direction direction, BlockState blockState2, WorldAccess worldAccess, BlockPos blockPos, BlockPos blockPos2) {
        if (!this.canPlaceAt(blockState, worldAccess, blockPos)) {
            return Blocks.field_10124.getDefaultState();
        }
        return super.getStateForNeighborUpdate(blockState, direction, blockState2, worldAccess, blockPos, blockPos2);
    }

    @Override
    public void scheduledTick(BlockState blockState, ServerWorld serverWorld, BlockPos blockPos, Random random) {
        if (!this.canPlaceAt(blockState, serverWorld, blockPos)) {
            this.breakWithoutDrop(serverWorld, blockPos);
            return;
        }
        this.hatch(serverWorld, blockPos, random);
    }

    @Override
    public void onEntityCollision(BlockState blockState, World world, BlockPos blockPos, Entity entity) {
        if (entity.getType().equals(EntityType.field_6089)) {
            this.breakWithoutDrop(world, blockPos);
        }
    }

    private static boolean canLayAt(BlockView blockView, BlockPos blockPos) {
        FluidState fluidState = blockView.getFluidState(blockPos);
        FluidState fluidState2 = blockView.getFluidState(blockPos.up());
        return fluidState.getFluid() == Fluids.WATER && fluidState2.getFluid() == Fluids.field_15906;
    }

    private void hatch(ServerWorld serverWorld, BlockPos blockPos, Random random) {
        this.breakWithoutDrop(serverWorld, blockPos);
        serverWorld.playSound(null, blockPos, SoundEvents.field_37310, SoundCategory.field_15245, 1.0f, 1.0f);
        this.spawnTadpoles(serverWorld, blockPos, random);
    }

    private void breakWithoutDrop(World world, BlockPos blockPos) {
        world.breakBlock(blockPos, false);
    }

    private void spawnTadpoles(ServerWorld serverWorld, BlockPos blockPos, Random random) {
        int i = random.nextBetweenExclusive(2, 6);
        for (int j = 1; j <= i; ++j) {
            TadpoleEntity tadpoleEntity = EntityType.field_37420.create(serverWorld);
            if (tadpoleEntity == null) continue;
            double d = (double)blockPos.getX() + this.getSpawnOffset(random);
            double e = (double)blockPos.getZ() + this.getSpawnOffset(random);
            int k = random.nextBetweenExclusive(1, 361);
            tadpoleEntity.refreshPositionAndAngles(d, (double)blockPos.getY() - 0.5, e, k, 0.0f);
            tadpoleEntity.setPersistent();
            serverWorld.spawnEntity(tadpoleEntity);
        }
    }

    private double getSpawnOffset(Random random) {
        double d = TadpoleEntity.WIDTH / 2.0f;
        return MathHelper.clamp(random.nextDouble(), d, 1.0 - d);
    }

    @VisibleForTesting
    public static void setHatchTimeRange(int i, int j) {
        minHatchTime = i;
        maxHatchTime = j;
    }

    @VisibleForTesting
    public static void resetHatchTimeRange() {
        minHatchTime = 3600;
        maxHatchTime = 12000;
    }
}


/*
 * Decompiled with CFR 0.2.1 (FabricMC 53fa44c9).
 */
package net.minecraft.item;

import java.util.function.Predicate;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.enchantment.Enchantments;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.projectile.PersistentProjectileEntity;
import net.minecraft.item.ArrowItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.item.RangedWeaponItem;
import net.minecraft.item.Vanishable;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.stat.Stats;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.util.UseAction;
import net.minecraft.world.World;

public class BowItem
extends RangedWeaponItem
implements Vanishable {
    public static final int TICKS_PER_SECOND = 20;
    public static final int RANGE = 15;

    public BowItem(Item.Settings settings) {
        super(settings);
    }

    @Override
    public void onStoppedUsing(ItemStack itemStack, World world, LivingEntity livingEntity, int i) {
        boolean bl2;
        int j;
        float f;
        if (!(livingEntity instanceof PlayerEntity)) {
            return;
        }
        PlayerEntity playerEntity = (PlayerEntity)livingEntity;
        boolean bl = playerEntity.getAbilities().creativeMode || EnchantmentHelper.getLevel(Enchantments.field_9125, itemStack) > 0;
        ItemStack itemStack2 = playerEntity.getProjectileType(itemStack);
        if (itemStack2.isEmpty() && !bl) {
            return;
        }
        if (itemStack2.isEmpty()) {
            itemStack2 = new ItemStack(Items.field_8107);
        }
        if ((double)(f = BowItem.getPullProgress(j = this.getMaxUseTime(itemStack) - i)) < 0.1) {
            return;
        }
        boolean bl3 = bl2 = bl && itemStack2.isOf(Items.field_8107);
        if (!world.isClient) {
            int l;
            int k;
            ArrowItem arrowItem = (ArrowItem)(itemStack2.getItem() instanceof ArrowItem ? itemStack2.getItem() : Items.field_8107);
            PersistentProjectileEntity persistentProjectileEntity = arrowItem.createArrow(world, itemStack2, playerEntity);
            persistentProjectileEntity.setVelocity(playerEntity, playerEntity.getPitch(), playerEntity.getYaw(), 0.0f, f * 3.0f, 1.0f);
            if (f == 1.0f) {
                persistentProjectileEntity.setCritical(true);
            }
            if ((k = EnchantmentHelper.getLevel(Enchantments.field_9103, itemStack)) > 0) {
                persistentProjectileEntity.setDamage(persistentProjectileEntity.getDamage() + (double)k * 0.5 + 0.5);
            }
            if ((l = EnchantmentHelper.getLevel(Enchantments.field_9116, itemStack)) > 0) {
                persistentProjectileEntity.setPunch(l);
            }
            if (EnchantmentHelper.getLevel(Enchantments.field_9126, itemStack) > 0) {
                persistentProjectileEntity.setOnFireFor(100);
            }
            itemStack.damage(1, playerEntity, playerEntity2 -> playerEntity2.sendToolBreakStatus(playerEntity.getActiveHand()));
            if (bl2 || playerEntity.getAbilities().creativeMode && (itemStack2.isOf(Items.field_8236) || itemStack2.isOf(Items.field_8087))) {
                persistentProjectileEntity.pickupType = PersistentProjectileEntity.PickupPermission.field_7594;
            }
            world.spawnEntity(persistentProjectileEntity);
        }
        world.playSound(null, playerEntity.getX(), playerEntity.getY(), playerEntity.getZ(), SoundEvents.field_14600, SoundCategory.field_15248, 1.0f, 1.0f / (world.getRandom().nextFloat() * 0.4f + 1.2f) + f * 0.5f);
        if (!bl2 && !playerEntity.getAbilities().creativeMode) {
            itemStack2.decrement(1);
            if (itemStack2.isEmpty()) {
                playerEntity.getInventory().removeOne(itemStack2);
            }
        }
        playerEntity.incrementStat(Stats.field_15372.getOrCreateStat(this));
    }

    public static float getPullProgress(int i) {
        float f = (float)i / 20.0f;
        if ((f = (f * f + f * 2.0f) / 3.0f) > 1.0f) {
            f = 1.0f;
        }
        return f;
    }

    @Override
    public int getMaxUseTime(ItemStack itemStack) {
        return 72000;
    }

    @Override
    public UseAction getUseAction(ItemStack itemStack) {
        return UseAction.field_8953;
    }

    @Override
    public TypedActionResult<ItemStack> use(World world, PlayerEntity playerEntity, Hand hand) {
        boolean bl;
        ItemStack itemStack = playerEntity.getStackInHand(hand);
        boolean bl2 = bl = !playerEntity.getProjectileType(itemStack).isEmpty();
        if (playerEntity.getAbilities().creativeMode || bl) {
            playerEntity.setCurrentHand(hand);
            return TypedActionResult.consume(itemStack);
        }
        return TypedActionResult.fail(itemStack);
    }

    @Override
    public Predicate<ItemStack> getProjectiles() {
        return BOW_PROJECTILES;
    }

    @Override
    public int getRange() {
        return 15;
    }
}


/*
 * Decompiled with CFR 0.2.1 (FabricMC 53fa44c9).
 */
package net.minecraft.screen.slot;

import com.mojang.datafixers.util.Pair;
import io.github.fabricators_of_create.porting_lib.extensions.extensions.SlotExtensions;
import java.util.Optional;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.inventory.Inventory;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Identifier;
import org.jetbrains.annotations.Nullable;

public class Slot
implements SlotExtensions {
    private final int index;
    public final Inventory inventory;
    public int id;
    public final int x;
    public final int y;

    public Slot(Inventory inventory, int i, int j, int k) {
        this.inventory = inventory;
        this.index = i;
        this.x = j;
        this.y = k;
    }

    public void onQuickTransfer(ItemStack itemStack, ItemStack itemStack2) {
        int i = itemStack2.getCount() - itemStack.getCount();
        if (i > 0) {
            this.onCrafted(itemStack2, i);
        }
    }

    protected void onCrafted(ItemStack itemStack, int i) {
    }

    protected void onTake(int i) {
    }

    protected void onCrafted(ItemStack itemStack) {
    }

    public void onTakeItem(PlayerEntity playerEntity, ItemStack itemStack) {
        this.markDirty();
    }

    public boolean canInsert(ItemStack itemStack) {
        return true;
    }

    public ItemStack getStack() {
        return this.inventory.getStack(this.index);
    }

    public boolean hasStack() {
        return !this.getStack().isEmpty();
    }

    public void setStack(ItemStack itemStack) {
        this.setStackNoCallbacks(itemStack);
    }

    public void setStackNoCallbacks(ItemStack itemStack) {
        this.inventory.setStack(this.index, itemStack);
        this.markDirty();
    }

    public void markDirty() {
        this.inventory.markDirty();
    }

    public int getMaxItemCount() {
        return this.inventory.getMaxCountPerStack();
    }

    public int getMaxItemCount(ItemStack itemStack) {
        return Math.min(this.getMaxItemCount(), itemStack.getMaxCount());
    }

    @Nullable
    public Pair<Identifier, Identifier> getBackgroundSprite() {
        return null;
    }

    public ItemStack takeStack(int i) {
        return this.inventory.removeStack(this.index, i);
    }

    public boolean canTakeItems(PlayerEntity playerEntity) {
        return true;
    }

    public boolean isEnabled() {
        return true;
    }

    public Optional<ItemStack> tryTakeStackRange(int i, int j, PlayerEntity playerEntity) {
        if (!this.canTakeItems(playerEntity)) {
            return Optional.empty();
        }
        if (!this.canTakePartial(playerEntity) && j < this.getStack().getCount()) {
            return Optional.empty();
        }
        ItemStack itemStack = this.takeStack(i = Math.min(i, j));
        if (itemStack.isEmpty()) {
            return Optional.empty();
        }
        if (this.getStack().isEmpty()) {
            this.setStack(ItemStack.EMPTY);
        }
        return Optional.of(itemStack);
    }

    public ItemStack takeStackRange(int i, int j, PlayerEntity playerEntity) {
        Optional<ItemStack> optional = this.tryTakeStackRange(i, j, playerEntity);
        optional.ifPresent(itemStack -> this.onTakeItem(playerEntity, (ItemStack)itemStack));
        return optional.orElse(ItemStack.EMPTY);
    }

    public ItemStack insertStack(ItemStack itemStack) {
        return this.insertStack(itemStack, itemStack.getCount());
    }

    public ItemStack insertStack(ItemStack itemStack, int i) {
        if (itemStack.isEmpty() || !this.canInsert(itemStack)) {
            return itemStack;
        }
        ItemStack itemStack2 = this.getStack();
        int j = Math.min(Math.min(i, itemStack.getCount()), this.getMaxItemCount(itemStack) - itemStack2.getCount());
        if (itemStack2.isEmpty()) {
            this.setStack(itemStack.split(j));
        } else if (ItemStack.canCombine(itemStack2, itemStack)) {
            itemStack.decrement(j);
            itemStack2.increment(j);
            this.setStack(itemStack2);
        }
        return itemStack;
    }

    public boolean canTakePartial(PlayerEntity playerEntity) {
        return this.canTakeItems(playerEntity) && this.canInsert(this.getStack());
    }

    public int getIndex() {
        return this.index;
    }

    public boolean canBeHighlighted() {
        return true;
    }
}


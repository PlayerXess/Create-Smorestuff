/*
 * Decompiled with CFR 0.2.1 (FabricMC 53fa44c9).
 */
package net.minecraft.util;

import com.mojang.serialization.Codec;
import net.minecraft.text.Text;
import net.minecraft.util.BlockRotation;
import net.minecraft.util.StringIdentifiable;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.DirectionTransformation;

public enum BlockMirror implements StringIdentifiable
{
    field_11302("none", DirectionTransformation.field_23292),
    field_11300("left_right", DirectionTransformation.field_23267),
    field_11301("front_back", DirectionTransformation.field_23323);

    public static final Codec<BlockMirror> CODEC;
    private final String id;
    private final Text name;
    private final DirectionTransformation directionTransformation;

    private BlockMirror(String string2, DirectionTransformation directionTransformation) {
        this.id = string2;
        this.name = Text.translatable("mirror." + string2);
        this.directionTransformation = directionTransformation;
    }

    public int mirror(int i, int j) {
        int k = j / 2;
        int l = i > k ? i - j : i;
        switch (this) {
            case field_11301: {
                return (j - l) % j;
            }
            case field_11300: {
                return (k - l + j) % j;
            }
        }
        return i;
    }

    public BlockRotation getRotation(Direction direction) {
        Direction.Axis axis = direction.getAxis();
        return this == field_11300 && axis == Direction.Axis.field_11051 || this == field_11301 && axis == Direction.Axis.field_11048 ? BlockRotation.field_11464 : BlockRotation.field_11467;
    }

    public Direction apply(Direction direction) {
        if (this == field_11301 && direction.getAxis() == Direction.Axis.field_11048) {
            return direction.getOpposite();
        }
        if (this == field_11300 && direction.getAxis() == Direction.Axis.field_11051) {
            return direction.getOpposite();
        }
        return direction;
    }

    public DirectionTransformation getDirectionTransformation() {
        return this.directionTransformation;
    }

    public Text getName() {
        return this.name;
    }

    @Override
    public String asString() {
        return this.id;
    }

    static {
        CODEC = StringIdentifiable.createCodec(BlockMirror::values);
    }
}


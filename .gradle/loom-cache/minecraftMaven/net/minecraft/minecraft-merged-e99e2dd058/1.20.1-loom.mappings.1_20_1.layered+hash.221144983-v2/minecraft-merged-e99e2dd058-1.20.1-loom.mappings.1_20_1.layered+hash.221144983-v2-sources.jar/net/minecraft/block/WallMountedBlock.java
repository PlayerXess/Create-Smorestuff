/*
 * Decompiled with CFR 0.2.1 (FabricMC 53fa44c9).
 */
package net.minecraft.block;

import net.minecraft.block.AbstractBlock;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.HorizontalFacingBlock;
import net.minecraft.block.enums.WallMountLocation;
import net.minecraft.item.ItemPlacementContext;
import net.minecraft.state.property.EnumProperty;
import net.minecraft.state.property.Properties;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.world.WorldAccess;
import net.minecraft.world.WorldView;
import org.jetbrains.annotations.Nullable;

public class WallMountedBlock
extends HorizontalFacingBlock {
    public static final EnumProperty<WallMountLocation> FACE = Properties.WALL_MOUNT_LOCATION;

    public WallMountedBlock(AbstractBlock.Settings settings) {
        super(settings);
    }

    @Override
    public boolean canPlaceAt(BlockState blockState, WorldView worldView, BlockPos blockPos) {
        return WallMountedBlock.canPlaceAt(worldView, blockPos, WallMountedBlock.getDirection(blockState).getOpposite());
    }

    public static boolean canPlaceAt(WorldView worldView, BlockPos blockPos, Direction direction) {
        BlockPos blockPos2 = blockPos.offset(direction);
        return worldView.getBlockState(blockPos2).isSideSolidFullSquare(worldView, blockPos2, direction.getOpposite());
    }

    @Override
    @Nullable
    public BlockState getPlacementState(ItemPlacementContext itemPlacementContext) {
        for (Direction direction : itemPlacementContext.getPlacementDirections()) {
            BlockState blockState = direction.getAxis() == Direction.Axis.field_11052 ? (BlockState)((BlockState)this.getDefaultState().with(FACE, direction == Direction.field_11036 ? WallMountLocation.field_12473 : WallMountLocation.field_12475)).with(FACING, itemPlacementContext.getHorizontalPlayerFacing()) : (BlockState)((BlockState)this.getDefaultState().with(FACE, WallMountLocation.field_12471)).with(FACING, direction.getOpposite());
            if (!blockState.canPlaceAt(itemPlacementContext.getWorld(), itemPlacementContext.getBlockPos())) continue;
            return blockState;
        }
        return null;
    }

    @Override
    public BlockState getStateForNeighborUpdate(BlockState blockState, Direction direction, BlockState blockState2, WorldAccess worldAccess, BlockPos blockPos, BlockPos blockPos2) {
        if (WallMountedBlock.getDirection(blockState).getOpposite() == direction && !blockState.canPlaceAt(worldAccess, blockPos)) {
            return Blocks.field_10124.getDefaultState();
        }
        return super.getStateForNeighborUpdate(blockState, direction, blockState2, worldAccess, blockPos, blockPos2);
    }

    protected static Direction getDirection(BlockState blockState) {
        switch (blockState.get(FACE)) {
            case field_12473: {
                return Direction.field_11033;
            }
            case field_12475: {
                return Direction.field_11036;
            }
        }
        return blockState.get(FACING);
    }
}


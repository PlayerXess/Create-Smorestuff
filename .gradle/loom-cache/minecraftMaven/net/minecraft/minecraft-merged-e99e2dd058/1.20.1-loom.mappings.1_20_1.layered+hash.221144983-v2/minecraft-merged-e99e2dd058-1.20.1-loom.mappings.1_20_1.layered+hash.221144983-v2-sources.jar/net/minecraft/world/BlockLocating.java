/*
 * Decompiled with CFR 0.2.1 (FabricMC 53fa44c9).
 */
package net.minecraft.world;

import com.google.common.annotations.VisibleForTesting;
import com.mojang.datafixers.util.Pair;
import it.unimi.dsi.fastutil.ints.IntArrayList;
import java.util.Optional;
import java.util.function.Predicate;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.world.BlockView;

public class BlockLocating {
    public static Rectangle getLargestRectangle(BlockPos blockPos, Direction.Axis axis, int i, Direction.Axis axis2, int j, Predicate<BlockPos> predicate) {
        IntBounds intBounds;
        int o;
        BlockPos.Mutable mutable = blockPos.mutableCopy();
        Direction direction = Direction.get(Direction.AxisDirection.field_11060, axis);
        Direction direction2 = direction.getOpposite();
        Direction direction3 = Direction.get(Direction.AxisDirection.field_11060, axis2);
        Direction direction4 = direction3.getOpposite();
        int k = BlockLocating.moveWhile(predicate, mutable.set(blockPos), direction, i);
        int l = BlockLocating.moveWhile(predicate, mutable.set(blockPos), direction2, i);
        int m = k;
        IntBounds[] intBoundss = new IntBounds[m + 1 + l];
        intBoundss[m] = new IntBounds(BlockLocating.moveWhile(predicate, mutable.set(blockPos), direction3, j), BlockLocating.moveWhile(predicate, mutable.set(blockPos), direction4, j));
        int n = intBoundss[m].min;
        for (o = 1; o <= k; ++o) {
            intBounds = intBoundss[m - (o - 1)];
            intBoundss[m - o] = new IntBounds(BlockLocating.moveWhile(predicate, mutable.set(blockPos).move(direction, o), direction3, intBounds.min), BlockLocating.moveWhile(predicate, mutable.set(blockPos).move(direction, o), direction4, intBounds.max));
        }
        for (o = 1; o <= l; ++o) {
            intBounds = intBoundss[m + o - 1];
            intBoundss[m + o] = new IntBounds(BlockLocating.moveWhile(predicate, mutable.set(blockPos).move(direction2, o), direction3, intBounds.min), BlockLocating.moveWhile(predicate, mutable.set(blockPos).move(direction2, o), direction4, intBounds.max));
        }
        o = 0;
        int p = 0;
        int q = 0;
        int r = 0;
        int[] is = new int[intBoundss.length];
        for (int s = n; s >= 0; --s) {
            int v;
            int u;
            IntBounds intBounds2;
            for (int t = 0; t < intBoundss.length; ++t) {
                intBounds2 = intBoundss[t];
                u = n - intBounds2.min;
                v = n + intBounds2.max;
                is[t] = s >= u && s <= v ? v + 1 - s : 0;
            }
            Pair<IntBounds, Integer> pair = BlockLocating.findLargestRectangle(is);
            intBounds2 = pair.getFirst();
            u = 1 + intBounds2.max - intBounds2.min;
            v = pair.getSecond();
            if (u * v <= q * r) continue;
            o = intBounds2.min;
            p = s;
            q = u;
            r = v;
        }
        return new Rectangle(blockPos.offset(axis, o - m).offset(axis2, p - n), q, r);
    }

    private static int moveWhile(Predicate<BlockPos> predicate, BlockPos.Mutable mutable, Direction direction, int i) {
        int j;
        for (j = 0; j < i && predicate.test(mutable.move(direction)); ++j) {
        }
        return j;
    }

    @VisibleForTesting
    static Pair<IntBounds, Integer> findLargestRectangle(int[] is) {
        int i = 0;
        int j = 0;
        int k = 0;
        IntArrayList intStack = new IntArrayList();
        intStack.push(0);
        for (int l = 1; l <= is.length; ++l) {
            int m;
            int n = m = l == is.length ? 0 : is[l];
            while (!intStack.isEmpty()) {
                int n2 = is[intStack.topInt()];
                if (m >= n2) {
                    intStack.push(l);
                    break;
                }
                intStack.popInt();
                int o = intStack.isEmpty() ? 0 : intStack.topInt() + 1;
                if (n2 * (l - o) <= k * (j - i)) continue;
                j = l;
                i = o;
                k = n2;
            }
            if (!intStack.isEmpty()) continue;
            intStack.push(l);
        }
        return new Pair<IntBounds, Integer>(new IntBounds(i, j - 1), k);
    }

    public static Optional<BlockPos> findColumnEnd(BlockView blockView, BlockPos blockPos, Block block, Direction direction, Block block2) {
        BlockState blockState;
        BlockPos.Mutable mutable = blockPos.mutableCopy();
        do {
            mutable.move(direction);
        } while ((blockState = blockView.getBlockState(mutable)).isOf(block));
        if (blockState.isOf(block2)) {
            return Optional.of(mutable);
        }
        return Optional.empty();
    }

    public static class IntBounds {
        public final int min;
        public final int max;

        public IntBounds(int i, int j) {
            this.min = i;
            this.max = j;
        }

        public String toString() {
            return "IntBounds{min=" + this.min + ", max=" + this.max + "}";
        }
    }

    public static class Rectangle {
        public final BlockPos lowerLeft;
        public final int width;
        public final int height;

        public Rectangle(BlockPos blockPos, int i, int j) {
            this.lowerLeft = blockPos;
            this.width = i;
            this.height = j;
        }
    }
}


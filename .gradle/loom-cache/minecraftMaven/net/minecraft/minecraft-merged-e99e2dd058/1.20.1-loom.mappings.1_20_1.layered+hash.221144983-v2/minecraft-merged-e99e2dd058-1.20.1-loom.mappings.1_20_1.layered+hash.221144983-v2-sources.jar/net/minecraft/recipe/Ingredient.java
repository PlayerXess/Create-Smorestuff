/*
 * Decompiled with CFR 0.2.1 (FabricMC 53fa44c9).
 */
package net.minecraft.recipe;

import com.google.common.collect.Lists;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParseException;
import com.google.gson.JsonSyntaxException;
import it.unimi.dsi.fastutil.ints.IntArrayList;
import it.unimi.dsi.fastutil.ints.IntComparators;
import it.unimi.dsi.fastutil.ints.IntList;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.function.Predicate;
import java.util.stream.Stream;
import java.util.stream.StreamSupport;
import net.fabricmc.fabric.api.recipe.v1.ingredient.FabricIngredient;
import net.minecraft.item.Item;
import net.minecraft.item.ItemConvertible;
import net.minecraft.item.ItemStack;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.recipe.RecipeMatcher;
import net.minecraft.recipe.ShapedRecipe;
import net.minecraft.registry.Registries;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.registry.tag.TagKey;
import net.minecraft.util.Identifier;
import net.minecraft.util.JsonHelper;
import org.jetbrains.annotations.Nullable;

public class Ingredient
implements Predicate<ItemStack>,
FabricIngredient {
    public static final Ingredient EMPTY = new Ingredient(Stream.empty());
    public final Entry[] entries;
    @Nullable
    private ItemStack[] matchingStacks;
    @Nullable
    private IntList ids;

    public Ingredient(Stream<? extends Entry> stream) {
        this.entries = (Entry[])stream.toArray(Entry[]::new);
    }

    public ItemStack[] getMatchingStacks() {
        if (this.matchingStacks == null) {
            this.matchingStacks = (ItemStack[])Arrays.stream(this.entries).flatMap(entry -> entry.getStacks().stream()).distinct().toArray(ItemStack[]::new);
        }
        return this.matchingStacks;
    }

    @Override
    public boolean test(@Nullable ItemStack itemStack) {
        if (itemStack == null) {
            return false;
        }
        if (this.isEmpty()) {
            return itemStack.isEmpty();
        }
        for (ItemStack itemStack2 : this.getMatchingStacks()) {
            if (!itemStack2.isOf(itemStack.getItem())) continue;
            return true;
        }
        return false;
    }

    public IntList getMatchingItemIds() {
        if (this.ids == null) {
            ItemStack[] itemStacks = this.getMatchingStacks();
            this.ids = new IntArrayList(itemStacks.length);
            for (ItemStack itemStack : itemStacks) {
                this.ids.add(RecipeMatcher.getItemId(itemStack));
            }
            this.ids.sort(IntComparators.NATURAL_COMPARATOR);
        }
        return this.ids;
    }

    public void write(PacketByteBuf packetByteBuf) {
        packetByteBuf.writeCollection(Arrays.asList(this.getMatchingStacks()), PacketByteBuf::writeItemStack);
    }

    public JsonElement toJson() {
        if (this.entries.length == 1) {
            return this.entries[0].toJson();
        }
        JsonArray jsonArray = new JsonArray();
        for (Entry entry : this.entries) {
            jsonArray.add(entry.toJson());
        }
        return jsonArray;
    }

    public boolean isEmpty() {
        return this.entries.length == 0;
    }

    public static Ingredient ofEntries(Stream<? extends Entry> stream) {
        Ingredient ingredient = new Ingredient(stream);
        return ingredient.isEmpty() ? EMPTY : ingredient;
    }

    public static Ingredient empty() {
        return EMPTY;
    }

    public static Ingredient ofItems(ItemConvertible ... itemConvertibles) {
        return Ingredient.ofStacks(Arrays.stream(itemConvertibles).map(ItemStack::new));
    }

    public static Ingredient ofStacks(ItemStack ... itemStacks) {
        return Ingredient.ofStacks(Arrays.stream(itemStacks));
    }

    public static Ingredient ofStacks(Stream<ItemStack> stream) {
        return Ingredient.ofEntries(stream.filter(itemStack -> !itemStack.isEmpty()).map(StackEntry::new));
    }

    public static Ingredient fromTag(TagKey<Item> tagKey) {
        return Ingredient.ofEntries(Stream.of(new TagEntry(tagKey)));
    }

    public static Ingredient fromPacket(PacketByteBuf packetByteBuf) {
        return Ingredient.ofEntries(packetByteBuf.readList(PacketByteBuf::readItemStack).stream().map(StackEntry::new));
    }

    public static Ingredient fromJson(@Nullable JsonElement jsonElement) {
        return Ingredient.fromJson(jsonElement, true);
    }

    public static Ingredient fromJson(@Nullable JsonElement jsonElement2, boolean bl) {
        if (jsonElement2 == null || jsonElement2.isJsonNull()) {
            throw new JsonSyntaxException("Item cannot be null");
        }
        if (jsonElement2.isJsonObject()) {
            return Ingredient.ofEntries(Stream.of(Ingredient.entryFromJson(jsonElement2.getAsJsonObject())));
        }
        if (jsonElement2.isJsonArray()) {
            JsonArray jsonArray = jsonElement2.getAsJsonArray();
            if (jsonArray.size() == 0 && !bl) {
                throw new JsonSyntaxException("Item array cannot be empty, at least one item must be defined");
            }
            return Ingredient.ofEntries(StreamSupport.stream(jsonArray.spliterator(), false).map(jsonElement -> Ingredient.entryFromJson(JsonHelper.asObject(jsonElement, "item"))));
        }
        throw new JsonSyntaxException("Expected item to be object or array of objects");
    }

    public static Entry entryFromJson(JsonObject jsonObject) {
        if (jsonObject.has("item") && jsonObject.has("tag")) {
            throw new JsonParseException("An ingredient entry is either a tag or an item, not both");
        }
        if (jsonObject.has("item")) {
            Item item = ShapedRecipe.getItem(jsonObject);
            return new StackEntry(new ItemStack(item));
        }
        if (jsonObject.has("tag")) {
            Identifier identifier = new Identifier(JsonHelper.getString(jsonObject, "tag"));
            TagKey<Item> tagKey = TagKey.of(RegistryKeys.field_41197, identifier);
            return new TagEntry(tagKey);
        }
        throw new JsonParseException("An ingredient entry needs either a tag or an item");
    }

    @Override
    public /* synthetic */ boolean test(@Nullable Object object) {
        return this.test((ItemStack)object);
    }

    public static interface Entry {
        public Collection<ItemStack> getStacks();

        public JsonObject toJson();
    }

    public static class TagEntry
    implements Entry {
        private final TagKey<Item> tag;

        TagEntry(TagKey<Item> tagKey) {
            this.tag = tagKey;
        }

        @Override
        public Collection<ItemStack> getStacks() {
            ArrayList<ItemStack> list = Lists.newArrayList();
            for (RegistryEntry<Item> registryEntry : Registries.ITEM.iterateEntries(this.tag)) {
                list.add(new ItemStack(registryEntry));
            }
            return list;
        }

        @Override
        public JsonObject toJson() {
            JsonObject jsonObject = new JsonObject();
            jsonObject.addProperty("tag", this.tag.id().toString());
            return jsonObject;
        }
    }

    public static class StackEntry
    implements Entry {
        private final ItemStack stack;

        public StackEntry(ItemStack itemStack) {
            this.stack = itemStack;
        }

        @Override
        public Collection<ItemStack> getStacks() {
            return Collections.singleton(this.stack);
        }

        @Override
        public JsonObject toJson() {
            JsonObject jsonObject = new JsonObject();
            jsonObject.addProperty("item", Registries.ITEM.getId(this.stack.getItem()).toString());
            return jsonObject;
        }
    }
}


/*
 * Decompiled with CFR 0.2.1 (FabricMC 53fa44c9).
 */
package net.minecraft.util;

public enum UseAction {
    field_8952,
    field_8950,
    field_8946,
    field_8949,
    field_8953,
    field_8951,
    field_8947,
    field_27079,
    field_39058,
    field_42717;

}


/*
 * Decompiled with CFR 0.2.1 (FabricMC 53fa44c9).
 */
package net.minecraft.item;

import com.google.common.collect.Lists;
import java.util.Collection;
import java.util.List;
import java.util.Set;
import java.util.function.Consumer;
import java.util.function.Supplier;
import net.minecraft.item.ItemConvertible;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemStackSet;
import net.minecraft.registry.Registries;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryWrapper;
import net.minecraft.resource.featuretoggle.FeatureSet;
import net.minecraft.text.Text;
import org.jetbrains.annotations.Nullable;

public class ItemGroup {
    private final Text displayName;
    String texture = "items.png";
    boolean scrollbar = true;
    boolean renderName = true;
    boolean special = false;
    private final Row row;
    private final int column;
    private final Type type;
    @Nullable
    private ItemStack icon;
    private Collection<ItemStack> displayStacks = ItemStackSet.create();
    private Set<ItemStack> searchTabStacks = ItemStackSet.create();
    @Nullable
    private Consumer<List<ItemStack>> searchProviderReloader;
    private final Supplier<ItemStack> iconSupplier;
    private final EntryCollector entryCollector;

    ItemGroup(Row row, int i, Type type, Text text, Supplier<ItemStack> supplier, EntryCollector entryCollector) {
        this.row = row;
        this.column = i;
        this.displayName = text;
        this.iconSupplier = supplier;
        this.entryCollector = entryCollector;
        this.type = type;
    }

    public static Builder create(Row row, int i) {
        return new Builder(row, i);
    }

    public Text getDisplayName() {
        return this.displayName;
    }

    public ItemStack getIcon() {
        if (this.icon == null) {
            this.icon = this.iconSupplier.get();
        }
        return this.icon;
    }

    public String getTexture() {
        return this.texture;
    }

    public boolean shouldRenderName() {
        return this.renderName;
    }

    public boolean hasScrollbar() {
        return this.scrollbar;
    }

    public int getColumn() {
        return this.column;
    }

    public Row getRow() {
        return this.row;
    }

    public boolean hasStacks() {
        return !this.displayStacks.isEmpty();
    }

    public boolean shouldDisplay() {
        return this.type != Type.field_41052 || this.hasStacks();
    }

    public boolean isSpecial() {
        return this.special;
    }

    public Type getType() {
        return this.type;
    }

    public void updateEntries(DisplayContext displayContext) {
        EntriesImpl entriesImpl = new EntriesImpl(this, displayContext.comp_1251);
        RegistryKey<ItemGroup> registryKey = Registries.ITEM_GROUP.getKey(this).orElseThrow(() -> new IllegalStateException("Unregistered creative tab: " + this));
        this.entryCollector.accept(displayContext, entriesImpl);
        this.displayStacks = entriesImpl.parentTabStacks;
        this.searchTabStacks = entriesImpl.searchTabStacks;
        this.reloadSearchProvider();
    }

    public Collection<ItemStack> getDisplayStacks() {
        return this.displayStacks;
    }

    public Collection<ItemStack> getSearchTabStacks() {
        return this.searchTabStacks;
    }

    public boolean contains(ItemStack itemStack) {
        return this.searchTabStacks.contains(itemStack);
    }

    public void setSearchProviderReloader(Consumer<List<ItemStack>> consumer) {
        this.searchProviderReloader = consumer;
    }

    public void reloadSearchProvider() {
        if (this.searchProviderReloader != null) {
            this.searchProviderReloader.accept(Lists.newArrayList(this.searchTabStacks));
        }
    }

    public static enum Row {
        field_41049,
        field_41050;

    }

    @FunctionalInterface
    public static interface EntryCollector {
        public void accept(DisplayContext var1, Entries var2);
    }

    public static enum Type {
        field_41052,
        field_41053,
        field_41054,
        field_41055;

    }

    public static class Builder {
        private static final EntryCollector EMPTY_ENTRIES = (displayContext, entries) -> {};
        private final Row row;
        private final int column;
        private Text displayName = Text.empty();
        private Supplier<ItemStack> iconSupplier = () -> ItemStack.EMPTY;
        private EntryCollector entryCollector = EMPTY_ENTRIES;
        private boolean scrollbar = true;
        private boolean renderName = true;
        private boolean special = false;
        private Type type = Type.field_41052;
        private String texture = "items.png";

        public Builder(Row row, int i) {
            this.row = row;
            this.column = i;
        }

        public Builder displayName(Text text) {
            this.displayName = text;
            return this;
        }

        public Builder icon(Supplier<ItemStack> supplier) {
            this.iconSupplier = supplier;
            return this;
        }

        public Builder entries(EntryCollector entryCollector) {
            this.entryCollector = entryCollector;
            return this;
        }

        public Builder special() {
            this.special = true;
            return this;
        }

        public Builder noRenderedName() {
            this.renderName = false;
            return this;
        }

        public Builder noScrollbar() {
            this.scrollbar = false;
            return this;
        }

        protected Builder type(Type type) {
            this.type = type;
            return this;
        }

        public Builder texture(String string) {
            this.texture = string;
            return this;
        }

        public ItemGroup build() {
            if ((this.type == Type.field_41054 || this.type == Type.field_41053) && this.entryCollector != EMPTY_ENTRIES) {
                throw new IllegalStateException("Special tabs can't have display items");
            }
            ItemGroup itemGroup = new ItemGroup(this.row, this.column, this.type, this.displayName, this.iconSupplier, this.entryCollector);
            itemGroup.special = this.special;
            itemGroup.renderName = this.renderName;
            itemGroup.scrollbar = this.scrollbar;
            itemGroup.texture = this.texture;
            return itemGroup;
        }
    }

    static class EntriesImpl
    implements Entries {
        public final Collection<ItemStack> parentTabStacks = ItemStackSet.create();
        public final Set<ItemStack> searchTabStacks = ItemStackSet.create();
        private final ItemGroup group;
        private final FeatureSet enabledFeatures;

        public EntriesImpl(ItemGroup itemGroup, FeatureSet featureSet) {
            this.group = itemGroup;
            this.enabledFeatures = featureSet;
        }

        @Override
        public void add(ItemStack itemStack, StackVisibility stackVisibility) {
            boolean bl;
            if (itemStack.getCount() != 1) {
                throw new IllegalArgumentException("Stack size must be exactly 1");
            }
            boolean bl2 = bl = this.parentTabStacks.contains(itemStack) && stackVisibility != StackVisibility.field_40193;
            if (bl) {
                throw new IllegalStateException("Accidentally adding the same item stack twice " + itemStack.toHoverableText().getString() + " to a Creative Mode Tab: " + this.group.getDisplayName().getString());
            }
            if (itemStack.getItem().isEnabled(this.enabledFeatures)) {
                switch (stackVisibility) {
                    case field_40191: {
                        this.parentTabStacks.add(itemStack);
                        this.searchTabStacks.add(itemStack);
                        break;
                    }
                    case field_40192: {
                        this.parentTabStacks.add(itemStack);
                        break;
                    }
                    case field_40193: {
                        this.searchTabStacks.add(itemStack);
                    }
                }
            }
        }
    }

    public record DisplayContext(FeatureSet comp_1251, boolean comp_1252, RegistryWrapper.WrapperLookup lookup) {
        public boolean doesNotMatch(FeatureSet featureSet, boolean bl, RegistryWrapper.WrapperLookup wrapperLookup) {
            return !this.comp_1251.equals(featureSet) || this.comp_1252 != bl || this.lookup != wrapperLookup;
        }
    }

    public static interface Entries {
        public void add(ItemStack var1, StackVisibility var2);

        default public void add(ItemStack itemStack) {
            this.add(itemStack, StackVisibility.field_40191);
        }

        default public void add(ItemConvertible itemConvertible, StackVisibility stackVisibility) {
            this.add(new ItemStack(itemConvertible), stackVisibility);
        }

        default public void add(ItemConvertible itemConvertible) {
            this.add(new ItemStack(itemConvertible), StackVisibility.field_40191);
        }

        default public void addAll(Collection<ItemStack> collection, StackVisibility stackVisibility) {
            collection.forEach(itemStack -> this.add((ItemStack)itemStack, stackVisibility));
        }

        default public void addAll(Collection<ItemStack> collection) {
            this.addAll(collection, StackVisibility.field_40191);
        }
    }

    public static enum StackVisibility {
        field_40191,
        field_40192,
        field_40193;

    }
}


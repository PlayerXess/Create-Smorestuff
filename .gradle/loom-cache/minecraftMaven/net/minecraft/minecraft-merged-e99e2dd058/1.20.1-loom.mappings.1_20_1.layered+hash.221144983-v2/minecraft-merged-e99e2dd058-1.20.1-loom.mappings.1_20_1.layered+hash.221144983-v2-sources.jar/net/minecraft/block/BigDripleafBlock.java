/*
 * Decompiled with CFR 0.2.1 (FabricMC 53fa44c9).
 */
package net.minecraft.block;

import com.google.common.collect.ImmutableMap;
import it.unimi.dsi.fastutil.objects.Object2IntArrayMap;
import it.unimi.dsi.fastutil.objects.Object2IntMap;
import java.util.Map;
import net.minecraft.block.AbstractBlock;
import net.minecraft.block.BigDripleafStemBlock;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.Fertilizable;
import net.minecraft.block.HorizontalFacingBlock;
import net.minecraft.block.ShapeContext;
import net.minecraft.block.Waterloggable;
import net.minecraft.block.enums.Tilt;
import net.minecraft.entity.Entity;
import net.minecraft.entity.projectile.ProjectileEntity;
import net.minecraft.fluid.FluidState;
import net.minecraft.fluid.Fluids;
import net.minecraft.item.ItemPlacementContext;
import net.minecraft.registry.tag.BlockTags;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;
import net.minecraft.state.StateManager;
import net.minecraft.state.property.BooleanProperty;
import net.minecraft.state.property.EnumProperty;
import net.minecraft.state.property.Properties;
import net.minecraft.util.Util;
import net.minecraft.util.function.BooleanBiFunction;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.random.Random;
import net.minecraft.util.shape.VoxelShape;
import net.minecraft.util.shape.VoxelShapes;
import net.minecraft.world.BlockView;
import net.minecraft.world.HeightLimitView;
import net.minecraft.world.World;
import net.minecraft.world.WorldAccess;
import net.minecraft.world.WorldView;
import net.minecraft.world.event.GameEvent;
import org.jetbrains.annotations.Nullable;

public class BigDripleafBlock
extends HorizontalFacingBlock
implements Fertilizable,
Waterloggable {
    private static final BooleanProperty WATERLOGGED = Properties.WATERLOGGED;
    private static final EnumProperty<Tilt> TILT = Properties.TILT;
    private static final int field_31015 = -1;
    private static final Object2IntMap<Tilt> NEXT_TILT_DELAYS = Util.make(new Object2IntArrayMap(), object2IntArrayMap -> {
        object2IntArrayMap.defaultReturnValue(-1);
        object2IntArrayMap.put(Tilt.field_28719, 10);
        object2IntArrayMap.put(Tilt.field_28720, 10);
        object2IntArrayMap.put(Tilt.field_28721, 100);
    });
    private static final int field_31016 = 5;
    private static final int field_31017 = 6;
    private static final int field_31018 = 11;
    private static final int field_31019 = 13;
    private static final Map<Tilt, VoxelShape> SHAPES_FOR_TILT = ImmutableMap.of(Tilt.field_28718, Block.createCuboidShape(0.0, 11.0, 0.0, 16.0, 15.0, 16.0), Tilt.field_28719, Block.createCuboidShape(0.0, 11.0, 0.0, 16.0, 15.0, 16.0), Tilt.field_28720, Block.createCuboidShape(0.0, 11.0, 0.0, 16.0, 13.0, 16.0), Tilt.field_28721, VoxelShapes.empty());
    private static final VoxelShape BASE_SHAPE = Block.createCuboidShape(0.0, 13.0, 0.0, 16.0, 16.0, 16.0);
    private static final Map<Direction, VoxelShape> SHAPES_FOR_DIRECTION = ImmutableMap.of(Direction.field_11043, VoxelShapes.combine(BigDripleafStemBlock.NORTH_SHAPE, BASE_SHAPE, BooleanBiFunction.ONLY_FIRST), Direction.field_11035, VoxelShapes.combine(BigDripleafStemBlock.SOUTH_SHAPE, BASE_SHAPE, BooleanBiFunction.ONLY_FIRST), Direction.field_11034, VoxelShapes.combine(BigDripleafStemBlock.EAST_SHAPE, BASE_SHAPE, BooleanBiFunction.ONLY_FIRST), Direction.field_11039, VoxelShapes.combine(BigDripleafStemBlock.WEST_SHAPE, BASE_SHAPE, BooleanBiFunction.ONLY_FIRST));
    private final Map<BlockState, VoxelShape> shapes;

    public BigDripleafBlock(AbstractBlock.Settings settings) {
        super(settings);
        this.setDefaultState((BlockState)((BlockState)((BlockState)((BlockState)this.stateManager.getDefaultState()).with(WATERLOGGED, false)).with(FACING, Direction.field_11043)).with(TILT, Tilt.field_28718));
        this.shapes = this.getShapesForStates(BigDripleafBlock::getShapeForState);
    }

    private static VoxelShape getShapeForState(BlockState blockState) {
        return VoxelShapes.union(SHAPES_FOR_TILT.get(blockState.get(TILT)), SHAPES_FOR_DIRECTION.get(blockState.get(FACING)));
    }

    public static void grow(WorldAccess worldAccess, Random random, BlockPos blockPos, Direction direction) {
        int j;
        int i = MathHelper.nextInt(random, 2, 5);
        BlockPos.Mutable mutable = blockPos.mutableCopy();
        for (j = 0; j < i && BigDripleafBlock.canGrowInto(worldAccess, mutable, worldAccess.getBlockState(mutable)); ++j) {
            mutable.move(Direction.field_11036);
        }
        int k = blockPos.getY() + j - 1;
        mutable.setY(blockPos.getY());
        while (mutable.getY() < k) {
            BigDripleafStemBlock.placeStemAt(worldAccess, mutable, worldAccess.getFluidState(mutable), direction);
            mutable.move(Direction.field_11036);
        }
        BigDripleafBlock.placeDripleafAt(worldAccess, mutable, worldAccess.getFluidState(mutable), direction);
    }

    private static boolean canGrowInto(BlockState blockState) {
        return blockState.isAir() || blockState.isOf(Blocks.field_10382) || blockState.isOf(Blocks.field_28684);
    }

    protected static boolean canGrowInto(HeightLimitView heightLimitView, BlockPos blockPos, BlockState blockState) {
        return !heightLimitView.isOutOfHeightLimit(blockPos) && BigDripleafBlock.canGrowInto(blockState);
    }

    protected static boolean placeDripleafAt(WorldAccess worldAccess, BlockPos blockPos, FluidState fluidState, Direction direction) {
        BlockState blockState = (BlockState)((BlockState)Blocks.field_28682.getDefaultState().with(WATERLOGGED, fluidState.isEqualAndStill(Fluids.WATER))).with(FACING, direction);
        return worldAccess.setBlockState(blockPos, blockState, 3);
    }

    @Override
    public void onProjectileHit(World world, BlockState blockState, BlockHitResult blockHitResult, ProjectileEntity projectileEntity) {
        this.changeTilt(blockState, world, blockHitResult.getBlockPos(), Tilt.field_28721, SoundEvents.field_28579);
    }

    @Override
    public FluidState getFluidState(BlockState blockState) {
        if (blockState.get(WATERLOGGED).booleanValue()) {
            return Fluids.WATER.getStill(false);
        }
        return super.getFluidState(blockState);
    }

    @Override
    public boolean canPlaceAt(BlockState blockState, WorldView worldView, BlockPos blockPos) {
        BlockPos blockPos2 = blockPos.down();
        BlockState blockState2 = worldView.getBlockState(blockPos2);
        return blockState2.isOf(this) || blockState2.isOf(Blocks.field_28683) || blockState2.isIn(BlockTags.field_35443);
    }

    @Override
    public BlockState getStateForNeighborUpdate(BlockState blockState, Direction direction, BlockState blockState2, WorldAccess worldAccess, BlockPos blockPos, BlockPos blockPos2) {
        if (direction == Direction.field_11033 && !blockState.canPlaceAt(worldAccess, blockPos)) {
            return Blocks.field_10124.getDefaultState();
        }
        if (blockState.get(WATERLOGGED).booleanValue()) {
            worldAccess.scheduleFluidTick(blockPos, Fluids.WATER, Fluids.WATER.getTickRate(worldAccess));
        }
        if (direction == Direction.field_11036 && blockState2.isOf(this)) {
            return Blocks.field_28683.getStateWithProperties(blockState);
        }
        return super.getStateForNeighborUpdate(blockState, direction, blockState2, worldAccess, blockPos, blockPos2);
    }

    @Override
    public boolean isFertilizable(WorldView worldView, BlockPos blockPos, BlockState blockState, boolean bl) {
        BlockState blockState2 = worldView.getBlockState(blockPos.up());
        return BigDripleafBlock.canGrowInto(blockState2);
    }

    @Override
    public boolean canGrow(World world, Random random, BlockPos blockPos, BlockState blockState) {
        return true;
    }

    @Override
    public void grow(ServerWorld serverWorld, Random random, BlockPos blockPos, BlockState blockState) {
        BlockState blockState2;
        BlockPos blockPos2 = blockPos.up();
        if (BigDripleafBlock.canGrowInto(serverWorld, blockPos2, blockState2 = serverWorld.getBlockState(blockPos2))) {
            Direction direction = blockState.get(FACING);
            BigDripleafStemBlock.placeStemAt(serverWorld, blockPos, blockState.getFluidState(), direction);
            BigDripleafBlock.placeDripleafAt(serverWorld, blockPos2, blockState2.getFluidState(), direction);
        }
    }

    @Override
    public void onEntityCollision(BlockState blockState, World world, BlockPos blockPos, Entity entity) {
        if (world.isClient) {
            return;
        }
        if (blockState.get(TILT) == Tilt.field_28718 && BigDripleafBlock.isEntityAbove(blockPos, entity) && !world.isReceivingRedstonePower(blockPos)) {
            this.changeTilt(blockState, world, blockPos, Tilt.field_28719, null);
        }
    }

    @Override
    public void scheduledTick(BlockState blockState, ServerWorld serverWorld, BlockPos blockPos, Random random) {
        if (serverWorld.isReceivingRedstonePower(blockPos)) {
            BigDripleafBlock.resetTilt(blockState, serverWorld, blockPos);
            return;
        }
        Tilt tilt = blockState.get(TILT);
        if (tilt == Tilt.field_28719) {
            this.changeTilt(blockState, serverWorld, blockPos, Tilt.field_28720, SoundEvents.field_28579);
        } else if (tilt == Tilt.field_28720) {
            this.changeTilt(blockState, serverWorld, blockPos, Tilt.field_28721, SoundEvents.field_28579);
        } else if (tilt == Tilt.field_28721) {
            BigDripleafBlock.resetTilt(blockState, serverWorld, blockPos);
        }
    }

    @Override
    public void neighborUpdate(BlockState blockState, World world, BlockPos blockPos, Block block, BlockPos blockPos2, boolean bl) {
        if (world.isReceivingRedstonePower(blockPos)) {
            BigDripleafBlock.resetTilt(blockState, world, blockPos);
        }
    }

    private static void playTiltSound(World world, BlockPos blockPos, SoundEvent soundEvent) {
        float f = MathHelper.nextBetween(world.random, 0.8f, 1.2f);
        world.playSound(null, blockPos, soundEvent, SoundCategory.field_15245, 1.0f, f);
    }

    private static boolean isEntityAbove(BlockPos blockPos, Entity entity) {
        return entity.isOnGround() && entity.getPos().y > (double)((float)blockPos.getY() + 0.6875f);
    }

    private void changeTilt(BlockState blockState, World world, BlockPos blockPos, Tilt tilt, @Nullable SoundEvent soundEvent) {
        int i;
        BigDripleafBlock.changeTilt(blockState, world, blockPos, tilt);
        if (soundEvent != null) {
            BigDripleafBlock.playTiltSound(world, blockPos, soundEvent);
        }
        if ((i = NEXT_TILT_DELAYS.getInt(tilt)) != -1) {
            world.scheduleBlockTick(blockPos, this, i);
        }
    }

    private static void resetTilt(BlockState blockState, World world, BlockPos blockPos) {
        BigDripleafBlock.changeTilt(blockState, world, blockPos, Tilt.field_28718);
        if (blockState.get(TILT) != Tilt.field_28718) {
            BigDripleafBlock.playTiltSound(world, blockPos, SoundEvents.field_28580);
        }
    }

    private static void changeTilt(BlockState blockState, World world, BlockPos blockPos, Tilt tilt) {
        Tilt tilt2 = blockState.get(TILT);
        world.setBlockState(blockPos, (BlockState)blockState.with(TILT, tilt), 2);
        if (tilt.isStable() && tilt != tilt2) {
            world.emitGameEvent(null, GameEvent.field_28733, blockPos);
        }
    }

    @Override
    public VoxelShape getCollisionShape(BlockState blockState, BlockView blockView, BlockPos blockPos, ShapeContext shapeContext) {
        return SHAPES_FOR_TILT.get(blockState.get(TILT));
    }

    @Override
    public VoxelShape getOutlineShape(BlockState blockState, BlockView blockView, BlockPos blockPos, ShapeContext shapeContext) {
        return this.shapes.get(blockState);
    }

    @Override
    public BlockState getPlacementState(ItemPlacementContext itemPlacementContext) {
        BlockState blockState = itemPlacementContext.getWorld().getBlockState(itemPlacementContext.getBlockPos().down());
        FluidState fluidState = itemPlacementContext.getWorld().getFluidState(itemPlacementContext.getBlockPos());
        boolean bl = blockState.isOf(Blocks.field_28682) || blockState.isOf(Blocks.field_28683);
        return (BlockState)((BlockState)this.getDefaultState().with(WATERLOGGED, fluidState.isEqualAndStill(Fluids.WATER))).with(FACING, bl ? blockState.get(FACING) : itemPlacementContext.getHorizontalPlayerFacing().getOpposite());
    }

    @Override
    protected void appendProperties(StateManager.Builder<Block, BlockState> builder) {
        builder.add(WATERLOGGED, FACING, TILT);
    }
}


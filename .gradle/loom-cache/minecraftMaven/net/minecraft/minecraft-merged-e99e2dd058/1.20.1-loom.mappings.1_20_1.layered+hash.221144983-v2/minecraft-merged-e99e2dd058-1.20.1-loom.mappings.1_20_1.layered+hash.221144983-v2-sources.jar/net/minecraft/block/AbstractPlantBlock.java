/*
 * Decompiled with CFR 0.2.1 (FabricMC 53fa44c9).
 */
package net.minecraft.block;

import java.util.Optional;
import net.minecraft.block.AbstractBlock;
import net.minecraft.block.AbstractPlantPartBlock;
import net.minecraft.block.AbstractPlantStemBlock;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Fertilizable;
import net.minecraft.fluid.Fluids;
import net.minecraft.item.ItemPlacementContext;
import net.minecraft.item.ItemStack;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.random.Random;
import net.minecraft.util.shape.VoxelShape;
import net.minecraft.world.BlockLocating;
import net.minecraft.world.BlockView;
import net.minecraft.world.World;
import net.minecraft.world.WorldAccess;
import net.minecraft.world.WorldView;

public abstract class AbstractPlantBlock
extends AbstractPlantPartBlock
implements Fertilizable {
    protected AbstractPlantBlock(AbstractBlock.Settings settings, Direction direction, VoxelShape voxelShape, boolean bl) {
        super(settings, direction, voxelShape, bl);
    }

    protected BlockState copyState(BlockState blockState, BlockState blockState2) {
        return blockState2;
    }

    @Override
    public BlockState getStateForNeighborUpdate(BlockState blockState, Direction direction, BlockState blockState2, WorldAccess worldAccess, BlockPos blockPos, BlockPos blockPos2) {
        if (direction == this.growthDirection.getOpposite() && !blockState.canPlaceAt(worldAccess, blockPos)) {
            worldAccess.scheduleBlockTick(blockPos, this, 1);
        }
        AbstractPlantStemBlock abstractPlantStemBlock = this.getStem();
        if (direction == this.growthDirection && !blockState2.isOf(this) && !blockState2.isOf(abstractPlantStemBlock)) {
            return this.copyState(blockState, abstractPlantStemBlock.getRandomGrowthState(worldAccess));
        }
        if (this.tickWater) {
            worldAccess.scheduleFluidTick(blockPos, Fluids.WATER, Fluids.WATER.getTickRate(worldAccess));
        }
        return super.getStateForNeighborUpdate(blockState, direction, blockState2, worldAccess, blockPos, blockPos2);
    }

    @Override
    public ItemStack getPickStack(BlockView blockView, BlockPos blockPos, BlockState blockState) {
        return new ItemStack(this.getStem());
    }

    @Override
    public boolean isFertilizable(WorldView worldView, BlockPos blockPos, BlockState blockState, boolean bl) {
        Optional<BlockPos> optional = this.getStemHeadPos(worldView, blockPos, blockState.getBlock());
        return optional.isPresent() && this.getStem().chooseStemState(worldView.getBlockState(optional.get().offset(this.growthDirection)));
    }

    @Override
    public boolean canGrow(World world, Random random, BlockPos blockPos, BlockState blockState) {
        return true;
    }

    @Override
    public void grow(ServerWorld serverWorld, Random random, BlockPos blockPos, BlockState blockState) {
        Optional<BlockPos> optional = this.getStemHeadPos(serverWorld, blockPos, blockState.getBlock());
        if (optional.isPresent()) {
            BlockState blockState2 = serverWorld.getBlockState(optional.get());
            ((AbstractPlantStemBlock)blockState2.getBlock()).grow(serverWorld, random, optional.get(), blockState2);
        }
    }

    private Optional<BlockPos> getStemHeadPos(BlockView blockView, BlockPos blockPos, Block block) {
        return BlockLocating.findColumnEnd(blockView, blockPos, block, this.growthDirection, this.getStem());
    }

    @Override
    public boolean canReplace(BlockState blockState, ItemPlacementContext itemPlacementContext) {
        boolean bl = super.canReplace(blockState, itemPlacementContext);
        if (bl && itemPlacementContext.getStack().isOf(this.getStem().asItem())) {
            return false;
        }
        return bl;
    }

    @Override
    protected Block getPlant() {
        return this;
    }
}


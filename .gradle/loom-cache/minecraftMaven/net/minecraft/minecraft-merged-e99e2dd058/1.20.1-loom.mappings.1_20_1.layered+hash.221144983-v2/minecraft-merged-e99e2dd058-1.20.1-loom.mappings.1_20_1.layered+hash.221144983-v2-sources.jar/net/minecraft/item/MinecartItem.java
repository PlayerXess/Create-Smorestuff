/*
 * Decompiled with CFR 0.2.1 (FabricMC 53fa44c9).
 */
package net.minecraft.item;

import net.minecraft.block.AbstractRailBlock;
import net.minecraft.block.BlockState;
import net.minecraft.block.DispenserBlock;
import net.minecraft.block.dispenser.DispenserBehavior;
import net.minecraft.block.dispenser.ItemDispenserBehavior;
import net.minecraft.block.enums.RailShape;
import net.minecraft.entity.vehicle.AbstractMinecartEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemUsageContext;
import net.minecraft.registry.tag.BlockTags;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.ActionResult;
import net.minecraft.util.math.BlockPointer;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.world.World;
import net.minecraft.world.event.GameEvent;

public class MinecartItem
extends Item {
    private static final DispenserBehavior DISPENSER_BEHAVIOR = new ItemDispenserBehavior(){
        private final ItemDispenserBehavior defaultBehavior = new ItemDispenserBehavior();

        @Override
        public ItemStack dispenseSilently(BlockPointer blockPointer, ItemStack itemStack) {
            double g;
            RailShape railShape;
            Direction direction = blockPointer.getBlockState().get(DispenserBlock.FACING);
            ServerWorld world = blockPointer.getWorld();
            double d = blockPointer.getX() + (double)direction.getOffsetX() * 1.125;
            double e = Math.floor(blockPointer.getY()) + (double)direction.getOffsetY();
            double f = blockPointer.getZ() + (double)direction.getOffsetZ() * 1.125;
            BlockPos blockPos = blockPointer.getPos().offset(direction);
            BlockState blockState = world.getBlockState(blockPos);
            RailShape railShape2 = railShape = blockState.getBlock() instanceof AbstractRailBlock ? blockState.get(((AbstractRailBlock)blockState.getBlock()).getShapeProperty()) : RailShape.field_12665;
            if (blockState.isIn(BlockTags.field_15463)) {
                g = railShape.isAscending() ? 0.6 : 0.1;
            } else if (blockState.isAir() && world.getBlockState(blockPos.down()).isIn(BlockTags.field_15463)) {
                RailShape railShape22;
                BlockState blockState2 = world.getBlockState(blockPos.down());
                RailShape railShape3 = railShape22 = blockState2.getBlock() instanceof AbstractRailBlock ? blockState2.get(((AbstractRailBlock)blockState2.getBlock()).getShapeProperty()) : RailShape.field_12665;
                g = direction == Direction.field_11033 || !railShape22.isAscending() ? -0.9 : -0.4;
            } else {
                return this.defaultBehavior.dispense(blockPointer, itemStack);
            }
            AbstractMinecartEntity abstractMinecartEntity = AbstractMinecartEntity.create(world, d, e + g, f, ((MinecartItem)itemStack.getItem()).type);
            if (itemStack.hasCustomName()) {
                abstractMinecartEntity.setCustomName(itemStack.getName());
            }
            world.spawnEntity(abstractMinecartEntity);
            itemStack.decrement(1);
            return itemStack;
        }

        @Override
        protected void playSound(BlockPointer blockPointer) {
            blockPointer.getWorld().syncWorldEvent(1000, blockPointer.getPos(), 0);
        }
    };
    final AbstractMinecartEntity.Type type;

    public MinecartItem(AbstractMinecartEntity.Type type, Item.Settings settings) {
        super(settings);
        this.type = type;
        DispenserBlock.registerBehavior(this, DISPENSER_BEHAVIOR);
    }

    @Override
    public ActionResult useOnBlock(ItemUsageContext itemUsageContext) {
        BlockPos blockPos;
        World world = itemUsageContext.getWorld();
        BlockState blockState = world.getBlockState(blockPos = itemUsageContext.getBlockPos());
        if (!blockState.isIn(BlockTags.field_15463)) {
            return ActionResult.FAIL;
        }
        ItemStack itemStack = itemUsageContext.getStack();
        if (!world.isClient) {
            RailShape railShape = blockState.getBlock() instanceof AbstractRailBlock ? blockState.get(((AbstractRailBlock)blockState.getBlock()).getShapeProperty()) : RailShape.field_12665;
            double d = 0.0;
            if (railShape.isAscending()) {
                d = 0.5;
            }
            AbstractMinecartEntity abstractMinecartEntity = AbstractMinecartEntity.create(world, (double)blockPos.getX() + 0.5, (double)blockPos.getY() + 0.0625 + d, (double)blockPos.getZ() + 0.5, this.type);
            if (itemStack.hasCustomName()) {
                abstractMinecartEntity.setCustomName(itemStack.getName());
            }
            world.spawnEntity(abstractMinecartEntity);
            world.emitGameEvent(GameEvent.field_28738, blockPos, GameEvent.Emitter.of(itemUsageContext.getPlayer(), world.getBlockState(blockPos.down())));
        }
        itemStack.decrement(1);
        return ActionResult.success(world.isClient);
    }
}


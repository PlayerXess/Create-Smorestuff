/*
 * Decompiled with CFR 0.2.1 (FabricMC 53fa44c9).
 */
package net.minecraft.item;

import com.google.common.base.Suppliers;
import com.google.common.collect.BiMap;
import com.google.common.collect.ImmutableBiMap;
import java.util.Optional;
import java.util.function.Supplier;
import net.minecraft.advancement.criterion.Criteria;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.entity.SignBlockEntity;
import net.minecraft.block.entity.SignText;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemUsageContext;
import net.minecraft.item.SignChangingItem;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.util.ActionResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraft.world.event.GameEvent;

public class HoneycombItem
extends Item
implements SignChangingItem {
    public static final Supplier<BiMap<Block, Block>> UNWAXED_TO_WAXED_BLOCKS = Suppliers.memoize(() -> ((ImmutableBiMap.Builder)((ImmutableBiMap.Builder)((ImmutableBiMap.Builder)((ImmutableBiMap.Builder)((ImmutableBiMap.Builder)((ImmutableBiMap.Builder)((ImmutableBiMap.Builder)((ImmutableBiMap.Builder)((ImmutableBiMap.Builder)((ImmutableBiMap.Builder)((ImmutableBiMap.Builder)((ImmutableBiMap.Builder)((ImmutableBiMap.Builder)((ImmutableBiMap.Builder)((ImmutableBiMap.Builder)((ImmutableBiMap.Builder)ImmutableBiMap.builder().put(Blocks.field_27119, Blocks.field_27133)).put(Blocks.field_27118, Blocks.field_27135)).put(Blocks.field_27117, Blocks.field_27134)).put(Blocks.field_27116, Blocks.field_33407)).put(Blocks.field_27124, Blocks.field_27138)).put(Blocks.field_27123, Blocks.field_27137)).put(Blocks.field_27122, Blocks.field_27136)).put(Blocks.field_27121, Blocks.field_33408)).put(Blocks.field_27132, Blocks.field_27170)).put(Blocks.field_27131, Blocks.field_27169)).put(Blocks.field_27130, Blocks.field_27168)).put(Blocks.field_27129, Blocks.field_33410)).put(Blocks.field_27128, Blocks.field_27167)).put(Blocks.field_27127, Blocks.field_27166)).put(Blocks.field_27126, Blocks.field_27139)).put(Blocks.field_27125, Blocks.field_33409)).build());
    public static final Supplier<BiMap<Block, Block>> WAXED_TO_UNWAXED_BLOCKS = Suppliers.memoize(() -> UNWAXED_TO_WAXED_BLOCKS.get().inverse());

    public HoneycombItem(Item.Settings settings) {
        super(settings);
    }

    @Override
    public ActionResult useOnBlock(ItemUsageContext itemUsageContext) {
        World world = itemUsageContext.getWorld();
        BlockPos blockPos = itemUsageContext.getBlockPos();
        BlockState blockState2 = world.getBlockState(blockPos);
        return HoneycombItem.getWaxedState(blockState2).map(blockState -> {
            PlayerEntity playerEntity = itemUsageContext.getPlayer();
            ItemStack itemStack = itemUsageContext.getStack();
            if (playerEntity instanceof ServerPlayerEntity) {
                Criteria.ITEM_USED_ON_BLOCK.trigger((ServerPlayerEntity)playerEntity, blockPos, itemStack);
            }
            itemStack.decrement(1);
            world.setBlockState(blockPos, (BlockState)blockState, 11);
            world.emitGameEvent(GameEvent.field_28733, blockPos, GameEvent.Emitter.of(playerEntity, blockState));
            world.syncWorldEvent(playerEntity, 3003, blockPos, 0);
            return ActionResult.success(world.isClient);
        }).orElse(ActionResult.PASS);
    }

    public static Optional<BlockState> getWaxedState(BlockState blockState) {
        return Optional.ofNullable((Block)UNWAXED_TO_WAXED_BLOCKS.get().get(blockState.getBlock())).map(block -> block.getStateWithProperties(blockState));
    }

    @Override
    public boolean useOnSign(World world, SignBlockEntity signBlockEntity, boolean bl, PlayerEntity playerEntity) {
        if (signBlockEntity.setWaxed(true)) {
            world.syncWorldEvent(null, 3003, signBlockEntity.getPos(), 0);
            return true;
        }
        return false;
    }

    @Override
    public boolean canUseOnSignText(SignText signText, PlayerEntity playerEntity) {
        return true;
    }
}


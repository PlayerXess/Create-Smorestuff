/*
 * Decompiled with CFR 0.2.1 (FabricMC 53fa44c9).
 */
package net.minecraft.block;

import java.util.Map;
import java.util.function.Predicate;
import net.minecraft.block.AbstractBlock;
import net.minecraft.block.AbstractCauldronBlock;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.CauldronBlock;
import net.minecraft.block.cauldron.CauldronBehavior;
import net.minecraft.entity.Entity;
import net.minecraft.fluid.Fluid;
import net.minecraft.fluid.Fluids;
import net.minecraft.item.Item;
import net.minecraft.state.StateManager;
import net.minecraft.state.property.IntProperty;
import net.minecraft.state.property.Properties;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraft.world.biome.Biome;
import net.minecraft.world.event.GameEvent;

public class LeveledCauldronBlock
extends AbstractCauldronBlock {
    public static final int MIN_LEVEL = 1;
    public static final int MAX_LEVEL = 3;
    public static final IntProperty LEVEL = Properties.LEVEL_3;
    private static final int BASE_FLUID_HEIGHT = 6;
    private static final double FLUID_HEIGHT_PER_LEVEL = 3.0;
    public static final Predicate<Biome.Precipitation> RAIN_PREDICATE = precipitation -> precipitation == Biome.Precipitation.field_9382;
    public static final Predicate<Biome.Precipitation> SNOW_PREDICATE = precipitation -> precipitation == Biome.Precipitation.field_9383;
    private final Predicate<Biome.Precipitation> precipitationPredicate;

    public LeveledCauldronBlock(AbstractBlock.Settings settings, Predicate<Biome.Precipitation> predicate, Map<Item, CauldronBehavior> map) {
        super(settings, map);
        this.precipitationPredicate = predicate;
        this.setDefaultState((BlockState)((BlockState)this.stateManager.getDefaultState()).with(LEVEL, 1));
    }

    @Override
    public boolean isFull(BlockState blockState) {
        return blockState.get(LEVEL) == 3;
    }

    @Override
    protected boolean canBeFilledByDripstone(Fluid fluid) {
        return fluid == Fluids.WATER && this.precipitationPredicate == RAIN_PREDICATE;
    }

    @Override
    protected double getFluidHeight(BlockState blockState) {
        return (6.0 + (double)blockState.get(LEVEL).intValue() * 3.0) / 16.0;
    }

    @Override
    public void onEntityCollision(BlockState blockState, World world, BlockPos blockPos, Entity entity) {
        if (!world.isClient && entity.isOnFire() && this.isEntityTouchingFluid(blockState, blockPos, entity)) {
            entity.extinguish();
            if (entity.canModifyAt(world, blockPos)) {
                this.onFireCollision(blockState, world, blockPos);
            }
        }
    }

    protected void onFireCollision(BlockState blockState, World world, BlockPos blockPos) {
        LeveledCauldronBlock.decrementFluidLevel(blockState, world, blockPos);
    }

    public static void decrementFluidLevel(BlockState blockState, World world, BlockPos blockPos) {
        int i = blockState.get(LEVEL) - 1;
        BlockState blockState2 = i == 0 ? Blocks.field_10593.getDefaultState() : (BlockState)blockState.with(LEVEL, i);
        world.setBlockState(blockPos, blockState2);
        world.emitGameEvent(GameEvent.field_28733, blockPos, GameEvent.Emitter.of(blockState2));
    }

    @Override
    public void precipitationTick(BlockState blockState, World world, BlockPos blockPos, Biome.Precipitation precipitation) {
        if (!CauldronBlock.canFillWithPrecipitation(world, precipitation) || blockState.get(LEVEL) == 3 || !this.precipitationPredicate.test(precipitation)) {
            return;
        }
        BlockState blockState2 = (BlockState)blockState.cycle(LEVEL);
        world.setBlockState(blockPos, blockState2);
        world.emitGameEvent(GameEvent.field_28733, blockPos, GameEvent.Emitter.of(blockState2));
    }

    @Override
    public int getComparatorOutput(BlockState blockState, World world, BlockPos blockPos) {
        return blockState.get(LEVEL);
    }

    @Override
    protected void appendProperties(StateManager.Builder<Block, BlockState> builder) {
        builder.add(LEVEL);
    }

    @Override
    protected void fillFromDripstone(BlockState blockState, World world, BlockPos blockPos, Fluid fluid) {
        if (this.isFull(blockState)) {
            return;
        }
        BlockState blockState2 = (BlockState)blockState.with(LEVEL, blockState.get(LEVEL) + 1);
        world.setBlockState(blockPos, blockState2);
        world.emitGameEvent(GameEvent.field_28733, blockPos, GameEvent.Emitter.of(blockState2));
        world.syncWorldEvent(1047, blockPos, 0);
    }
}


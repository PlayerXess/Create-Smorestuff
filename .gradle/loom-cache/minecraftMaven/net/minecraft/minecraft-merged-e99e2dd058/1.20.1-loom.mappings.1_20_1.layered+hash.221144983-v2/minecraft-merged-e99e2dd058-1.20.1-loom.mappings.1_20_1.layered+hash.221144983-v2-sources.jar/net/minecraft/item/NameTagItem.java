/*
 * Decompiled with CFR 0.2.1 (FabricMC 53fa44c9).
 */
package net.minecraft.item;

import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;

public class NameTagItem
extends Item {
    public NameTagItem(Item.Settings settings) {
        super(settings);
    }

    @Override
    public ActionResult useOnEntity(ItemStack itemStack, PlayerEntity playerEntity, LivingEntity livingEntity, Hand hand) {
        if (itemStack.hasCustomName() && !(livingEntity instanceof PlayerEntity)) {
            if (!playerEntity.getWorld().isClient && livingEntity.isAlive()) {
                livingEntity.setCustomName(itemStack.getName());
                if (livingEntity instanceof MobEntity) {
                    ((MobEntity)livingEntity).setPersistent();
                }
                itemStack.decrement(1);
            }
            return ActionResult.success(playerEntity.getWorld().isClient);
        }
        return ActionResult.PASS;
    }
}


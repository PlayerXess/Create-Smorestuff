/*
 * Decompiled with CFR 0.2.1 (FabricMC 53fa44c9).
 */
package net.minecraft.item;

import java.util.List;
import net.minecraft.client.item.TooltipContext;
import net.minecraft.item.FireworkRocketItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.screen.ScreenTexts;
import net.minecraft.text.MutableText;
import net.minecraft.text.Text;
import net.minecraft.util.DyeColor;
import net.minecraft.util.Formatting;
import net.minecraft.world.World;
import org.jetbrains.annotations.Nullable;

public class FireworkStarItem
extends Item {
    public FireworkStarItem(Item.Settings settings) {
        super(settings);
    }

    @Override
    public void appendTooltip(ItemStack itemStack, @Nullable World world, List<Text> list, TooltipContext tooltipContext) {
        NbtCompound nbtCompound = itemStack.getSubNbt("Explosion");
        if (nbtCompound != null) {
            FireworkStarItem.appendFireworkTooltip(nbtCompound, list);
        }
    }

    public static void appendFireworkTooltip(NbtCompound nbtCompound, List<Text> list) {
        int[] js;
        FireworkRocketItem.Type type = FireworkRocketItem.Type.byId(nbtCompound.getByte("Type"));
        list.add(Text.translatable("item.minecraft.firework_star.shape." + type.getName()).formatted(Formatting.field_1080));
        int[] is = nbtCompound.getIntArray("Colors");
        if (is.length > 0) {
            list.add(FireworkStarItem.appendColors(Text.empty().formatted(Formatting.field_1080), is));
        }
        if ((js = nbtCompound.getIntArray("FadeColors")).length > 0) {
            list.add(FireworkStarItem.appendColors(Text.translatable("item.minecraft.firework_star.fade_to").append(ScreenTexts.SPACE).formatted(Formatting.field_1080), js));
        }
        if (nbtCompound.getBoolean("Trail")) {
            list.add(Text.translatable("item.minecraft.firework_star.trail").formatted(Formatting.field_1080));
        }
        if (nbtCompound.getBoolean("Flicker")) {
            list.add(Text.translatable("item.minecraft.firework_star.flicker").formatted(Formatting.field_1080));
        }
    }

    private static Text appendColors(MutableText mutableText, int[] is) {
        for (int i = 0; i < is.length; ++i) {
            if (i > 0) {
                mutableText.append(", ");
            }
            mutableText.append(FireworkStarItem.getColorText(is[i]));
        }
        return mutableText;
    }

    private static Text getColorText(int i) {
        DyeColor dyeColor = DyeColor.byFireworkColor(i);
        if (dyeColor == null) {
            return Text.translatable("item.minecraft.firework_star.custom_color");
        }
        return Text.translatable("item.minecraft.firework_star." + dyeColor.getName());
    }
}


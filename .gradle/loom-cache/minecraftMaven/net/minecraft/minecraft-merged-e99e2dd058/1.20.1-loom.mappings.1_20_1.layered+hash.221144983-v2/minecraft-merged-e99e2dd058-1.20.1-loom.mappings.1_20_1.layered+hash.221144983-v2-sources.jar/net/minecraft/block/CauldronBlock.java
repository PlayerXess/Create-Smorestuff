/*
 * Decompiled with CFR 0.2.1 (FabricMC 53fa44c9).
 */
package net.minecraft.block;

import net.minecraft.block.AbstractBlock;
import net.minecraft.block.AbstractCauldronBlock;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.cauldron.CauldronBehavior;
import net.minecraft.fluid.Fluid;
import net.minecraft.fluid.Fluids;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraft.world.biome.Biome;
import net.minecraft.world.event.GameEvent;

public class CauldronBlock
extends AbstractCauldronBlock {
    private static final float FILL_WITH_RAIN_CHANCE = 0.05f;
    private static final float FILL_WITH_SNOW_CHANCE = 0.1f;

    public CauldronBlock(AbstractBlock.Settings settings) {
        super(settings, CauldronBehavior.EMPTY_CAULDRON_BEHAVIOR);
    }

    @Override
    public boolean isFull(BlockState blockState) {
        return false;
    }

    protected static boolean canFillWithPrecipitation(World world, Biome.Precipitation precipitation) {
        if (precipitation == Biome.Precipitation.field_9382) {
            return world.getRandom().nextFloat() < 0.05f;
        }
        if (precipitation == Biome.Precipitation.field_9383) {
            return world.getRandom().nextFloat() < 0.1f;
        }
        return false;
    }

    @Override
    public void precipitationTick(BlockState blockState, World world, BlockPos blockPos, Biome.Precipitation precipitation) {
        if (!CauldronBlock.canFillWithPrecipitation(world, precipitation)) {
            return;
        }
        if (precipitation == Biome.Precipitation.field_9382) {
            world.setBlockState(blockPos, Blocks.field_27097.getDefaultState());
            world.emitGameEvent(null, GameEvent.field_28733, blockPos);
        } else if (precipitation == Biome.Precipitation.field_9383) {
            world.setBlockState(blockPos, Blocks.field_27878.getDefaultState());
            world.emitGameEvent(null, GameEvent.field_28733, blockPos);
        }
    }

    @Override
    protected boolean canBeFilledByDripstone(Fluid fluid) {
        return true;
    }

    @Override
    protected void fillFromDripstone(BlockState blockState, World world, BlockPos blockPos, Fluid fluid) {
        if (fluid == Fluids.WATER) {
            BlockState blockState2 = Blocks.field_27097.getDefaultState();
            world.setBlockState(blockPos, blockState2);
            world.emitGameEvent(GameEvent.field_28733, blockPos, GameEvent.Emitter.of(blockState2));
            world.syncWorldEvent(1047, blockPos, 0);
        } else if (fluid == Fluids.LAVA) {
            BlockState blockState2 = Blocks.field_27098.getDefaultState();
            world.setBlockState(blockPos, blockState2);
            world.emitGameEvent(GameEvent.field_28733, blockPos, GameEvent.Emitter.of(blockState2));
            world.syncWorldEvent(1046, blockPos, 0);
        }
    }
}


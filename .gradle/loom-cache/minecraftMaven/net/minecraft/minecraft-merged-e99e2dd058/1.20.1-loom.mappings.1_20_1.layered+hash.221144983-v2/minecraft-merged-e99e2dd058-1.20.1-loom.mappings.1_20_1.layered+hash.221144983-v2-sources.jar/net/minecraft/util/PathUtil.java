/*
 * Decompiled with CFR 0.2.1 (FabricMC 53fa44c9).
 */
package net.minecraft.util;

import com.mojang.serialization.DataResult;
import java.io.File;
import java.io.IOException;
import java.nio.file.FileAlreadyExistsException;
import java.nio.file.Files;
import java.nio.file.InvalidPathException;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.attribute.FileAttribute;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import net.minecraft.SharedConstants;
import org.apache.commons.io.FilenameUtils;

public class PathUtil {
    private static final Pattern FILE_NAME_WITH_COUNT = Pattern.compile("(<name>.*) \\((<count>\\d*)\\)", 66);
    private static final int MAX_NAME_LENGTH = 255;
    private static final Pattern RESERVED_WINDOWS_NAMES = Pattern.compile(".*\\.|(?:COM|CLOCK\\$|CON|PRN|AUX|NUL|COM[1-9]|LPT[1-9])(?:\\..*)?", 2);
    private static final Pattern VALID_FILE_NAME = Pattern.compile("[-._a-z0-9]+");

    public static String getNextUniqueName(Path path, String string, String string2) throws IOException {
        for (char c : SharedConstants.INVALID_CHARS_LEVEL_NAME) {
            string = ((String)string).replace(c, '_');
        }
        if (RESERVED_WINDOWS_NAMES.matcher((CharSequence)(string = ((String)string).replaceAll("[./\"]", "_"))).matches()) {
            string = "_" + (String)string + "_";
        }
        Matcher matcher = FILE_NAME_WITH_COUNT.matcher((CharSequence)string);
        int i = 0;
        if (matcher.matches()) {
            string = matcher.group("name");
            i = Integer.parseInt(matcher.group("count"));
        }
        if (((String)string).length() > 255 - string2.length()) {
            string = ((String)string).substring(0, 255 - string2.length());
        }
        while (true) {
            Object string3 = string;
            if (i != 0) {
                String string4 = " (" + i + ")";
                int j = 255 - string4.length();
                if (((String)string3).length() > j) {
                    string3 = ((String)string3).substring(0, j);
                }
                string3 = (String)string3 + string4;
            }
            string3 = (String)string3 + string2;
            Path path2 = path.resolve((String)string3);
            try {
                Path path3 = Files.createDirectory(path2, new FileAttribute[0]);
                Files.deleteIfExists(path3);
                return path.relativize(path3).toString();
            } catch (FileAlreadyExistsException fileAlreadyExistsException) {
                ++i;
                continue;
            }
            break;
        }
    }

    public static boolean isNormal(Path path) {
        Path path2 = path.normalize();
        return path2.equals(path);
    }

    public static boolean isAllowedName(Path path) {
        for (Path path2 : path) {
            if (!RESERVED_WINDOWS_NAMES.matcher(path2.toString()).matches()) continue;
            return false;
        }
        return true;
    }

    public static Path getResourcePath(Path path, String string, String string2) {
        String string3 = string + string2;
        Path path2 = Paths.get(string3, new String[0]);
        if (path2.endsWith(string2)) {
            throw new InvalidPathException(string3, "empty resource name");
        }
        return path.resolve(path2);
    }

    public static String getPosixFullPath(String string) {
        return FilenameUtils.getFullPath(string).replace(File.separator, "/");
    }

    public static String normalizeToPosix(String string) {
        return FilenameUtils.normalize(string).replace(File.separator, "/");
    }

    public static DataResult<List<String>> split(String string) {
        int i = string.indexOf(47);
        if (i == -1) {
            return switch (string) {
                case "", ".", ".." -> DataResult.error(() -> "Invalid path '" + string + "'");
                default -> !PathUtil.isFileNameValid(string) ? DataResult.error(() -> "Invalid path '" + string + "'") : DataResult.success(List.of(string));
            };
        }
        ArrayList<String> list = new ArrayList<String>();
        int j = 0;
        boolean bl = false;
        while (true) {
            String string2;
            switch (string2 = string.substring(j, i)) {
                case "": 
                case ".": 
                case "..": {
                    return DataResult.error(() -> "Invalid segment '" + string2 + "' in path '" + string + "'");
                }
            }
            if (!PathUtil.isFileNameValid(string2)) {
                return DataResult.error(() -> "Invalid segment '" + string2 + "' in path '" + string + "'");
            }
            list.add(string2);
            if (bl) {
                return DataResult.success(list);
            }
            j = i + 1;
            if ((i = string.indexOf(47, j)) != -1) continue;
            i = string.length();
            bl = true;
        }
    }

    public static Path getPath(Path path, List<String> list) {
        int i = list.size();
        return switch (i) {
            case 0 -> path;
            case 1 -> path.resolve(list.get(0));
            default -> {
                String[] strings = new String[i - 1];
                for (int j = 1; j < i; ++j) {
                    strings[j - 1] = list.get(j);
                }
                yield path.resolve(path.getFileSystem().getPath(list.get(0), strings));
            }
        };
    }

    public static boolean isFileNameValid(String string) {
        return VALID_FILE_NAME.matcher(string).matches();
    }

    public static void validatePath(String ... strings) {
        if (strings.length == 0) {
            throw new IllegalArgumentException("Path must have at least one element");
        }
        for (String string : strings) {
            if (!string.equals("..") && !string.equals(".") && PathUtil.isFileNameValid(string)) continue;
            throw new IllegalArgumentException("Illegal segment " + string + " in path " + Arrays.toString(strings));
        }
    }

    public static void createDirectories(Path path) throws IOException {
        Files.createDirectories(Files.exists(path, new LinkOption[0]) ? path.toRealPath(new LinkOption[0]) : path, new FileAttribute[0]);
    }
}


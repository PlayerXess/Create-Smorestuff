/*
 * Decompiled with CFR 0.2.1 (FabricMC 53fa44c9).
 */
package net.minecraft.block;

import net.minecraft.block.AbstractBlock;
import net.minecraft.block.Block;
import net.minecraft.block.BlockRenderType;
import net.minecraft.block.BlockState;
import net.minecraft.block.BlockWithEntity;
import net.minecraft.block.Blocks;
import net.minecraft.block.HorizontalFacingBlock;
import net.minecraft.block.ShapeContext;
import net.minecraft.block.WallMountedBlock;
import net.minecraft.block.entity.BellBlockEntity;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.block.entity.BlockEntityTicker;
import net.minecraft.block.entity.BlockEntityType;
import net.minecraft.block.enums.Attachment;
import net.minecraft.entity.Entity;
import net.minecraft.entity.ai.pathing.NavigationType;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.projectile.ProjectileEntity;
import net.minecraft.item.ItemPlacementContext;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.stat.Stats;
import net.minecraft.state.StateManager;
import net.minecraft.state.property.BooleanProperty;
import net.minecraft.state.property.DirectionProperty;
import net.minecraft.state.property.EnumProperty;
import net.minecraft.state.property.Properties;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.shape.VoxelShape;
import net.minecraft.util.shape.VoxelShapes;
import net.minecraft.world.BlockView;
import net.minecraft.world.World;
import net.minecraft.world.WorldAccess;
import net.minecraft.world.WorldView;
import net.minecraft.world.event.GameEvent;
import org.jetbrains.annotations.Nullable;

public class BellBlock
extends BlockWithEntity {
    public static final DirectionProperty FACING = HorizontalFacingBlock.FACING;
    public static final EnumProperty<Attachment> ATTACHMENT = Properties.ATTACHMENT;
    public static final BooleanProperty POWERED = Properties.POWERED;
    private static final VoxelShape NORTH_SOUTH_SHAPE = Block.createCuboidShape(0.0, 0.0, 4.0, 16.0, 16.0, 12.0);
    private static final VoxelShape EAST_WEST_SHAPE = Block.createCuboidShape(4.0, 0.0, 0.0, 12.0, 16.0, 16.0);
    private static final VoxelShape BELL_WAIST_SHAPE = Block.createCuboidShape(5.0, 6.0, 5.0, 11.0, 13.0, 11.0);
    private static final VoxelShape BELL_LIP_SHAPE = Block.createCuboidShape(4.0, 4.0, 4.0, 12.0, 6.0, 12.0);
    private static final VoxelShape BELL_SHAPE = VoxelShapes.union(BELL_LIP_SHAPE, BELL_WAIST_SHAPE);
    private static final VoxelShape NORTH_SOUTH_WALLS_SHAPE = VoxelShapes.union(BELL_SHAPE, Block.createCuboidShape(7.0, 13.0, 0.0, 9.0, 15.0, 16.0));
    private static final VoxelShape EAST_WEST_WALLS_SHAPE = VoxelShapes.union(BELL_SHAPE, Block.createCuboidShape(0.0, 13.0, 7.0, 16.0, 15.0, 9.0));
    private static final VoxelShape WEST_WALL_SHAPE = VoxelShapes.union(BELL_SHAPE, Block.createCuboidShape(0.0, 13.0, 7.0, 13.0, 15.0, 9.0));
    private static final VoxelShape EAST_WALL_SHAPE = VoxelShapes.union(BELL_SHAPE, Block.createCuboidShape(3.0, 13.0, 7.0, 16.0, 15.0, 9.0));
    private static final VoxelShape NORTH_WALL_SHAPE = VoxelShapes.union(BELL_SHAPE, Block.createCuboidShape(7.0, 13.0, 0.0, 9.0, 15.0, 13.0));
    private static final VoxelShape SOUTH_WALL_SHAPE = VoxelShapes.union(BELL_SHAPE, Block.createCuboidShape(7.0, 13.0, 3.0, 9.0, 15.0, 16.0));
    private static final VoxelShape HANGING_SHAPE = VoxelShapes.union(BELL_SHAPE, Block.createCuboidShape(7.0, 13.0, 7.0, 9.0, 16.0, 9.0));
    public static final int field_31014 = 1;

    public BellBlock(AbstractBlock.Settings settings) {
        super(settings);
        this.setDefaultState((BlockState)((BlockState)((BlockState)((BlockState)this.stateManager.getDefaultState()).with(FACING, Direction.field_11043)).with(ATTACHMENT, Attachment.field_17098)).with(POWERED, false));
    }

    @Override
    public void neighborUpdate(BlockState blockState, World world, BlockPos blockPos, Block block, BlockPos blockPos2, boolean bl) {
        boolean bl2 = world.isReceivingRedstonePower(blockPos);
        if (bl2 != blockState.get(POWERED)) {
            if (bl2) {
                this.ring(world, blockPos, null);
            }
            world.setBlockState(blockPos, (BlockState)blockState.with(POWERED, bl2), 3);
        }
    }

    @Override
    public void onProjectileHit(World world, BlockState blockState, BlockHitResult blockHitResult, ProjectileEntity projectileEntity) {
        Entity entity = projectileEntity.getOwner();
        PlayerEntity playerEntity = entity instanceof PlayerEntity ? (PlayerEntity)entity : null;
        this.ring(world, blockState, blockHitResult, playerEntity, true);
    }

    @Override
    public ActionResult onUse(BlockState blockState, World world, BlockPos blockPos, PlayerEntity playerEntity, Hand hand, BlockHitResult blockHitResult) {
        return this.ring(world, blockState, blockHitResult, playerEntity, true) ? ActionResult.success(world.isClient) : ActionResult.PASS;
    }

    public boolean ring(World world, BlockState blockState, BlockHitResult blockHitResult, @Nullable PlayerEntity playerEntity, boolean bl) {
        boolean bl2;
        Direction direction = blockHitResult.getSide();
        BlockPos blockPos = blockHitResult.getBlockPos();
        boolean bl3 = bl2 = !bl || this.isPointOnBell(blockState, direction, blockHitResult.getPos().y - (double)blockPos.getY());
        if (bl2) {
            boolean bl32 = this.ring(playerEntity, world, blockPos, direction);
            if (bl32 && playerEntity != null) {
                playerEntity.incrementStat(Stats.field_19255);
            }
            return true;
        }
        return false;
    }

    private boolean isPointOnBell(BlockState blockState, Direction direction, double d) {
        if (direction.getAxis() == Direction.Axis.field_11052 || d > (double)0.8124f) {
            return false;
        }
        Direction direction2 = blockState.get(FACING);
        Attachment attachment = blockState.get(ATTACHMENT);
        switch (attachment) {
            case field_17098: {
                return direction2.getAxis() == direction.getAxis();
            }
            case field_17100: 
            case field_17101: {
                return direction2.getAxis() != direction.getAxis();
            }
            case field_17099: {
                return true;
            }
        }
        return false;
    }

    public boolean ring(World world, BlockPos blockPos, @Nullable Direction direction) {
        return this.ring(null, world, blockPos, direction);
    }

    public boolean ring(@Nullable Entity entity, World world, BlockPos blockPos, @Nullable Direction direction) {
        BlockEntity blockEntity = world.getBlockEntity(blockPos);
        if (!world.isClient && blockEntity instanceof BellBlockEntity) {
            if (direction == null) {
                direction = world.getBlockState(blockPos).get(FACING);
            }
            ((BellBlockEntity)blockEntity).activate(direction);
            world.playSound(null, blockPos, SoundEvents.field_17265, SoundCategory.field_15245, 2.0f, 1.0f);
            world.emitGameEvent(entity, GameEvent.field_28733, blockPos);
            return true;
        }
        return false;
    }

    private VoxelShape getShape(BlockState blockState) {
        Direction direction = blockState.get(FACING);
        Attachment attachment = blockState.get(ATTACHMENT);
        if (attachment == Attachment.field_17098) {
            if (direction == Direction.field_11043 || direction == Direction.field_11035) {
                return NORTH_SOUTH_SHAPE;
            }
            return EAST_WEST_SHAPE;
        }
        if (attachment == Attachment.field_17099) {
            return HANGING_SHAPE;
        }
        if (attachment == Attachment.field_17101) {
            if (direction == Direction.field_11043 || direction == Direction.field_11035) {
                return NORTH_SOUTH_WALLS_SHAPE;
            }
            return EAST_WEST_WALLS_SHAPE;
        }
        if (direction == Direction.field_11043) {
            return NORTH_WALL_SHAPE;
        }
        if (direction == Direction.field_11035) {
            return SOUTH_WALL_SHAPE;
        }
        if (direction == Direction.field_11034) {
            return EAST_WALL_SHAPE;
        }
        return WEST_WALL_SHAPE;
    }

    @Override
    public VoxelShape getCollisionShape(BlockState blockState, BlockView blockView, BlockPos blockPos, ShapeContext shapeContext) {
        return this.getShape(blockState);
    }

    @Override
    public VoxelShape getOutlineShape(BlockState blockState, BlockView blockView, BlockPos blockPos, ShapeContext shapeContext) {
        return this.getShape(blockState);
    }

    @Override
    public BlockRenderType getRenderType(BlockState blockState) {
        return BlockRenderType.field_11458;
    }

    @Override
    @Nullable
    public BlockState getPlacementState(ItemPlacementContext itemPlacementContext) {
        Direction direction = itemPlacementContext.getSide();
        BlockPos blockPos = itemPlacementContext.getBlockPos();
        World world = itemPlacementContext.getWorld();
        Direction.Axis axis = direction.getAxis();
        if (axis == Direction.Axis.field_11052) {
            BlockState blockState = (BlockState)((BlockState)this.getDefaultState().with(ATTACHMENT, direction == Direction.field_11033 ? Attachment.field_17099 : Attachment.field_17098)).with(FACING, itemPlacementContext.getHorizontalPlayerFacing());
            if (blockState.canPlaceAt(itemPlacementContext.getWorld(), blockPos)) {
                return blockState;
            }
        } else {
            boolean bl = axis == Direction.Axis.field_11048 && world.getBlockState(blockPos.west()).isSideSolidFullSquare(world, blockPos.west(), Direction.field_11034) && world.getBlockState(blockPos.east()).isSideSolidFullSquare(world, blockPos.east(), Direction.field_11039) || axis == Direction.Axis.field_11051 && world.getBlockState(blockPos.north()).isSideSolidFullSquare(world, blockPos.north(), Direction.field_11035) && world.getBlockState(blockPos.south()).isSideSolidFullSquare(world, blockPos.south(), Direction.field_11043);
            BlockState blockState = (BlockState)((BlockState)this.getDefaultState().with(FACING, direction.getOpposite())).with(ATTACHMENT, bl ? Attachment.field_17101 : Attachment.field_17100);
            if (blockState.canPlaceAt(itemPlacementContext.getWorld(), itemPlacementContext.getBlockPos())) {
                return blockState;
            }
            boolean bl2 = world.getBlockState(blockPos.down()).isSideSolidFullSquare(world, blockPos.down(), Direction.field_11036);
            if ((blockState = (BlockState)blockState.with(ATTACHMENT, bl2 ? Attachment.field_17098 : Attachment.field_17099)).canPlaceAt(itemPlacementContext.getWorld(), itemPlacementContext.getBlockPos())) {
                return blockState;
            }
        }
        return null;
    }

    @Override
    public BlockState getStateForNeighborUpdate(BlockState blockState, Direction direction, BlockState blockState2, WorldAccess worldAccess, BlockPos blockPos, BlockPos blockPos2) {
        Attachment attachment = blockState.get(ATTACHMENT);
        Direction direction2 = BellBlock.getPlacementSide(blockState).getOpposite();
        if (direction2 == direction && !blockState.canPlaceAt(worldAccess, blockPos) && attachment != Attachment.field_17101) {
            return Blocks.field_10124.getDefaultState();
        }
        if (direction.getAxis() == blockState.get(FACING).getAxis()) {
            if (attachment == Attachment.field_17101 && !blockState2.isSideSolidFullSquare(worldAccess, blockPos2, direction)) {
                return (BlockState)((BlockState)blockState.with(ATTACHMENT, Attachment.field_17100)).with(FACING, direction.getOpposite());
            }
            if (attachment == Attachment.field_17100 && direction2.getOpposite() == direction && blockState2.isSideSolidFullSquare(worldAccess, blockPos2, blockState.get(FACING))) {
                return (BlockState)blockState.with(ATTACHMENT, Attachment.field_17101);
            }
        }
        return super.getStateForNeighborUpdate(blockState, direction, blockState2, worldAccess, blockPos, blockPos2);
    }

    @Override
    public boolean canPlaceAt(BlockState blockState, WorldView worldView, BlockPos blockPos) {
        Direction direction = BellBlock.getPlacementSide(blockState).getOpposite();
        if (direction == Direction.field_11036) {
            return Block.sideCoversSmallSquare(worldView, blockPos.up(), Direction.field_11033);
        }
        return WallMountedBlock.canPlaceAt(worldView, blockPos, direction);
    }

    private static Direction getPlacementSide(BlockState blockState) {
        switch (blockState.get(ATTACHMENT)) {
            case field_17099: {
                return Direction.field_11033;
            }
            case field_17098: {
                return Direction.field_11036;
            }
        }
        return blockState.get(FACING).getOpposite();
    }

    @Override
    protected void appendProperties(StateManager.Builder<Block, BlockState> builder) {
        builder.add(FACING, ATTACHMENT, POWERED);
    }

    @Override
    @Nullable
    public BlockEntity createBlockEntity(BlockPos blockPos, BlockState blockState) {
        return new BellBlockEntity(blockPos, blockState);
    }

    @Override
    @Nullable
    public <T extends BlockEntity> BlockEntityTicker<T> getTicker(World world, BlockState blockState, BlockEntityType<T> blockEntityType) {
        return BellBlock.checkType(blockEntityType, BlockEntityType.field_16413, world.isClient ? BellBlockEntity::clientTick : BellBlockEntity::serverTick);
    }

    @Override
    public boolean canPathfindThrough(BlockState blockState, BlockView blockView, BlockPos blockPos, NavigationType navigationType) {
        return false;
    }
}


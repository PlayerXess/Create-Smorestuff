/*
 * Decompiled with CFR 0.2.1 (FabricMC 53fa44c9).
 */
package net.minecraft.item;

import com.google.common.collect.Maps;
import java.util.Map;
import net.minecraft.block.entity.SignBlockEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.passive.SheepEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.SignChangingItem;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.ActionResult;
import net.minecraft.util.DyeColor;
import net.minecraft.util.Hand;
import net.minecraft.world.World;

public class DyeItem
extends Item
implements SignChangingItem {
    private static final Map<DyeColor, DyeItem> DYES = Maps.newEnumMap(DyeColor.class);
    private final DyeColor color;

    public DyeItem(DyeColor dyeColor, Item.Settings settings) {
        super(settings);
        this.color = dyeColor;
        DYES.put(dyeColor, this);
    }

    @Override
    public ActionResult useOnEntity(ItemStack itemStack, PlayerEntity playerEntity, LivingEntity livingEntity, Hand hand) {
        SheepEntity sheepEntity;
        if (livingEntity instanceof SheepEntity && (sheepEntity = (SheepEntity)livingEntity).isAlive() && !sheepEntity.isSheared() && sheepEntity.getColor() != this.color) {
            sheepEntity.getWorld().playSoundFromEntity(playerEntity, sheepEntity, SoundEvents.field_28391, SoundCategory.field_15248, 1.0f, 1.0f);
            if (!playerEntity.getWorld().isClient) {
                sheepEntity.setColor(this.color);
                itemStack.decrement(1);
            }
            return ActionResult.success(playerEntity.getWorld().isClient);
        }
        return ActionResult.PASS;
    }

    public DyeColor getColor() {
        return this.color;
    }

    public static DyeItem byColor(DyeColor dyeColor) {
        return DYES.get(dyeColor);
    }

    @Override
    public boolean useOnSign(World world, SignBlockEntity signBlockEntity, boolean bl, PlayerEntity playerEntity) {
        if (signBlockEntity.changeText(signText -> signText.withColor(this.getColor()), bl)) {
            world.playSound(null, signBlockEntity.getPos(), SoundEvents.field_28391, SoundCategory.field_15245, 1.0f, 1.0f);
            return true;
        }
        return false;
    }
}


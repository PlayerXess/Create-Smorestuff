/*
 * Decompiled with CFR 0.2.1 (FabricMC 53fa44c9).
 */
package net.minecraft.recipe.book;

import net.minecraft.util.StringIdentifiable;

public enum CookingRecipeCategory implements StringIdentifiable
{
    field_40242("food"),
    field_40243("blocks"),
    field_40244("misc");

    public static final StringIdentifiable.Codec<CookingRecipeCategory> CODEC;
    private final String id;

    private CookingRecipeCategory(String string2) {
        this.id = string2;
    }

    @Override
    public String asString() {
        return this.id;
    }

    static {
        CODEC = StringIdentifiable.createCodec(CookingRecipeCategory::values);
    }
}


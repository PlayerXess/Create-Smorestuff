/*
 * Decompiled with CFR 0.2.1 (FabricMC 53fa44c9).
 */
package net.minecraft.unused.packageinfo;

import javax.annotation.ParametersAreNonnullByDefault;
import net.minecraft.util.annotation.FieldsAreNonnullByDefault2;
import net.minecraft.util.annotation.MathMethodsReturnNonnullByDefault;

@ParametersAreNonnullByDefault
@MathMethodsReturnNonnullByDefault
@FieldsAreNonnullByDefault2
interface PackageInfo6305 {
}


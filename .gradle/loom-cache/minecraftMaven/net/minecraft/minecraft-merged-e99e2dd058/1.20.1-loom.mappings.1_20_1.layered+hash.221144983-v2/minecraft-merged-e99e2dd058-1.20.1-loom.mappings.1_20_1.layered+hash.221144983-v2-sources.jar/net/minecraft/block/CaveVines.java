/*
 * Decompiled with CFR 0.2.1 (FabricMC 53fa44c9).
 */
package net.minecraft.block;

import java.util.function.ToIntFunction;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.entity.Entity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.state.property.BooleanProperty;
import net.minecraft.state.property.Properties;
import net.minecraft.util.ActionResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.shape.VoxelShape;
import net.minecraft.world.World;
import net.minecraft.world.event.GameEvent;
import org.jetbrains.annotations.Nullable;

public interface CaveVines {
    public static final VoxelShape SHAPE = Block.createCuboidShape(1.0, 0.0, 1.0, 15.0, 16.0, 15.0);
    public static final BooleanProperty BERRIES = Properties.BERRIES;

    public static ActionResult pickBerries(@Nullable Entity entity, BlockState blockState, World world, BlockPos blockPos) {
        if (blockState.get(BERRIES).booleanValue()) {
            Block.dropStack(world, blockPos, new ItemStack(Items.field_28659, 1));
            float f = MathHelper.nextBetween(world.random, 0.8f, 1.2f);
            world.playSound(null, blockPos, SoundEvents.field_28575, SoundCategory.field_15245, 1.0f, f);
            BlockState blockState2 = (BlockState)blockState.with(BERRIES, false);
            world.setBlockState(blockPos, blockState2, 2);
            world.emitGameEvent(GameEvent.field_28733, blockPos, GameEvent.Emitter.of(entity, blockState2));
            return ActionResult.success(world.isClient);
        }
        return ActionResult.PASS;
    }

    public static boolean hasBerries(BlockState blockState) {
        return blockState.contains(BERRIES) && blockState.get(BERRIES) != false;
    }

    public static ToIntFunction<BlockState> getLuminanceSupplier(int i) {
        return blockState -> blockState.get(Properties.BERRIES) != false ? i : 0;
    }
}


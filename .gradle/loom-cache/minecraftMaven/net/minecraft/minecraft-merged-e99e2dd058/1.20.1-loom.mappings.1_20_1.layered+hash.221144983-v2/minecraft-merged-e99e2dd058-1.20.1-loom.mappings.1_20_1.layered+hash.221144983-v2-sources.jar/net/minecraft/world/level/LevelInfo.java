/*
 * Decompiled with CFR 0.2.1 (FabricMC 53fa44c9).
 */
package net.minecraft.world.level;

import com.mojang.serialization.Dynamic;
import net.minecraft.resource.DataConfiguration;
import net.minecraft.world.Difficulty;
import net.minecraft.world.GameMode;
import net.minecraft.world.GameRules;

public final class LevelInfo {
    private final String name;
    private final GameMode gameMode;
    private final boolean hardcore;
    private final Difficulty difficulty;
    private final boolean allowCommands;
    private final GameRules gameRules;
    private final DataConfiguration dataConfiguration;

    public LevelInfo(String string, GameMode gameMode, boolean bl, Difficulty difficulty, boolean bl2, GameRules gameRules, DataConfiguration dataConfiguration) {
        this.name = string;
        this.gameMode = gameMode;
        this.hardcore = bl;
        this.difficulty = difficulty;
        this.allowCommands = bl2;
        this.gameRules = gameRules;
        this.dataConfiguration = dataConfiguration;
    }

    public static LevelInfo fromDynamic(Dynamic<?> dynamic, DataConfiguration dataConfiguration) {
        GameMode gameMode = GameMode.byId(dynamic.get("GameType").asInt(0));
        return new LevelInfo(dynamic.get("LevelName").asString(""), gameMode, dynamic.get("hardcore").asBoolean(false), dynamic.get("Difficulty").asNumber().map(number -> Difficulty.byId(number.byteValue())).result().orElse(Difficulty.field_5802), dynamic.get("allowCommands").asBoolean(gameMode == GameMode.field_9220), new GameRules(dynamic.get("GameRules")), dataConfiguration);
    }

    public String getLevelName() {
        return this.name;
    }

    public GameMode getGameMode() {
        return this.gameMode;
    }

    public boolean isHardcore() {
        return this.hardcore;
    }

    public Difficulty getDifficulty() {
        return this.difficulty;
    }

    public boolean areCommandsAllowed() {
        return this.allowCommands;
    }

    public GameRules getGameRules() {
        return this.gameRules;
    }

    public DataConfiguration getDataConfiguration() {
        return this.dataConfiguration;
    }

    public LevelInfo withGameMode(GameMode gameMode) {
        return new LevelInfo(this.name, gameMode, this.hardcore, this.difficulty, this.allowCommands, this.gameRules, this.dataConfiguration);
    }

    public LevelInfo withDifficulty(Difficulty difficulty) {
        return new LevelInfo(this.name, this.gameMode, this.hardcore, difficulty, this.allowCommands, this.gameRules, this.dataConfiguration);
    }

    public LevelInfo withDataConfiguration(DataConfiguration dataConfiguration) {
        return new LevelInfo(this.name, this.gameMode, this.hardcore, this.difficulty, this.allowCommands, this.gameRules, dataConfiguration);
    }

    public LevelInfo withCopiedGameRules() {
        return new LevelInfo(this.name, this.gameMode, this.hardcore, this.difficulty, this.allowCommands, this.gameRules.copy(), this.dataConfiguration);
    }
}


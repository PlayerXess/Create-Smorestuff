/*
 * Decompiled with CFR 0.2.1 (FabricMC 53fa44c9).
 */
package net.minecraft.item;

import java.util.function.Supplier;
import net.minecraft.item.Items;
import net.minecraft.item.ToolMaterial;
import net.minecraft.recipe.Ingredient;
import net.minecraft.registry.tag.ItemTags;
import net.minecraft.util.Lazy;

public enum ToolMaterials implements ToolMaterial
{
    field_8922(0, 59, 2.0f, 0.0f, 15, () -> Ingredient.fromTag(ItemTags.field_15537)),
    field_8927(1, 131, 4.0f, 1.0f, 5, () -> Ingredient.fromTag(ItemTags.field_23802)),
    field_8923(2, 250, 6.0f, 2.0f, 14, () -> Ingredient.ofItems(Items.field_8620)),
    field_8930(3, 1561, 8.0f, 3.0f, 10, () -> Ingredient.ofItems(Items.field_8477)),
    field_8929(0, 32, 12.0f, 0.0f, 22, () -> Ingredient.ofItems(Items.field_8695)),
    field_22033(4, 2031, 9.0f, 4.0f, 15, () -> Ingredient.ofItems(Items.field_22020));

    private final int miningLevel;
    private final int itemDurability;
    private final float miningSpeed;
    private final float attackDamage;
    private final int enchantability;
    private final Lazy<Ingredient> repairIngredient;

    private ToolMaterials(int j, int k, float f, float g, int l, Supplier<Ingredient> supplier) {
        this.miningLevel = j;
        this.itemDurability = k;
        this.miningSpeed = f;
        this.attackDamage = g;
        this.enchantability = l;
        this.repairIngredient = new Lazy<Ingredient>(supplier);
    }

    @Override
    public int getDurability() {
        return this.itemDurability;
    }

    @Override
    public float getMiningSpeedMultiplier() {
        return this.miningSpeed;
    }

    @Override
    public float getAttackDamage() {
        return this.attackDamage;
    }

    @Override
    public int getMiningLevel() {
        return this.miningLevel;
    }

    @Override
    public int getEnchantability() {
        return this.enchantability;
    }

    @Override
    public Ingredient getRepairIngredient() {
        return this.repairIngredient.get();
    }
}


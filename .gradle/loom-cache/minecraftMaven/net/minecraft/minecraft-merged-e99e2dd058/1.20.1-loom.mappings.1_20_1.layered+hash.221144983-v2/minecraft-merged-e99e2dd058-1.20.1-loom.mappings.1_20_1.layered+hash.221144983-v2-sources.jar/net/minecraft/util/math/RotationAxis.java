/*
 * Decompiled with CFR 0.2.1 (FabricMC 53fa44c9).
 */
package net.minecraft.util.math;

import org.joml.Quaternionf;
import org.joml.Vector3f;

@FunctionalInterface
public interface RotationAxis {
    public static final RotationAxis NEGATIVE_X = f -> new Quaternionf().rotationX(-f);
    public static final RotationAxis POSITIVE_X = f -> new Quaternionf().rotationX(f);
    public static final RotationAxis NEGATIVE_Y = f -> new Quaternionf().rotationY(-f);
    public static final RotationAxis POSITIVE_Y = f -> new Quaternionf().rotationY(f);
    public static final RotationAxis NEGATIVE_Z = f -> new Quaternionf().rotationZ(-f);
    public static final RotationAxis POSITIVE_Z = f -> new Quaternionf().rotationZ(f);

    public static RotationAxis of(Vector3f vector3f) {
        return f -> new Quaternionf().rotationAxis(f, vector3f);
    }

    public Quaternionf rotation(float var1);

    default public Quaternionf rotationDegrees(float f) {
        return this.rotation(f * ((float)Math.PI / 180));
    }
}


/*
 * Decompiled with CFR 0.2.1 (FabricMC 53fa44c9).
 */
package net.minecraft.block;

import java.util.function.BiPredicate;
import java.util.function.Function;
import net.minecraft.block.BlockState;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.block.entity.BlockEntityType;
import net.minecraft.state.property.DirectionProperty;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.world.WorldAccess;

public class DoubleBlockProperties {
    public static <S extends BlockEntity> PropertySource<S> toPropertySource(BlockEntityType<S> blockEntityType, Function<BlockState, Type> function, Function<BlockState, Direction> function2, DirectionProperty directionProperty, BlockState blockState, WorldAccess worldAccess, BlockPos blockPos, BiPredicate<WorldAccess, BlockPos> biPredicate) {
        Type type2;
        boolean bl2;
        S blockEntity = blockEntityType.get(worldAccess, blockPos);
        if (blockEntity == null) {
            return PropertyRetriever::getFallback;
        }
        if (biPredicate.test(worldAccess, blockPos)) {
            return PropertyRetriever::getFallback;
        }
        Type type = function.apply(blockState);
        boolean bl = type == Type.field_21783;
        boolean bl3 = bl2 = type == Type.field_21784;
        if (bl) {
            return new PropertySource.Single<S>(blockEntity);
        }
        BlockPos blockPos2 = blockPos.offset(function2.apply(blockState));
        BlockState blockState2 = worldAccess.getBlockState(blockPos2);
        if (blockState2.isOf(blockState.getBlock()) && (type2 = function.apply(blockState2)) != Type.field_21783 && type != type2 && blockState2.get(directionProperty) == blockState.get(directionProperty)) {
            if (biPredicate.test(worldAccess, blockPos2)) {
                return PropertyRetriever::getFallback;
            }
            S blockEntity2 = blockEntityType.get(worldAccess, blockPos2);
            if (blockEntity2 != null) {
                S blockEntity3 = bl2 ? blockEntity : blockEntity2;
                S blockEntity4 = bl2 ? blockEntity2 : blockEntity;
                return new PropertySource.Pair<S>(blockEntity3, blockEntity4);
            }
        }
        return new PropertySource.Single<S>(blockEntity);
    }

    public static interface PropertySource<S> {
        public <T> T apply(PropertyRetriever<? super S, T> var1);

        public static final class Single<S>
        implements PropertySource<S> {
            private final S single;

            public Single(S object) {
                this.single = object;
            }

            @Override
            public <T> T apply(PropertyRetriever<? super S, T> propertyRetriever) {
                return propertyRetriever.getFrom(this.single);
            }
        }

        public static final class Pair<S>
        implements PropertySource<S> {
            private final S first;
            private final S second;

            public Pair(S object, S object2) {
                this.first = object;
                this.second = object2;
            }

            @Override
            public <T> T apply(PropertyRetriever<? super S, T> propertyRetriever) {
                return propertyRetriever.getFromBoth(this.first, this.second);
            }
        }
    }

    public static enum Type {
        field_21783,
        field_21784,
        field_21785;

    }

    public static interface PropertyRetriever<S, T> {
        public T getFromBoth(S var1, S var2);

        public T getFrom(S var1);

        public T getFallback();
    }
}


/*
 * Decompiled with CFR 0.2.1 (FabricMC 53fa44c9).
 */
package net.minecraft.screen;

import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.resource.featuretoggle.FeatureFlag;
import net.minecraft.resource.featuretoggle.FeatureFlags;
import net.minecraft.resource.featuretoggle.FeatureSet;
import net.minecraft.resource.featuretoggle.ToggleableFeature;
import net.minecraft.screen.AnvilScreenHandler;
import net.minecraft.screen.BeaconScreenHandler;
import net.minecraft.screen.BlastFurnaceScreenHandler;
import net.minecraft.screen.BrewingStandScreenHandler;
import net.minecraft.screen.CartographyTableScreenHandler;
import net.minecraft.screen.CraftingScreenHandler;
import net.minecraft.screen.EnchantmentScreenHandler;
import net.minecraft.screen.FurnaceScreenHandler;
import net.minecraft.screen.Generic3x3ContainerScreenHandler;
import net.minecraft.screen.GenericContainerScreenHandler;
import net.minecraft.screen.GrindstoneScreenHandler;
import net.minecraft.screen.HopperScreenHandler;
import net.minecraft.screen.LecternScreenHandler;
import net.minecraft.screen.LoomScreenHandler;
import net.minecraft.screen.MerchantScreenHandler;
import net.minecraft.screen.ScreenHandler;
import net.minecraft.screen.ShulkerBoxScreenHandler;
import net.minecraft.screen.SmithingScreenHandler;
import net.minecraft.screen.SmokerScreenHandler;
import net.minecraft.screen.StonecutterScreenHandler;

public class ScreenHandlerType<T extends ScreenHandler>
implements ToggleableFeature {
    public static final ScreenHandlerType<GenericContainerScreenHandler> field_18664 = ScreenHandlerType.register("generic_9x1", GenericContainerScreenHandler::createGeneric9x1);
    public static final ScreenHandlerType<GenericContainerScreenHandler> field_18665 = ScreenHandlerType.register("generic_9x2", GenericContainerScreenHandler::createGeneric9x2);
    public static final ScreenHandlerType<GenericContainerScreenHandler> field_17326 = ScreenHandlerType.register("generic_9x3", GenericContainerScreenHandler::createGeneric9x3);
    public static final ScreenHandlerType<GenericContainerScreenHandler> field_18666 = ScreenHandlerType.register("generic_9x4", GenericContainerScreenHandler::createGeneric9x4);
    public static final ScreenHandlerType<GenericContainerScreenHandler> field_18667 = ScreenHandlerType.register("generic_9x5", GenericContainerScreenHandler::createGeneric9x5);
    public static final ScreenHandlerType<GenericContainerScreenHandler> field_17327 = ScreenHandlerType.register("generic_9x6", GenericContainerScreenHandler::createGeneric9x6);
    public static final ScreenHandlerType<Generic3x3ContainerScreenHandler> field_17328 = ScreenHandlerType.register("generic_3x3", Generic3x3ContainerScreenHandler::new);
    public static final ScreenHandlerType<AnvilScreenHandler> field_17329 = ScreenHandlerType.register("anvil", AnvilScreenHandler::new);
    public static final ScreenHandlerType<BeaconScreenHandler> field_17330 = ScreenHandlerType.register("beacon", BeaconScreenHandler::new);
    public static final ScreenHandlerType<BlastFurnaceScreenHandler> field_17331 = ScreenHandlerType.register("blast_furnace", BlastFurnaceScreenHandler::new);
    public static final ScreenHandlerType<BrewingStandScreenHandler> field_17332 = ScreenHandlerType.register("brewing_stand", BrewingStandScreenHandler::new);
    public static final ScreenHandlerType<CraftingScreenHandler> field_17333 = ScreenHandlerType.register("crafting", CraftingScreenHandler::new);
    public static final ScreenHandlerType<EnchantmentScreenHandler> field_17334 = ScreenHandlerType.register("enchantment", EnchantmentScreenHandler::new);
    public static final ScreenHandlerType<FurnaceScreenHandler> field_17335 = ScreenHandlerType.register("furnace", FurnaceScreenHandler::new);
    public static final ScreenHandlerType<GrindstoneScreenHandler> field_17336 = ScreenHandlerType.register("grindstone", GrindstoneScreenHandler::new);
    public static final ScreenHandlerType<HopperScreenHandler> field_17337 = ScreenHandlerType.register("hopper", HopperScreenHandler::new);
    public static final ScreenHandlerType<LecternScreenHandler> field_17338 = ScreenHandlerType.register("lectern", (i, playerInventory) -> new LecternScreenHandler(i));
    public static final ScreenHandlerType<LoomScreenHandler> field_17339 = ScreenHandlerType.register("loom", LoomScreenHandler::new);
    public static final ScreenHandlerType<MerchantScreenHandler> field_17340 = ScreenHandlerType.register("merchant", MerchantScreenHandler::new);
    public static final ScreenHandlerType<ShulkerBoxScreenHandler> field_17341 = ScreenHandlerType.register("shulker_box", ShulkerBoxScreenHandler::new);
    public static final ScreenHandlerType<SmithingScreenHandler> field_22484 = ScreenHandlerType.register("smithing", SmithingScreenHandler::new);
    public static final ScreenHandlerType<SmokerScreenHandler> field_17342 = ScreenHandlerType.register("smoker", SmokerScreenHandler::new);
    public static final ScreenHandlerType<CartographyTableScreenHandler> field_17343 = ScreenHandlerType.register("cartography_table", CartographyTableScreenHandler::new);
    public static final ScreenHandlerType<StonecutterScreenHandler> field_17625 = ScreenHandlerType.register("stonecutter", StonecutterScreenHandler::new);
    private final FeatureSet requiredFeatures;
    private final Factory<T> factory;

    private static <T extends ScreenHandler> ScreenHandlerType<T> register(String string, Factory<T> factory) {
        return Registry.register(Registries.SCREEN_HANDLER, string, new ScreenHandlerType<T>(factory, FeatureFlags.VANILLA_FEATURES));
    }

    private static <T extends ScreenHandler> ScreenHandlerType<T> register(String string, Factory<T> factory, FeatureFlag ... featureFlags) {
        return Registry.register(Registries.SCREEN_HANDLER, string, new ScreenHandlerType<T>(factory, FeatureFlags.FEATURE_MANAGER.featureSetOf(featureFlags)));
    }

    public ScreenHandlerType(Factory<T> factory, FeatureSet featureSet) {
        this.factory = factory;
        this.requiredFeatures = featureSet;
    }

    public T create(int i, PlayerInventory playerInventory) {
        return this.factory.create(i, playerInventory);
    }

    @Override
    public FeatureSet getRequiredFeatures() {
        return this.requiredFeatures;
    }

    public static interface Factory<T extends ScreenHandler> {
        public T create(int var1, PlayerInventory var2);
    }
}


/*
 * Decompiled with CFR 0.2.1 (FabricMC 53fa44c9).
 */
package net.minecraft.item;

import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.Saddleable;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.sound.SoundCategory;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.world.event.GameEvent;

public class SaddleItem
extends Item {
    public SaddleItem(Item.Settings settings) {
        super(settings);
    }

    @Override
    public ActionResult useOnEntity(ItemStack itemStack, PlayerEntity playerEntity, LivingEntity livingEntity, Hand hand) {
        Saddleable saddleable;
        if (livingEntity instanceof Saddleable && livingEntity.isAlive() && !(saddleable = (Saddleable)((Object)livingEntity)).isSaddled() && saddleable.canBeSaddled()) {
            if (!playerEntity.getWorld().isClient) {
                saddleable.saddle(SoundCategory.field_15254);
                livingEntity.getWorld().emitGameEvent((Entity)livingEntity, GameEvent.field_28739, livingEntity.getPos());
                itemStack.decrement(1);
            }
            return ActionResult.success(playerEntity.getWorld().isClient);
        }
        return ActionResult.PASS;
    }
}


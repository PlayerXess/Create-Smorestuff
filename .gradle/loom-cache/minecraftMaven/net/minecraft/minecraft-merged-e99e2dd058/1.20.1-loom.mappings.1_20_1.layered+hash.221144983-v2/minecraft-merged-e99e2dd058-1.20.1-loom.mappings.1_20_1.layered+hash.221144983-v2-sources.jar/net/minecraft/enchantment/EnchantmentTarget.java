/*
 * Decompiled with CFR 0.2.1 (FabricMC 53fa44c9).
 */
package net.minecraft.enchantment;

import net.minecraft.block.Block;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.item.ArmorItem;
import net.minecraft.item.BowItem;
import net.minecraft.item.CrossbowItem;
import net.minecraft.item.Equipment;
import net.minecraft.item.FishingRodItem;
import net.minecraft.item.Item;
import net.minecraft.item.MiningToolItem;
import net.minecraft.item.SwordItem;
import net.minecraft.item.TridentItem;
import net.minecraft.item.Vanishable;

/*
 * Uses 'sealed' constructs - enablewith --sealed true
 */
public enum EnchantmentTarget {
    field_9068{

        @Override
        public boolean isAcceptableItem(Item item) {
            return item instanceof ArmorItem;
        }
    }
    ,
    field_9079{

        @Override
        public boolean isAcceptableItem(Item item) {
            ArmorItem armorItem;
            return item instanceof ArmorItem && (armorItem = (ArmorItem)item).getSlotType() == EquipmentSlot.field_6166;
        }
    }
    ,
    field_9076{

        @Override
        public boolean isAcceptableItem(Item item) {
            ArmorItem armorItem;
            return item instanceof ArmorItem && (armorItem = (ArmorItem)item).getSlotType() == EquipmentSlot.field_6172;
        }
    }
    ,
    field_9071{

        @Override
        public boolean isAcceptableItem(Item item) {
            ArmorItem armorItem;
            return item instanceof ArmorItem && (armorItem = (ArmorItem)item).getSlotType() == EquipmentSlot.field_6174;
        }
    }
    ,
    field_9080{

        @Override
        public boolean isAcceptableItem(Item item) {
            ArmorItem armorItem;
            return item instanceof ArmorItem && (armorItem = (ArmorItem)item).getSlotType() == EquipmentSlot.field_6169;
        }
    }
    ,
    field_9074{

        @Override
        public boolean isAcceptableItem(Item item) {
            return item instanceof SwordItem;
        }
    }
    ,
    field_9069{

        @Override
        public boolean isAcceptableItem(Item item) {
            return item instanceof MiningToolItem;
        }
    }
    ,
    field_9072{

        @Override
        public boolean isAcceptableItem(Item item) {
            return item instanceof FishingRodItem;
        }
    }
    ,
    field_9073{

        @Override
        public boolean isAcceptableItem(Item item) {
            return item instanceof TridentItem;
        }
    }
    ,
    field_9082{

        @Override
        public boolean isAcceptableItem(Item item) {
            return item.isDamageable();
        }
    }
    ,
    field_9070{

        @Override
        public boolean isAcceptableItem(Item item) {
            return item instanceof BowItem;
        }
    }
    ,
    field_9078{

        @Override
        public boolean isAcceptableItem(Item item) {
            return item instanceof Equipment || Block.getBlockFromItem(item) instanceof Equipment;
        }
    }
    ,
    field_9081{

        @Override
        public boolean isAcceptableItem(Item item) {
            return item instanceof CrossbowItem;
        }
    }
    ,
    field_23747{

        @Override
        public boolean isAcceptableItem(Item item) {
            return item instanceof Vanishable || Block.getBlockFromItem(item) instanceof Vanishable || field_9082.isAcceptableItem(item);
        }
    };


    public abstract boolean isAcceptableItem(Item var1);
}


/*
 * Decompiled with CFR 0.2.1 (FabricMC 53fa44c9).
 */
package net.minecraft.item;

import net.minecraft.advancement.criterion.Criteria;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.FluidDrainable;
import net.minecraft.block.FluidFillable;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.fluid.FlowableFluid;
import net.minecraft.fluid.Fluid;
import net.minecraft.fluid.Fluids;
import net.minecraft.item.FluidModificationItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemUsage;
import net.minecraft.item.Items;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.registry.tag.FluidTags;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;
import net.minecraft.stat.Stats;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.world.RaycastContext;
import net.minecraft.world.World;
import net.minecraft.world.WorldAccess;
import net.minecraft.world.event.GameEvent;
import org.jetbrains.annotations.Nullable;

public class BucketItem
extends Item
implements FluidModificationItem {
    private final Fluid fluid;

    public BucketItem(Fluid fluid, Item.Settings settings) {
        super(settings);
        this.fluid = fluid;
    }

    @Override
    public TypedActionResult<ItemStack> use(World world, PlayerEntity playerEntity, Hand hand) {
        ItemStack itemStack = playerEntity.getStackInHand(hand);
        BlockHitResult blockHitResult = BucketItem.raycast(world, playerEntity, this.fluid == Fluids.field_15906 ? RaycastContext.FluidHandling.field_1345 : RaycastContext.FluidHandling.field_1348);
        if (blockHitResult.getType() == HitResult.Type.field_1333) {
            return TypedActionResult.pass(itemStack);
        }
        if (blockHitResult.getType() == HitResult.Type.field_1332) {
            BlockPos blockPos3;
            BlockPos blockPos = blockHitResult.getBlockPos();
            Direction direction = blockHitResult.getSide();
            BlockPos blockPos2 = blockPos.offset(direction);
            if (!world.canPlayerModifyAt(playerEntity, blockPos) || !playerEntity.canPlaceOn(blockPos2, direction, itemStack)) {
                return TypedActionResult.fail(itemStack);
            }
            if (this.fluid == Fluids.field_15906) {
                FluidDrainable fluidDrainable;
                ItemStack itemStack2;
                BlockState blockState = world.getBlockState(blockPos);
                if (blockState.getBlock() instanceof FluidDrainable && !(itemStack2 = (fluidDrainable = (FluidDrainable)((Object)blockState.getBlock())).tryDrainFluid(world, blockPos, blockState)).isEmpty()) {
                    playerEntity.incrementStat(Stats.field_15372.getOrCreateStat(this));
                    fluidDrainable.getBucketFillSound().ifPresent(soundEvent -> playerEntity.playSound((SoundEvent)soundEvent, 1.0f, 1.0f));
                    world.emitGameEvent((Entity)playerEntity, GameEvent.field_28167, blockPos);
                    ItemStack itemStack3 = ItemUsage.exchangeStack(itemStack, playerEntity, itemStack2);
                    if (!world.isClient) {
                        Criteria.FILLED_BUCKET.trigger((ServerPlayerEntity)playerEntity, itemStack2);
                    }
                    return TypedActionResult.success(itemStack3, world.isClient());
                }
                return TypedActionResult.fail(itemStack);
            }
            BlockState blockState = world.getBlockState(blockPos);
            BlockPos blockPos4 = blockPos3 = blockState.getBlock() instanceof FluidFillable && this.fluid == Fluids.WATER ? blockPos : blockPos2;
            if (this.placeFluid(playerEntity, world, blockPos3, blockHitResult)) {
                this.onEmptied(playerEntity, world, itemStack, blockPos3);
                if (playerEntity instanceof ServerPlayerEntity) {
                    Criteria.PLACED_BLOCK.trigger((ServerPlayerEntity)playerEntity, blockPos3, itemStack);
                }
                playerEntity.incrementStat(Stats.field_15372.getOrCreateStat(this));
                return TypedActionResult.success(BucketItem.getEmptiedStack(itemStack, playerEntity), world.isClient());
            }
            return TypedActionResult.fail(itemStack);
        }
        return TypedActionResult.pass(itemStack);
    }

    public static ItemStack getEmptiedStack(ItemStack itemStack, PlayerEntity playerEntity) {
        if (!playerEntity.getAbilities().creativeMode) {
            return new ItemStack(Items.field_8550);
        }
        return itemStack;
    }

    @Override
    public void onEmptied(@Nullable PlayerEntity playerEntity, World world, ItemStack itemStack, BlockPos blockPos) {
    }

    @Override
    public boolean placeFluid(@Nullable PlayerEntity playerEntity, World world, BlockPos blockPos, @Nullable BlockHitResult blockHitResult) {
        boolean bl2;
        if (!(this.fluid instanceof FlowableFluid)) {
            return false;
        }
        BlockState blockState = world.getBlockState(blockPos);
        Block block = blockState.getBlock();
        boolean bl = blockState.canBucketPlace(this.fluid);
        boolean bl3 = bl2 = blockState.isAir() || bl || block instanceof FluidFillable && ((FluidFillable)((Object)block)).canFillWithFluid(world, blockPos, blockState, this.fluid);
        if (!bl2) {
            return blockHitResult != null && this.placeFluid(playerEntity, world, blockHitResult.getBlockPos().offset(blockHitResult.getSide()), null);
        }
        if (world.getDimension().ultrawarm() && this.fluid.isIn(FluidTags.field_15517)) {
            int i = blockPos.getX();
            int j = blockPos.getY();
            int k = blockPos.getZ();
            world.playSound(playerEntity, blockPos, SoundEvents.field_15102, SoundCategory.field_15245, 0.5f, 2.6f + (world.random.nextFloat() - world.random.nextFloat()) * 0.8f);
            for (int l = 0; l < 8; ++l) {
                world.addParticle(ParticleTypes.field_11237, (double)i + Math.random(), (double)j + Math.random(), (double)k + Math.random(), 0.0, 0.0, 0.0);
            }
            return true;
        }
        if (block instanceof FluidFillable && this.fluid == Fluids.WATER) {
            ((FluidFillable)((Object)block)).tryFillWithFluid(world, blockPos, blockState, ((FlowableFluid)this.fluid).getStill(false));
            this.playEmptyingSound(playerEntity, world, blockPos);
            return true;
        }
        if (!world.isClient && bl && !blockState.isLiquid()) {
            world.breakBlock(blockPos, true);
        }
        if (world.setBlockState(blockPos, this.fluid.getDefaultState().getBlockState(), 11) || blockState.getFluidState().isStill()) {
            this.playEmptyingSound(playerEntity, world, blockPos);
            return true;
        }
        return false;
    }

    protected void playEmptyingSound(@Nullable PlayerEntity playerEntity, WorldAccess worldAccess, BlockPos blockPos) {
        SoundEvent soundEvent = this.fluid.isIn(FluidTags.field_15518) ? SoundEvents.field_15010 : SoundEvents.field_14834;
        worldAccess.playSound(playerEntity, blockPos, soundEvent, SoundCategory.field_15245, 1.0f, 1.0f);
        worldAccess.emitGameEvent((Entity)playerEntity, GameEvent.field_28166, blockPos);
    }
}


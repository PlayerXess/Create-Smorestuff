/*
 * Decompiled with CFR 0.2.1 (FabricMC 53fa44c9).
 */
package net.minecraft.block;

import net.minecraft.block.AbstractBlock;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.PlantBlock;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.block.enums.DoubleBlockHalf;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.fluid.Fluids;
import net.minecraft.item.ItemPlacementContext;
import net.minecraft.item.ItemStack;
import net.minecraft.state.StateManager;
import net.minecraft.state.property.EnumProperty;
import net.minecraft.state.property.Properties;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.MathHelper;
import net.minecraft.world.World;
import net.minecraft.world.WorldAccess;
import net.minecraft.world.WorldView;
import org.jetbrains.annotations.Nullable;

public class TallPlantBlock
extends PlantBlock {
    public static final EnumProperty<DoubleBlockHalf> HALF = Properties.DOUBLE_BLOCK_HALF;

    public TallPlantBlock(AbstractBlock.Settings settings) {
        super(settings);
        this.setDefaultState((BlockState)((BlockState)this.stateManager.getDefaultState()).with(HALF, DoubleBlockHalf.field_12607));
    }

    @Override
    public BlockState getStateForNeighborUpdate(BlockState blockState, Direction direction, BlockState blockState2, WorldAccess worldAccess, BlockPos blockPos, BlockPos blockPos2) {
        DoubleBlockHalf doubleBlockHalf = blockState.get(HALF);
        if (!(direction.getAxis() != Direction.Axis.field_11052 || doubleBlockHalf == DoubleBlockHalf.field_12607 != (direction == Direction.field_11036) || blockState2.isOf(this) && blockState2.get(HALF) != doubleBlockHalf)) {
            return Blocks.field_10124.getDefaultState();
        }
        if (doubleBlockHalf == DoubleBlockHalf.field_12607 && direction == Direction.field_11033 && !blockState.canPlaceAt(worldAccess, blockPos)) {
            return Blocks.field_10124.getDefaultState();
        }
        return super.getStateForNeighborUpdate(blockState, direction, blockState2, worldAccess, blockPos, blockPos2);
    }

    @Override
    @Nullable
    public BlockState getPlacementState(ItemPlacementContext itemPlacementContext) {
        BlockPos blockPos = itemPlacementContext.getBlockPos();
        World world = itemPlacementContext.getWorld();
        if (blockPos.getY() < world.getTopY() - 1 && world.getBlockState(blockPos.up()).canReplace(itemPlacementContext)) {
            return super.getPlacementState(itemPlacementContext);
        }
        return null;
    }

    @Override
    public void onPlaced(World world, BlockPos blockPos, BlockState blockState, LivingEntity livingEntity, ItemStack itemStack) {
        BlockPos blockPos2 = blockPos.up();
        world.setBlockState(blockPos2, TallPlantBlock.withWaterloggedState(world, blockPos2, (BlockState)this.getDefaultState().with(HALF, DoubleBlockHalf.field_12609)), 3);
    }

    @Override
    public boolean canPlaceAt(BlockState blockState, WorldView worldView, BlockPos blockPos) {
        if (blockState.get(HALF) == DoubleBlockHalf.field_12609) {
            BlockState blockState2 = worldView.getBlockState(blockPos.down());
            return blockState2.isOf(this) && blockState2.get(HALF) == DoubleBlockHalf.field_12607;
        }
        return super.canPlaceAt(blockState, worldView, blockPos);
    }

    public static void placeAt(WorldAccess worldAccess, BlockState blockState, BlockPos blockPos, int i) {
        BlockPos blockPos2 = blockPos.up();
        worldAccess.setBlockState(blockPos, TallPlantBlock.withWaterloggedState(worldAccess, blockPos, (BlockState)blockState.with(HALF, DoubleBlockHalf.field_12607)), i);
        worldAccess.setBlockState(blockPos2, TallPlantBlock.withWaterloggedState(worldAccess, blockPos2, (BlockState)blockState.with(HALF, DoubleBlockHalf.field_12609)), i);
    }

    public static BlockState withWaterloggedState(WorldView worldView, BlockPos blockPos, BlockState blockState) {
        if (blockState.contains(Properties.WATERLOGGED)) {
            return (BlockState)blockState.with(Properties.WATERLOGGED, worldView.isWater(blockPos));
        }
        return blockState;
    }

    @Override
    public void onBreak(World world, BlockPos blockPos, BlockState blockState, PlayerEntity playerEntity) {
        if (!world.isClient) {
            if (playerEntity.isCreative()) {
                TallPlantBlock.onBreakInCreative(world, blockPos, blockState, playerEntity);
            } else {
                TallPlantBlock.dropStacks(blockState, world, blockPos, null, playerEntity, playerEntity.getMainHandStack());
            }
        }
        super.onBreak(world, blockPos, blockState, playerEntity);
    }

    @Override
    public void afterBreak(World world, PlayerEntity playerEntity, BlockPos blockPos, BlockState blockState, @Nullable BlockEntity blockEntity, ItemStack itemStack) {
        super.afterBreak(world, playerEntity, blockPos, Blocks.field_10124.getDefaultState(), blockEntity, itemStack);
    }

    protected static void onBreakInCreative(World world, BlockPos blockPos, BlockState blockState, PlayerEntity playerEntity) {
        BlockPos blockPos2;
        BlockState blockState2;
        DoubleBlockHalf doubleBlockHalf = blockState.get(HALF);
        if (doubleBlockHalf == DoubleBlockHalf.field_12609 && (blockState2 = world.getBlockState(blockPos2 = blockPos.down())).isOf(blockState.getBlock()) && blockState2.get(HALF) == DoubleBlockHalf.field_12607) {
            BlockState blockState3 = blockState2.getFluidState().isOf(Fluids.WATER) ? Blocks.field_10382.getDefaultState() : Blocks.field_10124.getDefaultState();
            world.setBlockState(blockPos2, blockState3, 35);
            world.syncWorldEvent(playerEntity, 2001, blockPos2, Block.getRawIdFromState(blockState2));
        }
    }

    @Override
    protected void appendProperties(StateManager.Builder<Block, BlockState> builder) {
        builder.add(HALF);
    }

    @Override
    public long getRenderingSeed(BlockState blockState, BlockPos blockPos) {
        return MathHelper.hashCode(blockPos.getX(), blockPos.down(blockState.get(HALF) == DoubleBlockHalf.field_12607 ? 0 : 1).getY(), blockPos.getZ());
    }
}


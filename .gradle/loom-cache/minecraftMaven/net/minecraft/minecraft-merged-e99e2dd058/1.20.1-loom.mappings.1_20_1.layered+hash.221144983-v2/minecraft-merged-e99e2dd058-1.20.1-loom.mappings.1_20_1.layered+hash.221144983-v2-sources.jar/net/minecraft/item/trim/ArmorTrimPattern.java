/*
 * Decompiled with CFR 0.2.1 (FabricMC 53fa44c9).
 */
package net.minecraft.item.trim;

import com.mojang.datafixers.kinds.Applicative;
import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.minecraft.item.Item;
import net.minecraft.item.trim.ArmorTrimMaterial;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.registry.entry.RegistryElementCodec;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.registry.entry.RegistryFixedCodec;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import net.minecraft.util.dynamic.Codecs;

public record ArmorTrimPattern(Identifier comp_1213, RegistryEntry<Item> comp_1214, Text comp_1215) {
    public static final Codec<ArmorTrimPattern> CODEC = RecordCodecBuilder.create(instance -> instance.group(((MapCodec)Identifier.CODEC.fieldOf("asset_id")).forGetter(ArmorTrimPattern::comp_1213), ((MapCodec)RegistryFixedCodec.of(RegistryKeys.field_41197).fieldOf("template_item")).forGetter(ArmorTrimPattern::comp_1214), ((MapCodec)Codecs.TEXT.fieldOf("description")).forGetter(ArmorTrimPattern::comp_1215)).apply((Applicative<ArmorTrimPattern, ?>)instance, ArmorTrimPattern::new));
    public static final Codec<RegistryEntry<ArmorTrimPattern>> ENTRY_CODEC = RegistryElementCodec.of(RegistryKeys.field_42082, CODEC);

    public Text getDescription(RegistryEntry<ArmorTrimMaterial> registryEntry) {
        return this.comp_1215.copy().fillStyle(registryEntry.comp_349().comp_1212().getStyle());
    }
}


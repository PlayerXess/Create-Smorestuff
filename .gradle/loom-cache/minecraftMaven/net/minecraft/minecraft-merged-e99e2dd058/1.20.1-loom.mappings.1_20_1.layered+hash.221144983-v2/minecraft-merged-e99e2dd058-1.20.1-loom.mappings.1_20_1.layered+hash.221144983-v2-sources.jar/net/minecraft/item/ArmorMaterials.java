/*
 * Decompiled with CFR 0.2.1 (FabricMC 53fa44c9).
 */
package net.minecraft.item;

import java.util.EnumMap;
import java.util.function.Supplier;
import net.minecraft.item.ArmorItem;
import net.minecraft.item.ArmorMaterial;
import net.minecraft.item.Items;
import net.minecraft.recipe.Ingredient;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.Lazy;
import net.minecraft.util.StringIdentifiable;
import net.minecraft.util.Util;

public enum ArmorMaterials implements StringIdentifiable,
ArmorMaterial
{
    field_7897("leather", 5, Util.make(new EnumMap<ArmorItem.Type, V>(ArmorItem.Type.class), enumMap -> {
        enumMap.put(ArmorItem.Type.field_41937, 1);
        enumMap.put(ArmorItem.Type.field_41936, 2);
        enumMap.put(ArmorItem.Type.field_41935, 3);
        enumMap.put(ArmorItem.Type.field_41934, 1);
    }), 15, SoundEvents.field_14581, 0.0f, 0.0f, () -> Ingredient.ofItems(Items.field_8745)),
    CHAIN("chainmail", 15, Util.make(new EnumMap<ArmorItem.Type, V>(ArmorItem.Type.class), enumMap -> {
        enumMap.put(ArmorItem.Type.field_41937, 1);
        enumMap.put(ArmorItem.Type.field_41936, 4);
        enumMap.put(ArmorItem.Type.field_41935, 5);
        enumMap.put(ArmorItem.Type.field_41934, 2);
    }), 12, SoundEvents.field_15191, 0.0f, 0.0f, () -> Ingredient.ofItems(Items.field_8620)),
    field_7892("iron", 15, Util.make(new EnumMap<ArmorItem.Type, V>(ArmorItem.Type.class), enumMap -> {
        enumMap.put(ArmorItem.Type.field_41937, 2);
        enumMap.put(ArmorItem.Type.field_41936, 5);
        enumMap.put(ArmorItem.Type.field_41935, 6);
        enumMap.put(ArmorItem.Type.field_41934, 2);
    }), 9, SoundEvents.field_14862, 0.0f, 0.0f, () -> Ingredient.ofItems(Items.field_8620)),
    field_7895("gold", 7, Util.make(new EnumMap<ArmorItem.Type, V>(ArmorItem.Type.class), enumMap -> {
        enumMap.put(ArmorItem.Type.field_41937, 1);
        enumMap.put(ArmorItem.Type.field_41936, 3);
        enumMap.put(ArmorItem.Type.field_41935, 5);
        enumMap.put(ArmorItem.Type.field_41934, 2);
    }), 25, SoundEvents.field_14761, 0.0f, 0.0f, () -> Ingredient.ofItems(Items.field_8695)),
    field_7889("diamond", 33, Util.make(new EnumMap<ArmorItem.Type, V>(ArmorItem.Type.class), enumMap -> {
        enumMap.put(ArmorItem.Type.field_41937, 3);
        enumMap.put(ArmorItem.Type.field_41936, 6);
        enumMap.put(ArmorItem.Type.field_41935, 8);
        enumMap.put(ArmorItem.Type.field_41934, 3);
    }), 10, SoundEvents.field_15103, 2.0f, 0.0f, () -> Ingredient.ofItems(Items.field_8477)),
    field_7890("turtle", 25, Util.make(new EnumMap<ArmorItem.Type, V>(ArmorItem.Type.class), enumMap -> {
        enumMap.put(ArmorItem.Type.field_41937, 2);
        enumMap.put(ArmorItem.Type.field_41936, 5);
        enumMap.put(ArmorItem.Type.field_41935, 6);
        enumMap.put(ArmorItem.Type.field_41934, 2);
    }), 9, SoundEvents.field_14684, 0.0f, 0.0f, () -> Ingredient.ofItems(Items.field_8161)),
    field_21977("netherite", 37, Util.make(new EnumMap<ArmorItem.Type, V>(ArmorItem.Type.class), enumMap -> {
        enumMap.put(ArmorItem.Type.field_41937, 3);
        enumMap.put(ArmorItem.Type.field_41936, 6);
        enumMap.put(ArmorItem.Type.field_41935, 8);
        enumMap.put(ArmorItem.Type.field_41934, 3);
    }), 15, SoundEvents.field_21866, 3.0f, 0.1f, () -> Ingredient.ofItems(Items.field_22020));

    public static final StringIdentifiable.Codec<ArmorMaterials> CODEC;
    private static final EnumMap<ArmorItem.Type, Integer> BASE_DURABILITY;
    private final String name;
    private final int durabilityMultiplier;
    private final EnumMap<ArmorItem.Type, Integer> protectionAmounts;
    private final int enchantability;
    private final SoundEvent equipSound;
    private final float toughness;
    private final float knockbackResistance;
    private final Lazy<Ingredient> repairIngredientSupplier;

    private ArmorMaterials(String string2, int j, EnumMap<ArmorItem.Type, Integer> enumMap, int k, SoundEvent soundEvent, float f, float g, Supplier<Ingredient> supplier) {
        this.name = string2;
        this.durabilityMultiplier = j;
        this.protectionAmounts = enumMap;
        this.enchantability = k;
        this.equipSound = soundEvent;
        this.toughness = f;
        this.knockbackResistance = g;
        this.repairIngredientSupplier = new Lazy<Ingredient>(supplier);
    }

    @Override
    public int getDurability(ArmorItem.Type type) {
        return BASE_DURABILITY.get((Object)type) * this.durabilityMultiplier;
    }

    @Override
    public int getProtection(ArmorItem.Type type) {
        return this.protectionAmounts.get((Object)type);
    }

    @Override
    public int getEnchantability() {
        return this.enchantability;
    }

    @Override
    public SoundEvent getEquipSound() {
        return this.equipSound;
    }

    @Override
    public Ingredient getRepairIngredient() {
        return this.repairIngredientSupplier.get();
    }

    @Override
    public String getName() {
        return this.name;
    }

    @Override
    public float getToughness() {
        return this.toughness;
    }

    @Override
    public float getKnockbackResistance() {
        return this.knockbackResistance;
    }

    @Override
    public String asString() {
        return this.name;
    }

    static {
        CODEC = StringIdentifiable.createCodec(ArmorMaterials::values);
        BASE_DURABILITY = Util.make(new EnumMap(ArmorItem.Type.class), enumMap -> {
            enumMap.put(ArmorItem.Type.field_41937, 13);
            enumMap.put(ArmorItem.Type.field_41936, 15);
            enumMap.put(ArmorItem.Type.field_41935, 16);
            enumMap.put(ArmorItem.Type.field_41934, 11);
        });
    }
}


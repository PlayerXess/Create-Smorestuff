/*
 * Decompiled with CFR 0.2.1 (FabricMC 53fa44c9).
 */
package net.minecraft.block;

import io.github.fabricators_of_create.porting_lib.common.util.IPlantable;
import net.minecraft.block.AbstractBlock;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.ShapeContext;
import net.minecraft.entity.Entity;
import net.minecraft.entity.ai.pathing.NavigationType;
import net.minecraft.registry.tag.BlockTags;
import net.minecraft.registry.tag.FluidTags;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.state.StateManager;
import net.minecraft.state.property.IntProperty;
import net.minecraft.state.property.Properties;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.random.Random;
import net.minecraft.util.shape.VoxelShape;
import net.minecraft.world.BlockView;
import net.minecraft.world.World;
import net.minecraft.world.WorldAccess;
import net.minecraft.world.WorldView;

public class CactusBlock
extends Block
implements IPlantable {
    public static final IntProperty AGE = Properties.AGE_15;
    public static final int MAX_AGE = 15;
    protected static final int field_31045 = 1;
    protected static final VoxelShape COLLISION_SHAPE = Block.createCuboidShape(1.0, 0.0, 1.0, 15.0, 15.0, 15.0);
    protected static final VoxelShape OUTLINE_SHAPE = Block.createCuboidShape(1.0, 0.0, 1.0, 15.0, 16.0, 15.0);

    public CactusBlock(AbstractBlock.Settings settings) {
        super(settings);
        this.setDefaultState((BlockState)((BlockState)this.stateManager.getDefaultState()).with(AGE, 0));
    }

    @Override
    public void scheduledTick(BlockState blockState, ServerWorld serverWorld, BlockPos blockPos, Random random) {
        if (!blockState.canPlaceAt(serverWorld, blockPos)) {
            serverWorld.breakBlock(blockPos, true);
        }
    }

    @Override
    public void randomTick(BlockState blockState, ServerWorld serverWorld, BlockPos blockPos, Random random) {
        BlockPos blockPos2 = blockPos.up();
        if (!serverWorld.isAir(blockPos2)) {
            return;
        }
        int i = 1;
        while (serverWorld.getBlockState(blockPos.down(i)).isOf(this)) {
            ++i;
        }
        if (i >= 3) {
            return;
        }
        int j = blockState.get(AGE);
        if (j == 15) {
            serverWorld.setBlockState(blockPos2, this.getDefaultState());
            BlockState blockState2 = (BlockState)blockState.with(AGE, 0);
            serverWorld.setBlockState(blockPos, blockState2, 4);
            serverWorld.updateNeighbor(blockState2, blockPos2, this, blockPos, false);
        } else {
            serverWorld.setBlockState(blockPos, (BlockState)blockState.with(AGE, j + 1), 4);
        }
    }

    @Override
    public VoxelShape getCollisionShape(BlockState blockState, BlockView blockView, BlockPos blockPos, ShapeContext shapeContext) {
        return COLLISION_SHAPE;
    }

    @Override
    public VoxelShape getOutlineShape(BlockState blockState, BlockView blockView, BlockPos blockPos, ShapeContext shapeContext) {
        return OUTLINE_SHAPE;
    }

    @Override
    public BlockState getStateForNeighborUpdate(BlockState blockState, Direction direction, BlockState blockState2, WorldAccess worldAccess, BlockPos blockPos, BlockPos blockPos2) {
        if (!blockState.canPlaceAt(worldAccess, blockPos)) {
            worldAccess.scheduleBlockTick(blockPos, this, 1);
        }
        return super.getStateForNeighborUpdate(blockState, direction, blockState2, worldAccess, blockPos, blockPos2);
    }

    @Override
    public boolean canPlaceAt(BlockState blockState, WorldView worldView, BlockPos blockPos) {
        for (Direction direction : Direction.Type.field_11062) {
            BlockState blockState2 = worldView.getBlockState(blockPos.offset(direction));
            if (!blockState2.isSolid() && !worldView.getFluidState(blockPos.offset(direction)).isIn(FluidTags.field_15518)) continue;
            return false;
        }
        BlockState blockState3 = worldView.getBlockState(blockPos.down());
        return (blockState3.isOf(Blocks.field_10029) || blockState3.isIn(BlockTags.field_15466)) && !worldView.getBlockState(blockPos.up()).isLiquid();
    }

    @Override
    public void onEntityCollision(BlockState blockState, World world, BlockPos blockPos, Entity entity) {
        entity.damage(world.getDamageSources().cactus(), 1.0f);
    }

    @Override
    protected void appendProperties(StateManager.Builder<Block, BlockState> builder) {
        builder.add(AGE);
    }

    @Override
    public boolean canPathfindThrough(BlockState blockState, BlockView blockView, BlockPos blockPos, NavigationType navigationType) {
        return false;
    }
}


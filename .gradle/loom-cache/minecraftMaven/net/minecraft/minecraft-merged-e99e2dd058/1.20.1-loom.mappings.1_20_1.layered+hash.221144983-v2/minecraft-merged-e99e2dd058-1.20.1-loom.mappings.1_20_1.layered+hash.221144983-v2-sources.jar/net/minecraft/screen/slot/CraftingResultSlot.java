/*
 * Decompiled with CFR 0.2.1 (FabricMC 53fa44c9).
 */
package net.minecraft.screen.slot;

import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.inventory.Inventory;
import net.minecraft.inventory.RecipeInputInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.recipe.RecipeType;
import net.minecraft.recipe.RecipeUnlocker;
import net.minecraft.screen.slot.Slot;
import net.minecraft.util.collection.DefaultedList;

public class CraftingResultSlot
extends Slot {
    private final RecipeInputInventory input;
    private final PlayerEntity player;
    private int amount;

    public CraftingResultSlot(PlayerEntity playerEntity, RecipeInputInventory recipeInputInventory, Inventory inventory, int i, int j, int k) {
        super(inventory, i, j, k);
        this.player = playerEntity;
        this.input = recipeInputInventory;
    }

    @Override
    public boolean canInsert(ItemStack itemStack) {
        return false;
    }

    @Override
    public ItemStack takeStack(int i) {
        if (this.hasStack()) {
            this.amount += Math.min(i, this.getStack().getCount());
        }
        return super.takeStack(i);
    }

    @Override
    protected void onCrafted(ItemStack itemStack, int i) {
        this.amount += i;
        this.onCrafted(itemStack);
    }

    @Override
    protected void onTake(int i) {
        this.amount += i;
    }

    @Override
    protected void onCrafted(ItemStack itemStack) {
        Inventory inventory;
        if (this.amount > 0) {
            itemStack.onCraft(this.player.getWorld(), this.player, this.amount);
        }
        if ((inventory = this.inventory) instanceof RecipeUnlocker) {
            RecipeUnlocker recipeUnlocker = (RecipeUnlocker)((Object)inventory);
            recipeUnlocker.unlockLastRecipe(this.player, this.input.getInputStacks());
        }
        this.amount = 0;
    }

    @Override
    public void onTakeItem(PlayerEntity playerEntity, ItemStack itemStack) {
        this.onCrafted(itemStack);
        DefaultedList<ItemStack> defaultedList = playerEntity.getWorld().getRecipeManager().getRemainingStacks(RecipeType.field_17545, this.input, playerEntity.getWorld());
        for (int i = 0; i < defaultedList.size(); ++i) {
            ItemStack itemStack2 = this.input.getStack(i);
            ItemStack itemStack3 = defaultedList.get(i);
            if (!itemStack2.isEmpty()) {
                this.input.removeStack(i, 1);
                itemStack2 = this.input.getStack(i);
            }
            if (itemStack3.isEmpty()) continue;
            if (itemStack2.isEmpty()) {
                this.input.setStack(i, itemStack3);
                continue;
            }
            if (ItemStack.canCombine(itemStack2, itemStack3)) {
                itemStack3.increment(itemStack2.getCount());
                this.input.setStack(i, itemStack3);
                continue;
            }
            if (this.player.getInventory().insertStack(itemStack3)) continue;
            this.player.dropItem(itemStack3, false);
        }
    }
}


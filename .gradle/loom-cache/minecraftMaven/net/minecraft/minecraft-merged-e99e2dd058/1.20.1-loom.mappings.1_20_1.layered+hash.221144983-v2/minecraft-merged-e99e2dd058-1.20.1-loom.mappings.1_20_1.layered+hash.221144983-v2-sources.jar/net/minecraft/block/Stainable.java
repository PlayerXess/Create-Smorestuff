/*
 * Decompiled with CFR 0.2.1 (FabricMC 53fa44c9).
 */
package net.minecraft.block;

import net.minecraft.util.DyeColor;

public interface Stainable {
    public DyeColor getColor();
}


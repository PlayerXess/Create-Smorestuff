/*
 * Decompiled with CFR 0.2.1 (FabricMC 53fa44c9).
 */
package net.minecraft.block;

import com.google.common.collect.ImmutableMap;
import it.unimi.dsi.fastutil.objects.Object2IntMap;
import it.unimi.dsi.fastutil.objects.Object2IntOpenHashMap;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;
import net.minecraft.block.AbstractBlock;
import net.minecraft.block.AbstractFireBlock;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.ConnectingBlock;
import net.minecraft.block.ShapeContext;
import net.minecraft.block.TntBlock;
import net.minecraft.item.ItemPlacementContext;
import net.minecraft.registry.tag.BiomeTags;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.state.StateManager;
import net.minecraft.state.property.BooleanProperty;
import net.minecraft.state.property.IntProperty;
import net.minecraft.state.property.Properties;
import net.minecraft.util.Util;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.random.Random;
import net.minecraft.util.shape.VoxelShape;
import net.minecraft.util.shape.VoxelShapes;
import net.minecraft.world.BlockView;
import net.minecraft.world.GameRules;
import net.minecraft.world.World;
import net.minecraft.world.WorldAccess;
import net.minecraft.world.WorldView;

public class FireBlock
extends AbstractFireBlock {
    public static final int field_31093 = 15;
    public static final IntProperty AGE = Properties.AGE_15;
    public static final BooleanProperty NORTH = ConnectingBlock.NORTH;
    public static final BooleanProperty EAST = ConnectingBlock.EAST;
    public static final BooleanProperty SOUTH = ConnectingBlock.SOUTH;
    public static final BooleanProperty WEST = ConnectingBlock.WEST;
    public static final BooleanProperty UP = ConnectingBlock.UP;
    private static final Map<Direction, BooleanProperty> DIRECTION_PROPERTIES = ConnectingBlock.FACING_PROPERTIES.entrySet().stream().filter(entry -> entry.getKey() != Direction.field_11033).collect(Util.toMap());
    private static final VoxelShape UP_SHAPE = Block.createCuboidShape(0.0, 15.0, 0.0, 16.0, 16.0, 16.0);
    private static final VoxelShape WEST_SHAPE = Block.createCuboidShape(0.0, 0.0, 0.0, 1.0, 16.0, 16.0);
    private static final VoxelShape EAST_SHAPE = Block.createCuboidShape(15.0, 0.0, 0.0, 16.0, 16.0, 16.0);
    private static final VoxelShape NORTH_SHAPE = Block.createCuboidShape(0.0, 0.0, 0.0, 16.0, 16.0, 1.0);
    private static final VoxelShape SOUTH_SHAPE = Block.createCuboidShape(0.0, 0.0, 15.0, 16.0, 16.0, 16.0);
    private final Map<BlockState, VoxelShape> shapesByState;
    private static final int field_31085 = 60;
    private static final int field_31086 = 30;
    private static final int field_31087 = 15;
    private static final int field_31088 = 5;
    private static final int field_31089 = 100;
    private static final int field_31090 = 60;
    private static final int field_31091 = 20;
    private static final int field_31092 = 5;
    private final Object2IntMap<Block> burnChances = new Object2IntOpenHashMap<Block>();
    private final Object2IntMap<Block> spreadChances = new Object2IntOpenHashMap<Block>();

    public FireBlock(AbstractBlock.Settings settings) {
        super(settings, 1.0f);
        this.setDefaultState((BlockState)((BlockState)((BlockState)((BlockState)((BlockState)((BlockState)((BlockState)this.stateManager.getDefaultState()).with(AGE, 0)).with(NORTH, false)).with(EAST, false)).with(SOUTH, false)).with(WEST, false)).with(UP, false));
        this.shapesByState = ImmutableMap.copyOf(this.stateManager.getStates().stream().filter(blockState -> blockState.get(AGE) == 0).collect(Collectors.toMap(Function.identity(), FireBlock::getShapeForState)));
    }

    private static VoxelShape getShapeForState(BlockState blockState) {
        VoxelShape voxelShape = VoxelShapes.empty();
        if (blockState.get(UP).booleanValue()) {
            voxelShape = UP_SHAPE;
        }
        if (blockState.get(NORTH).booleanValue()) {
            voxelShape = VoxelShapes.union(voxelShape, NORTH_SHAPE);
        }
        if (blockState.get(SOUTH).booleanValue()) {
            voxelShape = VoxelShapes.union(voxelShape, SOUTH_SHAPE);
        }
        if (blockState.get(EAST).booleanValue()) {
            voxelShape = VoxelShapes.union(voxelShape, EAST_SHAPE);
        }
        if (blockState.get(WEST).booleanValue()) {
            voxelShape = VoxelShapes.union(voxelShape, WEST_SHAPE);
        }
        return voxelShape.isEmpty() ? BASE_SHAPE : voxelShape;
    }

    @Override
    public BlockState getStateForNeighborUpdate(BlockState blockState, Direction direction, BlockState blockState2, WorldAccess worldAccess, BlockPos blockPos, BlockPos blockPos2) {
        if (this.canPlaceAt(blockState, worldAccess, blockPos)) {
            return this.getStateWithAge(worldAccess, blockPos, blockState.get(AGE));
        }
        return Blocks.field_10124.getDefaultState();
    }

    @Override
    public VoxelShape getOutlineShape(BlockState blockState, BlockView blockView, BlockPos blockPos, ShapeContext shapeContext) {
        return this.shapesByState.get(blockState.with(AGE, 0));
    }

    @Override
    public BlockState getPlacementState(ItemPlacementContext itemPlacementContext) {
        return this.getStateForPosition(itemPlacementContext.getWorld(), itemPlacementContext.getBlockPos());
    }

    protected BlockState getStateForPosition(BlockView blockView, BlockPos blockPos) {
        BlockPos blockPos2 = blockPos.down();
        BlockState blockState = blockView.getBlockState(blockPos2);
        if (this.isFlammable(blockState) || blockState.isSideSolidFullSquare(blockView, blockPos2, Direction.field_11036)) {
            return this.getDefaultState();
        }
        BlockState blockState2 = this.getDefaultState();
        for (Direction direction : Direction.values()) {
            BooleanProperty booleanProperty = DIRECTION_PROPERTIES.get(direction);
            if (booleanProperty == null) continue;
            blockState2 = (BlockState)blockState2.with(booleanProperty, this.isFlammable(blockView.getBlockState(blockPos.offset(direction))));
        }
        return blockState2;
    }

    @Override
    public boolean canPlaceAt(BlockState blockState, WorldView worldView, BlockPos blockPos) {
        BlockPos blockPos2 = blockPos.down();
        return worldView.getBlockState(blockPos2).isSideSolidFullSquare(worldView, blockPos2, Direction.field_11036) || this.areBlocksAroundFlammable(worldView, blockPos);
    }

    @Override
    public void scheduledTick(BlockState blockState, ServerWorld serverWorld, BlockPos blockPos, Random random) {
        boolean bl2;
        serverWorld.scheduleBlockTick(blockPos, this, FireBlock.getFireTickDelay(serverWorld.random));
        if (!serverWorld.getGameRules().getBoolean(GameRules.field_19387)) {
            return;
        }
        if (!blockState.canPlaceAt(serverWorld, blockPos)) {
            serverWorld.removeBlock(blockPos, false);
        }
        BlockState blockState2 = serverWorld.getBlockState(blockPos.down());
        boolean bl = blockState2.isIn(serverWorld.getDimension().comp_654());
        int i = blockState.get(AGE);
        if (!bl && serverWorld.isRaining() && this.isRainingAround(serverWorld, blockPos) && random.nextFloat() < 0.2f + (float)i * 0.03f) {
            serverWorld.removeBlock(blockPos, false);
            return;
        }
        int j = Math.min(15, i + random.nextInt(3) / 2);
        if (i != j) {
            blockState = (BlockState)blockState.with(AGE, j);
            serverWorld.setBlockState(blockPos, blockState, 4);
        }
        if (!bl) {
            if (!this.areBlocksAroundFlammable(serverWorld, blockPos)) {
                BlockPos blockPos2 = blockPos.down();
                if (!serverWorld.getBlockState(blockPos2).isSideSolidFullSquare(serverWorld, blockPos2, Direction.field_11036) || i > 3) {
                    serverWorld.removeBlock(blockPos, false);
                }
                return;
            }
            if (i == 15 && random.nextInt(4) == 0 && !this.isFlammable(serverWorld.getBlockState(blockPos.down()))) {
                serverWorld.removeBlock(blockPos, false);
                return;
            }
        }
        int k = (bl2 = serverWorld.getBiome(blockPos).isIn(BiomeTags.field_41752)) ? -50 : 0;
        this.trySpreadingFire(serverWorld, blockPos.east(), 300 + k, random, i);
        this.trySpreadingFire(serverWorld, blockPos.west(), 300 + k, random, i);
        this.trySpreadingFire(serverWorld, blockPos.down(), 250 + k, random, i);
        this.trySpreadingFire(serverWorld, blockPos.up(), 250 + k, random, i);
        this.trySpreadingFire(serverWorld, blockPos.north(), 300 + k, random, i);
        this.trySpreadingFire(serverWorld, blockPos.south(), 300 + k, random, i);
        BlockPos.Mutable mutable = new BlockPos.Mutable();
        for (int l = -1; l <= 1; ++l) {
            for (int m = -1; m <= 1; ++m) {
                for (int n = -1; n <= 4; ++n) {
                    if (l == 0 && n == 0 && m == 0) continue;
                    int o = 100;
                    if (n > 1) {
                        o += (n - 1) * 100;
                    }
                    mutable.set(blockPos, l, n, m);
                    int p = this.getBurnChance(serverWorld, mutable);
                    if (p <= 0) continue;
                    int q = (p + 40 + serverWorld.getDifficulty().getId() * 7) / (i + 30);
                    if (bl2) {
                        q /= 2;
                    }
                    if (q <= 0 || random.nextInt(o) > q || serverWorld.isRaining() && this.isRainingAround(serverWorld, mutable)) continue;
                    int r = Math.min(15, i + random.nextInt(5) / 4);
                    serverWorld.setBlockState(mutable, this.getStateWithAge(serverWorld, mutable, r), 3);
                }
            }
        }
    }

    protected boolean isRainingAround(World world, BlockPos blockPos) {
        return world.hasRain(blockPos) || world.hasRain(blockPos.west()) || world.hasRain(blockPos.east()) || world.hasRain(blockPos.north()) || world.hasRain(blockPos.south());
    }

    private int getSpreadChance(BlockState blockState) {
        if (blockState.contains(Properties.WATERLOGGED) && blockState.get(Properties.WATERLOGGED).booleanValue()) {
            return 0;
        }
        return this.spreadChances.getInt(blockState.getBlock());
    }

    private int getBurnChance(BlockState blockState) {
        if (blockState.contains(Properties.WATERLOGGED) && blockState.get(Properties.WATERLOGGED).booleanValue()) {
            return 0;
        }
        return this.burnChances.getInt(blockState.getBlock());
    }

    private void trySpreadingFire(World world, BlockPos blockPos, int i, Random random, int j) {
        int k = this.getSpreadChance(world.getBlockState(blockPos));
        if (random.nextInt(i) < k) {
            BlockState blockState = world.getBlockState(blockPos);
            if (random.nextInt(j + 10) < 5 && !world.hasRain(blockPos)) {
                int l = Math.min(j + random.nextInt(5) / 4, 15);
                world.setBlockState(blockPos, this.getStateWithAge(world, blockPos, l), 3);
            } else {
                world.removeBlock(blockPos, false);
            }
            Block block = blockState.getBlock();
            if (block instanceof TntBlock) {
                TntBlock.primeTnt(world, blockPos);
            }
        }
    }

    private BlockState getStateWithAge(WorldAccess worldAccess, BlockPos blockPos, int i) {
        BlockState blockState = FireBlock.getState(worldAccess, blockPos);
        if (blockState.isOf(Blocks.field_10036)) {
            return (BlockState)blockState.with(AGE, i);
        }
        return blockState;
    }

    private boolean areBlocksAroundFlammable(BlockView blockView, BlockPos blockPos) {
        for (Direction direction : Direction.values()) {
            if (!this.isFlammable(blockView.getBlockState(blockPos.offset(direction)))) continue;
            return true;
        }
        return false;
    }

    private int getBurnChance(WorldView worldView, BlockPos blockPos) {
        if (!worldView.isAir(blockPos)) {
            return 0;
        }
        int i = 0;
        for (Direction direction : Direction.values()) {
            BlockState blockState = worldView.getBlockState(blockPos.offset(direction));
            i = Math.max(this.getBurnChance(blockState), i);
        }
        return i;
    }

    @Override
    protected boolean isFlammable(BlockState blockState) {
        return this.getBurnChance(blockState) > 0;
    }

    @Override
    public void onBlockAdded(BlockState blockState, World world, BlockPos blockPos, BlockState blockState2, boolean bl) {
        super.onBlockAdded(blockState, world, blockPos, blockState2, bl);
        world.scheduleBlockTick(blockPos, this, FireBlock.getFireTickDelay(world.random));
    }

    private static int getFireTickDelay(Random random) {
        return 30 + random.nextInt(10);
    }

    @Override
    protected void appendProperties(StateManager.Builder<Block, BlockState> builder) {
        builder.add(AGE, NORTH, EAST, SOUTH, WEST, UP);
    }

    private void registerFlammableBlock(Block block, int i, int j) {
        this.burnChances.put(block, i);
        this.spreadChances.put(block, j);
    }

    public static void registerDefaultFlammables() {
        FireBlock fireBlock = (FireBlock)Blocks.field_10036;
        fireBlock.registerFlammableBlock(Blocks.field_10161, 5, 20);
        fireBlock.registerFlammableBlock(Blocks.field_9975, 5, 20);
        fireBlock.registerFlammableBlock(Blocks.field_10148, 5, 20);
        fireBlock.registerFlammableBlock(Blocks.field_10334, 5, 20);
        fireBlock.registerFlammableBlock(Blocks.field_10218, 5, 20);
        fireBlock.registerFlammableBlock(Blocks.field_42751, 5, 20);
        fireBlock.registerFlammableBlock(Blocks.field_10075, 5, 20);
        fireBlock.registerFlammableBlock(Blocks.field_37577, 5, 20);
        fireBlock.registerFlammableBlock(Blocks.field_40294, 5, 20);
        fireBlock.registerFlammableBlock(Blocks.field_40295, 5, 20);
        fireBlock.registerFlammableBlock(Blocks.field_10119, 5, 20);
        fireBlock.registerFlammableBlock(Blocks.field_10071, 5, 20);
        fireBlock.registerFlammableBlock(Blocks.field_10257, 5, 20);
        fireBlock.registerFlammableBlock(Blocks.field_10617, 5, 20);
        fireBlock.registerFlammableBlock(Blocks.field_10031, 5, 20);
        fireBlock.registerFlammableBlock(Blocks.field_42746, 5, 20);
        fireBlock.registerFlammableBlock(Blocks.field_10500, 5, 20);
        fireBlock.registerFlammableBlock(Blocks.field_37564, 5, 20);
        fireBlock.registerFlammableBlock(Blocks.field_40292, 5, 20);
        fireBlock.registerFlammableBlock(Blocks.field_40293, 5, 20);
        fireBlock.registerFlammableBlock(Blocks.field_10188, 5, 20);
        fireBlock.registerFlammableBlock(Blocks.field_10291, 5, 20);
        fireBlock.registerFlammableBlock(Blocks.field_10513, 5, 20);
        fireBlock.registerFlammableBlock(Blocks.field_10041, 5, 20);
        fireBlock.registerFlammableBlock(Blocks.field_10457, 5, 20);
        fireBlock.registerFlammableBlock(Blocks.field_42745, 5, 20);
        fireBlock.registerFlammableBlock(Blocks.field_10196, 5, 20);
        fireBlock.registerFlammableBlock(Blocks.field_37563, 5, 20);
        fireBlock.registerFlammableBlock(Blocks.field_40289, 5, 20);
        fireBlock.registerFlammableBlock(Blocks.field_10620, 5, 20);
        fireBlock.registerFlammableBlock(Blocks.field_10020, 5, 20);
        fireBlock.registerFlammableBlock(Blocks.field_10299, 5, 20);
        fireBlock.registerFlammableBlock(Blocks.field_10319, 5, 20);
        fireBlock.registerFlammableBlock(Blocks.field_10144, 5, 20);
        fireBlock.registerFlammableBlock(Blocks.field_42747, 5, 20);
        fireBlock.registerFlammableBlock(Blocks.field_10132, 5, 20);
        fireBlock.registerFlammableBlock(Blocks.field_37565, 5, 20);
        fireBlock.registerFlammableBlock(Blocks.field_40290, 5, 20);
        fireBlock.registerFlammableBlock(Blocks.field_10563, 5, 20);
        fireBlock.registerFlammableBlock(Blocks.field_10408, 5, 20);
        fireBlock.registerFlammableBlock(Blocks.field_10569, 5, 20);
        fireBlock.registerFlammableBlock(Blocks.field_10122, 5, 20);
        fireBlock.registerFlammableBlock(Blocks.field_10256, 5, 20);
        fireBlock.registerFlammableBlock(Blocks.field_42744, 5, 20);
        fireBlock.registerFlammableBlock(Blocks.field_10616, 5, 20);
        fireBlock.registerFlammableBlock(Blocks.field_37561, 5, 20);
        fireBlock.registerFlammableBlock(Blocks.field_40287, 5, 20);
        fireBlock.registerFlammableBlock(Blocks.field_40288, 5, 20);
        fireBlock.registerFlammableBlock(Blocks.field_10431, 5, 5);
        fireBlock.registerFlammableBlock(Blocks.field_10037, 5, 5);
        fireBlock.registerFlammableBlock(Blocks.field_10511, 5, 5);
        fireBlock.registerFlammableBlock(Blocks.field_10306, 5, 5);
        fireBlock.registerFlammableBlock(Blocks.field_10533, 5, 5);
        fireBlock.registerFlammableBlock(Blocks.field_42729, 5, 5);
        fireBlock.registerFlammableBlock(Blocks.field_10010, 5, 5);
        fireBlock.registerFlammableBlock(Blocks.field_37545, 5, 5);
        fireBlock.registerFlammableBlock(Blocks.field_41072, 5, 5);
        fireBlock.registerFlammableBlock(Blocks.field_10519, 5, 5);
        fireBlock.registerFlammableBlock(Blocks.field_10436, 5, 5);
        fireBlock.registerFlammableBlock(Blocks.field_10366, 5, 5);
        fireBlock.registerFlammableBlock(Blocks.field_10254, 5, 5);
        fireBlock.registerFlammableBlock(Blocks.field_10622, 5, 5);
        fireBlock.registerFlammableBlock(Blocks.field_42732, 5, 5);
        fireBlock.registerFlammableBlock(Blocks.field_10244, 5, 5);
        fireBlock.registerFlammableBlock(Blocks.field_37548, 5, 5);
        fireBlock.registerFlammableBlock(Blocks.field_41073, 5, 5);
        fireBlock.registerFlammableBlock(Blocks.field_10250, 5, 5);
        fireBlock.registerFlammableBlock(Blocks.field_10558, 5, 5);
        fireBlock.registerFlammableBlock(Blocks.field_10204, 5, 5);
        fireBlock.registerFlammableBlock(Blocks.field_10084, 5, 5);
        fireBlock.registerFlammableBlock(Blocks.field_10103, 5, 5);
        fireBlock.registerFlammableBlock(Blocks.field_42730, 5, 5);
        fireBlock.registerFlammableBlock(Blocks.field_10374, 5, 5);
        fireBlock.registerFlammableBlock(Blocks.field_37550, 5, 5);
        fireBlock.registerFlammableBlock(Blocks.field_10126, 5, 5);
        fireBlock.registerFlammableBlock(Blocks.field_10155, 5, 5);
        fireBlock.registerFlammableBlock(Blocks.field_10307, 5, 5);
        fireBlock.registerFlammableBlock(Blocks.field_10303, 5, 5);
        fireBlock.registerFlammableBlock(Blocks.field_9999, 5, 5);
        fireBlock.registerFlammableBlock(Blocks.field_42733, 5, 5);
        fireBlock.registerFlammableBlock(Blocks.field_10178, 5, 5);
        fireBlock.registerFlammableBlock(Blocks.field_37549, 5, 5);
        fireBlock.registerFlammableBlock(Blocks.field_37546, 5, 20);
        fireBlock.registerFlammableBlock(Blocks.field_10503, 30, 60);
        fireBlock.registerFlammableBlock(Blocks.field_9988, 30, 60);
        fireBlock.registerFlammableBlock(Blocks.field_10539, 30, 60);
        fireBlock.registerFlammableBlock(Blocks.field_10335, 30, 60);
        fireBlock.registerFlammableBlock(Blocks.field_10098, 30, 60);
        fireBlock.registerFlammableBlock(Blocks.field_42731, 30, 60);
        fireBlock.registerFlammableBlock(Blocks.field_10035, 30, 60);
        fireBlock.registerFlammableBlock(Blocks.field_37551, 30, 60);
        fireBlock.registerFlammableBlock(Blocks.field_10504, 30, 20);
        fireBlock.registerFlammableBlock(Blocks.field_10375, 15, 100);
        fireBlock.registerFlammableBlock(Blocks.field_10479, 60, 100);
        fireBlock.registerFlammableBlock(Blocks.field_10112, 60, 100);
        fireBlock.registerFlammableBlock(Blocks.field_10428, 60, 100);
        fireBlock.registerFlammableBlock(Blocks.field_10583, 60, 100);
        fireBlock.registerFlammableBlock(Blocks.field_10378, 60, 100);
        fireBlock.registerFlammableBlock(Blocks.field_10430, 60, 100);
        fireBlock.registerFlammableBlock(Blocks.field_10003, 60, 100);
        fireBlock.registerFlammableBlock(Blocks.field_10214, 60, 100);
        fireBlock.registerFlammableBlock(Blocks.field_10313, 60, 100);
        fireBlock.registerFlammableBlock(Blocks.field_10182, 60, 100);
        fireBlock.registerFlammableBlock(Blocks.field_10449, 60, 100);
        fireBlock.registerFlammableBlock(Blocks.field_10086, 60, 100);
        fireBlock.registerFlammableBlock(Blocks.field_10226, 60, 100);
        fireBlock.registerFlammableBlock(Blocks.field_10573, 60, 100);
        fireBlock.registerFlammableBlock(Blocks.field_10270, 60, 100);
        fireBlock.registerFlammableBlock(Blocks.field_10048, 60, 100);
        fireBlock.registerFlammableBlock(Blocks.field_10156, 60, 100);
        fireBlock.registerFlammableBlock(Blocks.field_10315, 60, 100);
        fireBlock.registerFlammableBlock(Blocks.field_10554, 60, 100);
        fireBlock.registerFlammableBlock(Blocks.field_9995, 60, 100);
        fireBlock.registerFlammableBlock(Blocks.field_10548, 60, 100);
        fireBlock.registerFlammableBlock(Blocks.field_42734, 60, 100);
        fireBlock.registerFlammableBlock(Blocks.field_43229, 60, 100);
        fireBlock.registerFlammableBlock(Blocks.field_10606, 60, 100);
        fireBlock.registerFlammableBlock(Blocks.field_42750, 60, 100);
        fireBlock.registerFlammableBlock(Blocks.field_10446, 30, 60);
        fireBlock.registerFlammableBlock(Blocks.field_10095, 30, 60);
        fireBlock.registerFlammableBlock(Blocks.field_10215, 30, 60);
        fireBlock.registerFlammableBlock(Blocks.field_10294, 30, 60);
        fireBlock.registerFlammableBlock(Blocks.field_10490, 30, 60);
        fireBlock.registerFlammableBlock(Blocks.field_10028, 30, 60);
        fireBlock.registerFlammableBlock(Blocks.field_10459, 30, 60);
        fireBlock.registerFlammableBlock(Blocks.field_10423, 30, 60);
        fireBlock.registerFlammableBlock(Blocks.field_10222, 30, 60);
        fireBlock.registerFlammableBlock(Blocks.field_10619, 30, 60);
        fireBlock.registerFlammableBlock(Blocks.field_10259, 30, 60);
        fireBlock.registerFlammableBlock(Blocks.field_10514, 30, 60);
        fireBlock.registerFlammableBlock(Blocks.field_10113, 30, 60);
        fireBlock.registerFlammableBlock(Blocks.field_10170, 30, 60);
        fireBlock.registerFlammableBlock(Blocks.field_10314, 30, 60);
        fireBlock.registerFlammableBlock(Blocks.field_10146, 30, 60);
        fireBlock.registerFlammableBlock(Blocks.field_10597, 15, 100);
        fireBlock.registerFlammableBlock(Blocks.field_10381, 5, 5);
        fireBlock.registerFlammableBlock(Blocks.field_10359, 60, 20);
        fireBlock.registerFlammableBlock(Blocks.field_22422, 15, 20);
        fireBlock.registerFlammableBlock(Blocks.field_10466, 60, 20);
        fireBlock.registerFlammableBlock(Blocks.field_9977, 60, 20);
        fireBlock.registerFlammableBlock(Blocks.field_10482, 60, 20);
        fireBlock.registerFlammableBlock(Blocks.field_10290, 60, 20);
        fireBlock.registerFlammableBlock(Blocks.field_10512, 60, 20);
        fireBlock.registerFlammableBlock(Blocks.field_10040, 60, 20);
        fireBlock.registerFlammableBlock(Blocks.field_10393, 60, 20);
        fireBlock.registerFlammableBlock(Blocks.field_10591, 60, 20);
        fireBlock.registerFlammableBlock(Blocks.field_10209, 60, 20);
        fireBlock.registerFlammableBlock(Blocks.field_10433, 60, 20);
        fireBlock.registerFlammableBlock(Blocks.field_10510, 60, 20);
        fireBlock.registerFlammableBlock(Blocks.field_10043, 60, 20);
        fireBlock.registerFlammableBlock(Blocks.field_10473, 60, 20);
        fireBlock.registerFlammableBlock(Blocks.field_10338, 60, 20);
        fireBlock.registerFlammableBlock(Blocks.field_10536, 60, 20);
        fireBlock.registerFlammableBlock(Blocks.field_10106, 60, 20);
        fireBlock.registerFlammableBlock(Blocks.field_10342, 30, 60);
        fireBlock.registerFlammableBlock(Blocks.field_10211, 60, 60);
        fireBlock.registerFlammableBlock(Blocks.field_16492, 60, 60);
        fireBlock.registerFlammableBlock(Blocks.field_16330, 30, 20);
        fireBlock.registerFlammableBlock(Blocks.field_17563, 5, 20);
        fireBlock.registerFlammableBlock(Blocks.field_16999, 60, 100);
        fireBlock.registerFlammableBlock(Blocks.field_20422, 5, 20);
        fireBlock.registerFlammableBlock(Blocks.field_20421, 30, 20);
        fireBlock.registerFlammableBlock(Blocks.field_28673, 30, 60);
        fireBlock.registerFlammableBlock(Blocks.field_28674, 30, 60);
        fireBlock.registerFlammableBlock(Blocks.field_28675, 15, 60);
        fireBlock.registerFlammableBlock(Blocks.field_28676, 15, 60);
        fireBlock.registerFlammableBlock(Blocks.field_28677, 60, 100);
        fireBlock.registerFlammableBlock(Blocks.field_28678, 30, 60);
        fireBlock.registerFlammableBlock(Blocks.field_28679, 30, 60);
        fireBlock.registerFlammableBlock(Blocks.field_28682, 60, 100);
        fireBlock.registerFlammableBlock(Blocks.field_28683, 60, 100);
        fireBlock.registerFlammableBlock(Blocks.field_28684, 60, 100);
        fireBlock.registerFlammableBlock(Blocks.field_28686, 30, 60);
        fireBlock.registerFlammableBlock(Blocks.field_28411, 15, 100);
    }
}


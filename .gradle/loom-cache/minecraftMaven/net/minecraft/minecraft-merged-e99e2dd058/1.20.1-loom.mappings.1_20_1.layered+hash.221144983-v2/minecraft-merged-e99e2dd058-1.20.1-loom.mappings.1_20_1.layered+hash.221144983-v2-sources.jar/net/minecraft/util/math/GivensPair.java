/*
 * Decompiled with CFR 0.2.1 (FabricMC 53fa44c9).
 */
package net.minecraft.util.math;

import org.joml.Math;
import org.joml.Matrix3f;
import org.joml.Quaternionf;

public record GivensPair(float comp_1317, float comp_1318) {
    public static GivensPair normalize(float f, float g) {
        float h = Math.invsqrt(f * f + g * g);
        return new GivensPair(h * f, h * g);
    }

    public static GivensPair fromAngle(float f) {
        float g = Math.sin(f / 2.0f);
        float h = Math.cosFromSin(g, f / 2.0f);
        return new GivensPair(g, h);
    }

    public GivensPair negateSin() {
        return new GivensPair(-this.comp_1317, this.comp_1318);
    }

    public Quaternionf setXRotation(Quaternionf quaternionf) {
        return quaternionf.set(this.comp_1317, 0.0f, 0.0f, this.comp_1318);
    }

    public Quaternionf setYRotation(Quaternionf quaternionf) {
        return quaternionf.set(0.0f, this.comp_1317, 0.0f, this.comp_1318);
    }

    public Quaternionf setZRotation(Quaternionf quaternionf) {
        return quaternionf.set(0.0f, 0.0f, this.comp_1317, this.comp_1318);
    }

    public float cosDouble() {
        return this.comp_1318 * this.comp_1318 - this.comp_1317 * this.comp_1317;
    }

    public float sinDouble() {
        return 2.0f * this.comp_1317 * this.comp_1318;
    }

    public Matrix3f setRotationX(Matrix3f matrix3f) {
        matrix3f.m01 = 0.0f;
        matrix3f.m02 = 0.0f;
        matrix3f.m10 = 0.0f;
        matrix3f.m20 = 0.0f;
        float f = this.cosDouble();
        float g = this.sinDouble();
        matrix3f.m11 = f;
        matrix3f.m22 = f;
        matrix3f.m12 = g;
        matrix3f.m21 = -g;
        matrix3f.m00 = 1.0f;
        return matrix3f;
    }

    public Matrix3f setRotationY(Matrix3f matrix3f) {
        matrix3f.m01 = 0.0f;
        matrix3f.m10 = 0.0f;
        matrix3f.m12 = 0.0f;
        matrix3f.m21 = 0.0f;
        float f = this.cosDouble();
        float g = this.sinDouble();
        matrix3f.m00 = f;
        matrix3f.m22 = f;
        matrix3f.m02 = -g;
        matrix3f.m20 = g;
        matrix3f.m11 = 1.0f;
        return matrix3f;
    }

    public Matrix3f setRotationZ(Matrix3f matrix3f) {
        matrix3f.m02 = 0.0f;
        matrix3f.m12 = 0.0f;
        matrix3f.m20 = 0.0f;
        matrix3f.m21 = 0.0f;
        float f = this.cosDouble();
        float g = this.sinDouble();
        matrix3f.m00 = f;
        matrix3f.m11 = f;
        matrix3f.m01 = g;
        matrix3f.m10 = -g;
        matrix3f.m22 = 1.0f;
        return matrix3f;
    }
}


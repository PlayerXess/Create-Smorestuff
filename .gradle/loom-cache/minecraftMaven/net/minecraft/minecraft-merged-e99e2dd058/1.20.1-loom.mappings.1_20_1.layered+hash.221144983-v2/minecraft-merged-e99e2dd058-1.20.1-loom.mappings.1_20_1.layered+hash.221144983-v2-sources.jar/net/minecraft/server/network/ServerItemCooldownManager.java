/*
 * Decompiled with CFR 0.2.1 (FabricMC 53fa44c9).
 */
package net.minecraft.server.network;

import net.minecraft.entity.player.ItemCooldownManager;
import net.minecraft.item.Item;
import net.minecraft.network.packet.s2c.play.CooldownUpdateS2CPacket;
import net.minecraft.server.network.ServerPlayerEntity;

public class ServerItemCooldownManager
extends ItemCooldownManager {
    private final ServerPlayerEntity player;

    public ServerItemCooldownManager(ServerPlayerEntity serverPlayerEntity) {
        this.player = serverPlayerEntity;
    }

    @Override
    protected void onCooldownUpdate(Item item, int i) {
        super.onCooldownUpdate(item, i);
        this.player.networkHandler.sendPacket(new CooldownUpdateS2CPacket(item, i));
    }

    @Override
    protected void onCooldownUpdate(Item item) {
        super.onCooldownUpdate(item);
        this.player.networkHandler.sendPacket(new CooldownUpdateS2CPacket(item, 0));
    }
}


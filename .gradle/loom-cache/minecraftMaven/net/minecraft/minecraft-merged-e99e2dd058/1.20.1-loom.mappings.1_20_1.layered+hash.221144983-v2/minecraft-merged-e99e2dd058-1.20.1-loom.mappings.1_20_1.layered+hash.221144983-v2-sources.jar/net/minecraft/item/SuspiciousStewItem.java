/*
 * Decompiled with CFR 0.2.1 (FabricMC 53fa44c9).
 */
package net.minecraft.item;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;
import net.minecraft.client.item.TooltipContext;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffect;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.nbt.NbtList;
import net.minecraft.potion.PotionUtil;
import net.minecraft.text.Text;
import net.minecraft.world.World;
import org.jetbrains.annotations.Nullable;

public class SuspiciousStewItem
extends Item {
    public static final String EFFECTS_KEY = "Effects";
    public static final String EFFECT_ID_KEY = "EffectId";
    public static final String EFFECT_DURATION_KEY = "EffectDuration";
    public static final int DEFAULT_DURATION = 160;

    public SuspiciousStewItem(Item.Settings settings) {
        super(settings);
    }

    public static void addEffectToStew(ItemStack itemStack, StatusEffect statusEffect, int i) {
        NbtCompound nbtCompound = itemStack.getOrCreateNbt();
        NbtList nbtList = nbtCompound.getList(EFFECTS_KEY, 9);
        NbtCompound nbtCompound2 = new NbtCompound();
        nbtCompound2.putInt(EFFECT_ID_KEY, StatusEffect.getRawId(statusEffect));
        nbtCompound2.putInt(EFFECT_DURATION_KEY, i);
        nbtList.add(nbtCompound2);
        nbtCompound.put(EFFECTS_KEY, nbtList);
    }

    private static void forEachEffect(ItemStack itemStack, Consumer<StatusEffectInstance> consumer) {
        NbtCompound nbtCompound = itemStack.getNbt();
        if (nbtCompound != null && nbtCompound.contains(EFFECTS_KEY, 9)) {
            NbtList nbtList = nbtCompound.getList(EFFECTS_KEY, 10);
            for (int i = 0; i < nbtList.size(); ++i) {
                NbtCompound nbtCompound2 = nbtList.getCompound(i);
                int j = nbtCompound2.contains(EFFECT_DURATION_KEY, 99) ? nbtCompound2.getInt(EFFECT_DURATION_KEY) : 160;
                StatusEffect statusEffect = StatusEffect.byRawId(nbtCompound2.getInt(EFFECT_ID_KEY));
                if (statusEffect == null) continue;
                consumer.accept(new StatusEffectInstance(statusEffect, j));
            }
        }
    }

    @Override
    public void appendTooltip(ItemStack itemStack, @Nullable World world, List<Text> list, TooltipContext tooltipContext) {
        super.appendTooltip(itemStack, world, list, tooltipContext);
        if (tooltipContext.isCreative()) {
            ArrayList<StatusEffectInstance> list2 = new ArrayList<StatusEffectInstance>();
            SuspiciousStewItem.forEachEffect(itemStack, list2::add);
            PotionUtil.buildTooltip(list2, list, 1.0f);
        }
    }

    @Override
    public ItemStack finishUsing(ItemStack itemStack, World world, LivingEntity livingEntity) {
        ItemStack itemStack2 = super.finishUsing(itemStack, world, livingEntity);
        SuspiciousStewItem.forEachEffect(itemStack2, livingEntity::addStatusEffect);
        if (livingEntity instanceof PlayerEntity && ((PlayerEntity)livingEntity).getAbilities().creativeMode) {
            return itemStack2;
        }
        return new ItemStack(Items.field_8428);
    }
}


/*
 * Decompiled with CFR 0.2.1 (FabricMC 53fa44c9).
 */
package net.minecraft.world.biome;

import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.util.Identifier;
import net.minecraft.world.biome.Biome;

public abstract class BiomeKeys {
    public static final RegistryKey<Biome> field_9473 = BiomeKeys.register("the_void");
    public static final RegistryKey<Biome> field_9451 = BiomeKeys.register("plains");
    public static final RegistryKey<Biome> field_9455 = BiomeKeys.register("sunflower_plains");
    public static final RegistryKey<Biome> field_35117 = BiomeKeys.register("snowy_plains");
    public static final RegistryKey<Biome> field_9453 = BiomeKeys.register("ice_spikes");
    public static final RegistryKey<Biome> field_9424 = BiomeKeys.register("desert");
    public static final RegistryKey<Biome> field_9471 = BiomeKeys.register("swamp");
    public static final RegistryKey<Biome> field_38748 = BiomeKeys.register("mangrove_swamp");
    public static final RegistryKey<Biome> field_9409 = BiomeKeys.register("forest");
    public static final RegistryKey<Biome> field_9414 = BiomeKeys.register("flower_forest");
    public static final RegistryKey<Biome> field_9412 = BiomeKeys.register("birch_forest");
    public static final RegistryKey<Biome> field_9475 = BiomeKeys.register("dark_forest");
    public static final RegistryKey<Biome> field_35112 = BiomeKeys.register("old_growth_birch_forest");
    public static final RegistryKey<Biome> field_35119 = BiomeKeys.register("old_growth_pine_taiga");
    public static final RegistryKey<Biome> field_35113 = BiomeKeys.register("old_growth_spruce_taiga");
    public static final RegistryKey<Biome> field_9420 = BiomeKeys.register("taiga");
    public static final RegistryKey<Biome> field_9454 = BiomeKeys.register("snowy_taiga");
    public static final RegistryKey<Biome> field_9449 = BiomeKeys.register("savanna");
    public static final RegistryKey<Biome> field_9430 = BiomeKeys.register("savanna_plateau");
    public static final RegistryKey<Biome> field_35116 = BiomeKeys.register("windswept_hills");
    public static final RegistryKey<Biome> field_35111 = BiomeKeys.register("windswept_gravelly_hills");
    public static final RegistryKey<Biome> field_35120 = BiomeKeys.register("windswept_forest");
    public static final RegistryKey<Biome> field_35114 = BiomeKeys.register("windswept_savanna");
    public static final RegistryKey<Biome> field_9417 = BiomeKeys.register("jungle");
    public static final RegistryKey<Biome> field_35118 = BiomeKeys.register("sparse_jungle");
    public static final RegistryKey<Biome> field_9440 = BiomeKeys.register("bamboo_jungle");
    public static final RegistryKey<Biome> field_9415 = BiomeKeys.register("badlands");
    public static final RegistryKey<Biome> field_9443 = BiomeKeys.register("eroded_badlands");
    public static final RegistryKey<Biome> field_35110 = BiomeKeys.register("wooded_badlands");
    public static final RegistryKey<Biome> field_34470 = BiomeKeys.register("meadow");
    public static final RegistryKey<Biome> field_42720 = BiomeKeys.register("cherry_grove");
    public static final RegistryKey<Biome> field_34471 = BiomeKeys.register("grove");
    public static final RegistryKey<Biome> field_34472 = BiomeKeys.register("snowy_slopes");
    public static final RegistryKey<Biome> field_35115 = BiomeKeys.register("frozen_peaks");
    public static final RegistryKey<Biome> field_34474 = BiomeKeys.register("jagged_peaks");
    public static final RegistryKey<Biome> field_34475 = BiomeKeys.register("stony_peaks");
    public static final RegistryKey<Biome> field_9438 = BiomeKeys.register("river");
    public static final RegistryKey<Biome> field_9463 = BiomeKeys.register("frozen_river");
    public static final RegistryKey<Biome> field_9434 = BiomeKeys.register("beach");
    public static final RegistryKey<Biome> field_9478 = BiomeKeys.register("snowy_beach");
    public static final RegistryKey<Biome> field_9419 = BiomeKeys.register("stony_shore");
    public static final RegistryKey<Biome> field_9408 = BiomeKeys.register("warm_ocean");
    public static final RegistryKey<Biome> field_9441 = BiomeKeys.register("lukewarm_ocean");
    public static final RegistryKey<Biome> field_9439 = BiomeKeys.register("deep_lukewarm_ocean");
    public static final RegistryKey<Biome> field_9423 = BiomeKeys.register("ocean");
    public static final RegistryKey<Biome> field_9446 = BiomeKeys.register("deep_ocean");
    public static final RegistryKey<Biome> field_9467 = BiomeKeys.register("cold_ocean");
    public static final RegistryKey<Biome> field_9470 = BiomeKeys.register("deep_cold_ocean");
    public static final RegistryKey<Biome> field_9435 = BiomeKeys.register("frozen_ocean");
    public static final RegistryKey<Biome> field_9418 = BiomeKeys.register("deep_frozen_ocean");
    public static final RegistryKey<Biome> field_9462 = BiomeKeys.register("mushroom_fields");
    public static final RegistryKey<Biome> field_28107 = BiomeKeys.register("dripstone_caves");
    public static final RegistryKey<Biome> field_29218 = BiomeKeys.register("lush_caves");
    public static final RegistryKey<Biome> field_37543 = BiomeKeys.register("deep_dark");
    public static final RegistryKey<Biome> field_9461 = BiomeKeys.register("nether_wastes");
    public static final RegistryKey<Biome> field_22075 = BiomeKeys.register("warped_forest");
    public static final RegistryKey<Biome> field_22077 = BiomeKeys.register("crimson_forest");
    public static final RegistryKey<Biome> field_22076 = BiomeKeys.register("soul_sand_valley");
    public static final RegistryKey<Biome> field_23859 = BiomeKeys.register("basalt_deltas");
    public static final RegistryKey<Biome> field_9411 = BiomeKeys.register("the_end");
    public static final RegistryKey<Biome> field_9442 = BiomeKeys.register("end_highlands");
    public static final RegistryKey<Biome> field_9447 = BiomeKeys.register("end_midlands");
    public static final RegistryKey<Biome> field_9457 = BiomeKeys.register("small_end_islands");
    public static final RegistryKey<Biome> field_9465 = BiomeKeys.register("end_barrens");

    private static RegistryKey<Biome> register(String string) {
        return RegistryKey.of(RegistryKeys.BIOME, new Identifier(string));
    }
}


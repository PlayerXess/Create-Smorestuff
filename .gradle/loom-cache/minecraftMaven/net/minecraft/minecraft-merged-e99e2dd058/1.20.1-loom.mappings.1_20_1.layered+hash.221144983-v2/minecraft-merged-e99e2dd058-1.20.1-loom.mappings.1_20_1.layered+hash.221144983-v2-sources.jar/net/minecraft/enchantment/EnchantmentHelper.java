/*
 * Decompiled with CFR 0.2.1 (FabricMC 53fa44c9).
 */
package net.minecraft.enchantment;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Predicate;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.enchantment.EnchantmentLevelEntry;
import net.minecraft.enchantment.Enchantments;
import net.minecraft.enchantment.SweepingEnchantment;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityGroup;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.EnchantedBookItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.nbt.NbtList;
import net.minecraft.registry.Registries;
import net.minecraft.util.Identifier;
import net.minecraft.util.Util;
import net.minecraft.util.collection.Weighting;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.random.Random;
import org.apache.commons.lang3.mutable.MutableFloat;
import org.apache.commons.lang3.mutable.MutableInt;
import org.jetbrains.annotations.Nullable;

public class EnchantmentHelper {
    private static final String ID_KEY = "id";
    private static final String LEVEL_KEY = "lvl";
    private static final float field_38222 = 0.15f;

    public static NbtCompound createNbt(@Nullable Identifier identifier, int i) {
        NbtCompound nbtCompound = new NbtCompound();
        nbtCompound.putString(ID_KEY, String.valueOf(identifier));
        nbtCompound.putShort(LEVEL_KEY, (short)i);
        return nbtCompound;
    }

    public static void writeLevelToNbt(NbtCompound nbtCompound, int i) {
        nbtCompound.putShort(LEVEL_KEY, (short)i);
    }

    public static int getLevelFromNbt(NbtCompound nbtCompound) {
        return MathHelper.clamp(nbtCompound.getInt(LEVEL_KEY), 0, 255);
    }

    @Nullable
    public static Identifier getIdFromNbt(NbtCompound nbtCompound) {
        return Identifier.tryParse(nbtCompound.getString(ID_KEY));
    }

    @Nullable
    public static Identifier getEnchantmentId(Enchantment enchantment) {
        return Registries.ENCHANTMENT.getId(enchantment);
    }

    public static int getLevel(Enchantment enchantment, ItemStack itemStack) {
        if (itemStack.isEmpty()) {
            return 0;
        }
        Identifier identifier = EnchantmentHelper.getEnchantmentId(enchantment);
        NbtList nbtList = itemStack.getEnchantments();
        for (int i = 0; i < nbtList.size(); ++i) {
            NbtCompound nbtCompound = nbtList.getCompound(i);
            Identifier identifier2 = EnchantmentHelper.getIdFromNbt(nbtCompound);
            if (identifier2 == null || !identifier2.equals(identifier)) continue;
            return EnchantmentHelper.getLevelFromNbt(nbtCompound);
        }
        return 0;
    }

    public static Map<Enchantment, Integer> get(ItemStack itemStack) {
        NbtList nbtList = itemStack.isOf(Items.field_8598) ? EnchantedBookItem.getEnchantmentNbt(itemStack) : itemStack.getEnchantments();
        return EnchantmentHelper.fromNbt(nbtList);
    }

    public static Map<Enchantment, Integer> fromNbt(NbtList nbtList) {
        LinkedHashMap<Enchantment, Integer> map = Maps.newLinkedHashMap();
        for (int i = 0; i < nbtList.size(); ++i) {
            NbtCompound nbtCompound = nbtList.getCompound(i);
            Registries.ENCHANTMENT.getOrEmpty(EnchantmentHelper.getIdFromNbt(nbtCompound)).ifPresent(enchantment -> map.put((Enchantment)enchantment, EnchantmentHelper.getLevelFromNbt(nbtCompound)));
        }
        return map;
    }

    public static void set(Map<Enchantment, Integer> map, ItemStack itemStack) {
        NbtList nbtList = new NbtList();
        for (Map.Entry<Enchantment, Integer> entry : map.entrySet()) {
            Enchantment enchantment = entry.getKey();
            if (enchantment == null) continue;
            int i = entry.getValue();
            nbtList.add(EnchantmentHelper.createNbt(EnchantmentHelper.getEnchantmentId(enchantment), i));
            if (!itemStack.isOf(Items.field_8598)) continue;
            EnchantedBookItem.addEnchantment(itemStack, new EnchantmentLevelEntry(enchantment, i));
        }
        if (nbtList.isEmpty()) {
            itemStack.removeSubNbt("Enchantments");
        } else if (!itemStack.isOf(Items.field_8598)) {
            itemStack.setSubNbt("Enchantments", nbtList);
        }
    }

    private static void forEachEnchantment(Consumer consumer, ItemStack itemStack) {
        if (itemStack.isEmpty()) {
            return;
        }
        NbtList nbtList = itemStack.getEnchantments();
        for (int i = 0; i < nbtList.size(); ++i) {
            NbtCompound nbtCompound = nbtList.getCompound(i);
            Registries.ENCHANTMENT.getOrEmpty(EnchantmentHelper.getIdFromNbt(nbtCompound)).ifPresent(enchantment -> consumer.accept((Enchantment)enchantment, EnchantmentHelper.getLevelFromNbt(nbtCompound)));
        }
    }

    private static void forEachEnchantment(Consumer consumer, Iterable<ItemStack> iterable) {
        for (ItemStack itemStack : iterable) {
            EnchantmentHelper.forEachEnchantment(consumer, itemStack);
        }
    }

    public static int getProtectionAmount(Iterable<ItemStack> iterable, DamageSource damageSource) {
        MutableInt mutableInt = new MutableInt();
        EnchantmentHelper.forEachEnchantment((Enchantment enchantment, int i) -> mutableInt.add(enchantment.getProtectionAmount(i, damageSource)), iterable);
        return mutableInt.intValue();
    }

    public static float getAttackDamage(ItemStack itemStack, EntityGroup entityGroup) {
        MutableFloat mutableFloat = new MutableFloat();
        EnchantmentHelper.forEachEnchantment((Enchantment enchantment, int i) -> mutableFloat.add(enchantment.getAttackDamage(i, entityGroup)), itemStack);
        return mutableFloat.floatValue();
    }

    public static float getSweepingMultiplier(LivingEntity livingEntity) {
        int i = EnchantmentHelper.getEquipmentLevel(Enchantments.field_9115, livingEntity);
        if (i > 0) {
            return SweepingEnchantment.getMultiplier(i);
        }
        return 0.0f;
    }

    public static void onUserDamaged(LivingEntity livingEntity, Entity entity) {
        Consumer consumer = (enchantment, i) -> enchantment.onUserDamaged(livingEntity, entity, i);
        if (livingEntity != null) {
            EnchantmentHelper.forEachEnchantment(consumer, livingEntity.getItemsEquipped());
        }
        if (entity instanceof PlayerEntity) {
            EnchantmentHelper.forEachEnchantment(consumer, livingEntity.getMainHandStack());
        }
    }

    public static void onTargetDamaged(LivingEntity livingEntity, Entity entity) {
        Consumer consumer = (enchantment, i) -> enchantment.onTargetDamaged(livingEntity, entity, i);
        if (livingEntity != null) {
            EnchantmentHelper.forEachEnchantment(consumer, livingEntity.getItemsEquipped());
        }
        if (livingEntity instanceof PlayerEntity) {
            EnchantmentHelper.forEachEnchantment(consumer, livingEntity.getMainHandStack());
        }
    }

    public static int getEquipmentLevel(Enchantment enchantment, LivingEntity livingEntity) {
        Collection<ItemStack> iterable = enchantment.getEquipment(livingEntity).values();
        if (iterable == null) {
            return 0;
        }
        int i = 0;
        for (ItemStack itemStack : iterable) {
            int j = EnchantmentHelper.getLevel(enchantment, itemStack);
            if (j <= i) continue;
            i = j;
        }
        return i;
    }

    public static float getSwiftSneakSpeedBoost(LivingEntity livingEntity) {
        return (float)EnchantmentHelper.getEquipmentLevel(Enchantments.field_38223, livingEntity) * 0.15f;
    }

    public static int getKnockback(LivingEntity livingEntity) {
        return EnchantmentHelper.getEquipmentLevel(Enchantments.field_9121, livingEntity);
    }

    public static int getFireAspect(LivingEntity livingEntity) {
        return EnchantmentHelper.getEquipmentLevel(Enchantments.field_9124, livingEntity);
    }

    public static int getRespiration(LivingEntity livingEntity) {
        return EnchantmentHelper.getEquipmentLevel(Enchantments.field_9127, livingEntity);
    }

    public static int getDepthStrider(LivingEntity livingEntity) {
        return EnchantmentHelper.getEquipmentLevel(Enchantments.field_9128, livingEntity);
    }

    public static int getEfficiency(LivingEntity livingEntity) {
        return EnchantmentHelper.getEquipmentLevel(Enchantments.field_9131, livingEntity);
    }

    public static int getLuckOfTheSea(ItemStack itemStack) {
        return EnchantmentHelper.getLevel(Enchantments.field_9114, itemStack);
    }

    public static int getLure(ItemStack itemStack) {
        return EnchantmentHelper.getLevel(Enchantments.field_9100, itemStack);
    }

    public static int getLooting(LivingEntity livingEntity) {
        return EnchantmentHelper.getEquipmentLevel(Enchantments.field_9110, livingEntity);
    }

    public static boolean hasAquaAffinity(LivingEntity livingEntity) {
        return EnchantmentHelper.getEquipmentLevel(Enchantments.field_9105, livingEntity) > 0;
    }

    public static boolean hasFrostWalker(LivingEntity livingEntity) {
        return EnchantmentHelper.getEquipmentLevel(Enchantments.field_9122, livingEntity) > 0;
    }

    public static boolean hasSoulSpeed(LivingEntity livingEntity) {
        return EnchantmentHelper.getEquipmentLevel(Enchantments.field_23071, livingEntity) > 0;
    }

    public static boolean hasBindingCurse(ItemStack itemStack) {
        return EnchantmentHelper.getLevel(Enchantments.field_9113, itemStack) > 0;
    }

    public static boolean hasVanishingCurse(ItemStack itemStack) {
        return EnchantmentHelper.getLevel(Enchantments.field_9109, itemStack) > 0;
    }

    public static boolean hasSilkTouch(ItemStack itemStack) {
        return EnchantmentHelper.getLevel(Enchantments.field_9099, itemStack) > 0;
    }

    public static int getLoyalty(ItemStack itemStack) {
        return EnchantmentHelper.getLevel(Enchantments.field_9120, itemStack);
    }

    public static int getRiptide(ItemStack itemStack) {
        return EnchantmentHelper.getLevel(Enchantments.field_9104, itemStack);
    }

    public static boolean hasChanneling(ItemStack itemStack) {
        return EnchantmentHelper.getLevel(Enchantments.field_9117, itemStack) > 0;
    }

    @Nullable
    public static Map.Entry<EquipmentSlot, ItemStack> chooseEquipmentWith(Enchantment enchantment, LivingEntity livingEntity) {
        return EnchantmentHelper.chooseEquipmentWith(enchantment, livingEntity, itemStack -> true);
    }

    @Nullable
    public static Map.Entry<EquipmentSlot, ItemStack> chooseEquipmentWith(Enchantment enchantment, LivingEntity livingEntity, Predicate<ItemStack> predicate) {
        Map<EquipmentSlot, ItemStack> map = enchantment.getEquipment(livingEntity);
        if (map.isEmpty()) {
            return null;
        }
        ArrayList<Map.Entry<EquipmentSlot, ItemStack>> list = Lists.newArrayList();
        for (Map.Entry<EquipmentSlot, ItemStack> entry : map.entrySet()) {
            ItemStack itemStack = entry.getValue();
            if (itemStack.isEmpty() || EnchantmentHelper.getLevel(enchantment, itemStack) <= 0 || !predicate.test(itemStack)) continue;
            list.add(entry);
        }
        return list.isEmpty() ? null : (Map.Entry)list.get(livingEntity.getRandom().nextInt(list.size()));
    }

    public static int calculateRequiredExperienceLevel(Random random, int i, int j, ItemStack itemStack) {
        Item item = itemStack.getItem();
        int k = item.getEnchantability();
        if (k <= 0) {
            return 0;
        }
        if (j > 15) {
            j = 15;
        }
        int l = random.nextInt(8) + 1 + (j >> 1) + random.nextInt(j + 1);
        if (i == 0) {
            return Math.max(l / 3, 1);
        }
        if (i == 1) {
            return l * 2 / 3 + 1;
        }
        return Math.max(l, j * 2);
    }

    public static ItemStack enchant(Random random, ItemStack itemStack, int i, boolean bl) {
        List<EnchantmentLevelEntry> list = EnchantmentHelper.generateEnchantments(random, itemStack, i, bl);
        boolean bl2 = itemStack.isOf(Items.field_8529);
        if (bl2) {
            itemStack = new ItemStack(Items.field_8598);
        }
        for (EnchantmentLevelEntry enchantmentLevelEntry : list) {
            if (bl2) {
                EnchantedBookItem.addEnchantment(itemStack, enchantmentLevelEntry);
                continue;
            }
            itemStack.addEnchantment(enchantmentLevelEntry.enchantment, enchantmentLevelEntry.level);
        }
        return itemStack;
    }

    public static List<EnchantmentLevelEntry> generateEnchantments(Random random, ItemStack itemStack, int i, boolean bl) {
        ArrayList<EnchantmentLevelEntry> list = Lists.newArrayList();
        Item item = itemStack.getItem();
        int j = item.getEnchantability();
        if (j <= 0) {
            return list;
        }
        i += 1 + random.nextInt(j / 4 + 1) + random.nextInt(j / 4 + 1);
        float f = (random.nextFloat() + random.nextFloat() - 1.0f) * 0.15f;
        List<EnchantmentLevelEntry> list2 = EnchantmentHelper.getPossibleEntries(i = MathHelper.clamp(Math.round((float)i + (float)i * f), 1, Integer.MAX_VALUE), itemStack, bl);
        if (!list2.isEmpty()) {
            Weighting.getRandom(random, list2).ifPresent(list::add);
            while (random.nextInt(50) <= i) {
                if (!list.isEmpty()) {
                    EnchantmentHelper.removeConflicts(list2, Util.getLast(list));
                }
                if (list2.isEmpty()) break;
                Weighting.getRandom(random, list2).ifPresent(list::add);
                i /= 2;
            }
        }
        return list;
    }

    public static void removeConflicts(List<EnchantmentLevelEntry> list, EnchantmentLevelEntry enchantmentLevelEntry) {
        Iterator<EnchantmentLevelEntry> iterator = list.iterator();
        while (iterator.hasNext()) {
            if (enchantmentLevelEntry.enchantment.canCombine(iterator.next().enchantment)) continue;
            iterator.remove();
        }
    }

    public static boolean isCompatible(Collection<Enchantment> collection, Enchantment enchantment) {
        for (Enchantment enchantment2 : collection) {
            if (enchantment2.canCombine(enchantment)) continue;
            return false;
        }
        return true;
    }

    public static List<EnchantmentLevelEntry> getPossibleEntries(int i, ItemStack itemStack, boolean bl) {
        ArrayList<EnchantmentLevelEntry> list = Lists.newArrayList();
        Item item = itemStack.getItem();
        boolean bl2 = itemStack.isOf(Items.field_8529);
        block0: for (Enchantment enchantment : Registries.ENCHANTMENT) {
            if (enchantment.isTreasure() && !bl || !enchantment.isAvailableForRandomSelection() || !enchantment.target.isAcceptableItem(item) && !bl2) continue;
            for (int j = enchantment.getMaxLevel(); j > enchantment.getMinLevel() - 1; --j) {
                if (i < enchantment.getMinPower(j) || i > enchantment.getMaxPower(j)) continue;
                list.add(new EnchantmentLevelEntry(enchantment, j));
                continue block0;
            }
        }
        return list;
    }

    @FunctionalInterface
    public static interface Consumer {
        public void accept(Enchantment var1, int var2);
    }
}


/*
 * Decompiled with CFR 0.2.1 (FabricMC 53fa44c9).
 */
package net.minecraft.client.render.model.json;

import com.mojang.serialization.Codec;
import java.util.function.IntFunction;
import net.minecraft.util.StringIdentifiable;
import net.minecraft.util.function.ValueLists;

public enum ModelTransformationMode implements StringIdentifiable
{
    field_4315(0, "none"),
    field_4323(1, "thirdperson_lefthand"),
    field_4320(2, "thirdperson_righthand"),
    field_4321(3, "firstperson_lefthand"),
    field_4322(4, "firstperson_righthand"),
    field_4316(5, "head"),
    field_4317(6, "gui"),
    field_4318(7, "ground"),
    field_4319(8, "fixed");

    public static final Codec<ModelTransformationMode> CODEC;
    public static final IntFunction<ModelTransformationMode> FROM_INDEX;
    private final byte index;
    private final String name;

    private ModelTransformationMode(int j, String string2) {
        this.name = string2;
        this.index = (byte)j;
    }

    @Override
    public String asString() {
        return this.name;
    }

    public byte getIndex() {
        return this.index;
    }

    public boolean isFirstPerson() {
        return this == field_4321 || this == field_4322;
    }

    static {
        CODEC = StringIdentifiable.createCodec(ModelTransformationMode::values);
        FROM_INDEX = ValueLists.createIdToValueFunction(ModelTransformationMode::getIndex, ModelTransformationMode.values(), ValueLists.OutOfBoundsHandling.field_41664);
    }
}


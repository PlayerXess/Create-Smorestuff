/*
 * Decompiled with CFR 0.2.1 (FabricMC 53fa44c9).
 */
package net.minecraft.util.math;

import java.util.Arrays;
import net.minecraft.util.Util;
import org.joml.Matrix3f;

public enum AxisTransformation {
    field_23362(0, 1, 2),
    field_23363(1, 0, 2),
    field_23364(0, 2, 1),
    field_23365(1, 2, 0),
    field_23366(2, 0, 1),
    field_23367(2, 1, 0);

    private final int[] mappings;
    private final Matrix3f matrix;
    private static final int NUM_AXES = 3;
    private static final AxisTransformation[][] COMBINATIONS;

    private AxisTransformation(int j, int k, int l) {
        this.mappings = new int[]{j, k, l};
        this.matrix = new Matrix3f();
        this.matrix.set(this.map(0), 0, 1.0f);
        this.matrix.set(this.map(1), 1, 1.0f);
        this.matrix.set(this.map(2), 2, 1.0f);
    }

    public AxisTransformation prepend(AxisTransformation axisTransformation) {
        return COMBINATIONS[this.ordinal()][axisTransformation.ordinal()];
    }

    public int map(int i) {
        return this.mappings[i];
    }

    public Matrix3f getMatrix() {
        return this.matrix;
    }

    static {
        COMBINATIONS = Util.make(new AxisTransformation[AxisTransformation.values().length][AxisTransformation.values().length], axisTransformations -> {
            for (AxisTransformation axisTransformation2 : AxisTransformation.values()) {
                for (AxisTransformation axisTransformation22 : AxisTransformation.values()) {
                    AxisTransformation axisTransformation3;
                    int[] is = new int[3];
                    for (int i = 0; i < 3; ++i) {
                        is[i] = axisTransformation2.mappings[axisTransformation22.mappings[i]];
                    }
                    axisTransformations[axisTransformation2.ordinal()][axisTransformation22.ordinal()] = axisTransformation3 = Arrays.stream(AxisTransformation.values()).filter(axisTransformation -> Arrays.equals(axisTransformation.mappings, is)).findFirst().get();
                }
            }
        });
    }
}


/*
 * Decompiled with CFR 0.2.1 (FabricMC 53fa44c9).
 */
package net.minecraft.block;

import net.minecraft.block.AbstractBlock;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.FenceGateBlock;
import net.minecraft.block.PistonExtensionBlock;
import net.minecraft.block.ShapeContext;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.ai.pathing.NavigationType;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemPlacementContext;
import net.minecraft.registry.tag.BlockTags;
import net.minecraft.registry.tag.FluidTags;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.state.StateManager;
import net.minecraft.state.property.IntProperty;
import net.minecraft.state.property.Properties;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.random.Random;
import net.minecraft.util.shape.VoxelShape;
import net.minecraft.world.BlockView;
import net.minecraft.world.GameRules;
import net.minecraft.world.World;
import net.minecraft.world.WorldAccess;
import net.minecraft.world.WorldView;
import net.minecraft.world.event.GameEvent;
import org.jetbrains.annotations.Nullable;

public class FarmlandBlock
extends Block {
    public static final IntProperty MOISTURE = Properties.MOISTURE;
    protected static final VoxelShape SHAPE = Block.createCuboidShape(0.0, 0.0, 0.0, 16.0, 15.0, 16.0);
    public static final int MAX_MOISTURE = 7;

    public FarmlandBlock(AbstractBlock.Settings settings) {
        super(settings);
        this.setDefaultState((BlockState)((BlockState)this.stateManager.getDefaultState()).with(MOISTURE, 0));
    }

    @Override
    public BlockState getStateForNeighborUpdate(BlockState blockState, Direction direction, BlockState blockState2, WorldAccess worldAccess, BlockPos blockPos, BlockPos blockPos2) {
        if (direction == Direction.field_11036 && !blockState.canPlaceAt(worldAccess, blockPos)) {
            worldAccess.scheduleBlockTick(blockPos, this, 1);
        }
        return super.getStateForNeighborUpdate(blockState, direction, blockState2, worldAccess, blockPos, blockPos2);
    }

    @Override
    public boolean canPlaceAt(BlockState blockState, WorldView worldView, BlockPos blockPos) {
        BlockState blockState2 = worldView.getBlockState(blockPos.up());
        return !blockState2.isSolid() || blockState2.getBlock() instanceof FenceGateBlock || blockState2.getBlock() instanceof PistonExtensionBlock;
    }

    @Override
    public BlockState getPlacementState(ItemPlacementContext itemPlacementContext) {
        if (!this.getDefaultState().canPlaceAt(itemPlacementContext.getWorld(), itemPlacementContext.getBlockPos())) {
            return Blocks.field_10566.getDefaultState();
        }
        return super.getPlacementState(itemPlacementContext);
    }

    @Override
    public boolean hasSidedTransparency(BlockState blockState) {
        return true;
    }

    @Override
    public VoxelShape getOutlineShape(BlockState blockState, BlockView blockView, BlockPos blockPos, ShapeContext shapeContext) {
        return SHAPE;
    }

    @Override
    public void scheduledTick(BlockState blockState, ServerWorld serverWorld, BlockPos blockPos, Random random) {
        if (!blockState.canPlaceAt(serverWorld, blockPos)) {
            FarmlandBlock.setToDirt(null, blockState, serverWorld, blockPos);
        }
    }

    @Override
    public void randomTick(BlockState blockState, ServerWorld serverWorld, BlockPos blockPos, Random random) {
        int i = blockState.get(MOISTURE);
        if (FarmlandBlock.isWaterNearby(serverWorld, blockPos) || serverWorld.hasRain(blockPos.up())) {
            if (i < 7) {
                serverWorld.setBlockState(blockPos, (BlockState)blockState.with(MOISTURE, 7), 2);
            }
        } else if (i > 0) {
            serverWorld.setBlockState(blockPos, (BlockState)blockState.with(MOISTURE, i - 1), 2);
        } else if (!FarmlandBlock.hasCrop(serverWorld, blockPos)) {
            FarmlandBlock.setToDirt(null, blockState, serverWorld, blockPos);
        }
    }

    @Override
    public void onLandedUpon(World world, BlockState blockState, BlockPos blockPos, Entity entity, float f) {
        if (!world.isClient && world.random.nextFloat() < f - 0.5f && entity instanceof LivingEntity && (entity instanceof PlayerEntity || world.getGameRules().getBoolean(GameRules.DO_MOB_GRIEFING)) && entity.getWidth() * entity.getWidth() * entity.getHeight() > 0.512f) {
            FarmlandBlock.setToDirt(entity, blockState, world, blockPos);
        }
        super.onLandedUpon(world, blockState, blockPos, entity, f);
    }

    public static void setToDirt(@Nullable Entity entity, BlockState blockState, World world, BlockPos blockPos) {
        BlockState blockState2 = FarmlandBlock.pushEntitiesUpBeforeBlockChange(blockState, Blocks.field_10566.getDefaultState(), world, blockPos);
        world.setBlockState(blockPos, blockState2);
        world.emitGameEvent(GameEvent.field_28733, blockPos, GameEvent.Emitter.of(entity, blockState2));
    }

    private static boolean hasCrop(BlockView blockView, BlockPos blockPos) {
        return blockView.getBlockState(blockPos.up()).isIn(BlockTags.field_44589);
    }

    private static boolean isWaterNearby(WorldView worldView, BlockPos blockPos) {
        for (BlockPos blockPos2 : BlockPos.iterate(blockPos.add(-4, 0, -4), blockPos.add(4, 1, 4))) {
            if (!worldView.getFluidState(blockPos2).isIn(FluidTags.field_15517)) continue;
            return true;
        }
        return false;
    }

    @Override
    protected void appendProperties(StateManager.Builder<Block, BlockState> builder) {
        builder.add(MOISTURE);
    }

    @Override
    public boolean canPathfindThrough(BlockState blockState, BlockView blockView, BlockPos blockPos, NavigationType navigationType) {
        return false;
    }
}


/*
 * Decompiled with CFR 0.2.1 (FabricMC 53fa44c9).
 */
package net.minecraft.item;

import net.minecraft.item.DyeableItem;
import net.minecraft.item.HorseArmorItem;
import net.minecraft.item.Item;

public class DyeableHorseArmorItem
extends HorseArmorItem
implements DyeableItem {
    public DyeableHorseArmorItem(int i, String string, Item.Settings settings) {
        super(i, string, settings);
    }
}


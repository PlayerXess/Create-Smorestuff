/*
 * Decompiled with CFR 0.2.1 (FabricMC 53fa44c9).
 */
package net.minecraft.item.trim;

import com.mojang.datafixers.kinds.Applicative;
import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import java.util.Map;
import net.minecraft.item.ArmorMaterials;
import net.minecraft.item.Item;
import net.minecraft.registry.Registries;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.registry.entry.RegistryElementCodec;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.registry.entry.RegistryFixedCodec;
import net.minecraft.text.Text;
import net.minecraft.util.dynamic.Codecs;

public record ArmorTrimMaterial(String comp_1208, RegistryEntry<Item> comp_1209, float comp_1210, Map<ArmorMaterials, String> comp_1237, Text comp_1212) {
    public static final Codec<ArmorTrimMaterial> CODEC = RecordCodecBuilder.create(instance -> instance.group(((MapCodec)Codec.STRING.fieldOf("asset_name")).forGetter(ArmorTrimMaterial::comp_1208), ((MapCodec)RegistryFixedCodec.of(RegistryKeys.field_41197).fieldOf("ingredient")).forGetter(ArmorTrimMaterial::comp_1209), ((MapCodec)Codec.FLOAT.fieldOf("item_model_index")).forGetter(ArmorTrimMaterial::comp_1210), Codec.unboundedMap(ArmorMaterials.CODEC, Codec.STRING).optionalFieldOf("override_armor_materials", Map.of()).forGetter(ArmorTrimMaterial::comp_1237), ((MapCodec)Codecs.TEXT.fieldOf("description")).forGetter(ArmorTrimMaterial::comp_1212)).apply((Applicative<ArmorTrimMaterial, ?>)instance, ArmorTrimMaterial::new));
    public static final Codec<RegistryEntry<ArmorTrimMaterial>> ENTRY_CODEC = RegistryElementCodec.of(RegistryKeys.field_42083, CODEC);

    public static ArmorTrimMaterial of(String string, Item item, float f, Text text, Map<ArmorMaterials, String> map) {
        return new ArmorTrimMaterial(string, Registries.ITEM.getEntry(item), f, map, text);
    }
}


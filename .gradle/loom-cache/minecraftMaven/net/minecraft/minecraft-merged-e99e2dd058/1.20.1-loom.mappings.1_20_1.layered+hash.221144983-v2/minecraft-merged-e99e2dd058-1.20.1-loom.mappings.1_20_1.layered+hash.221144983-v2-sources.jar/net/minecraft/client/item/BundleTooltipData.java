/*
 * Decompiled with CFR 0.2.1 (FabricMC 53fa44c9).
 */
package net.minecraft.client.item;

import net.minecraft.client.item.TooltipData;
import net.minecraft.item.ItemStack;
import net.minecraft.util.collection.DefaultedList;

public class BundleTooltipData
implements TooltipData {
    private final DefaultedList<ItemStack> inventory;
    private final int bundleOccupancy;

    public BundleTooltipData(DefaultedList<ItemStack> defaultedList, int i) {
        this.inventory = defaultedList;
        this.bundleOccupancy = i;
    }

    public DefaultedList<ItemStack> getInventory() {
        return this.inventory;
    }

    public int getBundleOccupancy() {
        return this.bundleOccupancy;
    }
}


/*
 * Decompiled with CFR 0.2.1 (FabricMC 53fa44c9).
 */
package net.minecraft.enchantment;

import net.minecraft.enchantment.AquaAffinityEnchantment;
import net.minecraft.enchantment.BindingCurseEnchantment;
import net.minecraft.enchantment.ChannelingEnchantment;
import net.minecraft.enchantment.DamageEnchantment;
import net.minecraft.enchantment.DepthStriderEnchantment;
import net.minecraft.enchantment.EfficiencyEnchantment;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.enchantment.EnchantmentTarget;
import net.minecraft.enchantment.FireAspectEnchantment;
import net.minecraft.enchantment.FlameEnchantment;
import net.minecraft.enchantment.FrostWalkerEnchantment;
import net.minecraft.enchantment.ImpalingEnchantment;
import net.minecraft.enchantment.InfinityEnchantment;
import net.minecraft.enchantment.KnockbackEnchantment;
import net.minecraft.enchantment.LoyaltyEnchantment;
import net.minecraft.enchantment.LuckEnchantment;
import net.minecraft.enchantment.LureEnchantment;
import net.minecraft.enchantment.MendingEnchantment;
import net.minecraft.enchantment.MultishotEnchantment;
import net.minecraft.enchantment.PiercingEnchantment;
import net.minecraft.enchantment.PowerEnchantment;
import net.minecraft.enchantment.ProtectionEnchantment;
import net.minecraft.enchantment.PunchEnchantment;
import net.minecraft.enchantment.QuickChargeEnchantment;
import net.minecraft.enchantment.RespirationEnchantment;
import net.minecraft.enchantment.RiptideEnchantment;
import net.minecraft.enchantment.SilkTouchEnchantment;
import net.minecraft.enchantment.SoulSpeedEnchantment;
import net.minecraft.enchantment.SweepingEnchantment;
import net.minecraft.enchantment.SwiftSneakEnchantment;
import net.minecraft.enchantment.ThornsEnchantment;
import net.minecraft.enchantment.UnbreakingEnchantment;
import net.minecraft.enchantment.VanishingCurseEnchantment;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;

public class Enchantments {
    private static final EquipmentSlot[] ALL_ARMOR = new EquipmentSlot[]{EquipmentSlot.field_6169, EquipmentSlot.field_6174, EquipmentSlot.field_6172, EquipmentSlot.field_6166};
    public static final Enchantment field_9111 = Enchantments.register("protection", new ProtectionEnchantment(Enchantment.Rarity.field_9087, ProtectionEnchantment.Type.field_9138, ALL_ARMOR));
    public static final Enchantment field_9095 = Enchantments.register("fire_protection", new ProtectionEnchantment(Enchantment.Rarity.field_9090, ProtectionEnchantment.Type.field_9139, ALL_ARMOR));
    public static final Enchantment field_9129 = Enchantments.register("feather_falling", new ProtectionEnchantment(Enchantment.Rarity.field_9090, ProtectionEnchantment.Type.field_9140, ALL_ARMOR));
    public static final Enchantment field_9107 = Enchantments.register("blast_protection", new ProtectionEnchantment(Enchantment.Rarity.field_9088, ProtectionEnchantment.Type.field_9141, ALL_ARMOR));
    public static final Enchantment field_9096 = Enchantments.register("projectile_protection", new ProtectionEnchantment(Enchantment.Rarity.field_9090, ProtectionEnchantment.Type.field_9142, ALL_ARMOR));
    public static final Enchantment field_9127 = Enchantments.register("respiration", new RespirationEnchantment(Enchantment.Rarity.field_9088, ALL_ARMOR));
    public static final Enchantment field_9105 = Enchantments.register("aqua_affinity", new AquaAffinityEnchantment(Enchantment.Rarity.field_9088, ALL_ARMOR));
    public static final Enchantment field_9097 = Enchantments.register("thorns", new ThornsEnchantment(Enchantment.Rarity.field_9091, ALL_ARMOR));
    public static final Enchantment field_9128 = Enchantments.register("depth_strider", new DepthStriderEnchantment(Enchantment.Rarity.field_9088, ALL_ARMOR));
    public static final Enchantment field_9122 = Enchantments.register("frost_walker", new FrostWalkerEnchantment(Enchantment.Rarity.field_9088, EquipmentSlot.field_6166));
    public static final Enchantment field_9113 = Enchantments.register("binding_curse", new BindingCurseEnchantment(Enchantment.Rarity.field_9091, ALL_ARMOR));
    public static final Enchantment field_23071 = Enchantments.register("soul_speed", new SoulSpeedEnchantment(Enchantment.Rarity.field_9091, EquipmentSlot.field_6166));
    public static final Enchantment field_38223 = Enchantments.register("swift_sneak", new SwiftSneakEnchantment(Enchantment.Rarity.field_9091, EquipmentSlot.field_6172));
    public static final Enchantment field_9118 = Enchantments.register("sharpness", new DamageEnchantment(Enchantment.Rarity.field_9087, 0, EquipmentSlot.field_6173));
    public static final Enchantment field_9123 = Enchantments.register("smite", new DamageEnchantment(Enchantment.Rarity.field_9090, 1, EquipmentSlot.field_6173));
    public static final Enchantment field_9112 = Enchantments.register("bane_of_arthropods", new DamageEnchantment(Enchantment.Rarity.field_9090, 2, EquipmentSlot.field_6173));
    public static final Enchantment field_9121 = Enchantments.register("knockback", new KnockbackEnchantment(Enchantment.Rarity.field_9090, EquipmentSlot.field_6173));
    public static final Enchantment field_9124 = Enchantments.register("fire_aspect", new FireAspectEnchantment(Enchantment.Rarity.field_9088, EquipmentSlot.field_6173));
    public static final Enchantment field_9110 = Enchantments.register("looting", new LuckEnchantment(Enchantment.Rarity.field_9088, EnchantmentTarget.field_9074, EquipmentSlot.field_6173));
    public static final Enchantment field_9115 = Enchantments.register("sweeping", new SweepingEnchantment(Enchantment.Rarity.field_9088, EquipmentSlot.field_6173));
    public static final Enchantment field_9131 = Enchantments.register("efficiency", new EfficiencyEnchantment(Enchantment.Rarity.field_9087, EquipmentSlot.field_6173));
    public static final Enchantment field_9099 = Enchantments.register("silk_touch", new SilkTouchEnchantment(Enchantment.Rarity.field_9091, EquipmentSlot.field_6173));
    public static final Enchantment field_9119 = Enchantments.register("unbreaking", new UnbreakingEnchantment(Enchantment.Rarity.field_9090, EquipmentSlot.field_6173));
    public static final Enchantment field_9130 = Enchantments.register("fortune", new LuckEnchantment(Enchantment.Rarity.field_9088, EnchantmentTarget.field_9069, EquipmentSlot.field_6173));
    public static final Enchantment field_9103 = Enchantments.register("power", new PowerEnchantment(Enchantment.Rarity.field_9087, EquipmentSlot.field_6173));
    public static final Enchantment field_9116 = Enchantments.register("punch", new PunchEnchantment(Enchantment.Rarity.field_9088, EquipmentSlot.field_6173));
    public static final Enchantment field_9126 = Enchantments.register("flame", new FlameEnchantment(Enchantment.Rarity.field_9088, EquipmentSlot.field_6173));
    public static final Enchantment field_9125 = Enchantments.register("infinity", new InfinityEnchantment(Enchantment.Rarity.field_9091, EquipmentSlot.field_6173));
    public static final Enchantment field_9114 = Enchantments.register("luck_of_the_sea", new LuckEnchantment(Enchantment.Rarity.field_9088, EnchantmentTarget.field_9072, EquipmentSlot.field_6173));
    public static final Enchantment field_9100 = Enchantments.register("lure", new LureEnchantment(Enchantment.Rarity.field_9088, EnchantmentTarget.field_9072, EquipmentSlot.field_6173));
    public static final Enchantment field_9120 = Enchantments.register("loyalty", new LoyaltyEnchantment(Enchantment.Rarity.field_9090, EquipmentSlot.field_6173));
    public static final Enchantment field_9106 = Enchantments.register("impaling", new ImpalingEnchantment(Enchantment.Rarity.field_9088, EquipmentSlot.field_6173));
    public static final Enchantment field_9104 = Enchantments.register("riptide", new RiptideEnchantment(Enchantment.Rarity.field_9088, EquipmentSlot.field_6173));
    public static final Enchantment field_9117 = Enchantments.register("channeling", new ChannelingEnchantment(Enchantment.Rarity.field_9091, EquipmentSlot.field_6173));
    public static final Enchantment field_9108 = Enchantments.register("multishot", new MultishotEnchantment(Enchantment.Rarity.field_9088, EquipmentSlot.field_6173));
    public static final Enchantment field_9098 = Enchantments.register("quick_charge", new QuickChargeEnchantment(Enchantment.Rarity.field_9090, EquipmentSlot.field_6173));
    public static final Enchantment field_9132 = Enchantments.register("piercing", new PiercingEnchantment(Enchantment.Rarity.field_9087, EquipmentSlot.field_6173));
    public static final Enchantment field_9101 = Enchantments.register("mending", new MendingEnchantment(Enchantment.Rarity.field_9088, EquipmentSlot.values()));
    public static final Enchantment field_9109 = Enchantments.register("vanishing_curse", new VanishingCurseEnchantment(Enchantment.Rarity.field_9091, EquipmentSlot.values()));

    private static Enchantment register(String string, Enchantment enchantment) {
        return Registry.register(Registries.ENCHANTMENT, string, enchantment);
    }
}


/*
 * Decompiled with CFR 0.2.1 (FabricMC 53fa44c9).
 */
package net.minecraft.screen.slot;

import net.minecraft.block.entity.AbstractFurnaceBlockEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.inventory.Inventory;
import net.minecraft.item.ItemStack;
import net.minecraft.screen.slot.Slot;
import net.minecraft.server.network.ServerPlayerEntity;

public class FurnaceOutputSlot
extends Slot {
    private final PlayerEntity player;
    private int amount;

    public FurnaceOutputSlot(PlayerEntity playerEntity, Inventory inventory, int i, int j, int k) {
        super(inventory, i, j, k);
        this.player = playerEntity;
    }

    @Override
    public boolean canInsert(ItemStack itemStack) {
        return false;
    }

    @Override
    public ItemStack takeStack(int i) {
        if (this.hasStack()) {
            this.amount += Math.min(i, this.getStack().getCount());
        }
        return super.takeStack(i);
    }

    @Override
    public void onTakeItem(PlayerEntity playerEntity, ItemStack itemStack) {
        this.onCrafted(itemStack);
        super.onTakeItem(playerEntity, itemStack);
    }

    @Override
    protected void onCrafted(ItemStack itemStack, int i) {
        this.amount += i;
        this.onCrafted(itemStack);
    }

    @Override
    protected void onCrafted(ItemStack itemStack) {
        itemStack.onCraft(this.player.getWorld(), this.player, this.amount);
        Object object = this.player;
        if (object instanceof ServerPlayerEntity) {
            ServerPlayerEntity serverPlayerEntity = (ServerPlayerEntity)object;
            object = this.inventory;
            if (object instanceof AbstractFurnaceBlockEntity) {
                AbstractFurnaceBlockEntity abstractFurnaceBlockEntity = (AbstractFurnaceBlockEntity)object;
                abstractFurnaceBlockEntity.dropExperienceForRecipesUsed(serverPlayerEntity);
            }
        }
        this.amount = 0;
    }
}


/*
 * Decompiled with CFR 0.2.1 (FabricMC 53fa44c9).
 */
package net.minecraft.block;

import net.minecraft.block.AbstractBlock;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.ChorusPlantBlock;
import net.minecraft.entity.projectile.ProjectileEntity;
import net.minecraft.registry.tag.EntityTypeTags;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.state.StateManager;
import net.minecraft.state.property.IntProperty;
import net.minecraft.state.property.Properties;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.random.Random;
import net.minecraft.world.World;
import net.minecraft.world.WorldAccess;
import net.minecraft.world.WorldView;
import org.jetbrains.annotations.Nullable;

public class ChorusFlowerBlock
extends Block {
    public static final int MAX_AGE = 5;
    public static final IntProperty AGE = Properties.AGE_5;
    private final ChorusPlantBlock plantBlock;

    public ChorusFlowerBlock(ChorusPlantBlock chorusPlantBlock, AbstractBlock.Settings settings) {
        super(settings);
        this.plantBlock = chorusPlantBlock;
        this.setDefaultState((BlockState)((BlockState)this.stateManager.getDefaultState()).with(AGE, 0));
    }

    @Override
    public void scheduledTick(BlockState blockState, ServerWorld serverWorld, BlockPos blockPos, Random random) {
        if (!blockState.canPlaceAt(serverWorld, blockPos)) {
            serverWorld.breakBlock(blockPos, true);
        }
    }

    @Override
    public boolean hasRandomTicks(BlockState blockState) {
        return blockState.get(AGE) < 5;
    }

    @Override
    public void randomTick(BlockState blockState, ServerWorld serverWorld, BlockPos blockPos, Random random) {
        int j;
        BlockPos blockPos2 = blockPos.up();
        if (!serverWorld.isAir(blockPos2) || blockPos2.getY() >= serverWorld.getTopY()) {
            return;
        }
        int i = blockState.get(AGE);
        if (i >= 5) {
            return;
        }
        boolean bl = false;
        boolean bl2 = false;
        BlockState blockState2 = serverWorld.getBlockState(blockPos.down());
        if (blockState2.isOf(Blocks.field_10471)) {
            bl = true;
        } else if (blockState2.isOf(this.plantBlock)) {
            j = 1;
            for (int k = 0; k < 4; ++k) {
                BlockState blockState3 = serverWorld.getBlockState(blockPos.down(j + 1));
                if (blockState3.isOf(this.plantBlock)) {
                    ++j;
                    continue;
                }
                if (!blockState3.isOf(Blocks.field_10471)) break;
                bl2 = true;
                break;
            }
            if (j < 2 || j <= random.nextInt(bl2 ? 5 : 4)) {
                bl = true;
            }
        } else if (blockState2.isAir()) {
            bl = true;
        }
        if (bl && ChorusFlowerBlock.isSurroundedByAir(serverWorld, blockPos2, null) && serverWorld.isAir(blockPos.up(2))) {
            serverWorld.setBlockState(blockPos, this.plantBlock.withConnectionProperties(serverWorld, blockPos), 2);
            this.grow(serverWorld, blockPos2, i);
        } else if (i < 4) {
            j = random.nextInt(4);
            if (bl2) {
                ++j;
            }
            boolean bl3 = false;
            for (int l = 0; l < j; ++l) {
                Direction direction = Direction.Type.field_11062.random(random);
                BlockPos blockPos3 = blockPos.offset(direction);
                if (!serverWorld.isAir(blockPos3) || !serverWorld.isAir(blockPos3.down()) || !ChorusFlowerBlock.isSurroundedByAir(serverWorld, blockPos3, direction.getOpposite())) continue;
                this.grow(serverWorld, blockPos3, i + 1);
                bl3 = true;
            }
            if (bl3) {
                serverWorld.setBlockState(blockPos, this.plantBlock.withConnectionProperties(serverWorld, blockPos), 2);
            } else {
                this.die(serverWorld, blockPos);
            }
        } else {
            this.die(serverWorld, blockPos);
        }
    }

    private void grow(World world, BlockPos blockPos, int i) {
        world.setBlockState(blockPos, (BlockState)this.getDefaultState().with(AGE, i), 2);
        world.syncWorldEvent(1033, blockPos, 0);
    }

    private void die(World world, BlockPos blockPos) {
        world.setBlockState(blockPos, (BlockState)this.getDefaultState().with(AGE, 5), 2);
        world.syncWorldEvent(1034, blockPos, 0);
    }

    private static boolean isSurroundedByAir(WorldView worldView, BlockPos blockPos, @Nullable Direction direction) {
        for (Direction direction2 : Direction.Type.field_11062) {
            if (direction2 == direction || worldView.isAir(blockPos.offset(direction2))) continue;
            return false;
        }
        return true;
    }

    @Override
    public BlockState getStateForNeighborUpdate(BlockState blockState, Direction direction, BlockState blockState2, WorldAccess worldAccess, BlockPos blockPos, BlockPos blockPos2) {
        if (direction != Direction.field_11036 && !blockState.canPlaceAt(worldAccess, blockPos)) {
            worldAccess.scheduleBlockTick(blockPos, this, 1);
        }
        return super.getStateForNeighborUpdate(blockState, direction, blockState2, worldAccess, blockPos, blockPos2);
    }

    @Override
    public boolean canPlaceAt(BlockState blockState, WorldView worldView, BlockPos blockPos) {
        BlockState blockState2 = worldView.getBlockState(blockPos.down());
        if (blockState2.isOf(this.plantBlock) || blockState2.isOf(Blocks.field_10471)) {
            return true;
        }
        if (!blockState2.isAir()) {
            return false;
        }
        boolean bl = false;
        for (Direction direction : Direction.Type.field_11062) {
            BlockState blockState3 = worldView.getBlockState(blockPos.offset(direction));
            if (blockState3.isOf(this.plantBlock)) {
                if (bl) {
                    return false;
                }
                bl = true;
                continue;
            }
            if (blockState3.isAir()) continue;
            return false;
        }
        return bl;
    }

    @Override
    protected void appendProperties(StateManager.Builder<Block, BlockState> builder) {
        builder.add(AGE);
    }

    public static void generate(WorldAccess worldAccess, BlockPos blockPos, Random random, int i) {
        worldAccess.setBlockState(blockPos, ((ChorusPlantBlock)Blocks.field_10021).withConnectionProperties(worldAccess, blockPos), 2);
        ChorusFlowerBlock.generate(worldAccess, blockPos, random, blockPos, i, 0);
    }

    private static void generate(WorldAccess worldAccess, BlockPos blockPos, Random random, BlockPos blockPos2, int i, int j) {
        ChorusPlantBlock chorusPlantBlock = (ChorusPlantBlock)Blocks.field_10021;
        int k = random.nextInt(4) + 1;
        if (j == 0) {
            ++k;
        }
        for (int l = 0; l < k; ++l) {
            BlockPos blockPos3 = blockPos.up(l + 1);
            if (!ChorusFlowerBlock.isSurroundedByAir(worldAccess, blockPos3, null)) {
                return;
            }
            worldAccess.setBlockState(blockPos3, chorusPlantBlock.withConnectionProperties(worldAccess, blockPos3), 2);
            worldAccess.setBlockState(blockPos3.down(), chorusPlantBlock.withConnectionProperties(worldAccess, blockPos3.down()), 2);
        }
        boolean bl = false;
        if (j < 4) {
            int m = random.nextInt(4);
            if (j == 0) {
                ++m;
            }
            for (int n = 0; n < m; ++n) {
                Direction direction = Direction.Type.field_11062.random(random);
                BlockPos blockPos4 = blockPos.up(k).offset(direction);
                if (Math.abs(blockPos4.getX() - blockPos2.getX()) >= i || Math.abs(blockPos4.getZ() - blockPos2.getZ()) >= i || !worldAccess.isAir(blockPos4) || !worldAccess.isAir(blockPos4.down()) || !ChorusFlowerBlock.isSurroundedByAir(worldAccess, blockPos4, direction.getOpposite())) continue;
                bl = true;
                worldAccess.setBlockState(blockPos4, chorusPlantBlock.withConnectionProperties(worldAccess, blockPos4), 2);
                worldAccess.setBlockState(blockPos4.offset(direction.getOpposite()), chorusPlantBlock.withConnectionProperties(worldAccess, blockPos4.offset(direction.getOpposite())), 2);
                ChorusFlowerBlock.generate(worldAccess, blockPos4, random, blockPos2, i, j + 1);
            }
        }
        if (!bl) {
            worldAccess.setBlockState(blockPos.up(k), (BlockState)Blocks.field_10528.getDefaultState().with(AGE, 5), 2);
        }
    }

    @Override
    public void onProjectileHit(World world, BlockState blockState, BlockHitResult blockHitResult, ProjectileEntity projectileEntity) {
        BlockPos blockPos = blockHitResult.getBlockPos();
        if (!world.isClient && projectileEntity.canModifyAt(world, blockPos) && projectileEntity.getType().isIn(EntityTypeTags.field_22415)) {
            world.breakBlock(blockPos, true, projectileEntity);
        }
    }
}


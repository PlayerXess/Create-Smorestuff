/*
 * Decompiled with CFR 0.2.1 (FabricMC 53fa44c9).
 */
package net.minecraft.enchantment;

import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.FrostedIceBlock;
import net.minecraft.block.ShapeContext;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.enchantment.EnchantmentTarget;
import net.minecraft.enchantment.Enchantments;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.world.World;

public class FrostWalkerEnchantment
extends Enchantment {
    public FrostWalkerEnchantment(Enchantment.Rarity rarity, EquipmentSlot ... equipmentSlots) {
        super(rarity, EnchantmentTarget.field_9079, equipmentSlots);
    }

    @Override
    public int getMinPower(int i) {
        return i * 10;
    }

    @Override
    public int getMaxPower(int i) {
        return this.getMinPower(i) + 15;
    }

    @Override
    public boolean isTreasure() {
        return true;
    }

    @Override
    public int getMaxLevel() {
        return 2;
    }

    public static void freezeWater(LivingEntity livingEntity, World world, BlockPos blockPos, int i) {
        if (!livingEntity.isOnGround()) {
            return;
        }
        BlockState blockState = Blocks.field_10110.getDefaultState();
        int j = Math.min(16, 2 + i);
        BlockPos.Mutable mutable = new BlockPos.Mutable();
        for (BlockPos blockPos2 : BlockPos.iterate(blockPos.add(-j, -1, -j), blockPos.add(j, -1, j))) {
            BlockState blockState3;
            if (!blockPos2.isWithinDistance(livingEntity.getPos(), (double)j)) continue;
            mutable.set(blockPos2.getX(), blockPos2.getY() + 1, blockPos2.getZ());
            BlockState blockState2 = world.getBlockState(mutable);
            if (!blockState2.isAir() || (blockState3 = world.getBlockState(blockPos2)) != FrostedIceBlock.getMeltedState() || !blockState.canPlaceAt(world, blockPos2) || !world.canPlace(blockState, blockPos2, ShapeContext.absent())) continue;
            world.setBlockState(blockPos2, blockState);
            world.scheduleBlockTick(blockPos2, Blocks.field_10110, MathHelper.nextInt(livingEntity.getRandom(), 60, 120));
        }
    }

    @Override
    public boolean canAccept(Enchantment enchantment) {
        return super.canAccept(enchantment) && enchantment != Enchantments.field_9128;
    }
}


/*
 * Decompiled with CFR 0.2.1 (FabricMC 53fa44c9).
 */
package net.minecraft.util;

import com.google.common.collect.Lists;
import com.mojang.serialization.Codec;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Locale;
import java.util.Map;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import net.minecraft.util.StringIdentifiable;
import org.jetbrains.annotations.Nullable;

public enum Formatting implements StringIdentifiable
{
    field_1074("BLACK", '0', 0, 0),
    field_1058("DARK_BLUE", '1', 1, 170),
    field_1077("DARK_GREEN", '2', 2, 43520),
    field_1062("DARK_AQUA", '3', 3, 43690),
    field_1079("DARK_RED", '4', 4, 0xAA0000),
    field_1064("DARK_PURPLE", '5', 5, 0xAA00AA),
    field_1065("GOLD", '6', 6, 0xFFAA00),
    field_1080("GRAY", '7', 7, 0xAAAAAA),
    field_1063("DARK_GRAY", '8', 8, 0x555555),
    field_1078("BLUE", '9', 9, 0x5555FF),
    field_1060("GREEN", 'a', 10, 0x55FF55),
    field_1075("AQUA", 'b', 11, 0x55FFFF),
    field_1061("RED", 'c', 12, 0xFF5555),
    field_1076("LIGHT_PURPLE", 'd', 13, 0xFF55FF),
    field_1054("YELLOW", 'e', 14, 0xFFFF55),
    field_1068("WHITE", 'f', 15, 0xFFFFFF),
    field_1051("OBFUSCATED", 'k', true),
    field_1067("BOLD", 'l', true),
    field_1055("STRIKETHROUGH", 'm', true),
    field_1073("UNDERLINE", 'n', true),
    field_1056("ITALIC", 'o', true),
    field_1070("RESET", 'r', -1, null);

    public static final Codec<Formatting> CODEC;
    public static final char FORMATTING_CODE_PREFIX = '\u00a7';
    private static final Map<String, Formatting> BY_NAME;
    private static final Pattern FORMATTING_CODE_PATTERN;
    private final String name;
    private final char code;
    private final boolean modifier;
    private final String stringValue;
    private final int colorIndex;
    @Nullable
    private final Integer colorValue;

    private static String sanitize(String string) {
        return string.toLowerCase(Locale.ROOT).replaceAll("[^a-z]", "");
    }

    private Formatting(String string2, @Nullable char c, int j, Integer integer) {
        this(string2, c, false, j, integer);
    }

    private Formatting(String string2, char c, boolean bl) {
        this(string2, c, bl, -1, null);
    }

    private Formatting(String string2, char c, @Nullable boolean bl, int j, Integer integer) {
        this.name = string2;
        this.code = c;
        this.modifier = bl;
        this.colorIndex = j;
        this.colorValue = integer;
        this.stringValue = "\u00a7" + c;
    }

    public char getCode() {
        return this.code;
    }

    public int getColorIndex() {
        return this.colorIndex;
    }

    public boolean isModifier() {
        return this.modifier;
    }

    public boolean isColor() {
        return !this.modifier && this != field_1070;
    }

    @Nullable
    public Integer getColorValue() {
        return this.colorValue;
    }

    public String getName() {
        return this.name().toLowerCase(Locale.ROOT);
    }

    public String toString() {
        return this.stringValue;
    }

    @Nullable
    public static String strip(@Nullable String string) {
        return string == null ? null : FORMATTING_CODE_PATTERN.matcher(string).replaceAll("");
    }

    @Nullable
    public static Formatting byName(@Nullable String string) {
        if (string == null) {
            return null;
        }
        return BY_NAME.get(Formatting.sanitize(string));
    }

    @Nullable
    public static Formatting byColorIndex(int i) {
        if (i < 0) {
            return field_1070;
        }
        for (Formatting formatting : Formatting.values()) {
            if (formatting.getColorIndex() != i) continue;
            return formatting;
        }
        return null;
    }

    @Nullable
    public static Formatting byCode(char c) {
        char d = Character.toString(c).toLowerCase(Locale.ROOT).charAt(0);
        for (Formatting formatting : Formatting.values()) {
            if (formatting.code != d) continue;
            return formatting;
        }
        return null;
    }

    public static Collection<String> getNames(boolean bl, boolean bl2) {
        ArrayList<String> list = Lists.newArrayList();
        for (Formatting formatting : Formatting.values()) {
            if (formatting.isColor() && !bl || formatting.isModifier() && !bl2) continue;
            list.add(formatting.getName());
        }
        return list;
    }

    @Override
    public String asString() {
        return this.getName();
    }

    static {
        CODEC = StringIdentifiable.createCodec(Formatting::values);
        BY_NAME = Arrays.stream(Formatting.values()).collect(Collectors.toMap(formatting -> Formatting.sanitize(formatting.name), formatting -> formatting));
        FORMATTING_CODE_PATTERN = Pattern.compile("(?i)\u00a7[0-9A-FK-OR]");
    }
}


/*
 * Decompiled with CFR 0.2.1 (FabricMC 53fa44c9).
 */
package net.minecraft.potion;

import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.potion.Potion;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.util.Identifier;

public class Potions {
    public static RegistryKey<Potion> EMPTY_KEY = RegistryKey.of(RegistryKeys.field_41215, new Identifier("empty"));
    public static final Potion EMPTY = Potions.register(EMPTY_KEY, new Potion(new StatusEffectInstance[0]));
    public static final Potion field_8991 = Potions.register("water", new Potion(new StatusEffectInstance[0]));
    public static final Potion field_8967 = Potions.register("mundane", new Potion(new StatusEffectInstance[0]));
    public static final Potion field_8985 = Potions.register("thick", new Potion(new StatusEffectInstance[0]));
    public static final Potion field_8999 = Potions.register("awkward", new Potion(new StatusEffectInstance[0]));
    public static final Potion field_8968 = Potions.register("night_vision", new Potion(new StatusEffectInstance(StatusEffects.field_5925, 3600)));
    public static final Potion field_8981 = Potions.register("long_night_vision", new Potion("night_vision", new StatusEffectInstance(StatusEffects.field_5925, 9600)));
    public static final Potion field_8997 = Potions.register("invisibility", new Potion(new StatusEffectInstance(StatusEffects.field_5905, 3600)));
    public static final Potion field_9000 = Potions.register("long_invisibility", new Potion("invisibility", new StatusEffectInstance(StatusEffects.field_5905, 9600)));
    public static final Potion field_8979 = Potions.register("leaping", new Potion(new StatusEffectInstance(StatusEffects.field_5913, 3600)));
    public static final Potion field_8971 = Potions.register("long_leaping", new Potion("leaping", new StatusEffectInstance(StatusEffects.field_5913, 9600)));
    public static final Potion field_8998 = Potions.register("strong_leaping", new Potion("leaping", new StatusEffectInstance(StatusEffects.field_5913, 1800, 1)));
    public static final Potion field_8987 = Potions.register("fire_resistance", new Potion(new StatusEffectInstance(StatusEffects.field_5918, 3600)));
    public static final Potion field_8969 = Potions.register("long_fire_resistance", new Potion("fire_resistance", new StatusEffectInstance(StatusEffects.field_5918, 9600)));
    public static final Potion field_9005 = Potions.register("swiftness", new Potion(new StatusEffectInstance(StatusEffects.field_5904, 3600)));
    public static final Potion field_8983 = Potions.register("long_swiftness", new Potion("swiftness", new StatusEffectInstance(StatusEffects.field_5904, 9600)));
    public static final Potion field_8966 = Potions.register("strong_swiftness", new Potion("swiftness", new StatusEffectInstance(StatusEffects.field_5904, 1800, 1)));
    public static final Potion field_8996 = Potions.register("slowness", new Potion(new StatusEffectInstance(StatusEffects.field_5909, 1800)));
    public static final Potion field_8989 = Potions.register("long_slowness", new Potion("slowness", new StatusEffectInstance(StatusEffects.field_5909, 4800)));
    public static final Potion field_8976 = Potions.register("strong_slowness", new Potion("slowness", new StatusEffectInstance(StatusEffects.field_5909, 400, 3)));
    public static final Potion field_8990 = Potions.register("turtle_master", new Potion("turtle_master", new StatusEffectInstance(StatusEffects.field_5909, 400, 3), new StatusEffectInstance(StatusEffects.field_5907, 400, 2)));
    public static final Potion field_8988 = Potions.register("long_turtle_master", new Potion("turtle_master", new StatusEffectInstance(StatusEffects.field_5909, 800, 3), new StatusEffectInstance(StatusEffects.field_5907, 800, 2)));
    public static final Potion field_8977 = Potions.register("strong_turtle_master", new Potion("turtle_master", new StatusEffectInstance(StatusEffects.field_5909, 400, 5), new StatusEffectInstance(StatusEffects.field_5907, 400, 3)));
    public static final Potion field_8994 = Potions.register("water_breathing", new Potion(new StatusEffectInstance(StatusEffects.field_5923, 3600)));
    public static final Potion field_9001 = Potions.register("long_water_breathing", new Potion("water_breathing", new StatusEffectInstance(StatusEffects.field_5923, 9600)));
    public static final Potion field_8963 = Potions.register("healing", new Potion(new StatusEffectInstance(StatusEffects.field_5915, 1)));
    public static final Potion field_8980 = Potions.register("strong_healing", new Potion("healing", new StatusEffectInstance(StatusEffects.field_5915, 1, 1)));
    public static final Potion field_9004 = Potions.register("harming", new Potion(new StatusEffectInstance(StatusEffects.field_5921, 1)));
    public static final Potion field_8973 = Potions.register("strong_harming", new Potion("harming", new StatusEffectInstance(StatusEffects.field_5921, 1, 1)));
    public static final Potion field_8982 = Potions.register("poison", new Potion(new StatusEffectInstance(StatusEffects.field_5899, 900)));
    public static final Potion field_9002 = Potions.register("long_poison", new Potion("poison", new StatusEffectInstance(StatusEffects.field_5899, 1800)));
    public static final Potion field_8972 = Potions.register("strong_poison", new Potion("poison", new StatusEffectInstance(StatusEffects.field_5899, 432, 1)));
    public static final Potion field_8986 = Potions.register("regeneration", new Potion(new StatusEffectInstance(StatusEffects.field_5924, 900)));
    public static final Potion field_9003 = Potions.register("long_regeneration", new Potion("regeneration", new StatusEffectInstance(StatusEffects.field_5924, 1800)));
    public static final Potion field_8992 = Potions.register("strong_regeneration", new Potion("regeneration", new StatusEffectInstance(StatusEffects.field_5924, 450, 1)));
    public static final Potion field_8978 = Potions.register("strength", new Potion(new StatusEffectInstance(StatusEffects.field_5910, 3600)));
    public static final Potion field_8965 = Potions.register("long_strength", new Potion("strength", new StatusEffectInstance(StatusEffects.field_5910, 9600)));
    public static final Potion field_8993 = Potions.register("strong_strength", new Potion("strength", new StatusEffectInstance(StatusEffects.field_5910, 1800, 1)));
    public static final Potion field_8975 = Potions.register("weakness", new Potion(new StatusEffectInstance(StatusEffects.field_5911, 1800)));
    public static final Potion field_8970 = Potions.register("long_weakness", new Potion("weakness", new StatusEffectInstance(StatusEffects.field_5911, 4800)));
    public static final Potion field_8995 = Potions.register("luck", new Potion("luck", new StatusEffectInstance(StatusEffects.field_5926, 6000)));
    public static final Potion field_8974 = Potions.register("slow_falling", new Potion(new StatusEffectInstance(StatusEffects.field_5906, 1800)));
    public static final Potion field_8964 = Potions.register("long_slow_falling", new Potion("slow_falling", new StatusEffectInstance(StatusEffects.field_5906, 4800)));

    private static Potion register(String string, Potion potion) {
        return Registry.register(Registries.POTION, string, potion);
    }

    private static Potion register(RegistryKey<Potion> registryKey, Potion potion) {
        return Registry.register(Registries.POTION, registryKey, potion);
    }
}


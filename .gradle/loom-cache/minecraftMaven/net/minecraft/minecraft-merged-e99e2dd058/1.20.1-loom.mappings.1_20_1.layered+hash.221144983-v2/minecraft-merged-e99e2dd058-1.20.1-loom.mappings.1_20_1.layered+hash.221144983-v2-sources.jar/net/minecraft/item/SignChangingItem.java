/*
 * Decompiled with CFR 0.2.1 (FabricMC 53fa44c9).
 */
package net.minecraft.item;

import net.minecraft.block.entity.SignBlockEntity;
import net.minecraft.block.entity.SignText;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.world.World;

public interface SignChangingItem {
    public boolean useOnSign(World var1, SignBlockEntity var2, boolean var3, PlayerEntity var4);

    default public boolean canUseOnSignText(SignText signText, PlayerEntity playerEntity) {
        return signText.hasText(playerEntity);
    }
}


/*
 * Decompiled with CFR 0.2.1 (FabricMC 53fa44c9).
 */
package net.minecraft.item;

import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.DeadCoralWallFanBlock;
import net.minecraft.block.Fertilizable;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemUsageContext;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.registry.Registries;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.registry.tag.BiomeTags;
import net.minecraft.registry.tag.BlockTags;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.ActionResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.random.Random;
import net.minecraft.world.World;
import net.minecraft.world.WorldAccess;
import net.minecraft.world.biome.Biome;
import org.jetbrains.annotations.Nullable;

public class BoneMealItem
extends Item {
    public static final int field_30851 = 3;
    public static final int field_30852 = 1;
    public static final int field_30853 = 3;

    public BoneMealItem(Item.Settings settings) {
        super(settings);
    }

    @Override
    public ActionResult useOnBlock(ItemUsageContext itemUsageContext) {
        World world = itemUsageContext.getWorld();
        BlockPos blockPos = itemUsageContext.getBlockPos();
        BlockPos blockPos2 = blockPos.offset(itemUsageContext.getSide());
        if (BoneMealItem.useOnFertilizable(itemUsageContext.getStack(), world, blockPos)) {
            if (!world.isClient) {
                world.syncWorldEvent(1505, blockPos, 0);
            }
            return ActionResult.success(world.isClient);
        }
        BlockState blockState = world.getBlockState(blockPos);
        boolean bl = blockState.isSideSolidFullSquare(world, blockPos, itemUsageContext.getSide());
        if (bl && BoneMealItem.useOnGround(itemUsageContext.getStack(), world, blockPos2, itemUsageContext.getSide())) {
            if (!world.isClient) {
                world.syncWorldEvent(1505, blockPos2, 0);
            }
            return ActionResult.success(world.isClient);
        }
        return ActionResult.PASS;
    }

    public static boolean useOnFertilizable(ItemStack itemStack, World world, BlockPos blockPos) {
        Fertilizable fertilizable;
        BlockState blockState = world.getBlockState(blockPos);
        if (blockState.getBlock() instanceof Fertilizable && (fertilizable = (Fertilizable)((Object)blockState.getBlock())).isFertilizable(world, blockPos, blockState, world.isClient)) {
            if (world instanceof ServerWorld) {
                if (fertilizable.canGrow(world, world.random, blockPos, blockState)) {
                    fertilizable.grow((ServerWorld)world, world.random, blockPos, blockState);
                }
                itemStack.decrement(1);
            }
            return true;
        }
        return false;
    }

    public static boolean useOnGround(ItemStack itemStack, World world, BlockPos blockPos, @Nullable Direction direction) {
        if (!world.getBlockState(blockPos).isOf(Blocks.field_10382) || world.getFluidState(blockPos).getLevel() != 8) {
            return false;
        }
        if (!(world instanceof ServerWorld)) {
            return true;
        }
        Random random = world.getRandom();
        block0: for (int i = 0; i < 128; ++i) {
            BlockPos blockPos2 = blockPos;
            BlockState blockState = Blocks.field_10376.getDefaultState();
            for (int j = 0; j < i / 16; ++j) {
                if (world.getBlockState(blockPos2 = blockPos2.add(random.nextInt(3) - 1, (random.nextInt(3) - 1) * random.nextInt(3) / 2, random.nextInt(3) - 1)).isFullCube(world, blockPos2)) continue block0;
            }
            RegistryEntry<Biome> registryEntry2 = world.getBiome(blockPos2);
            if (registryEntry2.isIn(BiomeTags.field_37380)) {
                if (i == 0 && direction != null && direction.getAxis().isHorizontal()) {
                    blockState = Registries.BLOCK.getEntryList(BlockTags.field_15476).flatMap(named -> named.getRandom(world.random)).map(registryEntry -> ((Block)registryEntry.comp_349()).getDefaultState()).orElse(blockState);
                    if (blockState.contains(DeadCoralWallFanBlock.FACING)) {
                        blockState = (BlockState)blockState.with(DeadCoralWallFanBlock.FACING, direction);
                    }
                } else if (random.nextInt(4) == 0) {
                    blockState = Registries.BLOCK.getEntryList(BlockTags.field_15496).flatMap(named -> named.getRandom(world.random)).map(registryEntry -> ((Block)registryEntry.comp_349()).getDefaultState()).orElse(blockState);
                }
            }
            if (blockState.isIn(BlockTags.field_15476, abstractBlockState -> abstractBlockState.contains(DeadCoralWallFanBlock.FACING))) {
                for (int k = 0; !blockState.canPlaceAt(world, blockPos2) && k < 4; ++k) {
                    blockState = (BlockState)blockState.with(DeadCoralWallFanBlock.FACING, Direction.Type.field_11062.random(random));
                }
            }
            if (!blockState.canPlaceAt(world, blockPos2)) continue;
            BlockState blockState2 = world.getBlockState(blockPos2);
            if (blockState2.isOf(Blocks.field_10382) && world.getFluidState(blockPos2).getLevel() == 8) {
                world.setBlockState(blockPos2, blockState, 3);
                continue;
            }
            if (!blockState2.isOf(Blocks.field_10376) || random.nextInt(10) != 0) continue;
            ((Fertilizable)((Object)Blocks.field_10376)).grow((ServerWorld)world, random, blockPos2, blockState2);
        }
        itemStack.decrement(1);
        return true;
    }

    public static void createParticles(WorldAccess worldAccess, BlockPos blockPos, int i) {
        double e;
        BlockState blockState;
        if (i == 0) {
            i = 15;
        }
        if ((blockState = worldAccess.getBlockState(blockPos)).isAir()) {
            return;
        }
        double d = 0.5;
        if (blockState.isOf(Blocks.field_10382)) {
            i *= 3;
            e = 1.0;
            d = 3.0;
        } else if (blockState.isOpaqueFullCube(worldAccess, blockPos)) {
            blockPos = blockPos.up();
            i *= 3;
            d = 3.0;
            e = 1.0;
        } else {
            e = blockState.getOutlineShape(worldAccess, blockPos).getMax(Direction.Axis.field_11052);
        }
        worldAccess.addParticle(ParticleTypes.field_11211, (double)blockPos.getX() + 0.5, (double)blockPos.getY() + 0.5, (double)blockPos.getZ() + 0.5, 0.0, 0.0, 0.0);
        Random random = worldAccess.getRandom();
        for (int j = 0; j < i; ++j) {
            double n;
            double m;
            double f = random.nextGaussian() * 0.02;
            double g = random.nextGaussian() * 0.02;
            double h = random.nextGaussian() * 0.02;
            double k = 0.5 - d;
            double l = (double)blockPos.getX() + k + random.nextDouble() * d * 2.0;
            if (worldAccess.getBlockState(BlockPos.ofFloored(l, m = (double)blockPos.getY() + random.nextDouble() * e, n = (double)blockPos.getZ() + k + random.nextDouble() * d * 2.0).down()).isAir()) continue;
            worldAccess.addParticle(ParticleTypes.field_11211, l, m, n, f, g, h);
        }
    }
}


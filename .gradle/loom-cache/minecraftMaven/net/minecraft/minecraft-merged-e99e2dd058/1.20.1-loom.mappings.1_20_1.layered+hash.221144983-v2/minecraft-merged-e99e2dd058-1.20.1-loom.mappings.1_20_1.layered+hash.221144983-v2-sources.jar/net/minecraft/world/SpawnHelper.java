/*
 * Decompiled with CFR 0.2.1 (FabricMC 53fa44c9).
 */
package net.minecraft.world;

import com.mojang.logging.LogUtils;
import it.unimi.dsi.fastutil.objects.Object2IntMap;
import it.unimi.dsi.fastutil.objects.Object2IntMaps;
import it.unimi.dsi.fastutil.objects.Object2IntOpenHashMap;
import java.util.Objects;
import java.util.Optional;
import java.util.function.Consumer;
import java.util.stream.Stream;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityData;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnGroup;
import net.minecraft.entity.SpawnReason;
import net.minecraft.entity.SpawnRestriction;
import net.minecraft.entity.ai.pathing.NavigationType;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.fluid.FluidState;
import net.minecraft.registry.Registries;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.registry.tag.BiomeTags;
import net.minecraft.registry.tag.BlockTags;
import net.minecraft.registry.tag.FluidTags;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.annotation.Debug;
import net.minecraft.util.collection.Pool;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.GravityField;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.math.Vec3i;
import net.minecraft.util.math.random.Random;
import net.minecraft.world.BlockView;
import net.minecraft.world.Heightmap;
import net.minecraft.world.ServerWorldAccess;
import net.minecraft.world.SpawnDensityCapper;
import net.minecraft.world.World;
import net.minecraft.world.WorldView;
import net.minecraft.world.biome.Biome;
import net.minecraft.world.biome.SpawnSettings;
import net.minecraft.world.biome.source.BiomeCoords;
import net.minecraft.world.chunk.Chunk;
import net.minecraft.world.chunk.WorldChunk;
import net.minecraft.world.gen.StructureAccessor;
import net.minecraft.world.gen.chunk.ChunkGenerator;
import net.minecraft.world.gen.structure.NetherFortressStructure;
import net.minecraft.world.gen.structure.Structure;
import net.minecraft.world.gen.structure.StructureKeys;
import org.jetbrains.annotations.Nullable;
import org.slf4j.Logger;

public final class SpawnHelper {
    private static final Logger LOGGER = LogUtils.getLogger();
    private static final int MIN_SPAWN_DISTANCE = 24;
    public static final int field_30972 = 8;
    public static final int field_30973 = 128;
    static final int CHUNK_AREA = (int)Math.pow(17.0, 2.0);
    private static final SpawnGroup[] SPAWNABLE_GROUPS = (SpawnGroup[])Stream.of(SpawnGroup.values()).filter(spawnGroup -> spawnGroup != SpawnGroup.field_17715).toArray(SpawnGroup[]::new);

    private SpawnHelper() {
    }

    public static Info setupSpawn(int i, Iterable<Entity> iterable, ChunkSource chunkSource, SpawnDensityCapper spawnDensityCapper) {
        GravityField gravityField = new GravityField();
        Object2IntOpenHashMap<SpawnGroup> object2IntOpenHashMap = new Object2IntOpenHashMap<SpawnGroup>();
        for (Entity entity : iterable) {
            SpawnGroup spawnGroup;
            MobEntity mobEntity;
            if (entity instanceof MobEntity && ((mobEntity = (MobEntity)entity).isPersistent() || mobEntity.cannotDespawn()) || (spawnGroup = entity.getType().getSpawnGroup()) == SpawnGroup.field_17715) continue;
            BlockPos blockPos = entity.getBlockPos();
            chunkSource.query(ChunkPos.toLong(blockPos), worldChunk -> {
                SpawnSettings.SpawnDensity spawnDensity = SpawnHelper.getBiomeDirectly(blockPos, worldChunk).getSpawnSettings().getSpawnDensity(entity.getType());
                if (spawnDensity != null) {
                    gravityField.addPoint(entity.getBlockPos(), spawnDensity.mass());
                }
                if (entity instanceof MobEntity) {
                    spawnDensityCapper.increaseDensity(worldChunk.getPos(), spawnGroup);
                }
                object2IntOpenHashMap.addTo(spawnGroup, 1);
            });
        }
        return new Info(i, object2IntOpenHashMap, gravityField, spawnDensityCapper);
    }

    static Biome getBiomeDirectly(BlockPos blockPos, Chunk chunk) {
        return chunk.getBiomeForNoiseGen(BiomeCoords.fromBlock(blockPos.getX()), BiomeCoords.fromBlock(blockPos.getY()), BiomeCoords.fromBlock(blockPos.getZ())).comp_349();
    }

    public static void spawn(ServerWorld serverWorld, WorldChunk worldChunk, Info info, boolean bl, boolean bl2, boolean bl3) {
        serverWorld.getProfiler().push("spawner");
        for (SpawnGroup spawnGroup : SPAWNABLE_GROUPS) {
            if (!bl && spawnGroup.isPeaceful() || !bl2 && !spawnGroup.isPeaceful() || !bl3 && spawnGroup.isRare() || !info.isBelowCap(spawnGroup, worldChunk.getPos())) continue;
            SpawnHelper.spawnEntitiesInChunk(spawnGroup, serverWorld, worldChunk, info::test, info::run);
        }
        serverWorld.getProfiler().pop();
    }

    public static void spawnEntitiesInChunk(SpawnGroup spawnGroup, ServerWorld serverWorld, WorldChunk worldChunk, Checker checker, Runner runner) {
        BlockPos blockPos = SpawnHelper.getRandomPosInChunkSection(serverWorld, worldChunk);
        if (blockPos.getY() < serverWorld.getBottomY() + 1) {
            return;
        }
        SpawnHelper.spawnEntitiesInChunk(spawnGroup, serverWorld, worldChunk, blockPos, checker, runner);
    }

    @Debug
    public static void spawnEntitiesInChunk(SpawnGroup spawnGroup, ServerWorld serverWorld, BlockPos blockPos2) {
        SpawnHelper.spawnEntitiesInChunk(spawnGroup, serverWorld, serverWorld.getChunk(blockPos2), blockPos2, (entityType, blockPos, chunk) -> true, (mobEntity, chunk) -> {});
    }

    public static void spawnEntitiesInChunk(SpawnGroup spawnGroup, ServerWorld serverWorld, Chunk chunk, BlockPos blockPos, Checker checker, Runner runner) {
        StructureAccessor structureAccessor = serverWorld.getStructureAccessor();
        ChunkGenerator chunkGenerator = serverWorld.getChunkManager().getChunkGenerator();
        int i = blockPos.getY();
        BlockState blockState = chunk.getBlockState(blockPos);
        if (blockState.isSolidBlock(chunk, blockPos)) {
            return;
        }
        BlockPos.Mutable mutable = new BlockPos.Mutable();
        int j = 0;
        block0: for (int k = 0; k < 3; ++k) {
            int l = blockPos.getX();
            int m = blockPos.getZ();
            int n = 6;
            SpawnSettings.SpawnEntry spawnEntry = null;
            EntityData entityData = null;
            int o = MathHelper.ceil(serverWorld.random.nextFloat() * 4.0f);
            int p = 0;
            for (int q = 0; q < o; ++q) {
                double f;
                mutable.set(l += serverWorld.random.nextInt(6) - serverWorld.random.nextInt(6), i, m += serverWorld.random.nextInt(6) - serverWorld.random.nextInt(6));
                double d = (double)l + 0.5;
                double e = (double)m + 0.5;
                PlayerEntity playerEntity = serverWorld.getClosestPlayer(d, (double)i, e, -1.0, false);
                if (playerEntity == null || !SpawnHelper.isAcceptableSpawnPosition(serverWorld, chunk, mutable, f = playerEntity.squaredDistanceTo(d, i, e))) continue;
                if (spawnEntry == null) {
                    Optional<SpawnSettings.SpawnEntry> optional = SpawnHelper.pickRandomSpawnEntry(serverWorld, structureAccessor, chunkGenerator, spawnGroup, serverWorld.random, mutable);
                    if (optional.isEmpty()) continue block0;
                    spawnEntry = optional.get();
                    o = spawnEntry.minGroupSize + serverWorld.random.nextInt(1 + spawnEntry.maxGroupSize - spawnEntry.minGroupSize);
                }
                if (!SpawnHelper.canSpawn(serverWorld, spawnGroup, structureAccessor, chunkGenerator, spawnEntry, mutable, f) || !checker.test(spawnEntry.type, mutable, chunk)) continue;
                MobEntity mobEntity = SpawnHelper.createMob(serverWorld, spawnEntry.type);
                if (mobEntity == null) {
                    return;
                }
                mobEntity.refreshPositionAndAngles(d, i, e, serverWorld.random.nextFloat() * 360.0f, 0.0f);
                if (!SpawnHelper.isValidSpawn(serverWorld, mobEntity, f)) continue;
                entityData = mobEntity.initialize(serverWorld, serverWorld.getLocalDifficulty(mobEntity.getBlockPos()), SpawnReason.field_16459, entityData, null);
                ++p;
                serverWorld.spawnEntityAndPassengers(mobEntity);
                runner.run(mobEntity, chunk);
                if (++j >= mobEntity.getLimitPerChunk()) {
                    return;
                }
                if (mobEntity.spawnsTooManyForEachTry(p)) continue block0;
            }
        }
    }

    private static boolean isAcceptableSpawnPosition(ServerWorld serverWorld, Chunk chunk, BlockPos.Mutable mutable, double d) {
        if (d <= 576.0) {
            return false;
        }
        if (serverWorld.getSpawnPos().isWithinDistance(new Vec3d((double)mutable.getX() + 0.5, mutable.getY(), (double)mutable.getZ() + 0.5), 24.0)) {
            return false;
        }
        return Objects.equals(new ChunkPos(mutable), chunk.getPos()) || serverWorld.shouldTick(mutable);
    }

    private static boolean canSpawn(ServerWorld serverWorld, SpawnGroup spawnGroup, StructureAccessor structureAccessor, ChunkGenerator chunkGenerator, SpawnSettings.SpawnEntry spawnEntry, BlockPos.Mutable mutable, double d) {
        EntityType<?> entityType = spawnEntry.type;
        if (entityType.getSpawnGroup() == SpawnGroup.field_17715) {
            return false;
        }
        if (!entityType.isSpawnableFarFromPlayer() && d > (double)(entityType.getSpawnGroup().getImmediateDespawnRange() * entityType.getSpawnGroup().getImmediateDespawnRange())) {
            return false;
        }
        if (!entityType.isSummonable() || !SpawnHelper.containsSpawnEntry(serverWorld, structureAccessor, chunkGenerator, spawnGroup, spawnEntry, mutable)) {
            return false;
        }
        SpawnRestriction.Location location = SpawnRestriction.getLocation(entityType);
        if (!SpawnHelper.canSpawn(location, serverWorld, mutable, entityType)) {
            return false;
        }
        if (!SpawnRestriction.canSpawn(entityType, serverWorld, SpawnReason.field_16459, mutable, serverWorld.random)) {
            return false;
        }
        return serverWorld.isSpaceEmpty(entityType.createSimpleBoundingBox((double)mutable.getX() + 0.5, mutable.getY(), (double)mutable.getZ() + 0.5));
    }

    @Nullable
    private static MobEntity createMob(ServerWorld serverWorld, EntityType<?> entityType) {
        try {
            Object obj = entityType.create(serverWorld);
            if (obj instanceof MobEntity) {
                MobEntity mobEntity = (MobEntity)obj;
                return mobEntity;
            }
            LOGGER.warn("Can't spawn entity of type: {}", (Object)Registries.ENTITY_TYPE.getId(entityType));
        } catch (Exception exception) {
            LOGGER.warn("Failed to create mob", exception);
        }
        return null;
    }

    private static boolean isValidSpawn(ServerWorld serverWorld, MobEntity mobEntity, double d) {
        if (d > (double)(mobEntity.getType().getSpawnGroup().getImmediateDespawnRange() * mobEntity.getType().getSpawnGroup().getImmediateDespawnRange()) && mobEntity.canImmediatelyDespawn(d)) {
            return false;
        }
        return mobEntity.canSpawn(serverWorld, SpawnReason.field_16459) && mobEntity.canSpawn(serverWorld);
    }

    private static Optional<SpawnSettings.SpawnEntry> pickRandomSpawnEntry(ServerWorld serverWorld, StructureAccessor structureAccessor, ChunkGenerator chunkGenerator, SpawnGroup spawnGroup, Random random, BlockPos blockPos) {
        RegistryEntry<Biome> registryEntry = serverWorld.getBiome(blockPos);
        if (spawnGroup == SpawnGroup.field_24460 && registryEntry.isIn(BiomeTags.field_37387) && random.nextFloat() < 0.98f) {
            return Optional.empty();
        }
        return SpawnHelper.getSpawnEntries(serverWorld, structureAccessor, chunkGenerator, spawnGroup, blockPos, registryEntry).getOrEmpty(random);
    }

    private static boolean containsSpawnEntry(ServerWorld serverWorld, StructureAccessor structureAccessor, ChunkGenerator chunkGenerator, SpawnGroup spawnGroup, SpawnSettings.SpawnEntry spawnEntry, BlockPos blockPos) {
        return SpawnHelper.getSpawnEntries(serverWorld, structureAccessor, chunkGenerator, spawnGroup, blockPos, null).getEntries().contains(spawnEntry);
    }

    private static Pool<SpawnSettings.SpawnEntry> getSpawnEntries(ServerWorld serverWorld, StructureAccessor structureAccessor, ChunkGenerator chunkGenerator, SpawnGroup spawnGroup, BlockPos blockPos, @Nullable RegistryEntry<Biome> registryEntry) {
        if (SpawnHelper.shouldUseNetherFortressSpawns(blockPos, serverWorld, spawnGroup, structureAccessor)) {
            return NetherFortressStructure.MONSTER_SPAWNS;
        }
        return chunkGenerator.getEntitySpawnList(registryEntry != null ? registryEntry : serverWorld.getBiome(blockPos), structureAccessor, spawnGroup, blockPos);
    }

    public static boolean shouldUseNetherFortressSpawns(BlockPos blockPos, ServerWorld serverWorld, SpawnGroup spawnGroup, StructureAccessor structureAccessor) {
        if (spawnGroup != SpawnGroup.field_6302 || !serverWorld.getBlockState(blockPos.down()).isOf(Blocks.field_10266)) {
            return false;
        }
        Structure structure = structureAccessor.getRegistryManager().get(RegistryKeys.STRUCTURE).get(StructureKeys.field_37182);
        if (structure == null) {
            return false;
        }
        return structureAccessor.getStructureAt(blockPos, structure).hasChildren();
    }

    private static BlockPos getRandomPosInChunkSection(World world, WorldChunk worldChunk) {
        ChunkPos chunkPos = worldChunk.getPos();
        int i = chunkPos.getStartX() + world.random.nextInt(16);
        int j = chunkPos.getStartZ() + world.random.nextInt(16);
        int k = worldChunk.sampleHeightmap(Heightmap.Type.field_13202, i, j) + 1;
        int l = MathHelper.nextBetween(world.random, world.getBottomY(), k);
        return new BlockPos(i, l, j);
    }

    public static boolean isClearForSpawn(BlockView blockView, BlockPos blockPos, BlockState blockState, FluidState fluidState, EntityType<?> entityType) {
        if (blockState.isFullCube(blockView, blockPos)) {
            return false;
        }
        if (blockState.emitsRedstonePower()) {
            return false;
        }
        if (!fluidState.isEmpty()) {
            return false;
        }
        if (blockState.isIn(BlockTags.field_24459)) {
            return false;
        }
        return !entityType.isInvalidSpawn(blockState);
    }

    public static boolean canSpawn(SpawnRestriction.Location location, WorldView worldView, BlockPos blockPos, @Nullable EntityType<?> entityType) {
        if (location == SpawnRestriction.Location.field_19350) {
            return true;
        }
        if (entityType == null || !worldView.getWorldBorder().contains(blockPos)) {
            return false;
        }
        BlockState blockState = worldView.getBlockState(blockPos);
        FluidState fluidState = worldView.getFluidState(blockPos);
        BlockPos blockPos2 = blockPos.up();
        BlockPos blockPos3 = blockPos.down();
        switch (location) {
            case field_6318: {
                return fluidState.isIn(FluidTags.field_15517) && !worldView.getBlockState(blockPos2).isSolidBlock(worldView, blockPos2);
            }
            case field_23221: {
                return fluidState.isIn(FluidTags.field_15518);
            }
        }
        BlockState blockState2 = worldView.getBlockState(blockPos3);
        if (!blockState2.allowsSpawning(worldView, blockPos3, entityType)) {
            return false;
        }
        return SpawnHelper.isClearForSpawn(worldView, blockPos, blockState, fluidState, entityType) && SpawnHelper.isClearForSpawn(worldView, blockPos2, worldView.getBlockState(blockPos2), worldView.getFluidState(blockPos2), entityType);
    }

    public static void populateEntities(ServerWorldAccess serverWorldAccess, RegistryEntry<Biome> registryEntry, ChunkPos chunkPos, Random random) {
        SpawnSettings spawnSettings = registryEntry.comp_349().getSpawnSettings();
        Pool<SpawnSettings.SpawnEntry> pool = spawnSettings.getSpawnEntries(SpawnGroup.field_6294);
        if (pool.isEmpty()) {
            return;
        }
        int i = chunkPos.getStartX();
        int j = chunkPos.getStartZ();
        while (random.nextFloat() < spawnSettings.getCreatureSpawnProbability()) {
            Optional<SpawnSettings.SpawnEntry> optional = pool.getOrEmpty(random);
            if (!optional.isPresent()) continue;
            SpawnSettings.SpawnEntry spawnEntry = optional.get();
            int k = spawnEntry.minGroupSize + random.nextInt(1 + spawnEntry.maxGroupSize - spawnEntry.minGroupSize);
            EntityData entityData = null;
            int l = i + random.nextInt(16);
            int m = j + random.nextInt(16);
            int n = l;
            int o = m;
            for (int p = 0; p < k; ++p) {
                boolean bl = false;
                for (int q = 0; !bl && q < 4; ++q) {
                    BlockPos blockPos = SpawnHelper.getEntitySpawnPos(serverWorldAccess, spawnEntry.type, l, m);
                    if (spawnEntry.type.isSummonable() && SpawnHelper.canSpawn(SpawnRestriction.getLocation(spawnEntry.type), serverWorldAccess, blockPos, spawnEntry.type)) {
                        MobEntity mobEntity;
                        Object entity;
                        float f = spawnEntry.type.getWidth();
                        double d = MathHelper.clamp((double)l, (double)i + (double)f, (double)i + 16.0 - (double)f);
                        double e = MathHelper.clamp((double)m, (double)j + (double)f, (double)j + 16.0 - (double)f);
                        if (!serverWorldAccess.isSpaceEmpty(spawnEntry.type.createSimpleBoundingBox(d, blockPos.getY(), e)) || !SpawnRestriction.canSpawn(spawnEntry.type, serverWorldAccess, SpawnReason.field_16472, BlockPos.ofFloored(d, blockPos.getY(), e), serverWorldAccess.getRandom())) continue;
                        try {
                            entity = spawnEntry.type.create(serverWorldAccess.toServerWorld());
                        } catch (Exception exception) {
                            LOGGER.warn("Failed to create mob", exception);
                            continue;
                        }
                        if (entity == null) continue;
                        ((Entity)entity).refreshPositionAndAngles(d, blockPos.getY(), e, random.nextFloat() * 360.0f, 0.0f);
                        if (entity instanceof MobEntity && (mobEntity = (MobEntity)entity).canSpawn(serverWorldAccess, SpawnReason.field_16472) && mobEntity.canSpawn(serverWorldAccess)) {
                            entityData = mobEntity.initialize(serverWorldAccess, serverWorldAccess.getLocalDifficulty(mobEntity.getBlockPos()), SpawnReason.field_16472, entityData, null);
                            serverWorldAccess.spawnEntityAndPassengers(mobEntity);
                            bl = true;
                        }
                    }
                    l += random.nextInt(5) - random.nextInt(5);
                    m += random.nextInt(5) - random.nextInt(5);
                    while (l < i || l >= i + 16 || m < j || m >= j + 16) {
                        l = n + random.nextInt(5) - random.nextInt(5);
                        m = o + random.nextInt(5) - random.nextInt(5);
                    }
                }
            }
        }
    }

    private static BlockPos getEntitySpawnPos(WorldView worldView, EntityType<?> entityType, int i, int j) {
        Vec3i blockPos;
        int k = worldView.getTopY(SpawnRestriction.getHeightmapType(entityType), i, j);
        BlockPos.Mutable mutable = new BlockPos.Mutable(i, k, j);
        if (worldView.getDimension().comp_643()) {
            do {
                mutable.move(Direction.field_11033);
            } while (!worldView.getBlockState(mutable).isAir());
            do {
                mutable.move(Direction.field_11033);
            } while (worldView.getBlockState(mutable).isAir() && mutable.getY() > worldView.getBottomY());
        }
        if (SpawnRestriction.getLocation(entityType) == SpawnRestriction.Location.field_6317 && worldView.getBlockState((BlockPos)(blockPos = mutable.down())).canPathfindThrough(worldView, (BlockPos)blockPos, NavigationType.field_50)) {
            return blockPos;
        }
        return mutable.toImmutable();
    }

    @FunctionalInterface
    public static interface ChunkSource {
        public void query(long var1, Consumer<WorldChunk> var3);
    }

    public static class Info {
        private final int spawningChunkCount;
        private final Object2IntOpenHashMap<SpawnGroup> groupToCount;
        private final GravityField densityField;
        private final Object2IntMap<SpawnGroup> groupToCountView;
        private final SpawnDensityCapper densityCapper;
        @Nullable
        private BlockPos cachedPos;
        @Nullable
        private EntityType<?> cachedEntityType;
        private double cachedDensityMass;

        Info(int i, Object2IntOpenHashMap<SpawnGroup> object2IntOpenHashMap, GravityField gravityField, SpawnDensityCapper spawnDensityCapper) {
            this.spawningChunkCount = i;
            this.groupToCount = object2IntOpenHashMap;
            this.densityField = gravityField;
            this.densityCapper = spawnDensityCapper;
            this.groupToCountView = Object2IntMaps.unmodifiable(object2IntOpenHashMap);
        }

        private boolean test(EntityType<?> entityType, BlockPos blockPos, Chunk chunk) {
            double d;
            this.cachedPos = blockPos;
            this.cachedEntityType = entityType;
            SpawnSettings.SpawnDensity spawnDensity = SpawnHelper.getBiomeDirectly(blockPos, chunk).getSpawnSettings().getSpawnDensity(entityType);
            if (spawnDensity == null) {
                this.cachedDensityMass = 0.0;
                return true;
            }
            this.cachedDensityMass = d = spawnDensity.mass();
            double e = this.densityField.calculate(blockPos, d);
            return e <= spawnDensity.gravityLimit();
        }

        private void run(MobEntity mobEntity, Chunk chunk) {
            SpawnSettings.SpawnDensity spawnDensity;
            EntityType<?> entityType = mobEntity.getType();
            BlockPos blockPos = mobEntity.getBlockPos();
            double d = blockPos.equals(this.cachedPos) && entityType == this.cachedEntityType ? this.cachedDensityMass : ((spawnDensity = SpawnHelper.getBiomeDirectly(blockPos, chunk).getSpawnSettings().getSpawnDensity(entityType)) != null ? spawnDensity.mass() : 0.0);
            this.densityField.addPoint(blockPos, d);
            SpawnGroup spawnGroup = entityType.getSpawnGroup();
            this.groupToCount.addTo(spawnGroup, 1);
            this.densityCapper.increaseDensity(new ChunkPos(blockPos), spawnGroup);
        }

        public int getSpawningChunkCount() {
            return this.spawningChunkCount;
        }

        public Object2IntMap<SpawnGroup> getGroupToCount() {
            return this.groupToCountView;
        }

        boolean isBelowCap(SpawnGroup spawnGroup, ChunkPos chunkPos) {
            int i = spawnGroup.getCapacity() * this.spawningChunkCount / CHUNK_AREA;
            if (this.groupToCount.getInt(spawnGroup) >= i) {
                return false;
            }
            return this.densityCapper.canSpawn(spawnGroup, chunkPos);
        }
    }

    @FunctionalInterface
    public static interface Checker {
        public boolean test(EntityType<?> var1, BlockPos var2, Chunk var3);
    }

    @FunctionalInterface
    public static interface Runner {
        public void run(MobEntity var1, Chunk var2);
    }
}


/*
 * Decompiled with CFR 0.2.1 (FabricMC 53fa44c9).
 */
package net.minecraft.block;

import java.util.List;
import java.util.Optional;
import net.minecraft.block.AbstractBlock;
import net.minecraft.block.Block;
import net.minecraft.block.BlockEntityProvider;
import net.minecraft.block.BlockRenderType;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.DoubleBlockProperties;
import net.minecraft.block.HorizontalFacingBlock;
import net.minecraft.block.ShapeContext;
import net.minecraft.block.entity.BedBlockEntity;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.block.enums.BedPart;
import net.minecraft.entity.Dismounting;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.ai.pathing.NavigationType;
import net.minecraft.entity.passive.VillagerEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemPlacementContext;
import net.minecraft.item.ItemStack;
import net.minecraft.state.StateManager;
import net.minecraft.state.property.BooleanProperty;
import net.minecraft.state.property.EnumProperty;
import net.minecraft.state.property.Properties;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.DyeColor;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.shape.VoxelShape;
import net.minecraft.util.shape.VoxelShapes;
import net.minecraft.world.BlockView;
import net.minecraft.world.CollisionView;
import net.minecraft.world.World;
import net.minecraft.world.WorldAccess;
import org.apache.commons.lang3.ArrayUtils;
import org.jetbrains.annotations.Nullable;

public class BedBlock
extends HorizontalFacingBlock
implements BlockEntityProvider {
    public static final EnumProperty<BedPart> PART = Properties.BED_PART;
    public static final BooleanProperty OCCUPIED = Properties.OCCUPIED;
    protected static final int field_31009 = 9;
    protected static final VoxelShape TOP_SHAPE = Block.createCuboidShape(0.0, 3.0, 0.0, 16.0, 9.0, 16.0);
    private static final int field_31010 = 3;
    protected static final VoxelShape LEG_1_SHAPE = Block.createCuboidShape(0.0, 0.0, 0.0, 3.0, 3.0, 3.0);
    protected static final VoxelShape LEG_2_SHAPE = Block.createCuboidShape(0.0, 0.0, 13.0, 3.0, 3.0, 16.0);
    protected static final VoxelShape LEG_3_SHAPE = Block.createCuboidShape(13.0, 0.0, 0.0, 16.0, 3.0, 3.0);
    protected static final VoxelShape LEG_4_SHAPE = Block.createCuboidShape(13.0, 0.0, 13.0, 16.0, 3.0, 16.0);
    protected static final VoxelShape NORTH_SHAPE = VoxelShapes.union(TOP_SHAPE, LEG_1_SHAPE, LEG_3_SHAPE);
    protected static final VoxelShape SOUTH_SHAPE = VoxelShapes.union(TOP_SHAPE, LEG_2_SHAPE, LEG_4_SHAPE);
    protected static final VoxelShape WEST_SHAPE = VoxelShapes.union(TOP_SHAPE, LEG_1_SHAPE, LEG_2_SHAPE);
    protected static final VoxelShape EAST_SHAPE = VoxelShapes.union(TOP_SHAPE, LEG_3_SHAPE, LEG_4_SHAPE);
    private final DyeColor color;

    public BedBlock(DyeColor dyeColor, AbstractBlock.Settings settings) {
        super(settings);
        this.color = dyeColor;
        this.setDefaultState((BlockState)((BlockState)((BlockState)this.stateManager.getDefaultState()).with(PART, BedPart.field_12557)).with(OCCUPIED, false));
    }

    @Nullable
    public static Direction getDirection(BlockView blockView, BlockPos blockPos) {
        BlockState blockState = blockView.getBlockState(blockPos);
        return blockState.getBlock() instanceof BedBlock ? blockState.get(FACING) : null;
    }

    @Override
    public ActionResult onUse(BlockState blockState, World world, BlockPos blockPos, PlayerEntity playerEntity, Hand hand, BlockHitResult blockHitResult) {
        if (world.isClient) {
            return ActionResult.CONSUME;
        }
        if (blockState.get(PART) != BedPart.field_12560 && !(blockState = world.getBlockState(blockPos = blockPos.offset(blockState.get(FACING)))).isOf(this)) {
            return ActionResult.CONSUME;
        }
        if (!BedBlock.isBedWorking(world)) {
            world.removeBlock(blockPos, false);
            BlockPos blockPos2 = blockPos.offset(blockState.get(FACING).getOpposite());
            if (world.getBlockState(blockPos2).isOf(this)) {
                world.removeBlock(blockPos2, false);
            }
            Vec3d vec3d = blockPos.toCenterPos();
            world.createExplosion(null, world.getDamageSources().badRespawnPoint(vec3d), null, vec3d, 5.0f, true, World.ExplosionSourceType.field_40889);
            return ActionResult.SUCCESS;
        }
        if (blockState.get(OCCUPIED).booleanValue()) {
            if (!this.wakeVillager(world, blockPos)) {
                playerEntity.sendMessage(Text.translatable("block.minecraft.bed.occupied"), true);
            }
            return ActionResult.SUCCESS;
        }
        playerEntity.trySleep(blockPos).ifLeft(sleepFailureReason -> {
            if (sleepFailureReason.getMessage() != null) {
                playerEntity.sendMessage(sleepFailureReason.getMessage(), true);
            }
        });
        return ActionResult.SUCCESS;
    }

    public static boolean isBedWorking(World world) {
        return world.getDimension().comp_648();
    }

    private boolean wakeVillager(World world, BlockPos blockPos) {
        List<VillagerEntity> list = world.getEntitiesByClass(VillagerEntity.class, new Box(blockPos), LivingEntity::isSleeping);
        if (list.isEmpty()) {
            return false;
        }
        list.get(0).wakeUp();
        return true;
    }

    @Override
    public void onLandedUpon(World world, BlockState blockState, BlockPos blockPos, Entity entity, float f) {
        super.onLandedUpon(world, blockState, blockPos, entity, f * 0.5f);
    }

    @Override
    public void onEntityLand(BlockView blockView, Entity entity) {
        if (entity.bypassesLandingEffects()) {
            super.onEntityLand(blockView, entity);
        } else {
            this.bounceEntity(entity);
        }
    }

    private void bounceEntity(Entity entity) {
        Vec3d vec3d = entity.getVelocity();
        if (vec3d.y < 0.0) {
            double d = entity instanceof LivingEntity ? 1.0 : 0.8;
            entity.setVelocity(vec3d.x, -vec3d.y * (double)0.66f * d, vec3d.z);
        }
    }

    @Override
    public BlockState getStateForNeighborUpdate(BlockState blockState, Direction direction, BlockState blockState2, WorldAccess worldAccess, BlockPos blockPos, BlockPos blockPos2) {
        if (direction == BedBlock.getDirectionTowardsOtherPart(blockState.get(PART), blockState.get(FACING))) {
            if (blockState2.isOf(this) && blockState2.get(PART) != blockState.get(PART)) {
                return (BlockState)blockState.with(OCCUPIED, blockState2.get(OCCUPIED));
            }
            return Blocks.field_10124.getDefaultState();
        }
        return super.getStateForNeighborUpdate(blockState, direction, blockState2, worldAccess, blockPos, blockPos2);
    }

    private static Direction getDirectionTowardsOtherPart(BedPart bedPart, Direction direction) {
        return bedPart == BedPart.field_12557 ? direction : direction.getOpposite();
    }

    @Override
    public void onBreak(World world, BlockPos blockPos, BlockState blockState, PlayerEntity playerEntity) {
        BlockPos blockPos2;
        BlockState blockState2;
        BedPart bedPart;
        if (!world.isClient && playerEntity.isCreative() && (bedPart = blockState.get(PART)) == BedPart.field_12557 && (blockState2 = world.getBlockState(blockPos2 = blockPos.offset(BedBlock.getDirectionTowardsOtherPart(bedPart, blockState.get(FACING))))).isOf(this) && blockState2.get(PART) == BedPart.field_12560) {
            world.setBlockState(blockPos2, Blocks.field_10124.getDefaultState(), 35);
            world.syncWorldEvent(playerEntity, 2001, blockPos2, Block.getRawIdFromState(blockState2));
        }
        super.onBreak(world, blockPos, blockState, playerEntity);
    }

    @Override
    @Nullable
    public BlockState getPlacementState(ItemPlacementContext itemPlacementContext) {
        Direction direction = itemPlacementContext.getHorizontalPlayerFacing();
        BlockPos blockPos = itemPlacementContext.getBlockPos();
        BlockPos blockPos2 = blockPos.offset(direction);
        World world = itemPlacementContext.getWorld();
        if (world.getBlockState(blockPos2).canReplace(itemPlacementContext) && world.getWorldBorder().contains(blockPos2)) {
            return (BlockState)this.getDefaultState().with(FACING, direction);
        }
        return null;
    }

    @Override
    public VoxelShape getOutlineShape(BlockState blockState, BlockView blockView, BlockPos blockPos, ShapeContext shapeContext) {
        Direction direction = BedBlock.getOppositePartDirection(blockState).getOpposite();
        switch (direction) {
            case field_11043: {
                return NORTH_SHAPE;
            }
            case field_11035: {
                return SOUTH_SHAPE;
            }
            case field_11039: {
                return WEST_SHAPE;
            }
        }
        return EAST_SHAPE;
    }

    public static Direction getOppositePartDirection(BlockState blockState) {
        Direction direction = blockState.get(FACING);
        return blockState.get(PART) == BedPart.field_12560 ? direction.getOpposite() : direction;
    }

    public static DoubleBlockProperties.Type getBedPart(BlockState blockState) {
        BedPart bedPart = blockState.get(PART);
        if (bedPart == BedPart.field_12560) {
            return DoubleBlockProperties.Type.field_21784;
        }
        return DoubleBlockProperties.Type.field_21785;
    }

    private static boolean isBedBelow(BlockView blockView, BlockPos blockPos) {
        return blockView.getBlockState(blockPos.down()).getBlock() instanceof BedBlock;
    }

    public static Optional<Vec3d> findWakeUpPosition(EntityType<?> entityType, CollisionView collisionView, BlockPos blockPos, Direction direction, float f) {
        Direction direction3;
        Direction direction2 = direction.rotateYClockwise();
        Direction direction4 = direction3 = direction2.pointsTo(f) ? direction2.getOpposite() : direction2;
        if (BedBlock.isBedBelow(collisionView, blockPos)) {
            return BedBlock.findWakeUpPosition(entityType, collisionView, blockPos, direction, direction3);
        }
        int[][] is = BedBlock.getAroundAndOnBedOffsets(direction, direction3);
        Optional<Vec3d> optional = BedBlock.findWakeUpPosition(entityType, collisionView, blockPos, is, true);
        if (optional.isPresent()) {
            return optional;
        }
        return BedBlock.findWakeUpPosition(entityType, collisionView, blockPos, is, false);
    }

    private static Optional<Vec3d> findWakeUpPosition(EntityType<?> entityType, CollisionView collisionView, BlockPos blockPos, Direction direction, Direction direction2) {
        int[][] is = BedBlock.getAroundBedOffsets(direction, direction2);
        Optional<Vec3d> optional = BedBlock.findWakeUpPosition(entityType, collisionView, blockPos, is, true);
        if (optional.isPresent()) {
            return optional;
        }
        BlockPos blockPos2 = blockPos.down();
        Optional<Vec3d> optional2 = BedBlock.findWakeUpPosition(entityType, collisionView, blockPos2, is, true);
        if (optional2.isPresent()) {
            return optional2;
        }
        int[][] js = BedBlock.getOnBedOffsets(direction);
        Optional<Vec3d> optional3 = BedBlock.findWakeUpPosition(entityType, collisionView, blockPos, js, true);
        if (optional3.isPresent()) {
            return optional3;
        }
        Optional<Vec3d> optional4 = BedBlock.findWakeUpPosition(entityType, collisionView, blockPos, is, false);
        if (optional4.isPresent()) {
            return optional4;
        }
        Optional<Vec3d> optional5 = BedBlock.findWakeUpPosition(entityType, collisionView, blockPos2, is, false);
        if (optional5.isPresent()) {
            return optional5;
        }
        return BedBlock.findWakeUpPosition(entityType, collisionView, blockPos, js, false);
    }

    private static Optional<Vec3d> findWakeUpPosition(EntityType<?> entityType, CollisionView collisionView, BlockPos blockPos, int[][] is, boolean bl) {
        BlockPos.Mutable mutable = new BlockPos.Mutable();
        for (int[] js : is) {
            mutable.set(blockPos.getX() + js[0], blockPos.getY(), blockPos.getZ() + js[1]);
            Vec3d vec3d = Dismounting.findRespawnPos(entityType, collisionView, mutable, bl);
            if (vec3d == null) continue;
            return Optional.of(vec3d);
        }
        return Optional.empty();
    }

    @Override
    public BlockRenderType getRenderType(BlockState blockState) {
        return BlockRenderType.field_11456;
    }

    @Override
    protected void appendProperties(StateManager.Builder<Block, BlockState> builder) {
        builder.add(FACING, PART, OCCUPIED);
    }

    @Override
    public BlockEntity createBlockEntity(BlockPos blockPos, BlockState blockState) {
        return new BedBlockEntity(blockPos, blockState, this.color);
    }

    @Override
    public void onPlaced(World world, BlockPos blockPos, BlockState blockState, @Nullable LivingEntity livingEntity, ItemStack itemStack) {
        super.onPlaced(world, blockPos, blockState, livingEntity, itemStack);
        if (!world.isClient) {
            BlockPos blockPos2 = blockPos.offset(blockState.get(FACING));
            world.setBlockState(blockPos2, (BlockState)blockState.with(PART, BedPart.field_12560), 3);
            world.updateNeighbors(blockPos, Blocks.field_10124);
            blockState.updateNeighbors(world, blockPos, 3);
        }
    }

    public DyeColor getColor() {
        return this.color;
    }

    @Override
    public long getRenderingSeed(BlockState blockState, BlockPos blockPos) {
        BlockPos blockPos2 = blockPos.offset(blockState.get(FACING), blockState.get(PART) == BedPart.field_12560 ? 0 : 1);
        return MathHelper.hashCode(blockPos2.getX(), blockPos.getY(), blockPos2.getZ());
    }

    @Override
    public boolean canPathfindThrough(BlockState blockState, BlockView blockView, BlockPos blockPos, NavigationType navigationType) {
        return false;
    }

    private static int[][] getAroundAndOnBedOffsets(Direction direction, Direction direction2) {
        return (int[][])ArrayUtils.addAll(BedBlock.getAroundBedOffsets(direction, direction2), BedBlock.getOnBedOffsets(direction));
    }

    private static int[][] getAroundBedOffsets(Direction direction, Direction direction2) {
        return new int[][]{{direction2.getOffsetX(), direction2.getOffsetZ()}, {direction2.getOffsetX() - direction.getOffsetX(), direction2.getOffsetZ() - direction.getOffsetZ()}, {direction2.getOffsetX() - direction.getOffsetX() * 2, direction2.getOffsetZ() - direction.getOffsetZ() * 2}, {-direction.getOffsetX() * 2, -direction.getOffsetZ() * 2}, {-direction2.getOffsetX() - direction.getOffsetX() * 2, -direction2.getOffsetZ() - direction.getOffsetZ() * 2}, {-direction2.getOffsetX() - direction.getOffsetX(), -direction2.getOffsetZ() - direction.getOffsetZ()}, {-direction2.getOffsetX(), -direction2.getOffsetZ()}, {-direction2.getOffsetX() + direction.getOffsetX(), -direction2.getOffsetZ() + direction.getOffsetZ()}, {direction.getOffsetX(), direction.getOffsetZ()}, {direction2.getOffsetX() + direction.getOffsetX(), direction2.getOffsetZ() + direction.getOffsetZ()}};
    }

    private static int[][] getOnBedOffsets(Direction direction) {
        return new int[][]{{0, 0}, {-direction.getOffsetX(), -direction.getOffsetZ()}};
    }
}


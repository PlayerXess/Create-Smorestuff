/*
 * Decompiled with CFR 0.2.1 (FabricMC 53fa44c9).
 */
package net.minecraft.item;

import java.util.List;
import java.util.Optional;
import net.minecraft.client.item.TooltipContext;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.decoration.AbstractDecorationEntity;
import net.minecraft.entity.decoration.GlowItemFrameEntity;
import net.minecraft.entity.decoration.ItemFrameEntity;
import net.minecraft.entity.decoration.painting.PaintingEntity;
import net.minecraft.entity.decoration.painting.PaintingVariant;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemUsageContext;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Formatting;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.MathHelper;
import net.minecraft.world.World;
import net.minecraft.world.event.GameEvent;
import org.jetbrains.annotations.Nullable;

public class DecorationItem
extends Item {
    private static final Text RANDOM_TEXT = Text.translatable("painting.random").formatted(Formatting.field_1080);
    private final EntityType<? extends AbstractDecorationEntity> entityType;

    public DecorationItem(EntityType<? extends AbstractDecorationEntity> entityType, Item.Settings settings) {
        super(settings);
        this.entityType = entityType;
    }

    @Override
    public ActionResult useOnBlock(ItemUsageContext itemUsageContext) {
        AbstractDecorationEntity abstractDecorationEntity;
        BlockPos blockPos = itemUsageContext.getBlockPos();
        Direction direction = itemUsageContext.getSide();
        BlockPos blockPos2 = blockPos.offset(direction);
        PlayerEntity playerEntity = itemUsageContext.getPlayer();
        ItemStack itemStack = itemUsageContext.getStack();
        if (playerEntity != null && !this.canPlaceOn(playerEntity, direction, itemStack, blockPos2)) {
            return ActionResult.FAIL;
        }
        World world = itemUsageContext.getWorld();
        if (this.entityType == EntityType.field_6120) {
            Optional<PaintingEntity> optional = PaintingEntity.placePainting(world, blockPos2, direction);
            if (optional.isEmpty()) {
                return ActionResult.CONSUME;
            }
            abstractDecorationEntity = optional.get();
        } else if (this.entityType == EntityType.field_6043) {
            abstractDecorationEntity = new ItemFrameEntity(world, blockPos2, direction);
        } else if (this.entityType == EntityType.field_28401) {
            abstractDecorationEntity = new GlowItemFrameEntity(world, blockPos2, direction);
        } else {
            return ActionResult.success(world.isClient);
        }
        NbtCompound nbtCompound = itemStack.getNbt();
        if (nbtCompound != null) {
            EntityType.loadFromEntityNbt(world, playerEntity, abstractDecorationEntity, nbtCompound);
        }
        if (abstractDecorationEntity.canStayAttached()) {
            if (!world.isClient) {
                abstractDecorationEntity.onPlace();
                world.emitGameEvent((Entity)playerEntity, GameEvent.field_28738, abstractDecorationEntity.getPos());
                world.spawnEntity(abstractDecorationEntity);
            }
            itemStack.decrement(1);
            return ActionResult.success(world.isClient);
        }
        return ActionResult.CONSUME;
    }

    protected boolean canPlaceOn(PlayerEntity playerEntity, Direction direction, ItemStack itemStack, BlockPos blockPos) {
        return !direction.getAxis().isVertical() && playerEntity.canPlaceOn(blockPos, direction, itemStack);
    }

    @Override
    public void appendTooltip(ItemStack itemStack, @Nullable World world, List<Text> list, TooltipContext tooltipContext) {
        super.appendTooltip(itemStack, world, list, tooltipContext);
        if (this.entityType == EntityType.field_6120) {
            NbtCompound nbtCompound = itemStack.getNbt();
            if (nbtCompound != null && nbtCompound.contains("EntityTag", 10)) {
                NbtCompound nbtCompound2 = nbtCompound.getCompound("EntityTag");
                PaintingEntity.readVariantFromNbt(nbtCompound2).ifPresentOrElse(registryEntry -> {
                    registryEntry.getKey().ifPresent(registryKey -> {
                        list.add(Text.translatable(registryKey.getValue().toTranslationKey("painting", "title")).formatted(Formatting.field_1054));
                        list.add(Text.translatable(registryKey.getValue().toTranslationKey("painting", "author")).formatted(Formatting.field_1080));
                    });
                    list.add(Text.translatable("painting.dimensions", MathHelper.ceilDiv(((PaintingVariant)registryEntry.comp_349()).getWidth(), 16), MathHelper.ceilDiv(((PaintingVariant)registryEntry.comp_349()).getHeight(), 16)));
                }, () -> list.add(RANDOM_TEXT));
            } else if (tooltipContext.isCreative()) {
                list.add(RANDOM_TEXT);
            }
        }
    }
}


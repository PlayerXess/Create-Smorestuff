/*
 * Decompiled with CFR 0.2.1 (FabricMC 53fa44c9).
 */
package net.minecraft.world.spawner;

import net.minecraft.server.world.ServerWorld;

public interface Spawner {
    public int spawn(ServerWorld var1, boolean var2, boolean var3);
}


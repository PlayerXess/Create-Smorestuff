/*
 * Decompiled with CFR 0.2.1 (FabricMC 53fa44c9).
 */
package net.minecraft.sound;

import com.mojang.datafixers.kinds.Applicative;
import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;

public class BiomeMoodSound {
    public static final Codec<BiomeMoodSound> CODEC = RecordCodecBuilder.create(instance -> instance.group(((MapCodec)SoundEvent.ENTRY_CODEC.fieldOf("sound")).forGetter(biomeMoodSound -> biomeMoodSound.sound), ((MapCodec)Codec.INT.fieldOf("tick_delay")).forGetter(biomeMoodSound -> biomeMoodSound.cultivationTicks), ((MapCodec)Codec.INT.fieldOf("block_search_extent")).forGetter(biomeMoodSound -> biomeMoodSound.spawnRange), ((MapCodec)Codec.DOUBLE.fieldOf("offset")).forGetter(biomeMoodSound -> biomeMoodSound.extraDistance)).apply((Applicative<BiomeMoodSound, ?>)instance, BiomeMoodSound::new));
    public static final BiomeMoodSound CAVE = new BiomeMoodSound(SoundEvents.field_14564, 6000, 8, 2.0);
    private final RegistryEntry<SoundEvent> sound;
    private final int cultivationTicks;
    private final int spawnRange;
    private final double extraDistance;

    public BiomeMoodSound(RegistryEntry<SoundEvent> registryEntry, int i, int j, double d) {
        this.sound = registryEntry;
        this.cultivationTicks = i;
        this.spawnRange = j;
        this.extraDistance = d;
    }

    public RegistryEntry<SoundEvent> getSound() {
        return this.sound;
    }

    public int getCultivationTicks() {
        return this.cultivationTicks;
    }

    public int getSpawnRange() {
        return this.spawnRange;
    }

    public double getExtraDistance() {
        return this.extraDistance;
    }
}


/*
 * Decompiled with CFR 0.2.1 (FabricMC 53fa44c9).
 */
package net.minecraft.item;

import java.util.Collection;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemUsageContext;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.registry.Registries;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.state.StateManager;
import net.minecraft.state.property.Property;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.Util;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraft.world.WorldAccess;
import org.jetbrains.annotations.Nullable;

public class DebugStickItem
extends Item {
    public DebugStickItem(Item.Settings settings) {
        super(settings);
    }

    @Override
    public boolean hasGlint(ItemStack itemStack) {
        return true;
    }

    @Override
    public boolean canMine(BlockState blockState, World world, BlockPos blockPos, PlayerEntity playerEntity) {
        if (!world.isClient) {
            this.use(playerEntity, blockState, world, blockPos, false, playerEntity.getStackInHand(Hand.field_5808));
        }
        return false;
    }

    @Override
    public ActionResult useOnBlock(ItemUsageContext itemUsageContext) {
        BlockPos blockPos;
        PlayerEntity playerEntity = itemUsageContext.getPlayer();
        World world = itemUsageContext.getWorld();
        if (!world.isClient && playerEntity != null && !this.use(playerEntity, world.getBlockState(blockPos = itemUsageContext.getBlockPos()), world, blockPos, true, itemUsageContext.getStack())) {
            return ActionResult.FAIL;
        }
        return ActionResult.success(world.isClient);
    }

    private boolean use(PlayerEntity playerEntity, BlockState blockState, WorldAccess worldAccess, BlockPos blockPos, boolean bl, ItemStack itemStack) {
        if (!playerEntity.isCreativeLevelTwoOp()) {
            return false;
        }
        Block block = blockState.getBlock();
        StateManager<Block, BlockState> stateManager = block.getStateManager();
        Collection<Property<?>> collection = stateManager.getProperties();
        String string = Registries.BLOCK.getId(block).toString();
        if (collection.isEmpty()) {
            DebugStickItem.sendMessage(playerEntity, Text.translatable(this.getTranslationKey() + ".empty", string));
            return false;
        }
        NbtCompound nbtCompound = itemStack.getOrCreateSubNbt("DebugProperty");
        String string2 = nbtCompound.getString(string);
        Property<?> property = stateManager.getProperty(string2);
        if (bl) {
            if (property == null) {
                property = collection.iterator().next();
            }
            BlockState blockState2 = DebugStickItem.cycle(blockState, property, playerEntity.shouldCancelInteraction());
            worldAccess.setBlockState(blockPos, blockState2, 18);
            DebugStickItem.sendMessage(playerEntity, Text.translatable(this.getTranslationKey() + ".update", property.getName(), DebugStickItem.getValueString(blockState2, property)));
        } else {
            property = DebugStickItem.cycle(collection, property, playerEntity.shouldCancelInteraction());
            String string3 = property.getName();
            nbtCompound.putString(string, string3);
            DebugStickItem.sendMessage(playerEntity, Text.translatable(this.getTranslationKey() + ".select", string3, DebugStickItem.getValueString(blockState, property)));
        }
        return true;
    }

    private static <T extends Comparable<T>> BlockState cycle(BlockState blockState, Property<T> property, boolean bl) {
        return (BlockState)blockState.with(property, (Comparable)DebugStickItem.cycle(property.getValues(), blockState.get(property), bl));
    }

    private static <T> T cycle(Iterable<T> iterable, @Nullable T object, boolean bl) {
        return bl ? Util.previous(iterable, object) : Util.next(iterable, object);
    }

    private static void sendMessage(PlayerEntity playerEntity, Text text) {
        ((ServerPlayerEntity)playerEntity).sendMessageToClient(text, true);
    }

    private static <T extends Comparable<T>> String getValueString(BlockState blockState, Property<T> property) {
        return property.name(blockState.get(property));
    }
}


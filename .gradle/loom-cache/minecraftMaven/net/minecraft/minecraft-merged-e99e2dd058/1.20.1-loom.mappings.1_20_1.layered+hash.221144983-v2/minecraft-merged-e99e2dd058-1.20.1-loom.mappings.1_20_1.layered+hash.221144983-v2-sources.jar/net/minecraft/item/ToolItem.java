/*
 * Decompiled with CFR 0.2.1 (FabricMC 53fa44c9).
 */
package net.minecraft.item;

import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ToolMaterial;

public class ToolItem
extends Item {
    private final ToolMaterial material;

    public ToolItem(ToolMaterial toolMaterial, Item.Settings settings) {
        super(settings.maxDamageIfAbsent(toolMaterial.getDurability()));
        this.material = toolMaterial;
    }

    public ToolMaterial getMaterial() {
        return this.material;
    }

    @Override
    public int getEnchantability() {
        return this.material.getEnchantability();
    }

    @Override
    public boolean canRepair(ItemStack itemStack, ItemStack itemStack2) {
        return this.material.getRepairIngredient().test(itemStack2) || super.canRepair(itemStack, itemStack2);
    }
}


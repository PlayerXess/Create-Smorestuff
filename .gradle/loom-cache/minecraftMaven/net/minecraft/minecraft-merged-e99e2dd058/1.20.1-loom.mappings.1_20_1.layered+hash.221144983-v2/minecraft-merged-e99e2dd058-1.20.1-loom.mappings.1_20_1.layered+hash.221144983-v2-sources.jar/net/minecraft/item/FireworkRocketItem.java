/*
 * Decompiled with CFR 0.2.1 (FabricMC 53fa44c9).
 */
package net.minecraft.item;

import com.google.common.collect.Lists;
import java.util.ArrayList;
import java.util.List;
import java.util.function.IntFunction;
import net.minecraft.client.item.TooltipContext;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.projectile.FireworkRocketEntity;
import net.minecraft.item.FireworkStarItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemUsageContext;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.nbt.NbtList;
import net.minecraft.screen.ScreenTexts;
import net.minecraft.stat.Stats;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Formatting;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.util.function.ValueLists;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;
import org.jetbrains.annotations.Nullable;

public class FireworkRocketItem
extends Item {
    public static final byte[] FLIGHT_VALUES = new byte[]{1, 2, 3};
    public static final String FIREWORKS_KEY = "Fireworks";
    public static final String EXPLOSION_KEY = "Explosion";
    public static final String EXPLOSIONS_KEY = "Explosions";
    public static final String FLIGHT_KEY = "Flight";
    public static final String TYPE_KEY = "Type";
    public static final String TRAIL_KEY = "Trail";
    public static final String FLICKER_KEY = "Flicker";
    public static final String COLORS_KEY = "Colors";
    public static final String FADE_COLORS_KEY = "FadeColors";
    public static final double OFFSET_POS_MULTIPLIER = 0.15;

    public FireworkRocketItem(Item.Settings settings) {
        super(settings);
    }

    @Override
    public ActionResult useOnBlock(ItemUsageContext itemUsageContext) {
        World world = itemUsageContext.getWorld();
        if (!world.isClient) {
            ItemStack itemStack = itemUsageContext.getStack();
            Vec3d vec3d = itemUsageContext.getHitPos();
            Direction direction = itemUsageContext.getSide();
            FireworkRocketEntity fireworkRocketEntity = new FireworkRocketEntity(world, itemUsageContext.getPlayer(), vec3d.x + (double)direction.getOffsetX() * 0.15, vec3d.y + (double)direction.getOffsetY() * 0.15, vec3d.z + (double)direction.getOffsetZ() * 0.15, itemStack);
            world.spawnEntity(fireworkRocketEntity);
            itemStack.decrement(1);
        }
        return ActionResult.success(world.isClient);
    }

    @Override
    public TypedActionResult<ItemStack> use(World world, PlayerEntity playerEntity, Hand hand) {
        if (playerEntity.isFallFlying()) {
            ItemStack itemStack = playerEntity.getStackInHand(hand);
            if (!world.isClient) {
                FireworkRocketEntity fireworkRocketEntity = new FireworkRocketEntity(world, itemStack, playerEntity);
                world.spawnEntity(fireworkRocketEntity);
                if (!playerEntity.getAbilities().creativeMode) {
                    itemStack.decrement(1);
                }
                playerEntity.incrementStat(Stats.field_15372.getOrCreateStat(this));
            }
            return TypedActionResult.success(playerEntity.getStackInHand(hand), world.isClient());
        }
        return TypedActionResult.pass(playerEntity.getStackInHand(hand));
    }

    @Override
    public void appendTooltip(ItemStack itemStack, @Nullable World world, List<Text> list, TooltipContext tooltipContext) {
        NbtList nbtList;
        NbtCompound nbtCompound = itemStack.getSubNbt(FIREWORKS_KEY);
        if (nbtCompound == null) {
            return;
        }
        if (nbtCompound.contains(FLIGHT_KEY, 99)) {
            list.add(Text.translatable("item.minecraft.firework_rocket.flight").append(ScreenTexts.SPACE).append(String.valueOf(nbtCompound.getByte(FLIGHT_KEY))).formatted(Formatting.field_1080));
        }
        if (!(nbtList = nbtCompound.getList(EXPLOSIONS_KEY, 10)).isEmpty()) {
            for (int i = 0; i < nbtList.size(); ++i) {
                NbtCompound nbtCompound2 = nbtList.getCompound(i);
                ArrayList<Text> list2 = Lists.newArrayList();
                FireworkStarItem.appendFireworkTooltip(nbtCompound2, list2);
                if (list2.isEmpty()) continue;
                for (int j = 1; j < list2.size(); ++j) {
                    list2.set(j, Text.literal("  ").append((Text)list2.get(j)).formatted(Formatting.field_1080));
                }
                list.addAll(list2);
            }
        }
    }

    public static void setFlight(ItemStack itemStack, byte b) {
        itemStack.getOrCreateSubNbt(FIREWORKS_KEY).putByte(FLIGHT_KEY, b);
    }

    @Override
    public ItemStack getDefaultStack() {
        ItemStack itemStack = new ItemStack(this);
        FireworkRocketItem.setFlight(itemStack, (byte)1);
        return itemStack;
    }

    public static enum Type {
        field_7976(0, "small_ball"),
        field_7977(1, "large_ball"),
        field_7973(2, "star"),
        field_7974(3, "creeper"),
        field_7970(4, "burst");

        private static final IntFunction<Type> BY_ID;
        private final int id;
        private final String name;

        private Type(int j, String string2) {
            this.id = j;
            this.name = string2;
        }

        public int getId() {
            return this.id;
        }

        public String getName() {
            return this.name;
        }

        public static Type byId(int i) {
            return BY_ID.apply(i);
        }

        static {
            BY_ID = ValueLists.createIdToValueFunction(Type::getId, Type.values(), ValueLists.OutOfBoundsHandling.field_41664);
        }
    }
}


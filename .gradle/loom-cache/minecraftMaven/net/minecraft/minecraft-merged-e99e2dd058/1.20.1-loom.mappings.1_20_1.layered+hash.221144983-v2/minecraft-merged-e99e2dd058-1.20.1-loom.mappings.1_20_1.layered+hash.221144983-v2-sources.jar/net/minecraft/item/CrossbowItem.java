/*
 * Decompiled with CFR 0.2.1 (FabricMC 53fa44c9).
 */
package net.minecraft.item;

import com.google.common.collect.Lists;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Predicate;
import net.minecraft.advancement.criterion.Criteria;
import net.minecraft.client.item.TooltipContext;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.enchantment.Enchantments;
import net.minecraft.entity.CrossbowUser;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.projectile.FireworkRocketEntity;
import net.minecraft.entity.projectile.PersistentProjectileEntity;
import net.minecraft.entity.projectile.ProjectileEntity;
import net.minecraft.item.ArrowItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.item.RangedWeaponItem;
import net.minecraft.item.Vanishable;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.nbt.NbtList;
import net.minecraft.screen.ScreenTexts;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;
import net.minecraft.stat.Stats;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.util.UseAction;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.math.random.Random;
import net.minecraft.world.World;
import org.jetbrains.annotations.Nullable;
import org.joml.Quaternionf;
import org.joml.Vector3f;

public class CrossbowItem
extends RangedWeaponItem
implements Vanishable {
    private static final String CHARGED_KEY = "Charged";
    private static final String CHARGED_PROJECTILES_KEY = "ChargedProjectiles";
    private static final int DEFAULT_PULL_TIME = 25;
    public static final int RANGE = 8;
    private boolean charged = false;
    private boolean loaded = false;
    private static final float field_30867 = 0.2f;
    private static final float field_30868 = 0.5f;
    private static final float DEFAULT_SPEED = 3.15f;
    private static final float FIREWORK_ROCKET_SPEED = 1.6f;

    public CrossbowItem(Item.Settings settings) {
        super(settings);
    }

    @Override
    public Predicate<ItemStack> getHeldProjectiles() {
        return CROSSBOW_HELD_PROJECTILES;
    }

    @Override
    public Predicate<ItemStack> getProjectiles() {
        return BOW_PROJECTILES;
    }

    @Override
    public TypedActionResult<ItemStack> use(World world, PlayerEntity playerEntity, Hand hand) {
        ItemStack itemStack = playerEntity.getStackInHand(hand);
        if (CrossbowItem.isCharged(itemStack)) {
            CrossbowItem.shootAll(world, playerEntity, hand, itemStack, CrossbowItem.getSpeed(itemStack), 1.0f);
            CrossbowItem.setCharged(itemStack, false);
            return TypedActionResult.consume(itemStack);
        }
        if (!playerEntity.getProjectileType(itemStack).isEmpty()) {
            if (!CrossbowItem.isCharged(itemStack)) {
                this.charged = false;
                this.loaded = false;
                playerEntity.setCurrentHand(hand);
            }
            return TypedActionResult.consume(itemStack);
        }
        return TypedActionResult.fail(itemStack);
    }

    private static float getSpeed(ItemStack itemStack) {
        if (CrossbowItem.hasProjectile(itemStack, Items.field_8639)) {
            return 1.6f;
        }
        return 3.15f;
    }

    @Override
    public void onStoppedUsing(ItemStack itemStack, World world, LivingEntity livingEntity, int i) {
        int j = this.getMaxUseTime(itemStack) - i;
        float f = CrossbowItem.getPullProgress(j, itemStack);
        if (f >= 1.0f && !CrossbowItem.isCharged(itemStack) && CrossbowItem.loadProjectiles(livingEntity, itemStack)) {
            CrossbowItem.setCharged(itemStack, true);
            SoundCategory soundCategory = livingEntity instanceof PlayerEntity ? SoundCategory.field_15248 : SoundCategory.field_15251;
            world.playSound(null, livingEntity.getX(), livingEntity.getY(), livingEntity.getZ(), SoundEvents.field_14626, soundCategory, 1.0f, 1.0f / (world.getRandom().nextFloat() * 0.5f + 1.0f) + 0.2f);
        }
    }

    private static boolean loadProjectiles(LivingEntity livingEntity, ItemStack itemStack) {
        int i = EnchantmentHelper.getLevel(Enchantments.field_9108, itemStack);
        int j = i == 0 ? 1 : 3;
        boolean bl = livingEntity instanceof PlayerEntity && ((PlayerEntity)livingEntity).getAbilities().creativeMode;
        ItemStack itemStack2 = livingEntity.getProjectileType(itemStack);
        ItemStack itemStack3 = itemStack2.copy();
        for (int k = 0; k < j; ++k) {
            if (k > 0) {
                itemStack2 = itemStack3.copy();
            }
            if (itemStack2.isEmpty() && bl) {
                itemStack2 = new ItemStack(Items.field_8107);
                itemStack3 = itemStack2.copy();
            }
            if (CrossbowItem.loadProjectile(livingEntity, itemStack, itemStack2, k > 0, bl)) continue;
            return false;
        }
        return true;
    }

    private static boolean loadProjectile(LivingEntity livingEntity, ItemStack itemStack, ItemStack itemStack2, boolean bl, boolean bl2) {
        ItemStack itemStack3;
        boolean bl3;
        if (itemStack2.isEmpty()) {
            return false;
        }
        boolean bl4 = bl3 = bl2 && itemStack2.getItem() instanceof ArrowItem;
        if (!(bl3 || bl2 || bl)) {
            itemStack3 = itemStack2.split(1);
            if (itemStack2.isEmpty() && livingEntity instanceof PlayerEntity) {
                ((PlayerEntity)livingEntity).getInventory().removeOne(itemStack2);
            }
        } else {
            itemStack3 = itemStack2.copy();
        }
        CrossbowItem.putProjectile(itemStack, itemStack3);
        return true;
    }

    public static boolean isCharged(ItemStack itemStack) {
        NbtCompound nbtCompound = itemStack.getNbt();
        return nbtCompound != null && nbtCompound.getBoolean(CHARGED_KEY);
    }

    public static void setCharged(ItemStack itemStack, boolean bl) {
        NbtCompound nbtCompound = itemStack.getOrCreateNbt();
        nbtCompound.putBoolean(CHARGED_KEY, bl);
    }

    private static void putProjectile(ItemStack itemStack, ItemStack itemStack2) {
        NbtCompound nbtCompound = itemStack.getOrCreateNbt();
        NbtList nbtList = nbtCompound.contains(CHARGED_PROJECTILES_KEY, 9) ? nbtCompound.getList(CHARGED_PROJECTILES_KEY, 10) : new NbtList();
        NbtCompound nbtCompound2 = new NbtCompound();
        itemStack2.writeNbt(nbtCompound2);
        nbtList.add(nbtCompound2);
        nbtCompound.put(CHARGED_PROJECTILES_KEY, nbtList);
    }

    private static List<ItemStack> getProjectiles(ItemStack itemStack) {
        NbtList nbtList;
        ArrayList<ItemStack> list = Lists.newArrayList();
        NbtCompound nbtCompound = itemStack.getNbt();
        if (nbtCompound != null && nbtCompound.contains(CHARGED_PROJECTILES_KEY, 9) && (nbtList = nbtCompound.getList(CHARGED_PROJECTILES_KEY, 10)) != null) {
            for (int i = 0; i < nbtList.size(); ++i) {
                NbtCompound nbtCompound2 = nbtList.getCompound(i);
                list.add(ItemStack.fromNbt(nbtCompound2));
            }
        }
        return list;
    }

    private static void clearProjectiles(ItemStack itemStack) {
        NbtCompound nbtCompound = itemStack.getNbt();
        if (nbtCompound != null) {
            NbtList nbtList = nbtCompound.getList(CHARGED_PROJECTILES_KEY, 9);
            nbtList.clear();
            nbtCompound.put(CHARGED_PROJECTILES_KEY, nbtList);
        }
    }

    public static boolean hasProjectile(ItemStack itemStack2, Item item) {
        return CrossbowItem.getProjectiles(itemStack2).stream().anyMatch(itemStack -> itemStack.isOf(item));
    }

    private static void shoot(World world, LivingEntity livingEntity2, Hand hand, ItemStack itemStack, ItemStack itemStack2, float f, boolean bl, float g, float h, float i) {
        ProjectileEntity projectileEntity;
        if (world.isClient) {
            return;
        }
        boolean bl2 = itemStack2.isOf(Items.field_8639);
        if (bl2) {
            projectileEntity = new FireworkRocketEntity(world, itemStack2, livingEntity2, livingEntity2.getX(), livingEntity2.getEyeY() - (double)0.15f, livingEntity2.getZ(), true);
        } else {
            projectileEntity = CrossbowItem.createArrow(world, livingEntity2, itemStack, itemStack2);
            if (bl || i != 0.0f) {
                ((PersistentProjectileEntity)projectileEntity).pickupType = PersistentProjectileEntity.PickupPermission.field_7594;
            }
        }
        if (livingEntity2 instanceof CrossbowUser) {
            CrossbowUser crossbowUser = (CrossbowUser)((Object)livingEntity2);
            crossbowUser.shoot(crossbowUser.getTarget(), itemStack, projectileEntity, i);
        } else {
            Vec3d vec3d = livingEntity2.getOppositeRotationVector(1.0f);
            Quaternionf quaternionf = new Quaternionf().setAngleAxis((double)(i * ((float)Math.PI / 180)), vec3d.x, vec3d.y, vec3d.z);
            Vec3d vec3d2 = livingEntity2.getRotationVec(1.0f);
            Vector3f vector3f = vec3d2.toVector3f().rotate(quaternionf);
            projectileEntity.setVelocity(vector3f.x(), vector3f.y(), vector3f.z(), g, h);
        }
        itemStack.damage(bl2 ? 3 : 1, livingEntity2, livingEntity -> livingEntity.sendToolBreakStatus(hand));
        world.spawnEntity(projectileEntity);
        world.playSound(null, livingEntity2.getX(), livingEntity2.getY(), livingEntity2.getZ(), SoundEvents.field_15187, SoundCategory.field_15248, 1.0f, f);
    }

    private static PersistentProjectileEntity createArrow(World world, LivingEntity livingEntity, ItemStack itemStack, ItemStack itemStack2) {
        ArrowItem arrowItem = (ArrowItem)(itemStack2.getItem() instanceof ArrowItem ? itemStack2.getItem() : Items.field_8107);
        PersistentProjectileEntity persistentProjectileEntity = arrowItem.createArrow(world, itemStack2, livingEntity);
        if (livingEntity instanceof PlayerEntity) {
            persistentProjectileEntity.setCritical(true);
        }
        persistentProjectileEntity.setSound(SoundEvents.field_14636);
        persistentProjectileEntity.setShotFromCrossbow(true);
        int i = EnchantmentHelper.getLevel(Enchantments.field_9132, itemStack);
        if (i > 0) {
            persistentProjectileEntity.setPierceLevel((byte)i);
        }
        return persistentProjectileEntity;
    }

    public static void shootAll(World world, LivingEntity livingEntity, Hand hand, ItemStack itemStack, float f, float g) {
        List<ItemStack> list = CrossbowItem.getProjectiles(itemStack);
        float[] fs = CrossbowItem.getSoundPitches(livingEntity.getRandom());
        for (int i = 0; i < list.size(); ++i) {
            boolean bl;
            ItemStack itemStack2 = list.get(i);
            boolean bl2 = bl = livingEntity instanceof PlayerEntity && ((PlayerEntity)livingEntity).getAbilities().creativeMode;
            if (itemStack2.isEmpty()) continue;
            if (i == 0) {
                CrossbowItem.shoot(world, livingEntity, hand, itemStack, itemStack2, fs[i], bl, f, g, 0.0f);
                continue;
            }
            if (i == 1) {
                CrossbowItem.shoot(world, livingEntity, hand, itemStack, itemStack2, fs[i], bl, f, g, -10.0f);
                continue;
            }
            if (i != 2) continue;
            CrossbowItem.shoot(world, livingEntity, hand, itemStack, itemStack2, fs[i], bl, f, g, 10.0f);
        }
        CrossbowItem.postShoot(world, livingEntity, itemStack);
    }

    private static float[] getSoundPitches(Random random) {
        boolean bl = random.nextBoolean();
        return new float[]{1.0f, CrossbowItem.getSoundPitch(bl, random), CrossbowItem.getSoundPitch(!bl, random)};
    }

    private static float getSoundPitch(boolean bl, Random random) {
        float f = bl ? 0.63f : 0.43f;
        return 1.0f / (random.nextFloat() * 0.5f + 1.8f) + f;
    }

    private static void postShoot(World world, LivingEntity livingEntity, ItemStack itemStack) {
        if (livingEntity instanceof ServerPlayerEntity) {
            ServerPlayerEntity serverPlayerEntity = (ServerPlayerEntity)livingEntity;
            if (!world.isClient) {
                Criteria.SHOT_CROSSBOW.trigger(serverPlayerEntity, itemStack);
            }
            serverPlayerEntity.incrementStat(Stats.field_15372.getOrCreateStat(itemStack.getItem()));
        }
        CrossbowItem.clearProjectiles(itemStack);
    }

    @Override
    public void usageTick(World world, LivingEntity livingEntity, ItemStack itemStack, int i) {
        if (!world.isClient) {
            int j = EnchantmentHelper.getLevel(Enchantments.field_9098, itemStack);
            SoundEvent soundEvent = this.getQuickChargeSound(j);
            SoundEvent soundEvent2 = j == 0 ? SoundEvents.field_14860 : null;
            float f = (float)(itemStack.getMaxUseTime() - i) / (float)CrossbowItem.getPullTime(itemStack);
            if (f < 0.2f) {
                this.charged = false;
                this.loaded = false;
            }
            if (f >= 0.2f && !this.charged) {
                this.charged = true;
                world.playSound(null, livingEntity.getX(), livingEntity.getY(), livingEntity.getZ(), soundEvent, SoundCategory.field_15248, 0.5f, 1.0f);
            }
            if (f >= 0.5f && soundEvent2 != null && !this.loaded) {
                this.loaded = true;
                world.playSound(null, livingEntity.getX(), livingEntity.getY(), livingEntity.getZ(), soundEvent2, SoundCategory.field_15248, 0.5f, 1.0f);
            }
        }
    }

    @Override
    public int getMaxUseTime(ItemStack itemStack) {
        return CrossbowItem.getPullTime(itemStack) + 3;
    }

    public static int getPullTime(ItemStack itemStack) {
        int i = EnchantmentHelper.getLevel(Enchantments.field_9098, itemStack);
        return i == 0 ? 25 : 25 - 5 * i;
    }

    @Override
    public UseAction getUseAction(ItemStack itemStack) {
        return UseAction.field_8947;
    }

    private SoundEvent getQuickChargeSound(int i) {
        switch (i) {
            case 1: {
                return SoundEvents.field_15011;
            }
            case 2: {
                return SoundEvents.field_14916;
            }
            case 3: {
                return SoundEvents.field_15089;
            }
        }
        return SoundEvents.field_14765;
    }

    private static float getPullProgress(int i, ItemStack itemStack) {
        float f = (float)i / (float)CrossbowItem.getPullTime(itemStack);
        if (f > 1.0f) {
            f = 1.0f;
        }
        return f;
    }

    @Override
    public void appendTooltip(ItemStack itemStack, @Nullable World world, List<Text> list, TooltipContext tooltipContext) {
        List<ItemStack> list2 = CrossbowItem.getProjectiles(itemStack);
        if (!CrossbowItem.isCharged(itemStack) || list2.isEmpty()) {
            return;
        }
        ItemStack itemStack2 = list2.get(0);
        list.add(Text.translatable("item.minecraft.crossbow.projectile").append(ScreenTexts.SPACE).append(itemStack2.toHoverableText()));
        if (tooltipContext.isAdvanced() && itemStack2.isOf(Items.field_8639)) {
            ArrayList<Text> list3 = Lists.newArrayList();
            Items.field_8639.appendTooltip(itemStack2, world, list3, tooltipContext);
            if (!list3.isEmpty()) {
                for (int i = 0; i < list3.size(); ++i) {
                    list3.set(i, Text.literal("  ").append((Text)list3.get(i)).formatted(Formatting.field_1080));
                }
                list.addAll(list3);
            }
        }
    }

    @Override
    public boolean isUsedOnRelease(ItemStack itemStack) {
        return itemStack.isOf(this);
    }

    @Override
    public int getRange() {
        return 8;
    }
}


/*
 * Decompiled with CFR 0.2.1 (FabricMC 53fa44c9).
 */
package net.minecraft.block;

import java.util.List;
import net.minecraft.advancement.criterion.Criteria;
import net.minecraft.block.AbstractBlock;
import net.minecraft.block.Block;
import net.minecraft.block.BlockRenderType;
import net.minecraft.block.BlockState;
import net.minecraft.block.BlockWithEntity;
import net.minecraft.block.CampfireBlock;
import net.minecraft.block.FireBlock;
import net.minecraft.block.HorizontalFacingBlock;
import net.minecraft.block.entity.BeehiveBlockEntity;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.block.entity.BlockEntityTicker;
import net.minecraft.block.entity.BlockEntityType;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.enchantment.Enchantments;
import net.minecraft.entity.Entity;
import net.minecraft.entity.ItemEntity;
import net.minecraft.entity.TntEntity;
import net.minecraft.entity.boss.WitherEntity;
import net.minecraft.entity.mob.CreeperEntity;
import net.minecraft.entity.passive.BeeEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.projectile.WitherSkullEntity;
import net.minecraft.entity.vehicle.TntMinecartEntity;
import net.minecraft.item.BlockItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemPlacementContext;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.loot.context.LootContextParameterSet;
import net.minecraft.loot.context.LootContextParameters;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.registry.tag.BlockTags;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.stat.Stats;
import net.minecraft.state.StateManager;
import net.minecraft.state.property.DirectionProperty;
import net.minecraft.state.property.IntProperty;
import net.minecraft.state.property.Properties;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.random.Random;
import net.minecraft.util.shape.VoxelShape;
import net.minecraft.world.GameRules;
import net.minecraft.world.World;
import net.minecraft.world.WorldAccess;
import net.minecraft.world.event.GameEvent;
import org.jetbrains.annotations.Nullable;

public class BeehiveBlock
extends BlockWithEntity {
    public static final DirectionProperty FACING = HorizontalFacingBlock.FACING;
    public static final IntProperty HONEY_LEVEL = Properties.HONEY_LEVEL;
    public static final int FULL_HONEY_LEVEL = 5;
    private static final int DROPPED_HONEYCOMB_COUNT = 3;

    public BeehiveBlock(AbstractBlock.Settings settings) {
        super(settings);
        this.setDefaultState((BlockState)((BlockState)((BlockState)this.stateManager.getDefaultState()).with(HONEY_LEVEL, 0)).with(FACING, Direction.field_11043));
    }

    @Override
    public boolean hasComparatorOutput(BlockState blockState) {
        return true;
    }

    @Override
    public int getComparatorOutput(BlockState blockState, World world, BlockPos blockPos) {
        return blockState.get(HONEY_LEVEL);
    }

    @Override
    public void afterBreak(World world, PlayerEntity playerEntity, BlockPos blockPos, BlockState blockState, @Nullable BlockEntity blockEntity, ItemStack itemStack) {
        super.afterBreak(world, playerEntity, blockPos, blockState, blockEntity, itemStack);
        if (!world.isClient && blockEntity instanceof BeehiveBlockEntity) {
            BeehiveBlockEntity beehiveBlockEntity = (BeehiveBlockEntity)blockEntity;
            if (EnchantmentHelper.getLevel(Enchantments.field_9099, itemStack) == 0) {
                beehiveBlockEntity.angerBees(playerEntity, blockState, BeehiveBlockEntity.BeeState.field_21052);
                world.updateComparators(blockPos, this);
                this.angerNearbyBees(world, blockPos);
            }
            Criteria.BEE_NEST_DESTROYED.trigger((ServerPlayerEntity)playerEntity, blockState, itemStack, beehiveBlockEntity.getBeeCount());
        }
    }

    private void angerNearbyBees(World world, BlockPos blockPos) {
        List<BeeEntity> list = world.getNonSpectatingEntities(BeeEntity.class, new Box(blockPos).expand(8.0, 6.0, 8.0));
        if (!list.isEmpty()) {
            List<PlayerEntity> list2 = world.getNonSpectatingEntities(PlayerEntity.class, new Box(blockPos).expand(8.0, 6.0, 8.0));
            int i = list2.size();
            for (BeeEntity beeEntity : list) {
                if (beeEntity.getTarget() != null) continue;
                beeEntity.setTarget(list2.get(world.random.nextInt(i)));
            }
        }
    }

    public static void dropHoneycomb(World world, BlockPos blockPos) {
        BeehiveBlock.dropStack(world, blockPos, new ItemStack(Items.field_20414, 3));
    }

    @Override
    public ActionResult onUse(BlockState blockState, World world, BlockPos blockPos, PlayerEntity playerEntity2, Hand hand, BlockHitResult blockHitResult) {
        ItemStack itemStack = playerEntity2.getStackInHand(hand);
        int i = blockState.get(HONEY_LEVEL);
        boolean bl = false;
        if (i >= 5) {
            Item item = itemStack.getItem();
            if (itemStack.isOf(Items.field_8868)) {
                world.playSound(playerEntity2, playerEntity2.getX(), playerEntity2.getY(), playerEntity2.getZ(), SoundEvents.field_20611, SoundCategory.field_15245, 1.0f, 1.0f);
                BeehiveBlock.dropHoneycomb(world, blockPos);
                itemStack.damage(1, playerEntity2, playerEntity -> playerEntity.sendToolBreakStatus(hand));
                bl = true;
                world.emitGameEvent((Entity)playerEntity2, GameEvent.field_28730, blockPos);
            } else if (itemStack.isOf(Items.field_8469)) {
                itemStack.decrement(1);
                world.playSound(playerEntity2, playerEntity2.getX(), playerEntity2.getY(), playerEntity2.getZ(), SoundEvents.field_14779, SoundCategory.field_15245, 1.0f, 1.0f);
                if (itemStack.isEmpty()) {
                    playerEntity2.setStackInHand(hand, new ItemStack(Items.field_20417));
                } else if (!playerEntity2.getInventory().insertStack(new ItemStack(Items.field_20417))) {
                    playerEntity2.dropItem(new ItemStack(Items.field_20417), false);
                }
                bl = true;
                world.emitGameEvent((Entity)playerEntity2, GameEvent.field_28167, blockPos);
            }
            if (!world.isClient() && bl) {
                playerEntity2.incrementStat(Stats.field_15372.getOrCreateStat(item));
            }
        }
        if (bl) {
            if (!CampfireBlock.isLitCampfireInRange(world, blockPos)) {
                if (this.hasBees(world, blockPos)) {
                    this.angerNearbyBees(world, blockPos);
                }
                this.takeHoney(world, blockState, blockPos, playerEntity2, BeehiveBlockEntity.BeeState.field_21052);
            } else {
                this.takeHoney(world, blockState, blockPos);
            }
            return ActionResult.success(world.isClient);
        }
        return super.onUse(blockState, world, blockPos, playerEntity2, hand, blockHitResult);
    }

    private boolean hasBees(World world, BlockPos blockPos) {
        BlockEntity blockEntity = world.getBlockEntity(blockPos);
        if (blockEntity instanceof BeehiveBlockEntity) {
            BeehiveBlockEntity beehiveBlockEntity = (BeehiveBlockEntity)blockEntity;
            return !beehiveBlockEntity.hasNoBees();
        }
        return false;
    }

    public void takeHoney(World world, BlockState blockState, BlockPos blockPos, @Nullable PlayerEntity playerEntity, BeehiveBlockEntity.BeeState beeState) {
        this.takeHoney(world, blockState, blockPos);
        BlockEntity blockEntity = world.getBlockEntity(blockPos);
        if (blockEntity instanceof BeehiveBlockEntity) {
            BeehiveBlockEntity beehiveBlockEntity = (BeehiveBlockEntity)blockEntity;
            beehiveBlockEntity.angerBees(playerEntity, blockState, beeState);
        }
    }

    public void takeHoney(World world, BlockState blockState, BlockPos blockPos) {
        world.setBlockState(blockPos, (BlockState)blockState.with(HONEY_LEVEL, 0), 3);
    }

    @Override
    public void randomDisplayTick(BlockState blockState, World world, BlockPos blockPos, Random random) {
        if (blockState.get(HONEY_LEVEL) >= 5) {
            for (int i = 0; i < random.nextInt(1) + 1; ++i) {
                this.spawnHoneyParticles(world, blockPos, blockState);
            }
        }
    }

    private void spawnHoneyParticles(World world, BlockPos blockPos, BlockState blockState) {
        if (!blockState.getFluidState().isEmpty() || world.random.nextFloat() < 0.3f) {
            return;
        }
        VoxelShape voxelShape = blockState.getCollisionShape(world, blockPos);
        double d = voxelShape.getMax(Direction.Axis.field_11052);
        if (d >= 1.0 && !blockState.isIn(BlockTags.field_15490)) {
            double e = voxelShape.getMin(Direction.Axis.field_11052);
            if (e > 0.0) {
                this.addHoneyParticle(world, blockPos, voxelShape, (double)blockPos.getY() + e - 0.05);
            } else {
                BlockPos blockPos2 = blockPos.down();
                BlockState blockState2 = world.getBlockState(blockPos2);
                VoxelShape voxelShape2 = blockState2.getCollisionShape(world, blockPos2);
                double f = voxelShape2.getMax(Direction.Axis.field_11052);
                if ((f < 1.0 || !blockState2.isFullCube(world, blockPos2)) && blockState2.getFluidState().isEmpty()) {
                    this.addHoneyParticle(world, blockPos, voxelShape, (double)blockPos.getY() - 0.05);
                }
            }
        }
    }

    private void addHoneyParticle(World world, BlockPos blockPos, VoxelShape voxelShape, double d) {
        this.addHoneyParticle(world, (double)blockPos.getX() + voxelShape.getMin(Direction.Axis.field_11048), (double)blockPos.getX() + voxelShape.getMax(Direction.Axis.field_11048), (double)blockPos.getZ() + voxelShape.getMin(Direction.Axis.field_11051), (double)blockPos.getZ() + voxelShape.getMax(Direction.Axis.field_11051), d);
    }

    private void addHoneyParticle(World world, double d, double e, double f, double g, double h) {
        world.addParticle(ParticleTypes.field_20534, MathHelper.lerp(world.random.nextDouble(), d, e), h, MathHelper.lerp(world.random.nextDouble(), f, g), 0.0, 0.0, 0.0);
    }

    @Override
    public BlockState getPlacementState(ItemPlacementContext itemPlacementContext) {
        return (BlockState)this.getDefaultState().with(FACING, itemPlacementContext.getHorizontalPlayerFacing().getOpposite());
    }

    @Override
    protected void appendProperties(StateManager.Builder<Block, BlockState> builder) {
        builder.add(HONEY_LEVEL, FACING);
    }

    @Override
    public BlockRenderType getRenderType(BlockState blockState) {
        return BlockRenderType.field_11458;
    }

    @Override
    @Nullable
    public BlockEntity createBlockEntity(BlockPos blockPos, BlockState blockState) {
        return new BeehiveBlockEntity(blockPos, blockState);
    }

    @Override
    @Nullable
    public <T extends BlockEntity> BlockEntityTicker<T> getTicker(World world, BlockState blockState, BlockEntityType<T> blockEntityType) {
        return world.isClient ? null : BeehiveBlock.checkType(blockEntityType, BlockEntityType.field_20431, BeehiveBlockEntity::serverTick);
    }

    @Override
    public void onBreak(World world, BlockPos blockPos, BlockState blockState, PlayerEntity playerEntity) {
        BlockEntity blockEntity;
        if (!world.isClient && playerEntity.isCreative() && world.getGameRules().getBoolean(GameRules.DO_TILE_DROPS) && (blockEntity = world.getBlockEntity(blockPos)) instanceof BeehiveBlockEntity) {
            boolean bl;
            BeehiveBlockEntity beehiveBlockEntity = (BeehiveBlockEntity)blockEntity;
            ItemStack itemStack = new ItemStack(this);
            int i = blockState.get(HONEY_LEVEL);
            boolean bl2 = bl = !beehiveBlockEntity.hasNoBees();
            if (bl || i > 0) {
                NbtCompound nbtCompound;
                if (bl) {
                    nbtCompound = new NbtCompound();
                    nbtCompound.put("Bees", beehiveBlockEntity.getBees());
                    BlockItem.setBlockEntityNbt(itemStack, BlockEntityType.field_20431, nbtCompound);
                }
                nbtCompound = new NbtCompound();
                nbtCompound.putInt("honey_level", i);
                itemStack.setSubNbt("BlockStateTag", nbtCompound);
                ItemEntity itemEntity = new ItemEntity(world, blockPos.getX(), blockPos.getY(), blockPos.getZ(), itemStack);
                itemEntity.setToDefaultPickupDelay();
                world.spawnEntity(itemEntity);
            }
        }
        super.onBreak(world, blockPos, blockState, playerEntity);
    }

    @Override
    public List<ItemStack> getDroppedStacks(BlockState blockState, LootContextParameterSet.Builder builder) {
        BlockEntity blockEntity;
        Entity entity = builder.getOptional(LootContextParameters.field_1226);
        if ((entity instanceof TntEntity || entity instanceof CreeperEntity || entity instanceof WitherSkullEntity || entity instanceof WitherEntity || entity instanceof TntMinecartEntity) && (blockEntity = builder.getOptional(LootContextParameters.field_1228)) instanceof BeehiveBlockEntity) {
            BeehiveBlockEntity beehiveBlockEntity = (BeehiveBlockEntity)blockEntity;
            beehiveBlockEntity.angerBees(null, blockState, BeehiveBlockEntity.BeeState.field_21052);
        }
        return super.getDroppedStacks(blockState, builder);
    }

    @Override
    public BlockState getStateForNeighborUpdate(BlockState blockState, Direction direction, BlockState blockState2, WorldAccess worldAccess, BlockPos blockPos, BlockPos blockPos2) {
        BlockEntity blockEntity;
        if (worldAccess.getBlockState(blockPos2).getBlock() instanceof FireBlock && (blockEntity = worldAccess.getBlockEntity(blockPos)) instanceof BeehiveBlockEntity) {
            BeehiveBlockEntity beehiveBlockEntity = (BeehiveBlockEntity)blockEntity;
            beehiveBlockEntity.angerBees(null, blockState, BeehiveBlockEntity.BeeState.field_21052);
        }
        return super.getStateForNeighborUpdate(blockState, direction, blockState2, worldAccess, blockPos, blockPos2);
    }
}


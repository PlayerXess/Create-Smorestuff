/*
 * Decompiled with CFR 0.2.1 (FabricMC 53fa44c9).
 */
package net.minecraft.item;

import com.mojang.datafixers.kinds.Applicative;
import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.sound.SoundEvent;
import net.minecraft.util.dynamic.Codecs;

public record Instrument(RegistryEntry<SoundEvent> comp_772, int comp_773, float comp_774) {
    public static final Codec<Instrument> CODEC = RecordCodecBuilder.create(instance -> instance.group(((MapCodec)SoundEvent.ENTRY_CODEC.fieldOf("sound_event")).forGetter(Instrument::comp_772), ((MapCodec)Codecs.POSITIVE_INT.fieldOf("use_duration")).forGetter(Instrument::comp_773), ((MapCodec)Codecs.POSITIVE_FLOAT.fieldOf("range")).forGetter(Instrument::comp_774)).apply((Applicative<Instrument, ?>)instance, Instrument::new));
}


/*
 * Decompiled with CFR 0.2.1 (FabricMC 53fa44c9).
 */
package net.minecraft.world;

import com.google.common.collect.Lists;
import com.mojang.serialization.Codec;
import io.github.fabricators_of_create.porting_lib.entity.extensions.LevelExtensions;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Predicate;
import java.util.function.Supplier;
import net.minecraft.block.AbstractFireBlock;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.boss.dragon.EnderDragonEntity;
import net.minecraft.entity.boss.dragon.EnderDragonPart;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.damage.DamageSources;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.fluid.FluidState;
import net.minecraft.fluid.Fluids;
import net.minecraft.item.ItemStack;
import net.minecraft.item.map.MapState;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.network.packet.Packet;
import net.minecraft.particle.ParticleEffect;
import net.minecraft.recipe.RecipeManager;
import net.minecraft.registry.DynamicRegistryManager;
import net.minecraft.registry.Registries;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.scoreboard.Scoreboard;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.world.ChunkLevelType;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvent;
import net.minecraft.util.Identifier;
import net.minecraft.util.TypeFilter;
import net.minecraft.util.crash.CrashException;
import net.minecraft.util.crash.CrashReport;
import net.minecraft.util.crash.CrashReportSection;
import net.minecraft.util.function.LazyIterationConsumer;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.util.math.ChunkSectionPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.math.random.Random;
import net.minecraft.util.profiler.Profiler;
import net.minecraft.world.BlockView;
import net.minecraft.world.GameRules;
import net.minecraft.world.Heightmap;
import net.minecraft.world.LocalDifficulty;
import net.minecraft.world.MutableWorldProperties;
import net.minecraft.world.WorldAccess;
import net.minecraft.world.WorldProperties;
import net.minecraft.world.biome.Biome;
import net.minecraft.world.biome.source.BiomeAccess;
import net.minecraft.world.block.ChainRestrictedNeighborUpdater;
import net.minecraft.world.block.NeighborUpdater;
import net.minecraft.world.border.WorldBorder;
import net.minecraft.world.chunk.BlockEntityTickInvoker;
import net.minecraft.world.chunk.Chunk;
import net.minecraft.world.chunk.ChunkStatus;
import net.minecraft.world.chunk.WorldChunk;
import net.minecraft.world.chunk.light.LightingProvider;
import net.minecraft.world.dimension.DimensionType;
import net.minecraft.world.entity.EntityLookup;
import net.minecraft.world.event.GameEvent;
import net.minecraft.world.explosion.Explosion;
import net.minecraft.world.explosion.ExplosionBehavior;
import org.jetbrains.annotations.Nullable;

public abstract class World
implements WorldAccess,
AutoCloseable,
LevelExtensions,
io.github.fabricators_of_create.porting_lib.extensions.extensions.LevelExtensions {
    public static final Codec<RegistryKey<World>> CODEC = RegistryKey.createCodec(RegistryKeys.WORLD);
    public static final RegistryKey<World> OVERWORLD = RegistryKey.of(RegistryKeys.WORLD, new Identifier("overworld"));
    public static final RegistryKey<World> NETHER = RegistryKey.of(RegistryKeys.WORLD, new Identifier("the_nether"));
    public static final RegistryKey<World> END = RegistryKey.of(RegistryKeys.WORLD, new Identifier("the_end"));
    public static final int HORIZONTAL_LIMIT = 30000000;
    public static final int MAX_UPDATE_DEPTH = 512;
    public static final int field_30967 = 32;
    public static final int field_30968 = 15;
    public static final int field_30969 = 24000;
    public static final int MAX_Y = 20000000;
    public static final int MIN_Y = -20000000;
    protected final List<BlockEntityTickInvoker> blockEntityTickers = Lists.newArrayList();
    protected final NeighborUpdater neighborUpdater;
    private final List<BlockEntityTickInvoker> pendingBlockEntityTickers = Lists.newArrayList();
    private boolean iteratingTickingBlockEntities;
    private final Thread thread;
    private final boolean debugWorld;
    private int ambientDarkness;
    protected int lcgBlockSeed = Random.create().nextInt();
    protected final int lcgBlockSeedIncrement = 1013904223;
    protected float rainGradientPrev;
    protected float rainGradient;
    protected float thunderGradientPrev;
    protected float thunderGradient;
    public final Random random = Random.create();
    @Deprecated
    private final Random threadSafeRandom = Random.createThreadSafe();
    private final RegistryKey<DimensionType> dimension;
    private final RegistryEntry<DimensionType> dimensionEntry;
    protected final MutableWorldProperties properties;
    private final Supplier<Profiler> profiler;
    public final boolean isClient;
    private final WorldBorder border;
    private final BiomeAccess biomeAccess;
    private final RegistryKey<World> registryKey;
    private final DynamicRegistryManager registryManager;
    private final DamageSources damageSources;
    private long tickOrder;

    protected World(MutableWorldProperties mutableWorldProperties, RegistryKey<World> registryKey, DynamicRegistryManager dynamicRegistryManager, RegistryEntry<DimensionType> registryEntry, Supplier<Profiler> supplier, boolean bl, boolean bl2, long l, int i) {
        this.profiler = supplier;
        this.properties = mutableWorldProperties;
        this.dimensionEntry = registryEntry;
        this.dimension = registryEntry.getKey().orElseThrow(() -> new IllegalArgumentException("Dimension must be registered, got " + registryEntry));
        final DimensionType dimensionType = registryEntry.comp_349();
        this.registryKey = registryKey;
        this.isClient = bl;
        this.border = dimensionType.comp_646() != 1.0 ? new WorldBorder(){

            @Override
            public double getCenterX() {
                return super.getCenterX() / dimensionType.comp_646();
            }

            @Override
            public double getCenterZ() {
                return super.getCenterZ() / dimensionType.comp_646();
            }
        } : new WorldBorder();
        this.thread = Thread.currentThread();
        this.biomeAccess = new BiomeAccess(this, l);
        this.debugWorld = bl2;
        this.neighborUpdater = new ChainRestrictedNeighborUpdater(this, i);
        this.registryManager = dynamicRegistryManager;
        this.damageSources = new DamageSources(dynamicRegistryManager);
    }

    @Override
    public boolean isClient() {
        return this.isClient;
    }

    @Override
    @Nullable
    public MinecraftServer getServer() {
        return null;
    }

    public boolean isInBuildLimit(BlockPos blockPos) {
        return !this.isOutOfHeightLimit(blockPos) && World.isValidHorizontally(blockPos);
    }

    public static boolean isValid(BlockPos blockPos) {
        return !World.isInvalidVertically(blockPos.getY()) && World.isValidHorizontally(blockPos);
    }

    private static boolean isValidHorizontally(BlockPos blockPos) {
        return blockPos.getX() >= -30000000 && blockPos.getZ() >= -30000000 && blockPos.getX() < 30000000 && blockPos.getZ() < 30000000;
    }

    private static boolean isInvalidVertically(int i) {
        return i < -20000000 || i >= 20000000;
    }

    public WorldChunk getWorldChunk(BlockPos blockPos) {
        return this.getChunk(ChunkSectionPos.getSectionCoord(blockPos.getX()), ChunkSectionPos.getSectionCoord(blockPos.getZ()));
    }

    @Override
    public WorldChunk getChunk(int i, int j) {
        return (WorldChunk)this.getChunk(i, j, ChunkStatus.field_12803);
    }

    @Override
    @Nullable
    public Chunk getChunk(int i, int j, ChunkStatus chunkStatus, boolean bl) {
        Chunk chunk = this.getChunkManager().getChunk(i, j, chunkStatus, bl);
        if (chunk == null && bl) {
            throw new IllegalStateException("Should always be able to create a chunk!");
        }
        return chunk;
    }

    @Override
    public boolean setBlockState(BlockPos blockPos, BlockState blockState, int i) {
        return this.setBlockState(blockPos, blockState, i, 512);
    }

    @Override
    public boolean setBlockState(BlockPos blockPos, BlockState blockState, int i, int j) {
        if (this.isOutOfHeightLimit(blockPos)) {
            return false;
        }
        if (!this.isClient && this.isDebugWorld()) {
            return false;
        }
        WorldChunk worldChunk = this.getWorldChunk(blockPos);
        Block block = blockState.getBlock();
        BlockState blockState2 = worldChunk.setBlockState(blockPos, blockState, (i & 0x40) != 0);
        if (blockState2 != null) {
            BlockState blockState3 = this.getBlockState(blockPos);
            if (blockState3 == blockState) {
                if (blockState2 != blockState3) {
                    this.scheduleBlockRerenderIfNeeded(blockPos, blockState2, blockState3);
                }
                if ((i & 2) != 0 && (!this.isClient || (i & 4) == 0) && (this.isClient || worldChunk.getLevelType() != null && worldChunk.getLevelType().isAfter(ChunkLevelType.field_44856))) {
                    this.updateListeners(blockPos, blockState2, blockState, i);
                }
                if ((i & 1) != 0) {
                    this.updateNeighbors(blockPos, blockState2.getBlock());
                    if (!this.isClient && blockState.hasComparatorOutput()) {
                        this.updateComparators(blockPos, block);
                    }
                }
                if ((i & 0x10) == 0 && j > 0) {
                    int k = i & 0xFFFFFFDE;
                    blockState2.prepare(this, blockPos, k, j - 1);
                    blockState.updateNeighbors(this, blockPos, k, j - 1);
                    blockState.prepare(this, blockPos, k, j - 1);
                }
                this.onBlockChanged(blockPos, blockState2, blockState3);
            }
            return true;
        }
        return false;
    }

    public void onBlockChanged(BlockPos blockPos, BlockState blockState, BlockState blockState2) {
    }

    @Override
    public boolean removeBlock(BlockPos blockPos, boolean bl) {
        FluidState fluidState = this.getFluidState(blockPos);
        return this.setBlockState(blockPos, fluidState.getBlockState(), 3 | (bl ? 64 : 0));
    }

    @Override
    public boolean breakBlock(BlockPos blockPos, boolean bl, @Nullable Entity entity, int i) {
        boolean bl2;
        BlockState blockState = this.getBlockState(blockPos);
        if (blockState.isAir()) {
            return false;
        }
        FluidState fluidState = this.getFluidState(blockPos);
        if (!(blockState.getBlock() instanceof AbstractFireBlock)) {
            this.syncWorldEvent(2001, blockPos, Block.getRawIdFromState(blockState));
        }
        if (bl) {
            BlockEntity blockEntity = blockState.hasBlockEntity() ? this.getBlockEntity(blockPos) : null;
            Block.dropStacks(blockState, this, blockPos, blockEntity, entity, ItemStack.EMPTY);
        }
        if (bl2 = this.setBlockState(blockPos, fluidState.getBlockState(), 3, i)) {
            this.emitGameEvent(GameEvent.field_28165, blockPos, GameEvent.Emitter.of(entity, blockState));
        }
        return bl2;
    }

    public void addBlockBreakParticles(BlockPos blockPos, BlockState blockState) {
    }

    public boolean setBlockState(BlockPos blockPos, BlockState blockState) {
        return this.setBlockState(blockPos, blockState, 3);
    }

    public abstract void updateListeners(BlockPos var1, BlockState var2, BlockState var3, int var4);

    public void scheduleBlockRerenderIfNeeded(BlockPos blockPos, BlockState blockState, BlockState blockState2) {
    }

    public void updateNeighborsAlways(BlockPos blockPos, Block block) {
    }

    public void updateNeighborsExcept(BlockPos blockPos, Block block, Direction direction) {
    }

    public void updateNeighbor(BlockPos blockPos, Block block, BlockPos blockPos2) {
    }

    public void updateNeighbor(BlockState blockState, BlockPos blockPos, Block block, BlockPos blockPos2, boolean bl) {
    }

    @Override
    public void replaceWithStateForNeighborUpdate(Direction direction, BlockState blockState, BlockPos blockPos, BlockPos blockPos2, int i, int j) {
        this.neighborUpdater.replaceWithStateForNeighborUpdate(direction, blockState, blockPos, blockPos2, i, j);
    }

    @Override
    public int getTopY(Heightmap.Type type, int i, int j) {
        int k = i < -30000000 || j < -30000000 || i >= 30000000 || j >= 30000000 ? this.getSeaLevel() + 1 : (this.isChunkLoaded(ChunkSectionPos.getSectionCoord(i), ChunkSectionPos.getSectionCoord(j)) ? this.getChunk(ChunkSectionPos.getSectionCoord(i), ChunkSectionPos.getSectionCoord(j)).sampleHeightmap(type, i & 0xF, j & 0xF) + 1 : this.getBottomY());
        return k;
    }

    @Override
    public LightingProvider getLightingProvider() {
        return this.getChunkManager().getLightingProvider();
    }

    @Override
    public BlockState getBlockState(BlockPos blockPos) {
        if (this.isOutOfHeightLimit(blockPos)) {
            return Blocks.field_10243.getDefaultState();
        }
        WorldChunk worldChunk = this.getChunk(ChunkSectionPos.getSectionCoord(blockPos.getX()), ChunkSectionPos.getSectionCoord(blockPos.getZ()));
        return worldChunk.getBlockState(blockPos);
    }

    @Override
    public FluidState getFluidState(BlockPos blockPos) {
        if (this.isOutOfHeightLimit(blockPos)) {
            return Fluids.field_15906.getDefaultState();
        }
        WorldChunk worldChunk = this.getWorldChunk(blockPos);
        return worldChunk.getFluidState(blockPos);
    }

    public boolean isDay() {
        return !this.getDimension().hasFixedTime() && this.ambientDarkness < 4;
    }

    public boolean isNight() {
        return !this.getDimension().hasFixedTime() && !this.isDay();
    }

    public void playSound(@Nullable Entity entity, BlockPos blockPos, SoundEvent soundEvent, SoundCategory soundCategory, float f, float g) {
        PlayerEntity playerEntity;
        this.playSound(entity instanceof PlayerEntity ? (playerEntity = (PlayerEntity)entity) : null, blockPos, soundEvent, soundCategory, f, g);
    }

    @Override
    public void playSound(@Nullable PlayerEntity playerEntity, BlockPos blockPos, SoundEvent soundEvent, SoundCategory soundCategory, float f, float g) {
        this.playSound(playerEntity, (double)blockPos.getX() + 0.5, (double)blockPos.getY() + 0.5, (double)blockPos.getZ() + 0.5, soundEvent, soundCategory, f, g);
    }

    public abstract void playSound(@Nullable PlayerEntity var1, double var2, double var4, double var6, RegistryEntry<SoundEvent> var8, SoundCategory var9, float var10, float var11, long var12);

    public void playSound(@Nullable PlayerEntity playerEntity, double d, double e, double f, SoundEvent soundEvent, SoundCategory soundCategory, float g, float h, long l) {
        this.playSound(playerEntity, d, e, f, Registries.SOUND_EVENT.getEntry(soundEvent), soundCategory, g, h, l);
    }

    public abstract void playSoundFromEntity(@Nullable PlayerEntity var1, Entity var2, RegistryEntry<SoundEvent> var3, SoundCategory var4, float var5, float var6, long var7);

    public void playSound(@Nullable PlayerEntity playerEntity, double d, double e, double f, SoundEvent soundEvent, SoundCategory soundCategory, float g, float h) {
        this.playSound(playerEntity, d, e, f, soundEvent, soundCategory, g, h, this.threadSafeRandom.nextLong());
    }

    public void playSoundFromEntity(@Nullable PlayerEntity playerEntity, Entity entity, SoundEvent soundEvent, SoundCategory soundCategory, float f, float g) {
        this.playSoundFromEntity(playerEntity, entity, Registries.SOUND_EVENT.getEntry(soundEvent), soundCategory, f, g, this.threadSafeRandom.nextLong());
    }

    public void playSoundAtBlockCenter(BlockPos blockPos, SoundEvent soundEvent, SoundCategory soundCategory, float f, float g, boolean bl) {
        this.playSound((double)blockPos.getX() + 0.5, (double)blockPos.getY() + 0.5, (double)blockPos.getZ() + 0.5, soundEvent, soundCategory, f, g, bl);
    }

    public void playSound(double d, double e, double f, SoundEvent soundEvent, SoundCategory soundCategory, float g, float h, boolean bl) {
    }

    @Override
    public void addParticle(ParticleEffect particleEffect, double d, double e, double f, double g, double h, double i) {
    }

    public void addParticle(ParticleEffect particleEffect, boolean bl, double d, double e, double f, double g, double h, double i) {
    }

    public void addImportantParticle(ParticleEffect particleEffect, double d, double e, double f, double g, double h, double i) {
    }

    public void addImportantParticle(ParticleEffect particleEffect, boolean bl, double d, double e, double f, double g, double h, double i) {
    }

    public float getSkyAngleRadians(float f) {
        float g = this.getSkyAngle(f);
        return g * ((float)Math.PI * 2);
    }

    public void addBlockEntityTicker(BlockEntityTickInvoker blockEntityTickInvoker) {
        (this.iteratingTickingBlockEntities ? this.pendingBlockEntityTickers : this.blockEntityTickers).add(blockEntityTickInvoker);
    }

    protected void tickBlockEntities() {
        Profiler profiler = this.getProfiler();
        profiler.push("blockEntities");
        this.iteratingTickingBlockEntities = true;
        if (!this.pendingBlockEntityTickers.isEmpty()) {
            this.blockEntityTickers.addAll(this.pendingBlockEntityTickers);
            this.pendingBlockEntityTickers.clear();
        }
        Iterator<BlockEntityTickInvoker> iterator = this.blockEntityTickers.iterator();
        while (iterator.hasNext()) {
            BlockEntityTickInvoker blockEntityTickInvoker = iterator.next();
            if (blockEntityTickInvoker.isRemoved()) {
                iterator.remove();
                continue;
            }
            if (!this.shouldTickBlockPos(blockEntityTickInvoker.getPos())) continue;
            blockEntityTickInvoker.tick();
        }
        this.iteratingTickingBlockEntities = false;
        profiler.pop();
    }

    public <T extends Entity> void tickEntity(Consumer<T> consumer, T entity) {
        try {
            consumer.accept(entity);
        } catch (Throwable throwable) {
            CrashReport crashReport = CrashReport.create(throwable, "Ticking entity");
            CrashReportSection crashReportSection = crashReport.addElement("Entity being ticked");
            entity.populateCrashReport(crashReportSection);
            throw new CrashException(crashReport);
        }
    }

    public boolean shouldUpdatePostDeath(Entity entity) {
        return true;
    }

    public boolean shouldTickBlocksInChunk(long l) {
        return true;
    }

    public boolean shouldTickBlockPos(BlockPos blockPos) {
        return this.shouldTickBlocksInChunk(ChunkPos.toLong(blockPos));
    }

    public Explosion createExplosion(@Nullable Entity entity, double d, double e, double f, float g, ExplosionSourceType explosionSourceType) {
        return this.createExplosion(entity, null, null, d, e, f, g, false, explosionSourceType);
    }

    public Explosion createExplosion(@Nullable Entity entity, double d, double e, double f, float g, boolean bl, ExplosionSourceType explosionSourceType) {
        return this.createExplosion(entity, null, null, d, e, f, g, bl, explosionSourceType);
    }

    public Explosion createExplosion(@Nullable Entity entity, @Nullable DamageSource damageSource, @Nullable ExplosionBehavior explosionBehavior, Vec3d vec3d, float f, boolean bl, ExplosionSourceType explosionSourceType) {
        return this.createExplosion(entity, damageSource, explosionBehavior, vec3d.getX(), vec3d.getY(), vec3d.getZ(), f, bl, explosionSourceType);
    }

    public Explosion createExplosion(@Nullable Entity entity, @Nullable DamageSource damageSource, @Nullable ExplosionBehavior explosionBehavior, double d, double e, double f, float g, boolean bl, ExplosionSourceType explosionSourceType) {
        return this.createExplosion(entity, damageSource, explosionBehavior, d, e, f, g, bl, explosionSourceType, true);
    }

    public Explosion createExplosion(@Nullable Entity entity, @Nullable DamageSource damageSource, @Nullable ExplosionBehavior explosionBehavior, double d, double e, double f, float g, boolean bl, ExplosionSourceType explosionSourceType, boolean bl2) {
        Explosion.DestructionType destructionType = switch (explosionSourceType) {
            default -> throw new IncompatibleClassChangeError();
            case ExplosionSourceType.field_40888 -> Explosion.DestructionType.field_40878;
            case ExplosionSourceType.field_40889 -> this.getDestructionType(GameRules.field_40880);
            case ExplosionSourceType.field_40890 -> {
                if (this.getGameRules().getBoolean(GameRules.DO_MOB_GRIEFING)) {
                    yield this.getDestructionType(GameRules.field_40881);
                }
                yield Explosion.DestructionType.field_40878;
            }
            case ExplosionSourceType.field_40891 -> this.getDestructionType(GameRules.field_40882);
        };
        Explosion explosion = new Explosion(this, entity, damageSource, explosionBehavior, d, e, f, g, bl, destructionType);
        explosion.collectBlocksAndDamageEntities();
        explosion.affectWorld(bl2);
        return explosion;
    }

    private Explosion.DestructionType getDestructionType(GameRules.Key<GameRules.BooleanRule> key) {
        return this.getGameRules().getBoolean(key) ? Explosion.DestructionType.field_40879 : Explosion.DestructionType.field_18687;
    }

    public abstract String asString();

    @Override
    @Nullable
    public BlockEntity getBlockEntity(BlockPos blockPos) {
        if (this.isOutOfHeightLimit(blockPos)) {
            return null;
        }
        if (!this.isClient && Thread.currentThread() != this.thread) {
            return null;
        }
        return this.getWorldChunk(blockPos).getBlockEntity(blockPos, WorldChunk.CreationType.field_12860);
    }

    public void addBlockEntity(BlockEntity blockEntity) {
        BlockPos blockPos = blockEntity.getPos();
        if (this.isOutOfHeightLimit(blockPos)) {
            return;
        }
        this.getWorldChunk(blockPos).addBlockEntity(blockEntity);
    }

    public void removeBlockEntity(BlockPos blockPos) {
        if (this.isOutOfHeightLimit(blockPos)) {
            return;
        }
        this.getWorldChunk(blockPos).removeBlockEntity(blockPos);
    }

    public boolean canSetBlock(BlockPos blockPos) {
        if (this.isOutOfHeightLimit(blockPos)) {
            return false;
        }
        return this.getChunkManager().isChunkLoaded(ChunkSectionPos.getSectionCoord(blockPos.getX()), ChunkSectionPos.getSectionCoord(blockPos.getZ()));
    }

    public boolean isDirectionSolid(BlockPos blockPos, Entity entity, Direction direction) {
        if (this.isOutOfHeightLimit(blockPos)) {
            return false;
        }
        Chunk chunk = this.getChunk(ChunkSectionPos.getSectionCoord(blockPos.getX()), ChunkSectionPos.getSectionCoord(blockPos.getZ()), ChunkStatus.field_12803, false);
        if (chunk == null) {
            return false;
        }
        return chunk.getBlockState(blockPos).isSolidSurface(this, blockPos, entity, direction);
    }

    public boolean isTopSolid(BlockPos blockPos, Entity entity) {
        return this.isDirectionSolid(blockPos, entity, Direction.field_11036);
    }

    public void calculateAmbientDarkness() {
        double d = 1.0 - (double)(this.getRainGradient(1.0f) * 5.0f) / 16.0;
        double e = 1.0 - (double)(this.getThunderGradient(1.0f) * 5.0f) / 16.0;
        double f = 0.5 + 2.0 * MathHelper.clamp((double)MathHelper.cos(this.getSkyAngle(1.0f) * ((float)Math.PI * 2)), -0.25, 0.25);
        this.ambientDarkness = (int)((1.0 - f * d * e) * 11.0);
    }

    public void setMobSpawnOptions(boolean bl, boolean bl2) {
        this.getChunkManager().setMobSpawnOptions(bl, bl2);
    }

    public BlockPos getSpawnPos() {
        BlockPos blockPos = new BlockPos(this.properties.getSpawnX(), this.properties.getSpawnY(), this.properties.getSpawnZ());
        if (!this.getWorldBorder().contains(blockPos)) {
            blockPos = this.getTopPosition(Heightmap.Type.field_13197, BlockPos.ofFloored(this.getWorldBorder().getCenterX(), 0.0, this.getWorldBorder().getCenterZ()));
        }
        return blockPos;
    }

    public float getSpawnAngle() {
        return this.properties.getSpawnAngle();
    }

    protected void initWeatherGradients() {
        if (this.properties.isRaining()) {
            this.rainGradient = 1.0f;
            if (this.properties.isThundering()) {
                this.thunderGradient = 1.0f;
            }
        }
    }

    @Override
    public void close() throws IOException {
        this.getChunkManager().close();
    }

    @Override
    @Nullable
    public BlockView getChunkAsView(int i, int j) {
        return this.getChunk(i, j, ChunkStatus.field_12803, false);
    }

    @Override
    public List<Entity> getOtherEntities(@Nullable Entity entity, Box box, Predicate<? super Entity> predicate) {
        this.getProfiler().visit("getEntities");
        ArrayList<Entity> list = Lists.newArrayList();
        this.getEntityLookup().forEachIntersects(box, entity2 -> {
            if (entity2 != entity && predicate.test((Entity)entity2)) {
                list.add((Entity)entity2);
            }
            if (entity2 instanceof EnderDragonEntity) {
                for (EnderDragonPart enderDragonPart : ((EnderDragonEntity)entity2).getBodyParts()) {
                    if (entity2 == entity || !predicate.test(enderDragonPart)) continue;
                    list.add(enderDragonPart);
                }
            }
        });
        return list;
    }

    @Override
    public <T extends Entity> List<T> getEntitiesByType(TypeFilter<Entity, T> typeFilter, Box box, Predicate<? super T> predicate) {
        ArrayList list = Lists.newArrayList();
        this.collectEntitiesByType(typeFilter, box, predicate, list);
        return list;
    }

    public <T extends Entity> void collectEntitiesByType(TypeFilter<Entity, T> typeFilter, Box box, Predicate<? super T> predicate, List<? super T> list) {
        this.collectEntitiesByType(typeFilter, box, predicate, list, Integer.MAX_VALUE);
    }

    public <T extends Entity> void collectEntitiesByType(TypeFilter<Entity, T> typeFilter, Box box, Predicate<? super T> predicate, List<? super T> list, int i) {
        this.getProfiler().visit("getEntities");
        this.getEntityLookup().forEachIntersects(typeFilter, box, entity -> {
            if (predicate.test(entity)) {
                list.add((Object)entity);
                if (list.size() >= i) {
                    return LazyIterationConsumer.NextIteration.field_41284;
                }
            }
            if (entity instanceof EnderDragonEntity) {
                EnderDragonEntity enderDragonEntity = (EnderDragonEntity)entity;
                for (EnderDragonPart enderDragonPart : enderDragonEntity.getBodyParts()) {
                    Entity entity2 = (Entity)typeFilter.downcast(enderDragonPart);
                    if (entity2 == null || !predicate.test(entity2)) continue;
                    list.add((Object)entity2);
                    if (list.size() < i) continue;
                    return LazyIterationConsumer.NextIteration.field_41284;
                }
            }
            return LazyIterationConsumer.NextIteration.field_41283;
        });
    }

    @Nullable
    public abstract Entity getEntityById(int var1);

    public void markDirty(BlockPos blockPos) {
        if (this.isChunkLoaded(blockPos)) {
            this.getWorldChunk(blockPos).setNeedsSaving(true);
        }
    }

    @Override
    public int getSeaLevel() {
        return 63;
    }

    public void disconnect() {
    }

    public long getTime() {
        return this.properties.getTime();
    }

    public long getTimeOfDay() {
        return this.properties.getTimeOfDay();
    }

    public boolean canPlayerModifyAt(PlayerEntity playerEntity, BlockPos blockPos) {
        return true;
    }

    public void sendEntityStatus(Entity entity, byte b) {
    }

    public void sendEntityDamage(Entity entity, DamageSource damageSource) {
    }

    public void addSyncedBlockEvent(BlockPos blockPos, Block block, int i, int j) {
        this.getBlockState(blockPos).onSyncedBlockEvent(this, blockPos, i, j);
    }

    @Override
    public WorldProperties getLevelProperties() {
        return this.properties;
    }

    public GameRules getGameRules() {
        return this.properties.getGameRules();
    }

    public float getThunderGradient(float f) {
        return MathHelper.lerp(f, this.thunderGradientPrev, this.thunderGradient) * this.getRainGradient(f);
    }

    public void setThunderGradient(float f) {
        float g;
        this.thunderGradientPrev = g = MathHelper.clamp(f, 0.0f, 1.0f);
        this.thunderGradient = g;
    }

    public float getRainGradient(float f) {
        return MathHelper.lerp(f, this.rainGradientPrev, this.rainGradient);
    }

    public void setRainGradient(float f) {
        float g;
        this.rainGradientPrev = g = MathHelper.clamp(f, 0.0f, 1.0f);
        this.rainGradient = g;
    }

    public boolean isThundering() {
        if (!this.getDimension().comp_642() || this.getDimension().comp_643()) {
            return false;
        }
        return (double)this.getThunderGradient(1.0f) > 0.9;
    }

    public boolean isRaining() {
        return (double)this.getRainGradient(1.0f) > 0.2;
    }

    public boolean hasRain(BlockPos blockPos) {
        if (!this.isRaining()) {
            return false;
        }
        if (!this.isSkyVisible(blockPos)) {
            return false;
        }
        if (this.getTopPosition(Heightmap.Type.field_13197, blockPos).getY() > blockPos.getY()) {
            return false;
        }
        Biome biome = this.getBiome(blockPos).comp_349();
        return biome.getPrecipitation(blockPos) == Biome.Precipitation.field_9382;
    }

    @Nullable
    public abstract MapState getMapState(String var1);

    public abstract void putMapState(String var1, MapState var2);

    public abstract int getNextMapId();

    public void syncGlobalEvent(int i, BlockPos blockPos, int j) {
    }

    public CrashReportSection addDetailsToCrashReport(CrashReport crashReport) {
        CrashReportSection crashReportSection = crashReport.addElement("Affected level", 1);
        crashReportSection.add("All players", () -> this.getPlayers().size() + " total; " + this.getPlayers());
        crashReportSection.add("Chunk stats", this.getChunkManager()::getDebugString);
        crashReportSection.add("Level dimension", () -> this.getRegistryKey().getValue().toString());
        try {
            this.properties.populateCrashReport(crashReportSection, this);
        } catch (Throwable throwable) {
            crashReportSection.add("Level Data Unobtainable", throwable);
        }
        return crashReportSection;
    }

    public abstract void setBlockBreakingInfo(int var1, BlockPos var2, int var3);

    public void addFireworkParticle(double d, double e, double f, double g, double h, double i, @Nullable NbtCompound nbtCompound) {
    }

    public abstract Scoreboard getScoreboard();

    public void updateComparators(BlockPos blockPos, Block block) {
        for (Direction direction : Direction.Type.field_11062) {
            BlockPos blockPos2 = blockPos.offset(direction);
            if (!this.isChunkLoaded(blockPos2)) continue;
            BlockState blockState = this.getBlockState(blockPos2);
            if (blockState.isOf(Blocks.field_10377)) {
                this.updateNeighbor(blockState, blockPos2, block, blockPos, false);
                continue;
            }
            if (!blockState.isSolidBlock(this, blockPos2) || !(blockState = this.getBlockState(blockPos2 = blockPos2.offset(direction))).isOf(Blocks.field_10377)) continue;
            this.updateNeighbor(blockState, blockPos2, block, blockPos, false);
        }
    }

    @Override
    public LocalDifficulty getLocalDifficulty(BlockPos blockPos) {
        long l = 0L;
        float f = 0.0f;
        if (this.isChunkLoaded(blockPos)) {
            f = this.getMoonSize();
            l = this.getWorldChunk(blockPos).getInhabitedTime();
        }
        return new LocalDifficulty(this.getDifficulty(), this.getTimeOfDay(), l, f);
    }

    @Override
    public int getAmbientDarkness() {
        return this.ambientDarkness;
    }

    public void setLightningTicksLeft(int i) {
    }

    @Override
    public WorldBorder getWorldBorder() {
        return this.border;
    }

    public void sendPacket(Packet<?> packet) {
        throw new UnsupportedOperationException("Can't send packets to server unless you're on the client.");
    }

    @Override
    public DimensionType getDimension() {
        return this.dimensionEntry.comp_349();
    }

    public RegistryKey<DimensionType> getDimensionKey() {
        return this.dimension;
    }

    public RegistryEntry<DimensionType> getDimensionEntry() {
        return this.dimensionEntry;
    }

    public RegistryKey<World> getRegistryKey() {
        return this.registryKey;
    }

    @Override
    public Random getRandom() {
        return this.random;
    }

    @Override
    public boolean testBlockState(BlockPos blockPos, Predicate<BlockState> predicate) {
        return predicate.test(this.getBlockState(blockPos));
    }

    @Override
    public boolean testFluidState(BlockPos blockPos, Predicate<FluidState> predicate) {
        return predicate.test(this.getFluidState(blockPos));
    }

    public abstract RecipeManager getRecipeManager();

    public BlockPos getRandomPosInChunk(int i, int j, int k, int l) {
        this.lcgBlockSeed = this.lcgBlockSeed * 3 + 1013904223;
        int m = this.lcgBlockSeed >> 2;
        return new BlockPos(i + (m & 0xF), j + (m >> 16 & l), k + (m >> 8 & 0xF));
    }

    public boolean isSavingDisabled() {
        return false;
    }

    public Profiler getProfiler() {
        return this.profiler.get();
    }

    public Supplier<Profiler> getProfilerSupplier() {
        return this.profiler;
    }

    @Override
    public BiomeAccess getBiomeAccess() {
        return this.biomeAccess;
    }

    public final boolean isDebugWorld() {
        return this.debugWorld;
    }

    protected abstract EntityLookup<Entity> getEntityLookup();

    @Override
    public long getTickOrder() {
        return this.tickOrder++;
    }

    @Override
    public DynamicRegistryManager getRegistryManager() {
        return this.registryManager;
    }

    public DamageSources getDamageSources() {
        return this.damageSources;
    }

    @Override
    public /* synthetic */ Chunk getChunk(int i, int j) {
        return this.getChunk(i, j);
    }

    public static enum ExplosionSourceType {
        field_40888,
        field_40889,
        field_40890,
        field_40891;

    }
}


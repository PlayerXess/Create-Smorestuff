/*
 * Decompiled with CFR 0.2.1 (FabricMC 53fa44c9).
 */
package net.minecraft.world;

import io.github.fabricators_of_create.porting_lib.extensions.extensions.LevelReaderExtensions;
import java.util.stream.Stream;
import net.minecraft.block.BlockState;
import net.minecraft.registry.DynamicRegistryManager;
import net.minecraft.registry.Registry;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryWrapper;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.registry.tag.FluidTags;
import net.minecraft.resource.featuretoggle.FeatureSet;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.ChunkSectionPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.world.BlockRenderView;
import net.minecraft.world.BlockView;
import net.minecraft.world.CollisionView;
import net.minecraft.world.Heightmap;
import net.minecraft.world.RedstoneView;
import net.minecraft.world.biome.Biome;
import net.minecraft.world.biome.ColorResolver;
import net.minecraft.world.biome.source.BiomeAccess;
import net.minecraft.world.biome.source.BiomeCoords;
import net.minecraft.world.chunk.Chunk;
import net.minecraft.world.chunk.ChunkStatus;
import net.minecraft.world.dimension.DimensionType;
import org.jetbrains.annotations.Nullable;

public interface WorldView
extends BlockRenderView,
CollisionView,
RedstoneView,
BiomeAccess.Storage,
LevelReaderExtensions {
    @Nullable
    public Chunk getChunk(int var1, int var2, ChunkStatus var3, boolean var4);

    @Deprecated
    public boolean isChunkLoaded(int var1, int var2);

    public int getTopY(Heightmap.Type var1, int var2, int var3);

    public int getAmbientDarkness();

    public BiomeAccess getBiomeAccess();

    default public RegistryEntry<Biome> getBiome(BlockPos blockPos) {
        return this.getBiomeAccess().getBiome(blockPos);
    }

    default public Stream<BlockState> getStatesInBoxIfLoaded(Box box) {
        int n;
        int i = MathHelper.floor(box.minX);
        int j = MathHelper.floor(box.maxX);
        int k = MathHelper.floor(box.minY);
        int l = MathHelper.floor(box.maxY);
        int m = MathHelper.floor(box.minZ);
        if (this.isRegionLoaded(i, k, m, j, l, n = MathHelper.floor(box.maxZ))) {
            return this.getStatesInBox(box);
        }
        return Stream.empty();
    }

    @Override
    default public int getColor(BlockPos blockPos, ColorResolver colorResolver) {
        return colorResolver.getColor(this.getBiome(blockPos).comp_349(), blockPos.getX(), blockPos.getZ());
    }

    @Override
    default public RegistryEntry<Biome> getBiomeForNoiseGen(int i, int j, int k) {
        Chunk chunk = this.getChunk(BiomeCoords.toChunk(i), BiomeCoords.toChunk(k), ChunkStatus.field_12794, false);
        if (chunk != null) {
            return chunk.getBiomeForNoiseGen(i, j, k);
        }
        return this.getGeneratorStoredBiome(i, j, k);
    }

    public RegistryEntry<Biome> getGeneratorStoredBiome(int var1, int var2, int var3);

    public boolean isClient();

    @Deprecated
    public int getSeaLevel();

    public DimensionType getDimension();

    @Override
    default public int getBottomY() {
        return this.getDimension().comp_651();
    }

    @Override
    default public int getHeight() {
        return this.getDimension().comp_652();
    }

    default public BlockPos getTopPosition(Heightmap.Type type, BlockPos blockPos) {
        return new BlockPos(blockPos.getX(), this.getTopY(type, blockPos.getX(), blockPos.getZ()), blockPos.getZ());
    }

    default public boolean isAir(BlockPos blockPos) {
        return this.getBlockState(blockPos).isAir();
    }

    default public boolean isSkyVisibleAllowingSea(BlockPos blockPos) {
        if (blockPos.getY() >= this.getSeaLevel()) {
            return this.isSkyVisible(blockPos);
        }
        BlockPos blockPos2 = new BlockPos(blockPos.getX(), this.getSeaLevel(), blockPos.getZ());
        if (!this.isSkyVisible(blockPos2)) {
            return false;
        }
        blockPos2 = blockPos2.down();
        while (blockPos2.getY() > blockPos.getY()) {
            BlockState blockState = this.getBlockState(blockPos2);
            if (blockState.getOpacity(this, blockPos2) > 0 && !blockState.isLiquid()) {
                return false;
            }
            blockPos2 = blockPos2.down();
        }
        return true;
    }

    default public float getPhototaxisFavor(BlockPos blockPos) {
        return this.getBrightness(blockPos) - 0.5f;
    }

    @Deprecated
    default public float getBrightness(BlockPos blockPos) {
        float f = (float)this.getLightLevel(blockPos) / 15.0f;
        float g = f / (4.0f - 3.0f * f);
        return MathHelper.lerp(this.getDimension().comp_656(), g, 1.0f);
    }

    default public Chunk getChunk(BlockPos blockPos) {
        return this.getChunk(ChunkSectionPos.getSectionCoord(blockPos.getX()), ChunkSectionPos.getSectionCoord(blockPos.getZ()));
    }

    default public Chunk getChunk(int i, int j) {
        return this.getChunk(i, j, ChunkStatus.field_12803, true);
    }

    default public Chunk getChunk(int i, int j, ChunkStatus chunkStatus) {
        return this.getChunk(i, j, chunkStatus, true);
    }

    @Override
    @Nullable
    default public BlockView getChunkAsView(int i, int j) {
        return this.getChunk(i, j, ChunkStatus.field_12798, false);
    }

    default public boolean isWater(BlockPos blockPos) {
        return this.getFluidState(blockPos).isIn(FluidTags.field_15517);
    }

    default public boolean containsFluid(Box box) {
        int i = MathHelper.floor(box.minX);
        int j = MathHelper.ceil(box.maxX);
        int k = MathHelper.floor(box.minY);
        int l = MathHelper.ceil(box.maxY);
        int m = MathHelper.floor(box.minZ);
        int n = MathHelper.ceil(box.maxZ);
        BlockPos.Mutable mutable = new BlockPos.Mutable();
        for (int o = i; o < j; ++o) {
            for (int p = k; p < l; ++p) {
                for (int q = m; q < n; ++q) {
                    BlockState blockState = this.getBlockState(mutable.set(o, p, q));
                    if (blockState.getFluidState().isEmpty()) continue;
                    return true;
                }
            }
        }
        return false;
    }

    default public int getLightLevel(BlockPos blockPos) {
        return this.getLightLevel(blockPos, this.getAmbientDarkness());
    }

    default public int getLightLevel(BlockPos blockPos, int i) {
        if (blockPos.getX() < -30000000 || blockPos.getZ() < -30000000 || blockPos.getX() >= 30000000 || blockPos.getZ() >= 30000000) {
            return 15;
        }
        return this.getBaseLightLevel(blockPos, i);
    }

    @Deprecated
    default public boolean isPosLoaded(int i, int j) {
        return this.isChunkLoaded(ChunkSectionPos.getSectionCoord(i), ChunkSectionPos.getSectionCoord(j));
    }

    @Deprecated
    default public boolean isChunkLoaded(BlockPos blockPos) {
        return this.isPosLoaded(blockPos.getX(), blockPos.getZ());
    }

    @Deprecated
    default public boolean isRegionLoaded(BlockPos blockPos, BlockPos blockPos2) {
        return this.isRegionLoaded(blockPos.getX(), blockPos.getY(), blockPos.getZ(), blockPos2.getX(), blockPos2.getY(), blockPos2.getZ());
    }

    @Deprecated
    default public boolean isRegionLoaded(int i, int j, int k, int l, int m, int n) {
        if (m < this.getBottomY() || j >= this.getTopY()) {
            return false;
        }
        return this.isRegionLoaded(i, k, l, n);
    }

    @Deprecated
    default public boolean isRegionLoaded(int i, int j, int k, int l) {
        int m = ChunkSectionPos.getSectionCoord(i);
        int n = ChunkSectionPos.getSectionCoord(k);
        int o = ChunkSectionPos.getSectionCoord(j);
        int p = ChunkSectionPos.getSectionCoord(l);
        for (int q = m; q <= n; ++q) {
            for (int r = o; r <= p; ++r) {
                if (this.isChunkLoaded(q, r)) continue;
                return false;
            }
        }
        return true;
    }

    public DynamicRegistryManager getRegistryManager();

    public FeatureSet getEnabledFeatures();

    default public <T> RegistryWrapper<T> createCommandRegistryWrapper(RegistryKey<? extends Registry<? extends T>> registryKey) {
        Registry registry = this.getRegistryManager().get(registryKey);
        return registry.getReadOnlyWrapper().withFeatureFilter(this.getEnabledFeatures());
    }
}


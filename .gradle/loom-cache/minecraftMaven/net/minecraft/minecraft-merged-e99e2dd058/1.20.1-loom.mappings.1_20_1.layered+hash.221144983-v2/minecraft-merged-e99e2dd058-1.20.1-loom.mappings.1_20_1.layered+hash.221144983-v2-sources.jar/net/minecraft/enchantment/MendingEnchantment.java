/*
 * Decompiled with CFR 0.2.1 (FabricMC 53fa44c9).
 */
package net.minecraft.enchantment;

import net.minecraft.enchantment.Enchantment;
import net.minecraft.enchantment.EnchantmentTarget;
import net.minecraft.entity.EquipmentSlot;

public class MendingEnchantment
extends Enchantment {
    public MendingEnchantment(Enchantment.Rarity rarity, EquipmentSlot ... equipmentSlots) {
        super(rarity, EnchantmentTarget.field_9082, equipmentSlots);
    }

    @Override
    public int getMinPower(int i) {
        return i * 25;
    }

    @Override
    public int getMaxPower(int i) {
        return this.getMinPower(i) + 50;
    }

    @Override
    public boolean isTreasure() {
        return true;
    }
}


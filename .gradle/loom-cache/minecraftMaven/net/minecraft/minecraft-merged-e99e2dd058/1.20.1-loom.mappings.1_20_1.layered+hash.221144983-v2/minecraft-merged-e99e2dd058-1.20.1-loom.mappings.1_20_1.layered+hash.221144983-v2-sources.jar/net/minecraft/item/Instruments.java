/*
 * Decompiled with CFR 0.2.1 (FabricMC 53fa44c9).
 */
package net.minecraft.item;

import net.minecraft.item.Instrument;
import net.minecraft.registry.Registry;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.Identifier;

public interface Instruments {
    public static final int GOAT_HORN_RANGE = 256;
    public static final int GOAT_HORN_USE_DURATION = 140;
    public static final RegistryKey<Instrument> field_39126 = Instruments.of("ponder_goat_horn");
    public static final RegistryKey<Instrument> field_39127 = Instruments.of("sing_goat_horn");
    public static final RegistryKey<Instrument> field_39128 = Instruments.of("seek_goat_horn");
    public static final RegistryKey<Instrument> field_39129 = Instruments.of("feel_goat_horn");
    public static final RegistryKey<Instrument> field_39130 = Instruments.of("admire_goat_horn");
    public static final RegistryKey<Instrument> field_39131 = Instruments.of("call_goat_horn");
    public static final RegistryKey<Instrument> field_39132 = Instruments.of("yearn_goat_horn");
    public static final RegistryKey<Instrument> field_39133 = Instruments.of("dream_goat_horn");

    private static RegistryKey<Instrument> of(String string) {
        return RegistryKey.of(RegistryKeys.field_41275, new Identifier(string));
    }

    public static Instrument registerAndGetDefault(Registry<Instrument> registry) {
        Registry.register(registry, field_39126, new Instrument((RegistryEntry)SoundEvents.GOAT_HORN_SOUNDS.get(0), 140, 256.0f));
        Registry.register(registry, field_39127, new Instrument((RegistryEntry)SoundEvents.GOAT_HORN_SOUNDS.get(1), 140, 256.0f));
        Registry.register(registry, field_39128, new Instrument((RegistryEntry)SoundEvents.GOAT_HORN_SOUNDS.get(2), 140, 256.0f));
        Registry.register(registry, field_39129, new Instrument((RegistryEntry)SoundEvents.GOAT_HORN_SOUNDS.get(3), 140, 256.0f));
        Registry.register(registry, field_39130, new Instrument((RegistryEntry)SoundEvents.GOAT_HORN_SOUNDS.get(4), 140, 256.0f));
        Registry.register(registry, field_39131, new Instrument((RegistryEntry)SoundEvents.GOAT_HORN_SOUNDS.get(5), 140, 256.0f));
        Registry.register(registry, field_39132, new Instrument((RegistryEntry)SoundEvents.GOAT_HORN_SOUNDS.get(6), 140, 256.0f));
        return Registry.register(registry, field_39133, new Instrument((RegistryEntry)SoundEvents.GOAT_HORN_SOUNDS.get(7), 140, 256.0f));
    }
}


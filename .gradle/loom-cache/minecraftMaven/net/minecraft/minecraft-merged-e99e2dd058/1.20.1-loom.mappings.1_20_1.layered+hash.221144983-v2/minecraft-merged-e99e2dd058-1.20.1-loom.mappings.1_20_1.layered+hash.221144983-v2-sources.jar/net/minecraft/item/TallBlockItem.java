/*
 * Decompiled with CFR 0.2.1 (FabricMC 53fa44c9).
 */
package net.minecraft.item;

import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.item.BlockItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemPlacementContext;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

public class TallBlockItem
extends BlockItem {
    public TallBlockItem(Block block, Item.Settings settings) {
        super(block, settings);
    }

    @Override
    protected boolean place(ItemPlacementContext itemPlacementContext, BlockState blockState) {
        BlockPos blockPos;
        World world = itemPlacementContext.getWorld();
        BlockState blockState2 = world.isWater(blockPos = itemPlacementContext.getBlockPos().up()) ? Blocks.field_10382.getDefaultState() : Blocks.field_10124.getDefaultState();
        world.setBlockState(blockPos, blockState2, 27);
        return super.place(itemPlacementContext, blockState);
    }
}


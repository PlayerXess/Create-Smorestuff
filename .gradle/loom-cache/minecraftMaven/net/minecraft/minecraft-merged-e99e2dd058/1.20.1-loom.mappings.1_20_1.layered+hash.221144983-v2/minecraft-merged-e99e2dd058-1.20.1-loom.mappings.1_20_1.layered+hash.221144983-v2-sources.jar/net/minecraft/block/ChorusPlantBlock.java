/*
 * Decompiled with CFR 0.2.1 (FabricMC 53fa44c9).
 */
package net.minecraft.block;

import net.minecraft.block.AbstractBlock;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.ConnectingBlock;
import net.minecraft.entity.ai.pathing.NavigationType;
import net.minecraft.item.ItemPlacementContext;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.state.StateManager;
import net.minecraft.state.property.Property;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.random.Random;
import net.minecraft.world.BlockView;
import net.minecraft.world.WorldAccess;
import net.minecraft.world.WorldView;

public class ChorusPlantBlock
extends ConnectingBlock {
    public ChorusPlantBlock(AbstractBlock.Settings settings) {
        super(0.3125f, settings);
        this.setDefaultState((BlockState)((BlockState)((BlockState)((BlockState)((BlockState)((BlockState)((BlockState)this.stateManager.getDefaultState()).with(NORTH, false)).with(EAST, false)).with(SOUTH, false)).with(WEST, false)).with(UP, false)).with(DOWN, false));
    }

    @Override
    public BlockState getPlacementState(ItemPlacementContext itemPlacementContext) {
        return this.withConnectionProperties(itemPlacementContext.getWorld(), itemPlacementContext.getBlockPos());
    }

    public BlockState withConnectionProperties(BlockView blockView, BlockPos blockPos) {
        BlockState blockState = blockView.getBlockState(blockPos.down());
        BlockState blockState2 = blockView.getBlockState(blockPos.up());
        BlockState blockState3 = blockView.getBlockState(blockPos.north());
        BlockState blockState4 = blockView.getBlockState(blockPos.east());
        BlockState blockState5 = blockView.getBlockState(blockPos.south());
        BlockState blockState6 = blockView.getBlockState(blockPos.west());
        return (BlockState)((BlockState)((BlockState)((BlockState)((BlockState)((BlockState)this.getDefaultState().with(DOWN, blockState.isOf(this) || blockState.isOf(Blocks.field_10528) || blockState.isOf(Blocks.field_10471))).with(UP, blockState2.isOf(this) || blockState2.isOf(Blocks.field_10528))).with(NORTH, blockState3.isOf(this) || blockState3.isOf(Blocks.field_10528))).with(EAST, blockState4.isOf(this) || blockState4.isOf(Blocks.field_10528))).with(SOUTH, blockState5.isOf(this) || blockState5.isOf(Blocks.field_10528))).with(WEST, blockState6.isOf(this) || blockState6.isOf(Blocks.field_10528));
    }

    @Override
    public BlockState getStateForNeighborUpdate(BlockState blockState, Direction direction, BlockState blockState2, WorldAccess worldAccess, BlockPos blockPos, BlockPos blockPos2) {
        if (!blockState.canPlaceAt(worldAccess, blockPos)) {
            worldAccess.scheduleBlockTick(blockPos, this, 1);
            return super.getStateForNeighborUpdate(blockState, direction, blockState2, worldAccess, blockPos, blockPos2);
        }
        boolean bl = blockState2.isOf(this) || blockState2.isOf(Blocks.field_10528) || direction == Direction.field_11033 && blockState2.isOf(Blocks.field_10471);
        return (BlockState)blockState.with((Property)FACING_PROPERTIES.get(direction), bl);
    }

    @Override
    public void scheduledTick(BlockState blockState, ServerWorld serverWorld, BlockPos blockPos, Random random) {
        if (!blockState.canPlaceAt(serverWorld, blockPos)) {
            serverWorld.breakBlock(blockPos, true);
        }
    }

    @Override
    public boolean canPlaceAt(BlockState blockState, WorldView worldView, BlockPos blockPos) {
        BlockState blockState2 = worldView.getBlockState(blockPos.down());
        boolean bl = !worldView.getBlockState(blockPos.up()).isAir() && !blockState2.isAir();
        for (Direction direction : Direction.Type.field_11062) {
            BlockPos blockPos2 = blockPos.offset(direction);
            BlockState blockState3 = worldView.getBlockState(blockPos2);
            if (!blockState3.isOf(this)) continue;
            if (bl) {
                return false;
            }
            BlockState blockState4 = worldView.getBlockState(blockPos2.down());
            if (!blockState4.isOf(this) && !blockState4.isOf(Blocks.field_10471)) continue;
            return true;
        }
        return blockState2.isOf(this) || blockState2.isOf(Blocks.field_10471);
    }

    @Override
    protected void appendProperties(StateManager.Builder<Block, BlockState> builder) {
        builder.add(NORTH, EAST, SOUTH, WEST, UP, DOWN);
    }

    @Override
    public boolean canPathfindThrough(BlockState blockState, BlockView blockView, BlockPos blockPos, NavigationType navigationType) {
        return false;
    }
}


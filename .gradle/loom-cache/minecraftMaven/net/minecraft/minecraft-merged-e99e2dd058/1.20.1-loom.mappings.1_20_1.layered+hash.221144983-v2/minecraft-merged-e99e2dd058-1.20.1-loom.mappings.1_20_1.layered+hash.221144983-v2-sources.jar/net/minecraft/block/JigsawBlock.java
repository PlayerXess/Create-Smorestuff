/*
 * Decompiled with CFR 0.2.1 (FabricMC 53fa44c9).
 */
package net.minecraft.block;

import net.minecraft.block.AbstractBlock;
import net.minecraft.block.Block;
import net.minecraft.block.BlockEntityProvider;
import net.minecraft.block.BlockState;
import net.minecraft.block.OperatorBlock;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.block.entity.JigsawBlockEntity;
import net.minecraft.block.enums.JigsawOrientation;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemPlacementContext;
import net.minecraft.state.StateManager;
import net.minecraft.state.property.EnumProperty;
import net.minecraft.state.property.Properties;
import net.minecraft.structure.StructureTemplate;
import net.minecraft.util.ActionResult;
import net.minecraft.util.BlockMirror;
import net.minecraft.util.BlockRotation;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.world.World;

public class JigsawBlock
extends Block
implements BlockEntityProvider,
OperatorBlock {
    public static final EnumProperty<JigsawOrientation> ORIENTATION = Properties.ORIENTATION;

    public JigsawBlock(AbstractBlock.Settings settings) {
        super(settings);
        this.setDefaultState((BlockState)((BlockState)this.stateManager.getDefaultState()).with(ORIENTATION, JigsawOrientation.field_23391));
    }

    @Override
    protected void appendProperties(StateManager.Builder<Block, BlockState> builder) {
        builder.add(ORIENTATION);
    }

    @Override
    public BlockState rotate(BlockState blockState, BlockRotation blockRotation) {
        return (BlockState)blockState.with(ORIENTATION, blockRotation.getDirectionTransformation().mapJigsawOrientation(blockState.get(ORIENTATION)));
    }

    @Override
    public BlockState mirror(BlockState blockState, BlockMirror blockMirror) {
        return (BlockState)blockState.with(ORIENTATION, blockMirror.getDirectionTransformation().mapJigsawOrientation(blockState.get(ORIENTATION)));
    }

    @Override
    public BlockState getPlacementState(ItemPlacementContext itemPlacementContext) {
        Direction direction = itemPlacementContext.getSide();
        Direction direction2 = direction.getAxis() == Direction.Axis.field_11052 ? itemPlacementContext.getHorizontalPlayerFacing().getOpposite() : Direction.field_11036;
        return (BlockState)this.getDefaultState().with(ORIENTATION, JigsawOrientation.byDirections(direction, direction2));
    }

    @Override
    public BlockEntity createBlockEntity(BlockPos blockPos, BlockState blockState) {
        return new JigsawBlockEntity(blockPos, blockState);
    }

    @Override
    public ActionResult onUse(BlockState blockState, World world, BlockPos blockPos, PlayerEntity playerEntity, Hand hand, BlockHitResult blockHitResult) {
        BlockEntity blockEntity = world.getBlockEntity(blockPos);
        if (blockEntity instanceof JigsawBlockEntity && playerEntity.isCreativeLevelTwoOp()) {
            playerEntity.openJigsawScreen((JigsawBlockEntity)blockEntity);
            return ActionResult.success(world.isClient);
        }
        return ActionResult.PASS;
    }

    public static boolean attachmentMatches(StructureTemplate.StructureBlockInfo structureBlockInfo, StructureTemplate.StructureBlockInfo structureBlockInfo2) {
        Direction direction = JigsawBlock.getFacing(structureBlockInfo.comp_1342());
        Direction direction2 = JigsawBlock.getFacing(structureBlockInfo2.comp_1342());
        Direction direction3 = JigsawBlock.getRotation(structureBlockInfo.comp_1342());
        Direction direction4 = JigsawBlock.getRotation(structureBlockInfo2.comp_1342());
        JigsawBlockEntity.Joint joint = JigsawBlockEntity.Joint.byName(structureBlockInfo.comp_1343().getString("joint")).orElseGet(() -> direction.getAxis().isHorizontal() ? JigsawBlockEntity.Joint.field_23330 : JigsawBlockEntity.Joint.field_23329);
        boolean bl = joint == JigsawBlockEntity.Joint.field_23329;
        return direction == direction2.getOpposite() && (bl || direction3 == direction4) && structureBlockInfo.comp_1343().getString("target").equals(structureBlockInfo2.comp_1343().getString("name"));
    }

    public static Direction getFacing(BlockState blockState) {
        return blockState.get(ORIENTATION).getFacing();
    }

    public static Direction getRotation(BlockState blockState) {
        return blockState.get(ORIENTATION).getRotation();
    }
}


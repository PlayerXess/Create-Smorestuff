/*
 * Decompiled with CFR 0.2.1 (FabricMC 53fa44c9).
 */
package net.minecraft.block;

import net.minecraft.block.AbstractBlock;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.FallingBlock;
import net.minecraft.entity.FallingBlockEntity;
import net.minecraft.item.ItemPlacementContext;
import net.minecraft.registry.tag.FluidTags;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3i;
import net.minecraft.world.BlockView;
import net.minecraft.world.World;
import net.minecraft.world.WorldAccess;

public class ConcretePowderBlock
extends FallingBlock {
    private final BlockState hardenedState;

    public ConcretePowderBlock(Block block, AbstractBlock.Settings settings) {
        super(settings);
        this.hardenedState = block.getDefaultState();
    }

    @Override
    public void onLanding(World world, BlockPos blockPos, BlockState blockState, BlockState blockState2, FallingBlockEntity fallingBlockEntity) {
        if (ConcretePowderBlock.shouldHarden(world, blockPos, blockState2)) {
            world.setBlockState(blockPos, this.hardenedState, 3);
        }
    }

    @Override
    public BlockState getPlacementState(ItemPlacementContext itemPlacementContext) {
        BlockState blockState;
        BlockPos blockPos;
        World blockView = itemPlacementContext.getWorld();
        if (ConcretePowderBlock.shouldHarden(blockView, blockPos = itemPlacementContext.getBlockPos(), blockState = blockView.getBlockState(blockPos))) {
            return this.hardenedState;
        }
        return super.getPlacementState(itemPlacementContext);
    }

    private static boolean shouldHarden(BlockView blockView, BlockPos blockPos, BlockState blockState) {
        return ConcretePowderBlock.hardensIn(blockState) || ConcretePowderBlock.hardensOnAnySide(blockView, blockPos);
    }

    private static boolean hardensOnAnySide(BlockView blockView, BlockPos blockPos) {
        boolean bl = false;
        BlockPos.Mutable mutable = blockPos.mutableCopy();
        for (Direction direction : Direction.values()) {
            BlockState blockState = blockView.getBlockState(mutable);
            if (direction == Direction.field_11033 && !ConcretePowderBlock.hardensIn(blockState)) continue;
            mutable.set((Vec3i)blockPos, direction);
            blockState = blockView.getBlockState(mutable);
            if (!ConcretePowderBlock.hardensIn(blockState) || blockState.isSideSolidFullSquare(blockView, blockPos, direction.getOpposite())) continue;
            bl = true;
            break;
        }
        return bl;
    }

    private static boolean hardensIn(BlockState blockState) {
        return blockState.getFluidState().isIn(FluidTags.field_15517);
    }

    @Override
    public BlockState getStateForNeighborUpdate(BlockState blockState, Direction direction, BlockState blockState2, WorldAccess worldAccess, BlockPos blockPos, BlockPos blockPos2) {
        if (ConcretePowderBlock.hardensOnAnySide(worldAccess, blockPos)) {
            return this.hardenedState;
        }
        return super.getStateForNeighborUpdate(blockState, direction, blockState2, worldAccess, blockPos, blockPos2);
    }

    @Override
    public int getColor(BlockState blockState, BlockView blockView, BlockPos blockPos) {
        return blockState.getMapColor((BlockView)blockView, (BlockPos)blockPos).color;
    }
}


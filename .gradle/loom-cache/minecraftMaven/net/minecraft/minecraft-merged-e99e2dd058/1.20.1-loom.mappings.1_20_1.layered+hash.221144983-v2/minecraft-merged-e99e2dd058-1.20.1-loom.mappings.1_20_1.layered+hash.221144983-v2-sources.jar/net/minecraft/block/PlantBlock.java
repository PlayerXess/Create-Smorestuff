/*
 * Decompiled with CFR 0.2.1 (FabricMC 53fa44c9).
 */
package net.minecraft.block;

import io.github.fabricators_of_create.porting_lib.common.util.IPlantable;
import net.minecraft.block.AbstractBlock;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.entity.ai.pathing.NavigationType;
import net.minecraft.registry.tag.BlockTags;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.world.BlockView;
import net.minecraft.world.WorldAccess;
import net.minecraft.world.WorldView;

public class PlantBlock
extends Block
implements IPlantable {
    public PlantBlock(AbstractBlock.Settings settings) {
        super(settings);
    }

    public boolean canPlantOnTop(BlockState blockState, BlockView blockView, BlockPos blockPos) {
        return blockState.isIn(BlockTags.field_29822) || blockState.isOf(Blocks.field_10362);
    }

    @Override
    public BlockState getStateForNeighborUpdate(BlockState blockState, Direction direction, BlockState blockState2, WorldAccess worldAccess, BlockPos blockPos, BlockPos blockPos2) {
        if (!blockState.canPlaceAt(worldAccess, blockPos)) {
            return Blocks.field_10124.getDefaultState();
        }
        return super.getStateForNeighborUpdate(blockState, direction, blockState2, worldAccess, blockPos, blockPos2);
    }

    @Override
    public boolean canPlaceAt(BlockState blockState, WorldView worldView, BlockPos blockPos) {
        BlockPos blockPos2 = blockPos.down();
        return this.canPlantOnTop(worldView.getBlockState(blockPos2), worldView, blockPos2);
    }

    @Override
    public boolean isTransparent(BlockState blockState, BlockView blockView, BlockPos blockPos) {
        return blockState.getFluidState().isEmpty();
    }

    @Override
    public boolean canPathfindThrough(BlockState blockState, BlockView blockView, BlockPos blockPos, NavigationType navigationType) {
        if (navigationType == NavigationType.field_51 && !this.collidable) {
            return true;
        }
        return super.canPathfindThrough(blockState, blockView, blockPos, navigationType);
    }
}


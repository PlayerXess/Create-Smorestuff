/*
 * Decompiled with CFR 0.2.1 (FabricMC 53fa44c9).
 */
package net.minecraft.recipe;

import net.minecraft.inventory.RecipeInputInventory;
import net.minecraft.recipe.Recipe;
import net.minecraft.recipe.RecipeType;
import net.minecraft.recipe.book.CraftingRecipeCategory;

public interface CraftingRecipe
extends Recipe<RecipeInputInventory> {
    @Override
    default public RecipeType<?> getType() {
        return RecipeType.field_17545;
    }

    public CraftingRecipeCategory getCategory();
}


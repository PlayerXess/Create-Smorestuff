/*
 * Decompiled with CFR 0.2.1 (FabricMC 53fa44c9).
 */
package net.minecraft.world;

import java.util.function.Predicate;
import net.minecraft.block.BlockState;
import net.minecraft.util.math.Vec3d;

public class BlockStateRaycastContext {
    private final Vec3d start;
    private final Vec3d end;
    private final Predicate<BlockState> statePredicate;

    public BlockStateRaycastContext(Vec3d vec3d, Vec3d vec3d2, Predicate<BlockState> predicate) {
        this.start = vec3d;
        this.end = vec3d2;
        this.statePredicate = predicate;
    }

    public Vec3d getEnd() {
        return this.end;
    }

    public Vec3d getStart() {
        return this.start;
    }

    public Predicate<BlockState> getStatePredicate() {
        return this.statePredicate;
    }
}


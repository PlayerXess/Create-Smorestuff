/*
 * Decompiled with CFR 0.2.1 (FabricMC 53fa44c9).
 */
package net.minecraft.item;

import io.github.fabricators_of_create.porting_lib.extensions.extensions.BlockItemExtensions;
import java.util.List;
import java.util.Map;
import net.minecraft.advancement.criterion.Criteria;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.ShapeContext;
import net.minecraft.block.ShulkerBoxBlock;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.block.entity.BlockEntityType;
import net.minecraft.client.item.TooltipContext;
import net.minecraft.entity.ItemEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemPlacementContext;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemUsage;
import net.minecraft.item.ItemUsageContext;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.nbt.NbtList;
import net.minecraft.resource.featuretoggle.FeatureSet;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.sound.BlockSoundGroup;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvent;
import net.minecraft.state.StateManager;
import net.minecraft.state.property.Property;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraft.world.event.GameEvent;
import org.jetbrains.annotations.Nullable;

public class BlockItem
extends Item
implements BlockItemExtensions {
    public static final String BLOCK_ENTITY_TAG_KEY = "BlockEntityTag";
    public static final String BLOCK_STATE_TAG_KEY = "BlockStateTag";
    @Deprecated
    private final Block block;

    public BlockItem(Block block, Item.Settings settings) {
        super(settings);
        this.block = block;
    }

    @Override
    public ActionResult useOnBlock(ItemUsageContext itemUsageContext) {
        ActionResult actionResult = this.place(new ItemPlacementContext(itemUsageContext));
        if (!actionResult.isAccepted() && this.isFood()) {
            ActionResult actionResult2 = this.use(itemUsageContext.getWorld(), itemUsageContext.getPlayer(), itemUsageContext.getHand()).getResult();
            return actionResult2 == ActionResult.CONSUME ? ActionResult.CONSUME_PARTIAL : actionResult2;
        }
        return actionResult;
    }

    public ActionResult place(ItemPlacementContext itemPlacementContext) {
        if (!this.getBlock().isEnabled(itemPlacementContext.getWorld().getEnabledFeatures())) {
            return ActionResult.FAIL;
        }
        if (!itemPlacementContext.canPlace()) {
            return ActionResult.FAIL;
        }
        ItemPlacementContext itemPlacementContext2 = this.getPlacementContext(itemPlacementContext);
        if (itemPlacementContext2 == null) {
            return ActionResult.FAIL;
        }
        BlockState blockState = this.getPlacementState(itemPlacementContext2);
        if (blockState == null) {
            return ActionResult.FAIL;
        }
        if (!this.place(itemPlacementContext2, blockState)) {
            return ActionResult.FAIL;
        }
        BlockPos blockPos = itemPlacementContext2.getBlockPos();
        World world = itemPlacementContext2.getWorld();
        PlayerEntity playerEntity = itemPlacementContext2.getPlayer();
        ItemStack itemStack = itemPlacementContext2.getStack();
        BlockState blockState2 = world.getBlockState(blockPos);
        if (blockState2.isOf(blockState.getBlock())) {
            blockState2 = this.placeFromNbt(blockPos, world, itemStack, blockState2);
            this.postPlacement(blockPos, world, playerEntity, itemStack, blockState2);
            blockState2.getBlock().onPlaced(world, blockPos, blockState2, playerEntity, itemStack);
            if (playerEntity instanceof ServerPlayerEntity) {
                Criteria.PLACED_BLOCK.trigger((ServerPlayerEntity)playerEntity, blockPos, itemStack);
            }
        }
        BlockSoundGroup blockSoundGroup = blockState2.getSoundGroup();
        world.playSound(playerEntity, blockPos, this.getPlaceSound(blockState2), SoundCategory.field_15245, (blockSoundGroup.getVolume() + 1.0f) / 2.0f, blockSoundGroup.getPitch() * 0.8f);
        world.emitGameEvent(GameEvent.field_28164, blockPos, GameEvent.Emitter.of(playerEntity, blockState2));
        if (playerEntity == null || !playerEntity.getAbilities().creativeMode) {
            itemStack.decrement(1);
        }
        return ActionResult.success(world.isClient);
    }

    protected SoundEvent getPlaceSound(BlockState blockState) {
        return blockState.getSoundGroup().getPlaceSound();
    }

    @Nullable
    public ItemPlacementContext getPlacementContext(ItemPlacementContext itemPlacementContext) {
        return itemPlacementContext;
    }

    protected boolean postPlacement(BlockPos blockPos, World world, @Nullable PlayerEntity playerEntity, ItemStack itemStack, BlockState blockState) {
        return BlockItem.writeNbtToBlockEntity(world, playerEntity, blockPos, itemStack);
    }

    @Nullable
    protected BlockState getPlacementState(ItemPlacementContext itemPlacementContext) {
        BlockState blockState = this.getBlock().getPlacementState(itemPlacementContext);
        return blockState != null && this.canPlace(itemPlacementContext, blockState) ? blockState : null;
    }

    private BlockState placeFromNbt(BlockPos blockPos, World world, ItemStack itemStack, BlockState blockState) {
        BlockState blockState2 = blockState;
        NbtCompound nbtCompound = itemStack.getNbt();
        if (nbtCompound != null) {
            NbtCompound nbtCompound2 = nbtCompound.getCompound(BLOCK_STATE_TAG_KEY);
            StateManager<Block, BlockState> stateManager = blockState2.getBlock().getStateManager();
            for (String string : nbtCompound2.getKeys()) {
                Property<?> property = stateManager.getProperty(string);
                if (property == null) continue;
                String string2 = nbtCompound2.get(string).asString();
                blockState2 = BlockItem.with(blockState2, property, string2);
            }
        }
        if (blockState2 != blockState) {
            world.setBlockState(blockPos, blockState2, 2);
        }
        return blockState2;
    }

    private static <T extends Comparable<T>> BlockState with(BlockState blockState, Property<T> property, String string) {
        return property.parse(string).map(comparable -> (BlockState)blockState.with(property, comparable)).orElse(blockState);
    }

    protected boolean canPlace(ItemPlacementContext itemPlacementContext, BlockState blockState) {
        PlayerEntity playerEntity = itemPlacementContext.getPlayer();
        ShapeContext shapeContext = playerEntity == null ? ShapeContext.absent() : ShapeContext.of(playerEntity);
        return (!this.checkStatePlacement() || blockState.canPlaceAt(itemPlacementContext.getWorld(), itemPlacementContext.getBlockPos())) && itemPlacementContext.getWorld().canPlace(blockState, itemPlacementContext.getBlockPos(), shapeContext);
    }

    protected boolean checkStatePlacement() {
        return true;
    }

    protected boolean place(ItemPlacementContext itemPlacementContext, BlockState blockState) {
        return itemPlacementContext.getWorld().setBlockState(itemPlacementContext.getBlockPos(), blockState, 11);
    }

    public static boolean writeNbtToBlockEntity(World world, @Nullable PlayerEntity playerEntity, BlockPos blockPos, ItemStack itemStack) {
        BlockEntity blockEntity;
        MinecraftServer minecraftServer = world.getServer();
        if (minecraftServer == null) {
            return false;
        }
        NbtCompound nbtCompound = BlockItem.getBlockEntityNbt(itemStack);
        if (nbtCompound != null && (blockEntity = world.getBlockEntity(blockPos)) != null) {
            if (!(world.isClient || !blockEntity.copyItemDataRequiresOperator() || playerEntity != null && playerEntity.isCreativeLevelTwoOp())) {
                return false;
            }
            NbtCompound nbtCompound2 = blockEntity.createNbt();
            NbtCompound nbtCompound3 = nbtCompound2.copy();
            nbtCompound2.copyFrom(nbtCompound);
            if (!nbtCompound2.equals(nbtCompound3)) {
                blockEntity.readNbt(nbtCompound2);
                blockEntity.markDirty();
                return true;
            }
        }
        return false;
    }

    @Override
    public String getTranslationKey() {
        return this.getBlock().getTranslationKey();
    }

    @Override
    public void appendTooltip(ItemStack itemStack, @Nullable World world, List<Text> list, TooltipContext tooltipContext) {
        super.appendTooltip(itemStack, world, list, tooltipContext);
        this.getBlock().appendTooltip(itemStack, world, list, tooltipContext);
    }

    public Block getBlock() {
        return this.block;
    }

    public void appendBlocks(Map<Block, Item> map, Item item) {
        map.put(this.getBlock(), item);
    }

    @Override
    public boolean canBeNested() {
        return !(this.block instanceof ShulkerBoxBlock);
    }

    @Override
    public void onItemEntityDestroyed(ItemEntity itemEntity) {
        ItemStack itemStack;
        NbtCompound nbtCompound;
        if (this.block instanceof ShulkerBoxBlock && (nbtCompound = BlockItem.getBlockEntityNbt(itemStack = itemEntity.getStack())) != null && nbtCompound.contains("Items", 9)) {
            NbtList nbtList = nbtCompound.getList("Items", 10);
            ItemUsage.spawnItemContents(itemEntity, nbtList.stream().map(NbtCompound.class::cast).map(ItemStack::fromNbt));
        }
    }

    @Nullable
    public static NbtCompound getBlockEntityNbt(ItemStack itemStack) {
        return itemStack.getSubNbt(BLOCK_ENTITY_TAG_KEY);
    }

    public static void setBlockEntityNbt(ItemStack itemStack, BlockEntityType<?> blockEntityType, NbtCompound nbtCompound) {
        if (nbtCompound.isEmpty()) {
            itemStack.removeSubNbt(BLOCK_ENTITY_TAG_KEY);
        } else {
            BlockEntity.writeIdToNbt(nbtCompound, blockEntityType);
            itemStack.setSubNbt(BLOCK_ENTITY_TAG_KEY, nbtCompound);
        }
    }

    @Override
    public FeatureSet getRequiredFeatures() {
        return this.getBlock().getRequiredFeatures();
    }
}


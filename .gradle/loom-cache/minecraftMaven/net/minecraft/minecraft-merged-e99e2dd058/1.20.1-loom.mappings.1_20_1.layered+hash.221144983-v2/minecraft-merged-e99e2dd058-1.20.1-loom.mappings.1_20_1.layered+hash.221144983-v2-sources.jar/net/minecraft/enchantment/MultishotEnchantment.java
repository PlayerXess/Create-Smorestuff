/*
 * Decompiled with CFR 0.2.1 (FabricMC 53fa44c9).
 */
package net.minecraft.enchantment;

import net.minecraft.enchantment.Enchantment;
import net.minecraft.enchantment.EnchantmentTarget;
import net.minecraft.enchantment.Enchantments;
import net.minecraft.entity.EquipmentSlot;

public class MultishotEnchantment
extends Enchantment {
    public MultishotEnchantment(Enchantment.Rarity rarity, EquipmentSlot ... equipmentSlots) {
        super(rarity, EnchantmentTarget.field_9081, equipmentSlots);
    }

    @Override
    public int getMinPower(int i) {
        return 20;
    }

    @Override
    public int getMaxPower(int i) {
        return 50;
    }

    @Override
    public boolean canAccept(Enchantment enchantment) {
        return super.canAccept(enchantment) && enchantment != Enchantments.field_9132;
    }
}


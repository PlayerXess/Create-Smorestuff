/*
 * Decompiled with CFR 0.2.1 (FabricMC 53fa44c9).
 */
package net.minecraft.client.item;

public interface TooltipContext {
    public static final Default BASIC = new Default(false, false);
    public static final Default ADVANCED = new Default(true, false);

    public boolean isAdvanced();

    public boolean isCreative();

    public record Default(boolean comp_1152, boolean comp_1153) implements TooltipContext
    {
        @Override
        public boolean isAdvanced() {
            return this.comp_1152;
        }

        @Override
        public boolean isCreative() {
            return this.comp_1153;
        }

        public Default withCreative() {
            return new Default(this.comp_1152, true);
        }
    }
}


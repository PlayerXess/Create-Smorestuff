/*
 * Decompiled with CFR 0.2.1 (FabricMC 53fa44c9).
 */
package net.minecraft.item.trim;

import com.mojang.datafixers.kinds.Applicative;
import com.mojang.logging.LogUtils;
import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.function.Function;
import net.minecraft.item.ArmorMaterial;
import net.minecraft.item.ArmorMaterials;
import net.minecraft.item.ItemStack;
import net.minecraft.item.trim.ArmorTrimMaterial;
import net.minecraft.item.trim.ArmorTrimPattern;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.nbt.NbtOps;
import net.minecraft.registry.DynamicRegistryManager;
import net.minecraft.registry.RegistryOps;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.registry.tag.ItemTags;
import net.minecraft.screen.ScreenTexts;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.Identifier;
import net.minecraft.util.Util;
import org.slf4j.Logger;

public class ArmorTrim {
    public static final Codec<ArmorTrim> CODEC = RecordCodecBuilder.create(instance -> instance.group(((MapCodec)ArmorTrimMaterial.ENTRY_CODEC.fieldOf("material")).forGetter(ArmorTrim::getMaterial), ((MapCodec)ArmorTrimPattern.ENTRY_CODEC.fieldOf("pattern")).forGetter(ArmorTrim::getPattern)).apply((Applicative<ArmorTrim, ?>)instance, ArmorTrim::new));
    private static final Logger LOGGER = LogUtils.getLogger();
    public static final String NBT_KEY = "Trim";
    private static final Text UPGRADE_TEXT = Text.translatable(Util.createTranslationKey("item", new Identifier("smithing_template.upgrade"))).formatted(Formatting.field_1080);
    private final RegistryEntry<ArmorTrimMaterial> material;
    private final RegistryEntry<ArmorTrimPattern> pattern;
    private final Function<ArmorMaterial, Identifier> leggingsModelIdGetter;
    private final Function<ArmorMaterial, Identifier> genericModelIdGetter;

    public ArmorTrim(RegistryEntry<ArmorTrimMaterial> registryEntry, RegistryEntry<ArmorTrimPattern> registryEntry2) {
        this.material = registryEntry;
        this.pattern = registryEntry2;
        this.leggingsModelIdGetter = Util.memoize(armorMaterial -> {
            Identifier identifier = ((ArmorTrimPattern)registryEntry2.comp_349()).comp_1213();
            String string = this.getMaterialAssetNameFor((ArmorMaterial)armorMaterial);
            return identifier.withPath(string2 -> "trims/models/armor/" + string2 + "_leggings_" + string);
        });
        this.genericModelIdGetter = Util.memoize(armorMaterial -> {
            Identifier identifier = ((ArmorTrimPattern)registryEntry2.comp_349()).comp_1213();
            String string = this.getMaterialAssetNameFor((ArmorMaterial)armorMaterial);
            return identifier.withPath(string2 -> "trims/models/armor/" + string2 + "_" + string);
        });
    }

    private String getMaterialAssetNameFor(ArmorMaterial armorMaterial) {
        Map<ArmorMaterials, String> map = this.material.comp_349().comp_1237();
        if (armorMaterial instanceof ArmorMaterials && map.containsKey(armorMaterial)) {
            return map.get(armorMaterial);
        }
        return this.material.comp_349().comp_1208();
    }

    public boolean equals(RegistryEntry<ArmorTrimPattern> registryEntry, RegistryEntry<ArmorTrimMaterial> registryEntry2) {
        return registryEntry == this.pattern && registryEntry2 == this.material;
    }

    public RegistryEntry<ArmorTrimPattern> getPattern() {
        return this.pattern;
    }

    public RegistryEntry<ArmorTrimMaterial> getMaterial() {
        return this.material;
    }

    public Identifier getLeggingsModelId(ArmorMaterial armorMaterial) {
        return this.leggingsModelIdGetter.apply(armorMaterial);
    }

    public Identifier getGenericModelId(ArmorMaterial armorMaterial) {
        return this.genericModelIdGetter.apply(armorMaterial);
    }

    public boolean equals(Object object) {
        if (!(object instanceof ArmorTrim)) {
            return false;
        }
        ArmorTrim armorTrim = (ArmorTrim)object;
        return armorTrim.pattern == this.pattern && armorTrim.material == this.material;
    }

    public static boolean apply(DynamicRegistryManager dynamicRegistryManager, ItemStack itemStack, ArmorTrim armorTrim) {
        if (itemStack.isIn(ItemTags.field_41890)) {
            itemStack.getOrCreateNbt().put(NBT_KEY, CODEC.encodeStart(RegistryOps.of(NbtOps.INSTANCE, dynamicRegistryManager), armorTrim).result().orElseThrow());
            return true;
        }
        return false;
    }

    public static Optional<ArmorTrim> getTrim(DynamicRegistryManager dynamicRegistryManager, ItemStack itemStack) {
        if (itemStack.isIn(ItemTags.field_41890) && itemStack.getNbt() != null && itemStack.getNbt().contains(NBT_KEY)) {
            NbtCompound nbtCompound = itemStack.getSubNbt(NBT_KEY);
            ArmorTrim armorTrim = CODEC.parse(RegistryOps.of(NbtOps.INSTANCE, dynamicRegistryManager), nbtCompound).resultOrPartial(LOGGER::error).orElse(null);
            return Optional.ofNullable(armorTrim);
        }
        return Optional.empty();
    }

    public static void appendTooltip(ItemStack itemStack, DynamicRegistryManager dynamicRegistryManager, List<Text> list) {
        Optional<ArmorTrim> optional = ArmorTrim.getTrim(dynamicRegistryManager, itemStack);
        if (optional.isPresent()) {
            ArmorTrim armorTrim = optional.get();
            list.add(UPGRADE_TEXT);
            list.add(ScreenTexts.space().append(armorTrim.getPattern().comp_349().getDescription(armorTrim.getMaterial())));
            list.add(ScreenTexts.space().append(armorTrim.getMaterial().comp_349().comp_1212()));
        }
    }
}


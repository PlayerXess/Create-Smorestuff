/*
 * Decompiled with CFR 0.2.1 (FabricMC 53fa44c9).
 */
package net.minecraft.util;

import io.github.fabricators_of_create.porting_lib.tags.extensions.DyeExtension;
import it.unimi.dsi.fastutil.ints.Int2ObjectOpenHashMap;
import java.util.Arrays;
import java.util.function.IntFunction;
import java.util.stream.Collectors;
import net.minecraft.block.MapColor;
import net.minecraft.util.StringIdentifiable;
import net.minecraft.util.function.ValueLists;
import org.jetbrains.annotations.Contract;
import org.jetbrains.annotations.Nullable;

public enum DyeColor implements StringIdentifiable,
DyeExtension
{
    field_7952(0, "white", 0xF9FFFE, MapColor.WHITE, 0xF0F0F0, 0xFFFFFF),
    field_7946(1, "orange", 16351261, MapColor.ORANGE, 15435844, 16738335),
    field_7958(2, "magenta", 13061821, MapColor.MAGENTA, 12801229, 0xFF00FF),
    field_7951(3, "light_blue", 3847130, MapColor.LIGHT_BLUE, 6719955, 10141901),
    field_7947(4, "yellow", 16701501, MapColor.YELLOW, 14602026, 0xFFFF00),
    field_7961(5, "lime", 8439583, MapColor.LIME, 4312372, 0xBFFF00),
    field_7954(6, "pink", 15961002, MapColor.PINK, 14188952, 16738740),
    field_7944(7, "gray", 4673362, MapColor.GRAY, 0x434343, 0x808080),
    field_7967(8, "light_gray", 0x9D9D97, MapColor.LIGHT_GRAY, 0xABABAB, 0xD3D3D3),
    field_7955(9, "cyan", 1481884, MapColor.CYAN, 2651799, 65535),
    field_7945(10, "purple", 8991416, MapColor.PURPLE, 8073150, 10494192),
    field_7966(11, "blue", 3949738, MapColor.BLUE, 2437522, 255),
    field_7957(12, "brown", 8606770, MapColor.BROWN, 5320730, 9127187),
    field_7942(13, "green", 6192150, MapColor.GREEN, 3887386, 65280),
    field_7964(14, "red", 11546150, MapColor.RED, 11743532, 0xFF0000),
    field_7963(15, "black", 0x1D1D21, MapColor.BLACK, 0x1E1B1B, 0);

    private static final IntFunction<DyeColor> BY_ID;
    private static final Int2ObjectOpenHashMap<DyeColor> BY_FIREWORK_COLOR;
    public static final StringIdentifiable.Codec<DyeColor> CODEC;
    private final int id;
    private final String name;
    private final MapColor mapColor;
    private final float[] colorComponents;
    private final int fireworkColor;
    private final int signColor;

    private DyeColor(int j, String string2, int k, MapColor mapColor, int l, int m) {
        this.id = j;
        this.name = string2;
        this.mapColor = mapColor;
        this.signColor = m;
        int n = (k & 0xFF0000) >> 16;
        int o = (k & 0xFF00) >> 8;
        int p = (k & 0xFF) >> 0;
        this.colorComponents = new float[]{(float)n / 255.0f, (float)o / 255.0f, (float)p / 255.0f};
        this.fireworkColor = l;
    }

    public int getId() {
        return this.id;
    }

    public String getName() {
        return this.name;
    }

    public float[] getColorComponents() {
        return this.colorComponents;
    }

    public MapColor getMapColor() {
        return this.mapColor;
    }

    public int getFireworkColor() {
        return this.fireworkColor;
    }

    public int getSignColor() {
        return this.signColor;
    }

    public static DyeColor byId(int i) {
        return BY_ID.apply(i);
    }

    @Nullable
    @Contract(value="_,!null->!null;_,null->_")
    public static DyeColor byName(String string, @Nullable DyeColor dyeColor) {
        DyeColor dyeColor2 = CODEC.byId(string);
        return dyeColor2 != null ? dyeColor2 : dyeColor;
    }

    @Nullable
    public static DyeColor byFireworkColor(int i) {
        return BY_FIREWORK_COLOR.get(i);
    }

    public String toString() {
        return this.name;
    }

    @Override
    public String asString() {
        return this.name;
    }

    static {
        BY_ID = ValueLists.createIdToValueFunction(DyeColor::getId, DyeColor.values(), ValueLists.OutOfBoundsHandling.field_41664);
        BY_FIREWORK_COLOR = new Int2ObjectOpenHashMap<DyeColor>(Arrays.stream(DyeColor.values()).collect(Collectors.toMap(dyeColor -> dyeColor.fireworkColor, dyeColor -> dyeColor)));
        CODEC = StringIdentifiable.createCodec(DyeColor::values);
    }
}


/*
 * Decompiled with CFR 0.2.1 (FabricMC 53fa44c9).
 */
package net.minecraft.item;

import net.minecraft.block.BlockState;
import net.minecraft.block.BrushableBlock;
import net.minecraft.block.entity.BrushableBlockEntity;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.projectile.ProjectileUtil;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemUsageContext;
import net.minecraft.particle.BlockStateParticleEffect;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.network.ServerPlayNetworkHandler;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Arm;
import net.minecraft.util.Hand;
import net.minecraft.util.UseAction;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

public class BrushItem
extends Item {
    public static final int field_43390 = 10;
    private static final int MAX_BRUSH_TIME = 200;
    private static final double MAX_BRUSH_DISTANCE = Math.sqrt(ServerPlayNetworkHandler.MAX_BREAK_SQUARED_DISTANCE) - 1.0;

    public BrushItem(Item.Settings settings) {
        super(settings);
    }

    @Override
    public ActionResult useOnBlock(ItemUsageContext itemUsageContext) {
        PlayerEntity playerEntity = itemUsageContext.getPlayer();
        if (playerEntity != null && this.getHitResult(playerEntity).getType() == HitResult.Type.field_1332) {
            playerEntity.setCurrentHand(itemUsageContext.getHand());
        }
        return ActionResult.CONSUME;
    }

    @Override
    public UseAction getUseAction(ItemStack itemStack) {
        return UseAction.field_42717;
    }

    @Override
    public int getMaxUseTime(ItemStack itemStack) {
        return 200;
    }

    @Override
    public void usageTick(World world, LivingEntity livingEntity2, ItemStack itemStack, int i) {
        boolean bl;
        BlockHitResult blockHitResult;
        PlayerEntity playerEntity;
        block9: {
            block8: {
                if (i < 0 || !(livingEntity2 instanceof PlayerEntity)) {
                    livingEntity2.stopUsingItem();
                    return;
                }
                playerEntity = (PlayerEntity)livingEntity2;
                HitResult hitResult = this.getHitResult(livingEntity2);
                if (!(hitResult instanceof BlockHitResult)) break block8;
                blockHitResult = (BlockHitResult)hitResult;
                if (hitResult.getType() == HitResult.Type.field_1332) break block9;
            }
            livingEntity2.stopUsingItem();
            return;
        }
        int j = this.getMaxUseTime(itemStack) - i + 1;
        boolean bl2 = bl = j % 10 == 5;
        if (bl) {
            BrushableBlockEntity brushableBlockEntity;
            boolean bl22;
            SoundEvent soundEvent;
            BlockPos blockPos = blockHitResult.getBlockPos();
            BlockState blockState = world.getBlockState(blockPos);
            Arm arm = livingEntity2.getActiveHand() == Hand.field_5808 ? playerEntity.getMainArm() : playerEntity.getMainArm().getOpposite();
            this.addDustParticles(world, blockHitResult, blockState, livingEntity2.getRotationVec(0.0f), arm);
            Object object = blockState.getBlock();
            if (object instanceof BrushableBlock) {
                BrushableBlock brushableBlock = (BrushableBlock)object;
                soundEvent = brushableBlock.getBrushingSound();
            } else {
                soundEvent = SoundEvents.field_43155;
            }
            world.playSound(playerEntity, blockPos, soundEvent, SoundCategory.field_15245);
            if (!world.isClient() && (object = world.getBlockEntity(blockPos)) instanceof BrushableBlockEntity && (bl22 = (brushableBlockEntity = (BrushableBlockEntity)object).brush(world.getTime(), playerEntity, blockHitResult.getSide()))) {
                EquipmentSlot equipmentSlot = itemStack.equals(playerEntity.getEquippedStack(EquipmentSlot.field_6171)) ? EquipmentSlot.field_6171 : EquipmentSlot.field_6173;
                itemStack.damage(1, livingEntity2, livingEntity -> livingEntity.sendEquipmentBreakStatus(equipmentSlot));
            }
        }
    }

    private HitResult getHitResult(LivingEntity livingEntity) {
        return ProjectileUtil.getCollision(livingEntity, entity -> !entity.isSpectator() && entity.canHit(), MAX_BRUSH_DISTANCE);
    }

    public void addDustParticles(World world, BlockHitResult blockHitResult, BlockState blockState, Vec3d vec3d, Arm arm) {
        double d = 3.0;
        int i = arm == Arm.field_6183 ? 1 : -1;
        int j = world.getRandom().nextBetweenExclusive(7, 12);
        BlockStateParticleEffect blockStateParticleEffect = new BlockStateParticleEffect(ParticleTypes.field_11217, blockState);
        Direction direction = blockHitResult.getSide();
        DustParticlesOffset dustParticlesOffset = DustParticlesOffset.fromSide(vec3d, direction);
        Vec3d vec3d2 = blockHitResult.getPos();
        for (int k = 0; k < j; ++k) {
            world.addParticle(blockStateParticleEffect, vec3d2.x - (double)(direction == Direction.field_11039 ? 1.0E-6f : 0.0f), vec3d2.y, vec3d2.z - (double)(direction == Direction.field_11043 ? 1.0E-6f : 0.0f), dustParticlesOffset.comp_1286() * (double)i * 3.0 * world.getRandom().nextDouble(), 0.0, dustParticlesOffset.comp_1288() * (double)i * 3.0 * world.getRandom().nextDouble());
        }
    }

    record DustParticlesOffset(double comp_1286, double comp_1287, double comp_1288) {
        private static final double field_42685 = 1.0;
        private static final double field_42686 = 0.1;

        public static DustParticlesOffset fromSide(Vec3d vec3d, Direction direction) {
            double d = 0.0;
            return switch (direction) {
                default -> throw new IncompatibleClassChangeError();
                case Direction.field_11033, Direction.field_11036 -> new DustParticlesOffset(vec3d.getZ(), 0.0, -vec3d.getX());
                case Direction.field_11043 -> new DustParticlesOffset(1.0, 0.0, -0.1);
                case Direction.field_11035 -> new DustParticlesOffset(-1.0, 0.0, 0.1);
                case Direction.field_11039 -> new DustParticlesOffset(-0.1, 0.0, -1.0);
                case Direction.field_11034 -> new DustParticlesOffset(0.1, 0.0, 1.0);
            };
        }
    }
}


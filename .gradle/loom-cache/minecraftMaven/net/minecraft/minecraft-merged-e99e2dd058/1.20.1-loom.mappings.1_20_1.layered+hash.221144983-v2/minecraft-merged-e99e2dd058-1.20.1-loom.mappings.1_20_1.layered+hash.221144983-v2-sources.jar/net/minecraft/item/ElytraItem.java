/*
 * Decompiled with CFR 0.2.1 (FabricMC 53fa44c9).
 */
package net.minecraft.item;

import net.minecraft.block.DispenserBlock;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ArmorItem;
import net.minecraft.item.Equipment;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.world.World;

public class ElytraItem
extends Item
implements Equipment {
    public ElytraItem(Item.Settings settings) {
        super(settings);
        DispenserBlock.registerBehavior(this, ArmorItem.DISPENSER_BEHAVIOR);
    }

    public static boolean isUsable(ItemStack itemStack) {
        return itemStack.getDamage() < itemStack.getMaxDamage() - 1;
    }

    @Override
    public boolean canRepair(ItemStack itemStack, ItemStack itemStack2) {
        return itemStack2.isOf(Items.field_8614);
    }

    @Override
    public TypedActionResult<ItemStack> use(World world, PlayerEntity playerEntity, Hand hand) {
        return this.equipAndSwap(this, world, playerEntity, hand);
    }

    @Override
    public SoundEvent getEquipSound() {
        return SoundEvents.field_14966;
    }

    @Override
    public EquipmentSlot getSlotType() {
        return EquipmentSlot.field_6174;
    }
}


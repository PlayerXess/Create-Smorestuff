/*
 * Decompiled with CFR 0.2.1 (FabricMC 53fa44c9).
 */
package net.minecraft.item;

import com.google.common.collect.ImmutableMultimap;
import com.google.common.collect.Multimap;
import net.minecraft.block.BlockState;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.MovementType;
import net.minecraft.entity.attribute.EntityAttribute;
import net.minecraft.entity.attribute.EntityAttributeModifier;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.projectile.PersistentProjectileEntity;
import net.minecraft.entity.projectile.TridentEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Vanishable;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;
import net.minecraft.stat.Stats;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.util.UseAction;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

public class TridentItem
extends Item
implements Vanishable {
    public static final int field_30926 = 10;
    public static final float ATTACK_DAMAGE = 8.0f;
    public static final float field_30928 = 2.5f;
    private final Multimap<EntityAttribute, EntityAttributeModifier> attributeModifiers;

    public TridentItem(Item.Settings settings) {
        super(settings);
        ImmutableMultimap.Builder<EntityAttribute, EntityAttributeModifier> builder = ImmutableMultimap.builder();
        builder.put(EntityAttributes.field_23721, new EntityAttributeModifier(ATTACK_DAMAGE_MODIFIER_ID, "Tool modifier", 8.0, EntityAttributeModifier.Operation.ADDITION));
        builder.put(EntityAttributes.field_23723, new EntityAttributeModifier(ATTACK_SPEED_MODIFIER_ID, "Tool modifier", (double)-2.9f, EntityAttributeModifier.Operation.ADDITION));
        this.attributeModifiers = builder.build();
    }

    @Override
    public boolean canMine(BlockState blockState, World world, BlockPos blockPos, PlayerEntity playerEntity) {
        return !playerEntity.isCreative();
    }

    @Override
    public UseAction getUseAction(ItemStack itemStack) {
        return UseAction.field_8951;
    }

    @Override
    public int getMaxUseTime(ItemStack itemStack) {
        return 72000;
    }

    @Override
    public void onStoppedUsing(ItemStack itemStack, World world, LivingEntity livingEntity, int i) {
        if (!(livingEntity instanceof PlayerEntity)) {
            return;
        }
        PlayerEntity playerEntity2 = (PlayerEntity)livingEntity;
        int j = this.getMaxUseTime(itemStack) - i;
        if (j < 10) {
            return;
        }
        int k = EnchantmentHelper.getRiptide(itemStack);
        if (k > 0 && !playerEntity2.isTouchingWaterOrRain()) {
            return;
        }
        if (!world.isClient) {
            itemStack.damage(1, playerEntity2, playerEntity -> playerEntity.sendToolBreakStatus(livingEntity.getActiveHand()));
            if (k == 0) {
                TridentEntity tridentEntity = new TridentEntity(world, (LivingEntity)playerEntity2, itemStack);
                tridentEntity.setVelocity(playerEntity2, playerEntity2.getPitch(), playerEntity2.getYaw(), 0.0f, 2.5f + (float)k * 0.5f, 1.0f);
                if (playerEntity2.getAbilities().creativeMode) {
                    tridentEntity.pickupType = PersistentProjectileEntity.PickupPermission.field_7594;
                }
                world.spawnEntity(tridentEntity);
                world.playSoundFromEntity(null, tridentEntity, SoundEvents.field_15001, SoundCategory.field_15248, 1.0f, 1.0f);
                if (!playerEntity2.getAbilities().creativeMode) {
                    playerEntity2.getInventory().removeOne(itemStack);
                }
            }
        }
        playerEntity2.incrementStat(Stats.field_15372.getOrCreateStat(this));
        if (k > 0) {
            float f = playerEntity2.getYaw();
            float g = playerEntity2.getPitch();
            float h = -MathHelper.sin(f * ((float)Math.PI / 180)) * MathHelper.cos(g * ((float)Math.PI / 180));
            float l = -MathHelper.sin(g * ((float)Math.PI / 180));
            float m = MathHelper.cos(f * ((float)Math.PI / 180)) * MathHelper.cos(g * ((float)Math.PI / 180));
            float n = MathHelper.sqrt(h * h + l * l + m * m);
            float o = 3.0f * ((1.0f + (float)k) / 4.0f);
            playerEntity2.addVelocity(h *= o / n, l *= o / n, m *= o / n);
            playerEntity2.useRiptide(20);
            if (playerEntity2.isOnGround()) {
                float p = 1.1999999f;
                playerEntity2.move(MovementType.field_6308, new Vec3d(0.0, 1.1999999284744263, 0.0));
            }
            SoundEvent soundEvent = k >= 3 ? SoundEvents.field_14717 : (k == 2 ? SoundEvents.field_14806 : SoundEvents.field_14606);
            world.playSoundFromEntity(null, playerEntity2, soundEvent, SoundCategory.field_15248, 1.0f, 1.0f);
        }
    }

    @Override
    public TypedActionResult<ItemStack> use(World world, PlayerEntity playerEntity, Hand hand) {
        ItemStack itemStack = playerEntity.getStackInHand(hand);
        if (itemStack.getDamage() >= itemStack.getMaxDamage() - 1) {
            return TypedActionResult.fail(itemStack);
        }
        if (EnchantmentHelper.getRiptide(itemStack) > 0 && !playerEntity.isTouchingWaterOrRain()) {
            return TypedActionResult.fail(itemStack);
        }
        playerEntity.setCurrentHand(hand);
        return TypedActionResult.consume(itemStack);
    }

    @Override
    public boolean postHit(ItemStack itemStack, LivingEntity livingEntity2, LivingEntity livingEntity22) {
        itemStack.damage(1, livingEntity22, livingEntity -> livingEntity.sendEquipmentBreakStatus(EquipmentSlot.field_6173));
        return true;
    }

    @Override
    public boolean postMine(ItemStack itemStack, World world, BlockState blockState, BlockPos blockPos, LivingEntity livingEntity2) {
        if ((double)blockState.getHardness(world, blockPos) != 0.0) {
            itemStack.damage(2, livingEntity2, livingEntity -> livingEntity.sendEquipmentBreakStatus(EquipmentSlot.field_6173));
        }
        return true;
    }

    @Override
    public Multimap<EntityAttribute, EntityAttributeModifier> getAttributeModifiers(EquipmentSlot equipmentSlot) {
        if (equipmentSlot == EquipmentSlot.field_6173) {
            return this.attributeModifiers;
        }
        return super.getAttributeModifiers(equipmentSlot);
    }

    @Override
    public int getEnchantability() {
        return 1;
    }
}


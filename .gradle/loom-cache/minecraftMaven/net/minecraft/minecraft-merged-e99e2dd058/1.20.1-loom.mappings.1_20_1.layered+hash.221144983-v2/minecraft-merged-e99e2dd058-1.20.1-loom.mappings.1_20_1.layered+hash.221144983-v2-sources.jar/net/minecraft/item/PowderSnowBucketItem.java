/*
 * Decompiled with CFR 0.2.1 (FabricMC 53fa44c9).
 */
package net.minecraft.item;

import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.BlockItem;
import net.minecraft.item.FluidModificationItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemUsageContext;
import net.minecraft.item.Items;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvent;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraft.world.event.GameEvent;
import org.jetbrains.annotations.Nullable;

public class PowderSnowBucketItem
extends BlockItem
implements FluidModificationItem {
    private final SoundEvent placeSound;

    public PowderSnowBucketItem(Block block, SoundEvent soundEvent, Item.Settings settings) {
        super(block, settings);
        this.placeSound = soundEvent;
    }

    @Override
    public ActionResult useOnBlock(ItemUsageContext itemUsageContext) {
        ActionResult actionResult = super.useOnBlock(itemUsageContext);
        PlayerEntity playerEntity = itemUsageContext.getPlayer();
        if (actionResult.isAccepted() && playerEntity != null && !playerEntity.isCreative()) {
            Hand hand = itemUsageContext.getHand();
            playerEntity.setStackInHand(hand, Items.field_8550.getDefaultStack());
        }
        return actionResult;
    }

    @Override
    public String getTranslationKey() {
        return this.getOrCreateTranslationKey();
    }

    @Override
    protected SoundEvent getPlaceSound(BlockState blockState) {
        return this.placeSound;
    }

    @Override
    public boolean placeFluid(@Nullable PlayerEntity playerEntity, World world, BlockPos blockPos, @Nullable BlockHitResult blockHitResult) {
        if (world.isInBuildLimit(blockPos) && world.isAir(blockPos)) {
            if (!world.isClient) {
                world.setBlockState(blockPos, this.getBlock().getDefaultState(), 3);
            }
            world.emitGameEvent((Entity)playerEntity, GameEvent.field_28166, blockPos);
            world.playSound(playerEntity, blockPos, this.placeSound, SoundCategory.field_15245, 1.0f, 1.0f);
            return true;
        }
        return false;
    }
}


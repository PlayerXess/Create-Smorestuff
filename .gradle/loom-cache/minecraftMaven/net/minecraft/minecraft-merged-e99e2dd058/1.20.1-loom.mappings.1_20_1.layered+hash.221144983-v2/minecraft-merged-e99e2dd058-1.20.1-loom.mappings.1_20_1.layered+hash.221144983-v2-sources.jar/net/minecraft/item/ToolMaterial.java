/*
 * Decompiled with CFR 0.2.1 (FabricMC 53fa44c9).
 */
package net.minecraft.item;

import io.github.fabricators_of_create.porting_lib.extensions.extensions.TierExtensions;
import net.minecraft.recipe.Ingredient;

public interface ToolMaterial
extends TierExtensions {
    public int getDurability();

    public float getMiningSpeedMultiplier();

    public float getAttackDamage();

    public int getMiningLevel();

    public int getEnchantability();

    public Ingredient getRepairIngredient();
}


/*
 * Decompiled with CFR 0.2.1 (FabricMC 53fa44c9).
 */
package net.minecraft.item;

import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.BlockItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Vanishable;
import net.minecraft.resource.featuretoggle.ToggleableFeature;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;
import net.minecraft.stat.Stats;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.world.World;
import org.jetbrains.annotations.Nullable;

public interface Equipment
extends Vanishable {
    public EquipmentSlot getSlotType();

    default public SoundEvent getEquipSound() {
        return SoundEvents.field_14883;
    }

    default public TypedActionResult<ItemStack> equipAndSwap(Item item, World world, PlayerEntity playerEntity, Hand hand) {
        ItemStack itemStack = playerEntity.getStackInHand(hand);
        EquipmentSlot equipmentSlot = MobEntity.getPreferredEquipmentSlot(itemStack);
        ItemStack itemStack2 = playerEntity.getEquippedStack(equipmentSlot);
        if (EnchantmentHelper.hasBindingCurse(itemStack2) || ItemStack.areEqual(itemStack, itemStack2)) {
            return TypedActionResult.fail(itemStack);
        }
        if (!world.isClient()) {
            playerEntity.incrementStat(Stats.field_15372.getOrCreateStat(item));
        }
        ItemStack itemStack3 = itemStack2.isEmpty() ? itemStack : itemStack2.copyAndEmpty();
        ItemStack itemStack4 = itemStack.copyAndEmpty();
        playerEntity.equipStack(equipmentSlot, itemStack4);
        return TypedActionResult.success(itemStack3, world.isClient());
    }

    @Nullable
    public static Equipment fromStack(ItemStack itemStack) {
        BlockItem blockItem;
        Item item = itemStack.getItem();
        if (item instanceof Equipment) {
            Equipment equipment = (Equipment)((Object)item);
            return equipment;
        }
        ToggleableFeature toggleableFeature = itemStack.getItem();
        if (toggleableFeature instanceof BlockItem && (toggleableFeature = (blockItem = (BlockItem)toggleableFeature).getBlock()) instanceof Equipment) {
            Equipment equipment2 = (Equipment)((Object)toggleableFeature);
            return equipment2;
        }
        return null;
    }
}


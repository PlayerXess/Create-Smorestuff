/*
 * Decompiled with CFR 0.2.1 (FabricMC 53fa44c9).
 */
package net.minecraft.item;

import java.util.function.Consumer;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnReason;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemPlacementContext;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemUsageContext;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.ActionResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;
import net.minecraft.world.event.GameEvent;

public class ArmorStandItem
extends Item {
    public ArmorStandItem(Item.Settings settings) {
        super(settings);
    }

    @Override
    public ActionResult useOnBlock(ItemUsageContext itemUsageContext) {
        Direction direction = itemUsageContext.getSide();
        if (direction == Direction.field_11033) {
            return ActionResult.FAIL;
        }
        World world = itemUsageContext.getWorld();
        ItemPlacementContext itemPlacementContext = new ItemPlacementContext(itemUsageContext);
        BlockPos blockPos = itemPlacementContext.getBlockPos();
        ItemStack itemStack = itemUsageContext.getStack();
        Vec3d vec3d = Vec3d.ofBottomCenter(blockPos);
        Box box = EntityType.field_6131.getDimensions().getBoxAt(vec3d.getX(), vec3d.getY(), vec3d.getZ());
        if (!world.isSpaceEmpty(null, box) || !world.getOtherEntities(null, box).isEmpty()) {
            return ActionResult.FAIL;
        }
        if (world instanceof ServerWorld) {
            ServerWorld serverWorld = (ServerWorld)world;
            Consumer consumer = EntityType.copier(serverWorld, itemStack, itemUsageContext.getPlayer());
            ArmorStandEntity armorStandEntity = EntityType.field_6131.create(serverWorld, itemStack.getNbt(), consumer, blockPos, SpawnReason.field_16465, true, true);
            if (armorStandEntity == null) {
                return ActionResult.FAIL;
            }
            float f = (float)MathHelper.floor((MathHelper.wrapDegrees(itemUsageContext.getPlayerYaw() - 180.0f) + 22.5f) / 45.0f) * 45.0f;
            armorStandEntity.refreshPositionAndAngles(armorStandEntity.getX(), armorStandEntity.getY(), armorStandEntity.getZ(), f, 0.0f);
            serverWorld.spawnEntityAndPassengers(armorStandEntity);
            world.playSound(null, armorStandEntity.getX(), armorStandEntity.getY(), armorStandEntity.getZ(), SoundEvents.field_14969, SoundCategory.field_15245, 0.75f, 0.8f);
            armorStandEntity.emitGameEvent(GameEvent.field_28738, itemUsageContext.getPlayer());
        }
        itemStack.decrement(1);
        return ActionResult.success(world.isClient);
    }
}


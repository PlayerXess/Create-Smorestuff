/*
 * Decompiled with CFR 0.2.1 (FabricMC 53fa44c9).
 */
package net.minecraft.world;

import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.world.BlockView;
import net.minecraft.world.LightType;
import net.minecraft.world.biome.ColorResolver;
import net.minecraft.world.chunk.light.LightingProvider;

public interface BlockRenderView
extends BlockView {
    public float getBrightness(Direction var1, boolean var2);

    public LightingProvider getLightingProvider();

    public int getColor(BlockPos var1, ColorResolver var2);

    default public int getLightLevel(LightType lightType, BlockPos blockPos) {
        return this.getLightingProvider().get(lightType).getLightLevel(blockPos);
    }

    default public int getBaseLightLevel(BlockPos blockPos, int i) {
        return this.getLightingProvider().getLight(blockPos, i);
    }

    default public boolean isSkyVisible(BlockPos blockPos) {
        return this.getLightLevel(LightType.field_9284, blockPos) >= this.getMaxLightLevel();
    }
}


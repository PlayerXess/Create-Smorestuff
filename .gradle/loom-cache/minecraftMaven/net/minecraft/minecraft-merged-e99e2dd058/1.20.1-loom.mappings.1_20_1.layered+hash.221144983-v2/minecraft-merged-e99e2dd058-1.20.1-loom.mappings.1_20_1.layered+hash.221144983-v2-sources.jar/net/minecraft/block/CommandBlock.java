/*
 * Decompiled with CFR 0.2.1 (FabricMC 53fa44c9).
 */
package net.minecraft.block;

import com.mojang.logging.LogUtils;
import net.minecraft.block.AbstractBlock;
import net.minecraft.block.Block;
import net.minecraft.block.BlockRenderType;
import net.minecraft.block.BlockState;
import net.minecraft.block.BlockWithEntity;
import net.minecraft.block.Blocks;
import net.minecraft.block.FacingBlock;
import net.minecraft.block.OperatorBlock;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.block.entity.CommandBlockBlockEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.BlockItem;
import net.minecraft.item.ItemPlacementContext;
import net.minecraft.item.ItemStack;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.state.StateManager;
import net.minecraft.state.property.BooleanProperty;
import net.minecraft.state.property.DirectionProperty;
import net.minecraft.state.property.Properties;
import net.minecraft.util.ActionResult;
import net.minecraft.util.BlockMirror;
import net.minecraft.util.BlockRotation;
import net.minecraft.util.Hand;
import net.minecraft.util.StringHelper;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.random.Random;
import net.minecraft.world.CommandBlockExecutor;
import net.minecraft.world.GameRules;
import net.minecraft.world.World;
import org.slf4j.Logger;

public class CommandBlock
extends BlockWithEntity
implements OperatorBlock {
    private static final Logger LOGGER = LogUtils.getLogger();
    public static final DirectionProperty FACING = FacingBlock.FACING;
    public static final BooleanProperty CONDITIONAL = Properties.CONDITIONAL;
    private final boolean auto;

    public CommandBlock(AbstractBlock.Settings settings, boolean bl) {
        super(settings);
        this.setDefaultState((BlockState)((BlockState)((BlockState)this.stateManager.getDefaultState()).with(FACING, Direction.field_11043)).with(CONDITIONAL, false));
        this.auto = bl;
    }

    @Override
    public BlockEntity createBlockEntity(BlockPos blockPos, BlockState blockState) {
        CommandBlockBlockEntity commandBlockBlockEntity = new CommandBlockBlockEntity(blockPos, blockState);
        commandBlockBlockEntity.setAuto(this.auto);
        return commandBlockBlockEntity;
    }

    @Override
    public void neighborUpdate(BlockState blockState, World world, BlockPos blockPos, Block block, BlockPos blockPos2, boolean bl) {
        if (world.isClient) {
            return;
        }
        BlockEntity blockEntity = world.getBlockEntity(blockPos);
        if (!(blockEntity instanceof CommandBlockBlockEntity)) {
            return;
        }
        CommandBlockBlockEntity commandBlockBlockEntity = (CommandBlockBlockEntity)blockEntity;
        boolean bl2 = world.isReceivingRedstonePower(blockPos);
        boolean bl3 = commandBlockBlockEntity.isPowered();
        commandBlockBlockEntity.setPowered(bl2);
        if (bl3 || commandBlockBlockEntity.isAuto() || commandBlockBlockEntity.getCommandBlockType() == CommandBlockBlockEntity.Type.field_11922) {
            return;
        }
        if (bl2) {
            commandBlockBlockEntity.updateConditionMet();
            world.scheduleBlockTick(blockPos, this, 1);
        }
    }

    @Override
    public void scheduledTick(BlockState blockState, ServerWorld serverWorld, BlockPos blockPos, Random random) {
        BlockEntity blockEntity = serverWorld.getBlockEntity(blockPos);
        if (blockEntity instanceof CommandBlockBlockEntity) {
            CommandBlockBlockEntity commandBlockBlockEntity = (CommandBlockBlockEntity)blockEntity;
            CommandBlockExecutor commandBlockExecutor = commandBlockBlockEntity.getCommandExecutor();
            boolean bl = !StringHelper.isEmpty(commandBlockExecutor.getCommand());
            CommandBlockBlockEntity.Type type = commandBlockBlockEntity.getCommandBlockType();
            boolean bl2 = commandBlockBlockEntity.isConditionMet();
            if (type == CommandBlockBlockEntity.Type.field_11923) {
                commandBlockBlockEntity.updateConditionMet();
                if (bl2) {
                    this.execute(blockState, serverWorld, blockPos, commandBlockExecutor, bl);
                } else if (commandBlockBlockEntity.isConditionalCommandBlock()) {
                    commandBlockExecutor.setSuccessCount(0);
                }
                if (commandBlockBlockEntity.isPowered() || commandBlockBlockEntity.isAuto()) {
                    serverWorld.scheduleBlockTick(blockPos, this, 1);
                }
            } else if (type == CommandBlockBlockEntity.Type.field_11924) {
                if (bl2) {
                    this.execute(blockState, serverWorld, blockPos, commandBlockExecutor, bl);
                } else if (commandBlockBlockEntity.isConditionalCommandBlock()) {
                    commandBlockExecutor.setSuccessCount(0);
                }
            }
            serverWorld.updateComparators(blockPos, this);
        }
    }

    private void execute(BlockState blockState, World world, BlockPos blockPos, CommandBlockExecutor commandBlockExecutor, boolean bl) {
        if (bl) {
            commandBlockExecutor.execute(world);
        } else {
            commandBlockExecutor.setSuccessCount(0);
        }
        CommandBlock.executeCommandChain(world, blockPos, blockState.get(FACING));
    }

    @Override
    public ActionResult onUse(BlockState blockState, World world, BlockPos blockPos, PlayerEntity playerEntity, Hand hand, BlockHitResult blockHitResult) {
        BlockEntity blockEntity = world.getBlockEntity(blockPos);
        if (blockEntity instanceof CommandBlockBlockEntity && playerEntity.isCreativeLevelTwoOp()) {
            playerEntity.openCommandBlockScreen((CommandBlockBlockEntity)blockEntity);
            return ActionResult.success(world.isClient);
        }
        return ActionResult.PASS;
    }

    @Override
    public boolean hasComparatorOutput(BlockState blockState) {
        return true;
    }

    @Override
    public int getComparatorOutput(BlockState blockState, World world, BlockPos blockPos) {
        BlockEntity blockEntity = world.getBlockEntity(blockPos);
        if (blockEntity instanceof CommandBlockBlockEntity) {
            return ((CommandBlockBlockEntity)blockEntity).getCommandExecutor().getSuccessCount();
        }
        return 0;
    }

    @Override
    public void onPlaced(World world, BlockPos blockPos, BlockState blockState, LivingEntity livingEntity, ItemStack itemStack) {
        BlockEntity blockEntity = world.getBlockEntity(blockPos);
        if (!(blockEntity instanceof CommandBlockBlockEntity)) {
            return;
        }
        CommandBlockBlockEntity commandBlockBlockEntity = (CommandBlockBlockEntity)blockEntity;
        CommandBlockExecutor commandBlockExecutor = commandBlockBlockEntity.getCommandExecutor();
        if (itemStack.hasCustomName()) {
            commandBlockExecutor.setCustomName(itemStack.getName());
        }
        if (!world.isClient) {
            if (BlockItem.getBlockEntityNbt(itemStack) == null) {
                commandBlockExecutor.setTrackOutput(world.getGameRules().getBoolean(GameRules.field_19400));
                commandBlockBlockEntity.setAuto(this.auto);
            }
            if (commandBlockBlockEntity.getCommandBlockType() == CommandBlockBlockEntity.Type.field_11922) {
                boolean bl = world.isReceivingRedstonePower(blockPos);
                commandBlockBlockEntity.setPowered(bl);
            }
        }
    }

    @Override
    public BlockRenderType getRenderType(BlockState blockState) {
        return BlockRenderType.field_11458;
    }

    @Override
    public BlockState rotate(BlockState blockState, BlockRotation blockRotation) {
        return (BlockState)blockState.with(FACING, blockRotation.rotate(blockState.get(FACING)));
    }

    @Override
    public BlockState mirror(BlockState blockState, BlockMirror blockMirror) {
        return blockState.rotate(blockMirror.getRotation(blockState.get(FACING)));
    }

    @Override
    protected void appendProperties(StateManager.Builder<Block, BlockState> builder) {
        builder.add(FACING, CONDITIONAL);
    }

    @Override
    public BlockState getPlacementState(ItemPlacementContext itemPlacementContext) {
        return (BlockState)this.getDefaultState().with(FACING, itemPlacementContext.getPlayerLookDirection().getOpposite());
    }

    private static void executeCommandChain(World world, BlockPos blockPos, Direction direction) {
        BlockPos.Mutable mutable = blockPos.mutableCopy();
        GameRules gameRules = world.getGameRules();
        int i = gameRules.getInt(GameRules.field_19408);
        while (i-- > 0) {
            CommandBlockBlockEntity commandBlockBlockEntity;
            BlockEntity blockEntity;
            mutable.move(direction);
            BlockState blockState = world.getBlockState(mutable);
            Block block = blockState.getBlock();
            if (!blockState.isOf(Blocks.field_10395) || !((blockEntity = world.getBlockEntity(mutable)) instanceof CommandBlockBlockEntity) || (commandBlockBlockEntity = (CommandBlockBlockEntity)blockEntity).getCommandBlockType() != CommandBlockBlockEntity.Type.field_11922) break;
            if (commandBlockBlockEntity.isPowered() || commandBlockBlockEntity.isAuto()) {
                CommandBlockExecutor commandBlockExecutor = commandBlockBlockEntity.getCommandExecutor();
                if (commandBlockBlockEntity.updateConditionMet()) {
                    if (!commandBlockExecutor.execute(world)) break;
                    world.updateComparators(mutable, block);
                } else if (commandBlockBlockEntity.isConditionalCommandBlock()) {
                    commandBlockExecutor.setSuccessCount(0);
                }
            }
            direction = blockState.get(FACING);
        }
        if (i <= 0) {
            int j = Math.max(gameRules.getInt(GameRules.field_19408), 0);
            LOGGER.warn("Command Block chain tried to execute more than {} steps!", (Object)j);
        }
    }
}


/*
 * Decompiled with CFR 0.2.1 (FabricMC 53fa44c9).
 */
package net.minecraft.recipe.book;

import net.minecraft.util.StringIdentifiable;

public enum CraftingRecipeCategory implements StringIdentifiable
{
    field_40248("building"),
    field_40249("redstone"),
    field_40250("equipment"),
    field_40251("misc");

    public static final StringIdentifiable.Codec<CraftingRecipeCategory> CODEC;
    private final String id;

    private CraftingRecipeCategory(String string2) {
        this.id = string2;
    }

    @Override
    public String asString() {
        return this.id;
    }

    static {
        CODEC = StringIdentifiable.createCodec(CraftingRecipeCategory::values);
    }
}


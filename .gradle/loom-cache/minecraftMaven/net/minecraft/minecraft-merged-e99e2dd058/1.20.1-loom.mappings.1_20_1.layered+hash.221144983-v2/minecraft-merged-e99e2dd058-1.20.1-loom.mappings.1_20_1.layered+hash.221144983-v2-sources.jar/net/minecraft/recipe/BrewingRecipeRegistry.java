/*
 * Decompiled with CFR 0.2.1 (FabricMC 53fa44c9).
 */
package net.minecraft.recipe;

import com.google.common.collect.Lists;
import java.util.List;
import java.util.function.Predicate;
import net.minecraft.item.Item;
import net.minecraft.item.ItemConvertible;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.item.PotionItem;
import net.minecraft.potion.Potion;
import net.minecraft.potion.PotionUtil;
import net.minecraft.potion.Potions;
import net.minecraft.recipe.Ingredient;
import net.minecraft.registry.Registries;

public class BrewingRecipeRegistry {
    public static final int field_30942 = 20;
    private static final List<Recipe<Potion>> POTION_RECIPES = Lists.newArrayList();
    private static final List<Recipe<Item>> ITEM_RECIPES = Lists.newArrayList();
    private static final List<Ingredient> POTION_TYPES = Lists.newArrayList();
    private static final Predicate<ItemStack> POTION_TYPE_PREDICATE = itemStack -> {
        for (Ingredient ingredient : POTION_TYPES) {
            if (!ingredient.test((ItemStack)itemStack)) continue;
            return true;
        }
        return false;
    };

    public static boolean isValidIngredient(ItemStack itemStack) {
        return BrewingRecipeRegistry.isItemRecipeIngredient(itemStack) || BrewingRecipeRegistry.isPotionRecipeIngredient(itemStack);
    }

    protected static boolean isItemRecipeIngredient(ItemStack itemStack) {
        int j = ITEM_RECIPES.size();
        for (int i = 0; i < j; ++i) {
            if (!BrewingRecipeRegistry.ITEM_RECIPES.get((int)i).ingredient.test(itemStack)) continue;
            return true;
        }
        return false;
    }

    protected static boolean isPotionRecipeIngredient(ItemStack itemStack) {
        int j = POTION_RECIPES.size();
        for (int i = 0; i < j; ++i) {
            if (!BrewingRecipeRegistry.POTION_RECIPES.get((int)i).ingredient.test(itemStack)) continue;
            return true;
        }
        return false;
    }

    public static boolean isBrewable(Potion potion) {
        int j = POTION_RECIPES.size();
        for (int i = 0; i < j; ++i) {
            if (BrewingRecipeRegistry.POTION_RECIPES.get((int)i).output != potion) continue;
            return true;
        }
        return false;
    }

    public static boolean hasRecipe(ItemStack itemStack, ItemStack itemStack2) {
        if (!POTION_TYPE_PREDICATE.test(itemStack)) {
            return false;
        }
        return BrewingRecipeRegistry.hasItemRecipe(itemStack, itemStack2) || BrewingRecipeRegistry.hasPotionRecipe(itemStack, itemStack2);
    }

    protected static boolean hasItemRecipe(ItemStack itemStack, ItemStack itemStack2) {
        Item item = itemStack.getItem();
        int j = ITEM_RECIPES.size();
        for (int i = 0; i < j; ++i) {
            Recipe<Item> recipe = ITEM_RECIPES.get(i);
            if (recipe.input != item || !recipe.ingredient.test(itemStack2)) continue;
            return true;
        }
        return false;
    }

    protected static boolean hasPotionRecipe(ItemStack itemStack, ItemStack itemStack2) {
        Potion potion = PotionUtil.getPotion(itemStack);
        int j = POTION_RECIPES.size();
        for (int i = 0; i < j; ++i) {
            Recipe<Potion> recipe = POTION_RECIPES.get(i);
            if (recipe.input != potion || !recipe.ingredient.test(itemStack2)) continue;
            return true;
        }
        return false;
    }

    public static ItemStack craft(ItemStack itemStack, ItemStack itemStack2) {
        if (!itemStack2.isEmpty()) {
            Recipe<Object> recipe;
            int i;
            Potion potion = PotionUtil.getPotion(itemStack2);
            Item item = itemStack2.getItem();
            int j = ITEM_RECIPES.size();
            for (i = 0; i < j; ++i) {
                recipe = ITEM_RECIPES.get(i);
                if (recipe.input != item || !recipe.ingredient.test(itemStack)) continue;
                return PotionUtil.setPotion(new ItemStack((ItemConvertible)recipe.output), potion);
            }
            j = POTION_RECIPES.size();
            for (i = 0; i < j; ++i) {
                recipe = POTION_RECIPES.get(i);
                if (recipe.input != potion || !recipe.ingredient.test(itemStack)) continue;
                return PotionUtil.setPotion(new ItemStack(item), (Potion)recipe.output);
            }
        }
        return itemStack2;
    }

    public static void registerDefaults() {
        BrewingRecipeRegistry.registerPotionType(Items.field_8574);
        BrewingRecipeRegistry.registerPotionType(Items.field_8436);
        BrewingRecipeRegistry.registerPotionType(Items.field_8150);
        BrewingRecipeRegistry.registerItemRecipe(Items.field_8574, Items.field_8054, Items.field_8436);
        BrewingRecipeRegistry.registerItemRecipe(Items.field_8436, Items.field_8613, Items.field_8150);
        BrewingRecipeRegistry.registerPotionRecipe(Potions.field_8991, Items.field_8597, Potions.field_8967);
        BrewingRecipeRegistry.registerPotionRecipe(Potions.field_8991, Items.field_8070, Potions.field_8967);
        BrewingRecipeRegistry.registerPotionRecipe(Potions.field_8991, Items.field_8073, Potions.field_8967);
        BrewingRecipeRegistry.registerPotionRecipe(Potions.field_8991, Items.field_8183, Potions.field_8967);
        BrewingRecipeRegistry.registerPotionRecipe(Potions.field_8991, Items.field_8680, Potions.field_8967);
        BrewingRecipeRegistry.registerPotionRecipe(Potions.field_8991, Items.field_8479, Potions.field_8967);
        BrewingRecipeRegistry.registerPotionRecipe(Potions.field_8991, Items.field_8135, Potions.field_8967);
        BrewingRecipeRegistry.registerPotionRecipe(Potions.field_8991, Items.field_8601, Potions.field_8985);
        BrewingRecipeRegistry.registerPotionRecipe(Potions.field_8991, Items.field_8725, Potions.field_8967);
        BrewingRecipeRegistry.registerPotionRecipe(Potions.field_8991, Items.field_8790, Potions.field_8999);
        BrewingRecipeRegistry.registerPotionRecipe(Potions.field_8999, Items.field_8071, Potions.field_8968);
        BrewingRecipeRegistry.registerPotionRecipe(Potions.field_8968, Items.field_8725, Potions.field_8981);
        BrewingRecipeRegistry.registerPotionRecipe(Potions.field_8968, Items.field_8711, Potions.field_8997);
        BrewingRecipeRegistry.registerPotionRecipe(Potions.field_8981, Items.field_8711, Potions.field_9000);
        BrewingRecipeRegistry.registerPotionRecipe(Potions.field_8997, Items.field_8725, Potions.field_9000);
        BrewingRecipeRegistry.registerPotionRecipe(Potions.field_8999, Items.field_8135, Potions.field_8987);
        BrewingRecipeRegistry.registerPotionRecipe(Potions.field_8987, Items.field_8725, Potions.field_8969);
        BrewingRecipeRegistry.registerPotionRecipe(Potions.field_8999, Items.field_8073, Potions.field_8979);
        BrewingRecipeRegistry.registerPotionRecipe(Potions.field_8979, Items.field_8725, Potions.field_8971);
        BrewingRecipeRegistry.registerPotionRecipe(Potions.field_8979, Items.field_8601, Potions.field_8998);
        BrewingRecipeRegistry.registerPotionRecipe(Potions.field_8979, Items.field_8711, Potions.field_8996);
        BrewingRecipeRegistry.registerPotionRecipe(Potions.field_8971, Items.field_8711, Potions.field_8989);
        BrewingRecipeRegistry.registerPotionRecipe(Potions.field_8996, Items.field_8725, Potions.field_8989);
        BrewingRecipeRegistry.registerPotionRecipe(Potions.field_8996, Items.field_8601, Potions.field_8976);
        BrewingRecipeRegistry.registerPotionRecipe(Potions.field_8999, Items.field_8090, Potions.field_8990);
        BrewingRecipeRegistry.registerPotionRecipe(Potions.field_8990, Items.field_8725, Potions.field_8988);
        BrewingRecipeRegistry.registerPotionRecipe(Potions.field_8990, Items.field_8601, Potions.field_8977);
        BrewingRecipeRegistry.registerPotionRecipe(Potions.field_9005, Items.field_8711, Potions.field_8996);
        BrewingRecipeRegistry.registerPotionRecipe(Potions.field_8983, Items.field_8711, Potions.field_8989);
        BrewingRecipeRegistry.registerPotionRecipe(Potions.field_8999, Items.field_8479, Potions.field_9005);
        BrewingRecipeRegistry.registerPotionRecipe(Potions.field_9005, Items.field_8725, Potions.field_8983);
        BrewingRecipeRegistry.registerPotionRecipe(Potions.field_9005, Items.field_8601, Potions.field_8966);
        BrewingRecipeRegistry.registerPotionRecipe(Potions.field_8999, Items.field_8323, Potions.field_8994);
        BrewingRecipeRegistry.registerPotionRecipe(Potions.field_8994, Items.field_8725, Potions.field_9001);
        BrewingRecipeRegistry.registerPotionRecipe(Potions.field_8999, Items.field_8597, Potions.field_8963);
        BrewingRecipeRegistry.registerPotionRecipe(Potions.field_8963, Items.field_8601, Potions.field_8980);
        BrewingRecipeRegistry.registerPotionRecipe(Potions.field_8963, Items.field_8711, Potions.field_9004);
        BrewingRecipeRegistry.registerPotionRecipe(Potions.field_8980, Items.field_8711, Potions.field_8973);
        BrewingRecipeRegistry.registerPotionRecipe(Potions.field_9004, Items.field_8601, Potions.field_8973);
        BrewingRecipeRegistry.registerPotionRecipe(Potions.field_8982, Items.field_8711, Potions.field_9004);
        BrewingRecipeRegistry.registerPotionRecipe(Potions.field_9002, Items.field_8711, Potions.field_9004);
        BrewingRecipeRegistry.registerPotionRecipe(Potions.field_8972, Items.field_8711, Potions.field_8973);
        BrewingRecipeRegistry.registerPotionRecipe(Potions.field_8999, Items.field_8680, Potions.field_8982);
        BrewingRecipeRegistry.registerPotionRecipe(Potions.field_8982, Items.field_8725, Potions.field_9002);
        BrewingRecipeRegistry.registerPotionRecipe(Potions.field_8982, Items.field_8601, Potions.field_8972);
        BrewingRecipeRegistry.registerPotionRecipe(Potions.field_8999, Items.field_8070, Potions.field_8986);
        BrewingRecipeRegistry.registerPotionRecipe(Potions.field_8986, Items.field_8725, Potions.field_9003);
        BrewingRecipeRegistry.registerPotionRecipe(Potions.field_8986, Items.field_8601, Potions.field_8992);
        BrewingRecipeRegistry.registerPotionRecipe(Potions.field_8999, Items.field_8183, Potions.field_8978);
        BrewingRecipeRegistry.registerPotionRecipe(Potions.field_8978, Items.field_8725, Potions.field_8965);
        BrewingRecipeRegistry.registerPotionRecipe(Potions.field_8978, Items.field_8601, Potions.field_8993);
        BrewingRecipeRegistry.registerPotionRecipe(Potions.field_8991, Items.field_8711, Potions.field_8975);
        BrewingRecipeRegistry.registerPotionRecipe(Potions.field_8975, Items.field_8725, Potions.field_8970);
        BrewingRecipeRegistry.registerPotionRecipe(Potions.field_8999, Items.field_8614, Potions.field_8974);
        BrewingRecipeRegistry.registerPotionRecipe(Potions.field_8974, Items.field_8725, Potions.field_8964);
    }

    public static void registerItemRecipe(Item item, Item item2, Item item3) {
        if (!(item instanceof PotionItem)) {
            throw new IllegalArgumentException("Expected a potion, got: " + Registries.ITEM.getId(item));
        }
        if (!(item3 instanceof PotionItem)) {
            throw new IllegalArgumentException("Expected a potion, got: " + Registries.ITEM.getId(item3));
        }
        ITEM_RECIPES.add(new Recipe<Item>(item, Ingredient.ofItems(item2), item3));
    }

    public static void registerPotionType(Item item) {
        if (!(item instanceof PotionItem)) {
            throw new IllegalArgumentException("Expected a potion, got: " + Registries.ITEM.getId(item));
        }
        POTION_TYPES.add(Ingredient.ofItems(item));
    }

    public static void registerPotionRecipe(Potion potion, Item item, Potion potion2) {
        POTION_RECIPES.add(new Recipe<Potion>(potion, Ingredient.ofItems(item), potion2));
    }

    public static class Recipe<T> {
        final T input;
        final Ingredient ingredient;
        final T output;

        public Recipe(T object, Ingredient ingredient, T object2) {
            this.input = object;
            this.ingredient = ingredient;
            this.output = object2;
        }
    }
}


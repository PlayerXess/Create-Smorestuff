/*
 * Decompiled with CFR 0.2.1 (FabricMC 53fa44c9).
 */
package net.minecraft.block;

import io.github.fabricators_of_create.porting_lib.common.util.IPlantable;
import net.minecraft.block.AbstractBlock;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.Fertilizable;
import net.minecraft.block.ShapeContext;
import net.minecraft.block.enums.BambooLeaves;
import net.minecraft.entity.ai.pathing.NavigationType;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.fluid.FluidState;
import net.minecraft.item.ItemPlacementContext;
import net.minecraft.item.SwordItem;
import net.minecraft.registry.tag.BlockTags;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.state.StateManager;
import net.minecraft.state.property.EnumProperty;
import net.minecraft.state.property.IntProperty;
import net.minecraft.state.property.Properties;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.math.random.Random;
import net.minecraft.util.shape.VoxelShape;
import net.minecraft.world.BlockView;
import net.minecraft.world.World;
import net.minecraft.world.WorldAccess;
import net.minecraft.world.WorldView;
import org.jetbrains.annotations.Nullable;

public class BambooBlock
extends Block
implements Fertilizable,
IPlantable {
    protected static final float field_30997 = 3.0f;
    protected static final float field_30998 = 5.0f;
    protected static final float field_30999 = 1.5f;
    protected static final VoxelShape SMALL_LEAVES_SHAPE = Block.createCuboidShape(5.0, 0.0, 5.0, 11.0, 16.0, 11.0);
    protected static final VoxelShape LARGE_LEAVES_SHAPE = Block.createCuboidShape(3.0, 0.0, 3.0, 13.0, 16.0, 13.0);
    protected static final VoxelShape NO_LEAVES_SHAPE = Block.createCuboidShape(6.5, 0.0, 6.5, 9.5, 16.0, 9.5);
    public static final IntProperty AGE = Properties.AGE_1;
    public static final EnumProperty<BambooLeaves> LEAVES = Properties.BAMBOO_LEAVES;
    public static final IntProperty STAGE = Properties.STAGE;
    public static final int field_31000 = 16;
    public static final int field_31001 = 0;
    public static final int field_31002 = 1;
    public static final int field_31003 = 0;
    public static final int field_31004 = 1;

    public BambooBlock(AbstractBlock.Settings settings) {
        super(settings);
        this.setDefaultState((BlockState)((BlockState)((BlockState)((BlockState)this.stateManager.getDefaultState()).with(AGE, 0)).with(LEAVES, BambooLeaves.field_12469)).with(STAGE, 0));
    }

    @Override
    protected void appendProperties(StateManager.Builder<Block, BlockState> builder) {
        builder.add(AGE, LEAVES, STAGE);
    }

    @Override
    public boolean isTransparent(BlockState blockState, BlockView blockView, BlockPos blockPos) {
        return true;
    }

    @Override
    public VoxelShape getOutlineShape(BlockState blockState, BlockView blockView, BlockPos blockPos, ShapeContext shapeContext) {
        VoxelShape voxelShape = blockState.get(LEAVES) == BambooLeaves.field_12468 ? LARGE_LEAVES_SHAPE : SMALL_LEAVES_SHAPE;
        Vec3d vec3d = blockState.getModelOffset(blockView, blockPos);
        return voxelShape.offset(vec3d.x, vec3d.y, vec3d.z);
    }

    @Override
    public boolean canPathfindThrough(BlockState blockState, BlockView blockView, BlockPos blockPos, NavigationType navigationType) {
        return false;
    }

    @Override
    public VoxelShape getCollisionShape(BlockState blockState, BlockView blockView, BlockPos blockPos, ShapeContext shapeContext) {
        Vec3d vec3d = blockState.getModelOffset(blockView, blockPos);
        return NO_LEAVES_SHAPE.offset(vec3d.x, vec3d.y, vec3d.z);
    }

    @Override
    public boolean isShapeFullCube(BlockState blockState, BlockView blockView, BlockPos blockPos) {
        return false;
    }

    @Override
    @Nullable
    public BlockState getPlacementState(ItemPlacementContext itemPlacementContext) {
        FluidState fluidState = itemPlacementContext.getWorld().getFluidState(itemPlacementContext.getBlockPos());
        if (!fluidState.isEmpty()) {
            return null;
        }
        BlockState blockState = itemPlacementContext.getWorld().getBlockState(itemPlacementContext.getBlockPos().down());
        if (blockState.isIn(BlockTags.field_15497)) {
            if (blockState.isOf(Blocks.field_10108)) {
                return (BlockState)this.getDefaultState().with(AGE, 0);
            }
            if (blockState.isOf(Blocks.field_10211)) {
                int i = blockState.get(AGE) > 0 ? 1 : 0;
                return (BlockState)this.getDefaultState().with(AGE, i);
            }
            BlockState blockState2 = itemPlacementContext.getWorld().getBlockState(itemPlacementContext.getBlockPos().up());
            if (blockState2.isOf(Blocks.field_10211)) {
                return (BlockState)this.getDefaultState().with(AGE, blockState2.get(AGE));
            }
            return Blocks.field_10108.getDefaultState();
        }
        return null;
    }

    @Override
    public void scheduledTick(BlockState blockState, ServerWorld serverWorld, BlockPos blockPos, Random random) {
        if (!blockState.canPlaceAt(serverWorld, blockPos)) {
            serverWorld.breakBlock(blockPos, true);
        }
    }

    @Override
    public boolean hasRandomTicks(BlockState blockState) {
        return blockState.get(STAGE) == 0;
    }

    @Override
    public void randomTick(BlockState blockState, ServerWorld serverWorld, BlockPos blockPos, Random random) {
        int i;
        if (blockState.get(STAGE) != 0) {
            return;
        }
        if (random.nextInt(3) == 0 && serverWorld.isAir(blockPos.up()) && serverWorld.getBaseLightLevel(blockPos.up(), 0) >= 9 && (i = this.countBambooBelow(serverWorld, blockPos) + 1) < 16) {
            this.updateLeaves(blockState, serverWorld, blockPos, random, i);
        }
    }

    @Override
    public boolean canPlaceAt(BlockState blockState, WorldView worldView, BlockPos blockPos) {
        return worldView.getBlockState(blockPos.down()).isIn(BlockTags.field_15497);
    }

    @Override
    public BlockState getStateForNeighborUpdate(BlockState blockState, Direction direction, BlockState blockState2, WorldAccess worldAccess, BlockPos blockPos, BlockPos blockPos2) {
        if (!blockState.canPlaceAt(worldAccess, blockPos)) {
            worldAccess.scheduleBlockTick(blockPos, this, 1);
        }
        if (direction == Direction.field_11036 && blockState2.isOf(Blocks.field_10211) && blockState2.get(AGE) > blockState.get(AGE)) {
            worldAccess.setBlockState(blockPos, (BlockState)blockState.cycle(AGE), 2);
        }
        return super.getStateForNeighborUpdate(blockState, direction, blockState2, worldAccess, blockPos, blockPos2);
    }

    @Override
    public boolean isFertilizable(WorldView worldView, BlockPos blockPos, BlockState blockState, boolean bl) {
        int j;
        int i = this.countBambooAbove(worldView, blockPos);
        return i + (j = this.countBambooBelow(worldView, blockPos)) + 1 < 16 && worldView.getBlockState(blockPos.up(i)).get(STAGE) != 1;
    }

    @Override
    public boolean canGrow(World world, Random random, BlockPos blockPos, BlockState blockState) {
        return true;
    }

    @Override
    public void grow(ServerWorld serverWorld, Random random, BlockPos blockPos, BlockState blockState) {
        int i = this.countBambooAbove(serverWorld, blockPos);
        int j = this.countBambooBelow(serverWorld, blockPos);
        int k = i + j + 1;
        int l = 1 + random.nextInt(2);
        for (int m = 0; m < l; ++m) {
            BlockPos blockPos2 = blockPos.up(i);
            BlockState blockState2 = serverWorld.getBlockState(blockPos2);
            if (k >= 16 || blockState2.get(STAGE) == 1 || !serverWorld.isAir(blockPos2.up())) {
                return;
            }
            this.updateLeaves(blockState2, serverWorld, blockPos2, random, k);
            ++i;
            ++k;
        }
    }

    @Override
    public float calcBlockBreakingDelta(BlockState blockState, PlayerEntity playerEntity, BlockView blockView, BlockPos blockPos) {
        if (playerEntity.getMainHandStack().getItem() instanceof SwordItem) {
            return 1.0f;
        }
        return super.calcBlockBreakingDelta(blockState, playerEntity, blockView, blockPos);
    }

    protected void updateLeaves(BlockState blockState, World world, BlockPos blockPos, Random random, int i) {
        BlockState blockState2 = world.getBlockState(blockPos.down());
        BlockPos blockPos2 = blockPos.down(2);
        BlockState blockState3 = world.getBlockState(blockPos2);
        BambooLeaves bambooLeaves = BambooLeaves.field_12469;
        if (i >= 1) {
            if (!blockState2.isOf(Blocks.field_10211) || blockState2.get(LEAVES) == BambooLeaves.field_12469) {
                bambooLeaves = BambooLeaves.field_12466;
            } else if (blockState2.isOf(Blocks.field_10211) && blockState2.get(LEAVES) != BambooLeaves.field_12469) {
                bambooLeaves = BambooLeaves.field_12468;
                if (blockState3.isOf(Blocks.field_10211)) {
                    world.setBlockState(blockPos.down(), (BlockState)blockState2.with(LEAVES, BambooLeaves.field_12466), 3);
                    world.setBlockState(blockPos2, (BlockState)blockState3.with(LEAVES, BambooLeaves.field_12469), 3);
                }
            }
        }
        int j = blockState.get(AGE) == 1 || blockState3.isOf(Blocks.field_10211) ? 1 : 0;
        int k = i >= 11 && random.nextFloat() < 0.25f || i == 15 ? 1 : 0;
        world.setBlockState(blockPos.up(), (BlockState)((BlockState)((BlockState)this.getDefaultState().with(AGE, j)).with(LEAVES, bambooLeaves)).with(STAGE, k), 3);
    }

    protected int countBambooAbove(BlockView blockView, BlockPos blockPos) {
        int i;
        for (i = 0; i < 16 && blockView.getBlockState(blockPos.up(i + 1)).isOf(Blocks.field_10211); ++i) {
        }
        return i;
    }

    protected int countBambooBelow(BlockView blockView, BlockPos blockPos) {
        int i;
        for (i = 0; i < 16 && blockView.getBlockState(blockPos.down(i + 1)).isOf(Blocks.field_10211); ++i) {
        }
        return i;
    }
}


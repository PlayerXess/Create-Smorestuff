/*
 * Decompiled with CFR 0.2.1 (FabricMC 53fa44c9).
 */
package net.minecraft.item;

import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.ItemSteerable;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.stat.Stats;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.world.World;

public class OnAStickItem<T extends Entity>
extends Item {
    private final EntityType<T> target;
    private final int damagePerUse;

    public OnAStickItem(Item.Settings settings, EntityType<T> entityType, int i) {
        super(settings);
        this.target = entityType;
        this.damagePerUse = i;
    }

    @Override
    public TypedActionResult<ItemStack> use(World world, PlayerEntity playerEntity2, Hand hand) {
        ItemStack itemStack = playerEntity2.getStackInHand(hand);
        if (world.isClient) {
            return TypedActionResult.pass(itemStack);
        }
        Entity entity = playerEntity2.getControllingVehicle();
        if (playerEntity2.hasVehicle() && entity instanceof ItemSteerable) {
            ItemSteerable itemSteerable = (ItemSteerable)((Object)entity);
            if (entity.getType() == this.target && itemSteerable.consumeOnAStickItem()) {
                itemStack.damage(this.damagePerUse, playerEntity2, playerEntity -> playerEntity.sendToolBreakStatus(hand));
                if (itemStack.isEmpty()) {
                    ItemStack itemStack2 = new ItemStack(Items.field_8378);
                    itemStack2.setNbt(itemStack.getNbt());
                    return TypedActionResult.success(itemStack2);
                }
                return TypedActionResult.success(itemStack);
            }
        }
        playerEntity2.incrementStat(Stats.field_15372.getOrCreateStat(this));
        return TypedActionResult.pass(itemStack);
    }
}


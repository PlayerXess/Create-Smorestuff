/*
 * Decompiled with CFR 0.2.1 (FabricMC 53fa44c9).
 */
package net.minecraft.recipe;

import net.minecraft.recipe.BlastingRecipe;
import net.minecraft.recipe.CampfireCookingRecipe;
import net.minecraft.recipe.CraftingRecipe;
import net.minecraft.recipe.Recipe;
import net.minecraft.recipe.SmeltingRecipe;
import net.minecraft.recipe.SmithingRecipe;
import net.minecraft.recipe.SmokingRecipe;
import net.minecraft.recipe.StonecuttingRecipe;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;

public interface RecipeType<T extends Recipe<?>> {
    public static final RecipeType<CraftingRecipe> field_17545 = RecipeType.register("crafting");
    public static final RecipeType<SmeltingRecipe> field_17546 = RecipeType.register("smelting");
    public static final RecipeType<BlastingRecipe> field_17547 = RecipeType.register("blasting");
    public static final RecipeType<SmokingRecipe> field_17548 = RecipeType.register("smoking");
    public static final RecipeType<CampfireCookingRecipe> field_17549 = RecipeType.register("campfire_cooking");
    public static final RecipeType<StonecuttingRecipe> field_17641 = RecipeType.register("stonecutting");
    public static final RecipeType<SmithingRecipe> field_25388 = RecipeType.register("smithing");

    public static <T extends Recipe<?>> RecipeType<T> register(final String string) {
        return Registry.register(Registries.RECIPE_TYPE, new Identifier(string), new RecipeType<T>(){

            public String toString() {
                return string;
            }
        });
    }
}


/*
 * Decompiled with CFR 0.2.1 (FabricMC 53fa44c9).
 */
package net.minecraft.screen.slot;

import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.screen.slot.Slot;
import net.minecraft.stat.Stats;
import net.minecraft.village.Merchant;
import net.minecraft.village.MerchantInventory;
import net.minecraft.village.TradeOffer;

public class TradeOutputSlot
extends Slot {
    private final MerchantInventory merchantInventory;
    private final PlayerEntity player;
    private int amount;
    private final Merchant merchant;

    public TradeOutputSlot(PlayerEntity playerEntity, Merchant merchant, MerchantInventory merchantInventory, int i, int j, int k) {
        super(merchantInventory, i, j, k);
        this.player = playerEntity;
        this.merchant = merchant;
        this.merchantInventory = merchantInventory;
    }

    @Override
    public boolean canInsert(ItemStack itemStack) {
        return false;
    }

    @Override
    public ItemStack takeStack(int i) {
        if (this.hasStack()) {
            this.amount += Math.min(i, this.getStack().getCount());
        }
        return super.takeStack(i);
    }

    @Override
    protected void onCrafted(ItemStack itemStack, int i) {
        this.amount += i;
        this.onCrafted(itemStack);
    }

    @Override
    protected void onCrafted(ItemStack itemStack) {
        itemStack.onCraft(this.player.getWorld(), this.player, this.amount);
        this.amount = 0;
    }

    @Override
    public void onTakeItem(PlayerEntity playerEntity, ItemStack itemStack) {
        this.onCrafted(itemStack);
        TradeOffer tradeOffer = this.merchantInventory.getTradeOffer();
        if (tradeOffer != null) {
            ItemStack itemStack3;
            ItemStack itemStack2 = this.merchantInventory.getStack(0);
            if (tradeOffer.depleteBuyItems(itemStack2, itemStack3 = this.merchantInventory.getStack(1)) || tradeOffer.depleteBuyItems(itemStack3, itemStack2)) {
                this.merchant.trade(tradeOffer);
                playerEntity.incrementStat(Stats.field_15378);
                this.merchantInventory.setStack(0, itemStack2);
                this.merchantInventory.setStack(1, itemStack3);
            }
            this.merchant.setExperienceFromServer(this.merchant.getExperience() + tradeOffer.getMerchantExperience());
        }
    }
}


/*
 * Decompiled with CFR 0.2.1 (FabricMC 53fa44c9).
 */
package net.minecraft.world.biome.source;

import com.mojang.datafixers.util.Either;
import com.mojang.datafixers.util.Pair;
import com.mojang.serialization.Codec;
import com.mojang.serialization.Lifecycle;
import com.mojang.serialization.MapCodec;
import java.util.List;
import java.util.Optional;
import java.util.stream.Stream;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.util.annotation.Debug;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.biome.Biome;
import net.minecraft.world.biome.source.BiomeCoords;
import net.minecraft.world.biome.source.BiomeSource;
import net.minecraft.world.biome.source.MultiNoiseBiomeSourceParameterList;
import net.minecraft.world.biome.source.util.MultiNoiseUtil;
import net.minecraft.world.biome.source.util.VanillaBiomeParameters;
import net.minecraft.world.gen.densityfunction.DensityFunctions;

public class MultiNoiseBiomeSource
extends BiomeSource {
    private static final MapCodec<RegistryEntry<Biome>> BIOME_CODEC = Biome.REGISTRY_CODEC.fieldOf("biome");
    public static final MapCodec<MultiNoiseUtil.Entries<RegistryEntry<Biome>>> CUSTOM_CODEC = MultiNoiseUtil.Entries.createCodec(BIOME_CODEC).fieldOf("biomes");
    private static final MapCodec<RegistryEntry<MultiNoiseBiomeSourceParameterList>> PRESET_CODEC = ((MapCodec)MultiNoiseBiomeSourceParameterList.REGISTRY_CODEC.fieldOf("preset")).withLifecycle(Lifecycle.stable());
    public static final Codec<MultiNoiseBiomeSource> CODEC = Codec.mapEither(CUSTOM_CODEC, PRESET_CODEC).xmap(MultiNoiseBiomeSource::new, multiNoiseBiomeSource -> multiNoiseBiomeSource.biomeEntries).codec();
    private final Either<MultiNoiseUtil.Entries<RegistryEntry<Biome>>, RegistryEntry<MultiNoiseBiomeSourceParameterList>> biomeEntries;

    private MultiNoiseBiomeSource(Either<MultiNoiseUtil.Entries<RegistryEntry<Biome>>, RegistryEntry<MultiNoiseBiomeSourceParameterList>> either) {
        this.biomeEntries = either;
    }

    public static MultiNoiseBiomeSource create(MultiNoiseUtil.Entries<RegistryEntry<Biome>> entries) {
        return new MultiNoiseBiomeSource(Either.left(entries));
    }

    public static MultiNoiseBiomeSource create(RegistryEntry<MultiNoiseBiomeSourceParameterList> registryEntry) {
        return new MultiNoiseBiomeSource(Either.right(registryEntry));
    }

    private MultiNoiseUtil.Entries<RegistryEntry<Biome>> getBiomeEntries() {
        return this.biomeEntries.map(entries -> entries, registryEntry -> ((MultiNoiseBiomeSourceParameterList)registryEntry.comp_349()).getEntries());
    }

    @Override
    protected Stream<RegistryEntry<Biome>> biomeStream() {
        return this.getBiomeEntries().getEntries().stream().map(Pair::getSecond);
    }

    @Override
    protected Codec<? extends BiomeSource> getCodec() {
        return CODEC;
    }

    public boolean matchesInstance(RegistryKey<MultiNoiseBiomeSourceParameterList> registryKey) {
        Optional<RegistryEntry<MultiNoiseBiomeSourceParameterList>> optional = this.biomeEntries.right();
        return optional.isPresent() && optional.get().matchesKey(registryKey);
    }

    @Override
    public RegistryEntry<Biome> getBiome(int i, int j, int k, MultiNoiseUtil.MultiNoiseSampler multiNoiseSampler) {
        return this.getBiomeAtPoint(multiNoiseSampler.sample(i, j, k));
    }

    @Debug
    public RegistryEntry<Biome> getBiomeAtPoint(MultiNoiseUtil.NoiseValuePoint noiseValuePoint) {
        return this.getBiomeEntries().get(noiseValuePoint);
    }

    @Override
    public void addDebugInfo(List<String> list, BlockPos blockPos, MultiNoiseUtil.MultiNoiseSampler multiNoiseSampler) {
        int i = BiomeCoords.fromBlock(blockPos.getX());
        int j = BiomeCoords.fromBlock(blockPos.getY());
        int k = BiomeCoords.fromBlock(blockPos.getZ());
        MultiNoiseUtil.NoiseValuePoint noiseValuePoint = multiNoiseSampler.sample(i, j, k);
        float f = MultiNoiseUtil.toFloat(noiseValuePoint.continentalnessNoise());
        float g = MultiNoiseUtil.toFloat(noiseValuePoint.erosionNoise());
        float h = MultiNoiseUtil.toFloat(noiseValuePoint.temperatureNoise());
        float l = MultiNoiseUtil.toFloat(noiseValuePoint.humidityNoise());
        float m = MultiNoiseUtil.toFloat(noiseValuePoint.weirdnessNoise());
        double d = DensityFunctions.getPeaksValleysNoise(m);
        VanillaBiomeParameters vanillaBiomeParameters = new VanillaBiomeParameters();
        list.add("Biome builder PV: " + VanillaBiomeParameters.getPeaksValleysDescription(d) + " C: " + vanillaBiomeParameters.getContinentalnessDescription(f) + " E: " + vanillaBiomeParameters.getErosionDescription(g) + " T: " + vanillaBiomeParameters.getTemperatureDescription(h) + " H: " + vanillaBiomeParameters.getHumidityDescription(l));
    }
}


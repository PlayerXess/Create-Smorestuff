/*
 * Decompiled with CFR 0.2.1 (FabricMC 53fa44c9).
 */
package net.minecraft.util;

import org.apache.commons.lang3.StringEscapeUtils;

public class InvalidIdentifierException
extends RuntimeException {
    public InvalidIdentifierException(String string) {
        super(StringEscapeUtils.escapeJava(string));
    }

    public InvalidIdentifierException(String string, Throwable throwable) {
        super(StringEscapeUtils.escapeJava(string), throwable);
    }
}


/*
 * Decompiled with CFR 0.2.1 (FabricMC 53fa44c9).
 */
package net.minecraft.item;

import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemUsage;
import net.minecraft.sound.SoundEvents;
import net.minecraft.stat.Stats;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.util.UseAction;
import net.minecraft.world.World;

public class SpyglassItem
extends Item {
    public static final int MAX_USE_TIME = 1200;
    public static final float field_30922 = 0.1f;

    public SpyglassItem(Item.Settings settings) {
        super(settings);
    }

    @Override
    public int getMaxUseTime(ItemStack itemStack) {
        return 1200;
    }

    @Override
    public UseAction getUseAction(ItemStack itemStack) {
        return UseAction.field_27079;
    }

    @Override
    public TypedActionResult<ItemStack> use(World world, PlayerEntity playerEntity, Hand hand) {
        playerEntity.playSound(SoundEvents.field_26972, 1.0f, 1.0f);
        playerEntity.incrementStat(Stats.field_15372.getOrCreateStat(this));
        return ItemUsage.consumeHeldItem(world, playerEntity, hand);
    }

    @Override
    public ItemStack finishUsing(ItemStack itemStack, World world, LivingEntity livingEntity) {
        this.playStopUsingSound(livingEntity);
        return itemStack;
    }

    @Override
    public void onStoppedUsing(ItemStack itemStack, World world, LivingEntity livingEntity, int i) {
        this.playStopUsingSound(livingEntity);
    }

    private void playStopUsingSound(LivingEntity livingEntity) {
        livingEntity.playSound(SoundEvents.field_26973, 1.0f, 1.0f);
    }
}


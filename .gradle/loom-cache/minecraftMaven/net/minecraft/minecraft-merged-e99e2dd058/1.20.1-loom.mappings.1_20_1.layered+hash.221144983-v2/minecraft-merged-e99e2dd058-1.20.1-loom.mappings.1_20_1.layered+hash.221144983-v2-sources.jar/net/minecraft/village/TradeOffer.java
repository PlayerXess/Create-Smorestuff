/*
 * Decompiled with CFR 0.2.1 (FabricMC 53fa44c9).
 */
package net.minecraft.village;

import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.nbt.NbtHelper;
import net.minecraft.util.math.MathHelper;

public class TradeOffer {
    private final ItemStack firstBuyItem;
    private final ItemStack secondBuyItem;
    private final ItemStack sellItem;
    private int uses;
    private final int maxUses;
    private boolean rewardingPlayerExperience = true;
    private int specialPrice;
    private int demandBonus;
    private float priceMultiplier;
    private int merchantExperience = 1;

    public TradeOffer(NbtCompound nbtCompound) {
        this.firstBuyItem = ItemStack.fromNbt(nbtCompound.getCompound("buy"));
        this.secondBuyItem = ItemStack.fromNbt(nbtCompound.getCompound("buyB"));
        this.sellItem = ItemStack.fromNbt(nbtCompound.getCompound("sell"));
        this.uses = nbtCompound.getInt("uses");
        this.maxUses = nbtCompound.contains("maxUses", 99) ? nbtCompound.getInt("maxUses") : 4;
        if (nbtCompound.contains("rewardExp", 1)) {
            this.rewardingPlayerExperience = nbtCompound.getBoolean("rewardExp");
        }
        if (nbtCompound.contains("xp", 3)) {
            this.merchantExperience = nbtCompound.getInt("xp");
        }
        if (nbtCompound.contains("priceMultiplier", 5)) {
            this.priceMultiplier = nbtCompound.getFloat("priceMultiplier");
        }
        this.specialPrice = nbtCompound.getInt("specialPrice");
        this.demandBonus = nbtCompound.getInt("demand");
    }

    public TradeOffer(ItemStack itemStack, ItemStack itemStack2, int i, int j, float f) {
        this(itemStack, ItemStack.EMPTY, itemStack2, i, j, f);
    }

    public TradeOffer(ItemStack itemStack, ItemStack itemStack2, ItemStack itemStack3, int i, int j, float f) {
        this(itemStack, itemStack2, itemStack3, 0, i, j, f);
    }

    public TradeOffer(ItemStack itemStack, ItemStack itemStack2, ItemStack itemStack3, int i, int j, int k, float f) {
        this(itemStack, itemStack2, itemStack3, i, j, k, f, 0);
    }

    public TradeOffer(ItemStack itemStack, ItemStack itemStack2, ItemStack itemStack3, int i, int j, int k, float f, int l) {
        this.firstBuyItem = itemStack;
        this.secondBuyItem = itemStack2;
        this.sellItem = itemStack3;
        this.uses = i;
        this.maxUses = j;
        this.merchantExperience = k;
        this.priceMultiplier = f;
        this.demandBonus = l;
    }

    public ItemStack getOriginalFirstBuyItem() {
        return this.firstBuyItem;
    }

    public ItemStack getAdjustedFirstBuyItem() {
        if (this.firstBuyItem.isEmpty()) {
            return ItemStack.EMPTY;
        }
        int i = this.firstBuyItem.getCount();
        int j = Math.max(0, MathHelper.floor((float)(i * this.demandBonus) * this.priceMultiplier));
        return this.firstBuyItem.copyWithCount(MathHelper.clamp(i + j + this.specialPrice, 1, this.firstBuyItem.getItem().getMaxCount()));
    }

    public ItemStack getSecondBuyItem() {
        return this.secondBuyItem;
    }

    public ItemStack getSellItem() {
        return this.sellItem;
    }

    public void updateDemandBonus() {
        this.demandBonus = this.demandBonus + this.uses - (this.maxUses - this.uses);
    }

    public ItemStack copySellItem() {
        return this.sellItem.copy();
    }

    public int getUses() {
        return this.uses;
    }

    public void resetUses() {
        this.uses = 0;
    }

    public int getMaxUses() {
        return this.maxUses;
    }

    public void use() {
        ++this.uses;
    }

    public int getDemandBonus() {
        return this.demandBonus;
    }

    public void increaseSpecialPrice(int i) {
        this.specialPrice += i;
    }

    public void clearSpecialPrice() {
        this.specialPrice = 0;
    }

    public int getSpecialPrice() {
        return this.specialPrice;
    }

    public void setSpecialPrice(int i) {
        this.specialPrice = i;
    }

    public float getPriceMultiplier() {
        return this.priceMultiplier;
    }

    public int getMerchantExperience() {
        return this.merchantExperience;
    }

    public boolean isDisabled() {
        return this.uses >= this.maxUses;
    }

    public void disable() {
        this.uses = this.maxUses;
    }

    public boolean hasBeenUsed() {
        return this.uses > 0;
    }

    public boolean shouldRewardPlayerExperience() {
        return this.rewardingPlayerExperience;
    }

    public NbtCompound toNbt() {
        NbtCompound nbtCompound = new NbtCompound();
        nbtCompound.put("buy", this.firstBuyItem.writeNbt(new NbtCompound()));
        nbtCompound.put("sell", this.sellItem.writeNbt(new NbtCompound()));
        nbtCompound.put("buyB", this.secondBuyItem.writeNbt(new NbtCompound()));
        nbtCompound.putInt("uses", this.uses);
        nbtCompound.putInt("maxUses", this.maxUses);
        nbtCompound.putBoolean("rewardExp", this.rewardingPlayerExperience);
        nbtCompound.putInt("xp", this.merchantExperience);
        nbtCompound.putFloat("priceMultiplier", this.priceMultiplier);
        nbtCompound.putInt("specialPrice", this.specialPrice);
        nbtCompound.putInt("demand", this.demandBonus);
        return nbtCompound;
    }

    public boolean matchesBuyItems(ItemStack itemStack, ItemStack itemStack2) {
        return this.acceptsBuy(itemStack, this.getAdjustedFirstBuyItem()) && itemStack.getCount() >= this.getAdjustedFirstBuyItem().getCount() && this.acceptsBuy(itemStack2, this.secondBuyItem) && itemStack2.getCount() >= this.secondBuyItem.getCount();
    }

    private boolean acceptsBuy(ItemStack itemStack, ItemStack itemStack2) {
        if (itemStack2.isEmpty() && itemStack.isEmpty()) {
            return true;
        }
        ItemStack itemStack3 = itemStack.copy();
        if (itemStack3.getItem().isDamageable()) {
            itemStack3.setDamage(itemStack3.getDamage());
        }
        return ItemStack.areItemsEqual(itemStack3, itemStack2) && (!itemStack2.hasNbt() || itemStack3.hasNbt() && NbtHelper.matches(itemStack2.getNbt(), itemStack3.getNbt(), false));
    }

    public boolean depleteBuyItems(ItemStack itemStack, ItemStack itemStack2) {
        if (!this.matchesBuyItems(itemStack, itemStack2)) {
            return false;
        }
        itemStack.decrement(this.getAdjustedFirstBuyItem().getCount());
        if (!this.getSecondBuyItem().isEmpty()) {
            itemStack2.decrement(this.getSecondBuyItem().getCount());
        }
        return true;
    }
}


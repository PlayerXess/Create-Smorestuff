/*
 * Decompiled with CFR 0.2.1 (FabricMC 53fa44c9).
 */
package net.minecraft.village;

import java.util.ArrayList;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.nbt.NbtList;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.village.TradeOffer;
import org.jetbrains.annotations.Nullable;

public class TradeOfferList
extends ArrayList<TradeOffer> {
    public TradeOfferList() {
    }

    private TradeOfferList(int i) {
        super(i);
    }

    public TradeOfferList(NbtCompound nbtCompound) {
        NbtList nbtList = nbtCompound.getList("Recipes", 10);
        for (int i = 0; i < nbtList.size(); ++i) {
            this.add(new TradeOffer(nbtList.getCompound(i)));
        }
    }

    @Nullable
    public TradeOffer getValidOffer(ItemStack itemStack, ItemStack itemStack2, int i) {
        if (i > 0 && i < this.size()) {
            TradeOffer tradeOffer = (TradeOffer)this.get(i);
            if (tradeOffer.matchesBuyItems(itemStack, itemStack2)) {
                return tradeOffer;
            }
            return null;
        }
        for (int j = 0; j < this.size(); ++j) {
            TradeOffer tradeOffer2 = (TradeOffer)this.get(j);
            if (!tradeOffer2.matchesBuyItems(itemStack, itemStack2)) continue;
            return tradeOffer2;
        }
        return null;
    }

    public void toPacket(PacketByteBuf packetByteBuf2) {
        packetByteBuf2.writeCollection(this, (packetByteBuf, tradeOffer) -> {
            packetByteBuf.writeItemStack(tradeOffer.getOriginalFirstBuyItem());
            packetByteBuf.writeItemStack(tradeOffer.getSellItem());
            packetByteBuf.writeItemStack(tradeOffer.getSecondBuyItem());
            packetByteBuf.writeBoolean(tradeOffer.isDisabled());
            packetByteBuf.writeInt(tradeOffer.getUses());
            packetByteBuf.writeInt(tradeOffer.getMaxUses());
            packetByteBuf.writeInt(tradeOffer.getMerchantExperience());
            packetByteBuf.writeInt(tradeOffer.getSpecialPrice());
            packetByteBuf.writeFloat(tradeOffer.getPriceMultiplier());
            packetByteBuf.writeInt(tradeOffer.getDemandBonus());
        });
    }

    public static TradeOfferList fromPacket(PacketByteBuf packetByteBuf2) {
        return packetByteBuf2.readCollection(TradeOfferList::new, packetByteBuf -> {
            ItemStack itemStack = packetByteBuf.readItemStack();
            ItemStack itemStack2 = packetByteBuf.readItemStack();
            ItemStack itemStack3 = packetByteBuf.readItemStack();
            boolean bl = packetByteBuf.readBoolean();
            int i = packetByteBuf.readInt();
            int j = packetByteBuf.readInt();
            int k = packetByteBuf.readInt();
            int l = packetByteBuf.readInt();
            float f = packetByteBuf.readFloat();
            int m = packetByteBuf.readInt();
            TradeOffer tradeOffer = new TradeOffer(itemStack, itemStack3, itemStack2, i, j, k, f, m);
            if (bl) {
                tradeOffer.disable();
            }
            tradeOffer.setSpecialPrice(l);
            return tradeOffer;
        });
    }

    public NbtCompound toNbt() {
        NbtCompound nbtCompound = new NbtCompound();
        NbtList nbtList = new NbtList();
        for (int i = 0; i < this.size(); ++i) {
            TradeOffer tradeOffer = (TradeOffer)this.get(i);
            nbtList.add(tradeOffer.toNbt());
        }
        nbtCompound.put("Recipes", nbtList);
        return nbtCompound;
    }
}


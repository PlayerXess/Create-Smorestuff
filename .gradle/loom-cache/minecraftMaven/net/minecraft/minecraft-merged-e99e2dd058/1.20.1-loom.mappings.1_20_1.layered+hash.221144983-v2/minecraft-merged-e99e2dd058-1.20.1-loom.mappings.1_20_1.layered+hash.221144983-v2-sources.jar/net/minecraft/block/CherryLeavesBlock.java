/*
 * Decompiled with CFR 0.2.1 (FabricMC 53fa44c9).
 */
package net.minecraft.block;

import net.minecraft.block.AbstractBlock;
import net.minecraft.block.BlockState;
import net.minecraft.block.LeavesBlock;
import net.minecraft.client.util.ParticleUtil;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.random.Random;
import net.minecraft.world.World;

public class CherryLeavesBlock
extends LeavesBlock {
    public CherryLeavesBlock(AbstractBlock.Settings settings) {
        super(settings);
    }

    @Override
    public void randomDisplayTick(BlockState blockState, World world, BlockPos blockPos, Random random) {
        super.randomDisplayTick(blockState, world, blockPos, random);
        if (random.nextInt(10) != 0) {
            return;
        }
        BlockPos blockPos2 = blockPos.down();
        BlockState blockState2 = world.getBlockState(blockPos2);
        if (CherryLeavesBlock.isFaceFullSquare(blockState2.getCollisionShape(world, blockPos2), Direction.field_11036)) {
            return;
        }
        ParticleUtil.spawnParticle(world, blockPos, random, ParticleTypes.field_43379);
    }
}


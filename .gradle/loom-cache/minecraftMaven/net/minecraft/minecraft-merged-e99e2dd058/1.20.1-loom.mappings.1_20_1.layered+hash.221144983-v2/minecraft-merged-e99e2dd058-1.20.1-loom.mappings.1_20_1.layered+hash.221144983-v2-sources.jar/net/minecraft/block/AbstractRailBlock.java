/*
 * Decompiled with CFR 0.2.1 (FabricMC 53fa44c9).
 */
package net.minecraft.block;

import io.github.fabricators_of_create.porting_lib.extensions.extensions.BaseRailBlockExtensions;
import net.minecraft.block.AbstractBlock;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.RailPlacementHelper;
import net.minecraft.block.ShapeContext;
import net.minecraft.block.Waterloggable;
import net.minecraft.block.enums.RailShape;
import net.minecraft.fluid.FluidState;
import net.minecraft.fluid.Fluids;
import net.minecraft.item.ItemPlacementContext;
import net.minecraft.registry.tag.BlockTags;
import net.minecraft.state.property.BooleanProperty;
import net.minecraft.state.property.Properties;
import net.minecraft.state.property.Property;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.shape.VoxelShape;
import net.minecraft.world.BlockView;
import net.minecraft.world.World;
import net.minecraft.world.WorldAccess;
import net.minecraft.world.WorldView;

public abstract class AbstractRailBlock
extends Block
implements Waterloggable,
BaseRailBlockExtensions {
    protected static final VoxelShape STRAIGHT_SHAPE = Block.createCuboidShape(0.0, 0.0, 0.0, 16.0, 2.0, 16.0);
    protected static final VoxelShape ASCENDING_SHAPE = Block.createCuboidShape(0.0, 0.0, 0.0, 16.0, 8.0, 16.0);
    public static final BooleanProperty WATERLOGGED = Properties.WATERLOGGED;
    private final boolean forbidCurves;

    public static boolean isRail(World world, BlockPos blockPos) {
        return AbstractRailBlock.isRail(world.getBlockState(blockPos));
    }

    public static boolean isRail(BlockState blockState) {
        return blockState.isIn(BlockTags.field_15463) && blockState.getBlock() instanceof AbstractRailBlock;
    }

    protected AbstractRailBlock(boolean bl, AbstractBlock.Settings settings) {
        super(settings);
        this.forbidCurves = bl;
    }

    public boolean cannotMakeCurves() {
        return this.forbidCurves;
    }

    @Override
    public VoxelShape getOutlineShape(BlockState blockState, BlockView blockView, BlockPos blockPos, ShapeContext shapeContext) {
        RailShape railShape;
        RailShape railShape2 = railShape = blockState.isOf(this) ? blockState.get(this.getShapeProperty()) : null;
        if (railShape != null && railShape.isAscending()) {
            return ASCENDING_SHAPE;
        }
        return STRAIGHT_SHAPE;
    }

    @Override
    public boolean canPlaceAt(BlockState blockState, WorldView worldView, BlockPos blockPos) {
        return AbstractRailBlock.hasTopRim(worldView, blockPos.down());
    }

    @Override
    public void onBlockAdded(BlockState blockState, World world, BlockPos blockPos, BlockState blockState2, boolean bl) {
        if (blockState2.isOf(blockState.getBlock())) {
            return;
        }
        this.updateCurves(blockState, world, blockPos, bl);
    }

    protected BlockState updateCurves(BlockState blockState, World world, BlockPos blockPos, boolean bl) {
        blockState = this.updateBlockState(world, blockPos, blockState, true);
        if (this.forbidCurves) {
            world.updateNeighbor(blockState, blockPos, this, blockPos, bl);
        }
        return blockState;
    }

    @Override
    public void neighborUpdate(BlockState blockState, World world, BlockPos blockPos, Block block, BlockPos blockPos2, boolean bl) {
        if (world.isClient || !world.getBlockState(blockPos).isOf(this)) {
            return;
        }
        RailShape railShape = blockState.get(this.getShapeProperty());
        if (AbstractRailBlock.shouldDropRail(blockPos, world, railShape)) {
            AbstractRailBlock.dropStacks(blockState, world, blockPos);
            world.removeBlock(blockPos, bl);
        } else {
            this.updateBlockState(blockState, world, blockPos, block);
        }
    }

    private static boolean shouldDropRail(BlockPos blockPos, World world, RailShape railShape) {
        if (!AbstractRailBlock.hasTopRim(world, blockPos.down())) {
            return true;
        }
        switch (railShape) {
            case field_12667: {
                return !AbstractRailBlock.hasTopRim(world, blockPos.east());
            }
            case field_12666: {
                return !AbstractRailBlock.hasTopRim(world, blockPos.west());
            }
            case field_12670: {
                return !AbstractRailBlock.hasTopRim(world, blockPos.north());
            }
            case field_12668: {
                return !AbstractRailBlock.hasTopRim(world, blockPos.south());
            }
        }
        return false;
    }

    protected void updateBlockState(BlockState blockState, World world, BlockPos blockPos, Block block) {
    }

    protected BlockState updateBlockState(World world, BlockPos blockPos, BlockState blockState, boolean bl) {
        if (world.isClient) {
            return blockState;
        }
        RailShape railShape = blockState.get(this.getShapeProperty());
        return new RailPlacementHelper(world, blockPos, blockState).updateBlockState(world.isReceivingRedstonePower(blockPos), bl, railShape).getBlockState();
    }

    @Override
    public void onStateReplaced(BlockState blockState, World world, BlockPos blockPos, BlockState blockState2, boolean bl) {
        if (bl) {
            return;
        }
        super.onStateReplaced(blockState, world, blockPos, blockState2, bl);
        if (blockState.get(this.getShapeProperty()).isAscending()) {
            world.updateNeighborsAlways(blockPos.up(), this);
        }
        if (this.forbidCurves) {
            world.updateNeighborsAlways(blockPos, this);
            world.updateNeighborsAlways(blockPos.down(), this);
        }
    }

    @Override
    public BlockState getPlacementState(ItemPlacementContext itemPlacementContext) {
        FluidState fluidState = itemPlacementContext.getWorld().getFluidState(itemPlacementContext.getBlockPos());
        boolean bl = fluidState.getFluid() == Fluids.WATER;
        BlockState blockState = super.getDefaultState();
        Direction direction = itemPlacementContext.getHorizontalPlayerFacing();
        boolean bl2 = direction == Direction.field_11034 || direction == Direction.field_11039;
        return (BlockState)((BlockState)blockState.with(this.getShapeProperty(), bl2 ? RailShape.field_12674 : RailShape.field_12665)).with(WATERLOGGED, bl);
    }

    public abstract Property<RailShape> getShapeProperty();

    @Override
    public BlockState getStateForNeighborUpdate(BlockState blockState, Direction direction, BlockState blockState2, WorldAccess worldAccess, BlockPos blockPos, BlockPos blockPos2) {
        if (blockState.get(WATERLOGGED).booleanValue()) {
            worldAccess.scheduleFluidTick(blockPos, Fluids.WATER, Fluids.WATER.getTickRate(worldAccess));
        }
        return super.getStateForNeighborUpdate(blockState, direction, blockState2, worldAccess, blockPos, blockPos2);
    }

    @Override
    public FluidState getFluidState(BlockState blockState) {
        if (blockState.get(WATERLOGGED).booleanValue()) {
            return Fluids.WATER.getStill(false);
        }
        return super.getFluidState(blockState);
    }
}


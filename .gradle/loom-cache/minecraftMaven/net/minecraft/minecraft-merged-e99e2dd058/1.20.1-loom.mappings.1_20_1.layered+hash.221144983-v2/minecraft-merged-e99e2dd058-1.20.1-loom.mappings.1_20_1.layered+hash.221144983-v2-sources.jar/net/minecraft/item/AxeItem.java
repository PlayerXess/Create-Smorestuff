/*
 * Decompiled with CFR 0.2.1 (FabricMC 53fa44c9).
 */
package net.minecraft.item;

import com.google.common.collect.ImmutableMap;
import java.util.Map;
import java.util.Optional;
import net.minecraft.advancement.criterion.Criteria;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.Oxidizable;
import net.minecraft.block.PillarBlock;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.HoneycombItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemUsageContext;
import net.minecraft.item.MiningToolItem;
import net.minecraft.item.ToolMaterial;
import net.minecraft.registry.tag.BlockTags;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.ActionResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraft.world.event.GameEvent;

public class AxeItem
extends MiningToolItem {
    public static final Map<Block, Block> STRIPPED_BLOCKS = new ImmutableMap.Builder<Block, Block>().put(Blocks.field_10126, Blocks.field_10250).put(Blocks.field_10431, Blocks.field_10519).put(Blocks.field_10178, Blocks.field_10374).put(Blocks.field_10010, Blocks.field_10244).put(Blocks.field_9999, Blocks.field_10103).put(Blocks.field_10533, Blocks.field_10622).put(Blocks.field_42733, Blocks.field_42730).put(Blocks.field_42729, Blocks.field_42732).put(Blocks.field_10307, Blocks.field_10204).put(Blocks.field_10511, Blocks.field_10366).put(Blocks.field_10303, Blocks.field_10084).put(Blocks.field_10306, Blocks.field_10254).put(Blocks.field_10155, Blocks.field_10558).put(Blocks.field_10037, Blocks.field_10436).put(Blocks.field_22111, Blocks.field_22112).put(Blocks.field_22503, Blocks.field_22504).put(Blocks.field_22118, Blocks.field_22119).put(Blocks.field_22505, Blocks.field_22506).put(Blocks.field_37549, Blocks.field_37550).put(Blocks.field_37545, Blocks.field_37548).put(Blocks.field_41072, Blocks.field_41073).build();

    public AxeItem(ToolMaterial toolMaterial, float f, float g, Item.Settings settings) {
        super(f, g, toolMaterial, BlockTags.field_33713, settings);
    }

    @Override
    public ActionResult useOnBlock(ItemUsageContext itemUsageContext) {
        World world = itemUsageContext.getWorld();
        BlockPos blockPos = itemUsageContext.getBlockPos();
        PlayerEntity playerEntity2 = itemUsageContext.getPlayer();
        BlockState blockState = world.getBlockState(blockPos);
        Optional<BlockState> optional = this.getStrippedState(blockState);
        Optional<BlockState> optional2 = Oxidizable.getDecreasedOxidationState(blockState);
        Optional<BlockState> optional3 = Optional.ofNullable((Block)HoneycombItem.WAXED_TO_UNWAXED_BLOCKS.get().get(blockState.getBlock())).map(block -> block.getStateWithProperties(blockState));
        ItemStack itemStack = itemUsageContext.getStack();
        Optional<Object> optional4 = Optional.empty();
        if (optional.isPresent()) {
            world.playSound(playerEntity2, blockPos, SoundEvents.field_14675, SoundCategory.field_15245, 1.0f, 1.0f);
            optional4 = optional;
        } else if (optional2.isPresent()) {
            world.playSound(playerEntity2, blockPos, SoundEvents.field_29541, SoundCategory.field_15245, 1.0f, 1.0f);
            world.syncWorldEvent(playerEntity2, 3005, blockPos, 0);
            optional4 = optional2;
        } else if (optional3.isPresent()) {
            world.playSound(playerEntity2, blockPos, SoundEvents.field_29542, SoundCategory.field_15245, 1.0f, 1.0f);
            world.syncWorldEvent(playerEntity2, 3004, blockPos, 0);
            optional4 = optional3;
        }
        if (optional4.isPresent()) {
            if (playerEntity2 instanceof ServerPlayerEntity) {
                Criteria.ITEM_USED_ON_BLOCK.trigger((ServerPlayerEntity)playerEntity2, blockPos, itemStack);
            }
            world.setBlockState(blockPos, (BlockState)optional4.get(), 11);
            world.emitGameEvent(GameEvent.field_28733, blockPos, GameEvent.Emitter.of(playerEntity2, (BlockState)optional4.get()));
            if (playerEntity2 != null) {
                itemStack.damage(1, playerEntity2, playerEntity -> playerEntity.sendToolBreakStatus(itemUsageContext.getHand()));
            }
            return ActionResult.success(world.isClient);
        }
        return ActionResult.PASS;
    }

    private Optional<BlockState> getStrippedState(BlockState blockState) {
        return Optional.ofNullable(STRIPPED_BLOCKS.get(blockState.getBlock())).map(block -> (BlockState)block.getDefaultState().with(PillarBlock.AXIS, blockState.get(PillarBlock.AXIS)));
    }
}


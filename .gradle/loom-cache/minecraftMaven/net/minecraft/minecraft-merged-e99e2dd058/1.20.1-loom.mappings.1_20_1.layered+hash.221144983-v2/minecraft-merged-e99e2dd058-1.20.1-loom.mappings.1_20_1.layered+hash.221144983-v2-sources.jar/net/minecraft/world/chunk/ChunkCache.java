/*
 * Decompiled with CFR 0.2.1 (FabricMC 53fa44c9).
 */
package net.minecraft.world.chunk;

import com.google.common.base.Suppliers;
import java.util.List;
import java.util.function.Supplier;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.entity.Entity;
import net.minecraft.fluid.FluidState;
import net.minecraft.fluid.Fluids;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.util.math.ChunkSectionPos;
import net.minecraft.util.profiler.Profiler;
import net.minecraft.util.shape.VoxelShape;
import net.minecraft.world.BlockView;
import net.minecraft.world.CollisionView;
import net.minecraft.world.World;
import net.minecraft.world.biome.Biome;
import net.minecraft.world.biome.BiomeKeys;
import net.minecraft.world.border.WorldBorder;
import net.minecraft.world.chunk.Chunk;
import net.minecraft.world.chunk.ChunkManager;
import net.minecraft.world.chunk.EmptyChunk;
import org.jetbrains.annotations.Nullable;

public class ChunkCache
implements BlockView,
CollisionView {
    protected final int minX;
    protected final int minZ;
    protected final Chunk[][] chunks;
    protected boolean empty;
    protected final World world;
    private final Supplier<RegistryEntry<Biome>> plainsEntryGetter;

    public ChunkCache(World world, BlockPos blockPos, BlockPos blockPos2) {
        int l;
        int k;
        this.world = world;
        this.plainsEntryGetter = Suppliers.memoize(() -> world.getRegistryManager().get(RegistryKeys.BIOME).entryOf(BiomeKeys.field_9451));
        this.minX = ChunkSectionPos.getSectionCoord(blockPos.getX());
        this.minZ = ChunkSectionPos.getSectionCoord(blockPos.getZ());
        int i = ChunkSectionPos.getSectionCoord(blockPos2.getX());
        int j = ChunkSectionPos.getSectionCoord(blockPos2.getZ());
        this.chunks = new Chunk[i - this.minX + 1][j - this.minZ + 1];
        ChunkManager chunkManager = world.getChunkManager();
        this.empty = true;
        for (k = this.minX; k <= i; ++k) {
            for (l = this.minZ; l <= j; ++l) {
                this.chunks[k - this.minX][l - this.minZ] = chunkManager.getWorldChunk(k, l);
            }
        }
        for (k = ChunkSectionPos.getSectionCoord(blockPos.getX()); k <= ChunkSectionPos.getSectionCoord(blockPos2.getX()); ++k) {
            for (l = ChunkSectionPos.getSectionCoord(blockPos.getZ()); l <= ChunkSectionPos.getSectionCoord(blockPos2.getZ()); ++l) {
                Chunk chunk = this.chunks[k - this.minX][l - this.minZ];
                if (chunk == null || chunk.areSectionsEmptyBetween(blockPos.getY(), blockPos2.getY())) continue;
                this.empty = false;
                return;
            }
        }
    }

    private Chunk getChunk(BlockPos blockPos) {
        return this.getChunk(ChunkSectionPos.getSectionCoord(blockPos.getX()), ChunkSectionPos.getSectionCoord(blockPos.getZ()));
    }

    private Chunk getChunk(int i, int j) {
        int k = i - this.minX;
        int l = j - this.minZ;
        if (k < 0 || k >= this.chunks.length || l < 0 || l >= this.chunks[k].length) {
            return new EmptyChunk(this.world, new ChunkPos(i, j), this.plainsEntryGetter.get());
        }
        Chunk chunk = this.chunks[k][l];
        return chunk != null ? chunk : new EmptyChunk(this.world, new ChunkPos(i, j), this.plainsEntryGetter.get());
    }

    @Override
    public WorldBorder getWorldBorder() {
        return this.world.getWorldBorder();
    }

    @Override
    public BlockView getChunkAsView(int i, int j) {
        return this.getChunk(i, j);
    }

    @Override
    public List<VoxelShape> getEntityCollisions(@Nullable Entity entity, Box box) {
        return List.of();
    }

    @Override
    @Nullable
    public BlockEntity getBlockEntity(BlockPos blockPos) {
        Chunk chunk = this.getChunk(blockPos);
        return chunk.getBlockEntity(blockPos);
    }

    @Override
    public BlockState getBlockState(BlockPos blockPos) {
        if (this.isOutOfHeightLimit(blockPos)) {
            return Blocks.field_10124.getDefaultState();
        }
        Chunk chunk = this.getChunk(blockPos);
        return chunk.getBlockState(blockPos);
    }

    @Override
    public FluidState getFluidState(BlockPos blockPos) {
        if (this.isOutOfHeightLimit(blockPos)) {
            return Fluids.field_15906.getDefaultState();
        }
        Chunk chunk = this.getChunk(blockPos);
        return chunk.getFluidState(blockPos);
    }

    @Override
    public int getBottomY() {
        return this.world.getBottomY();
    }

    @Override
    public int getHeight() {
        return this.world.getHeight();
    }

    public Profiler getProfiler() {
        return this.world.getProfiler();
    }
}


/*
 * Decompiled with CFR 0.2.1 (FabricMC 53fa44c9).
 */
package net.minecraft.potion;

import com.google.common.collect.ImmutableList;
import java.util.List;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.registry.Registries;
import net.minecraft.util.Identifier;
import org.jetbrains.annotations.Nullable;

public class Potion {
    @Nullable
    private final String baseName;
    private final ImmutableList<StatusEffectInstance> effects;

    public static Potion byId(String string) {
        return Registries.POTION.get(Identifier.tryParse(string));
    }

    public Potion(StatusEffectInstance ... statusEffectInstances) {
        this((String)null, statusEffectInstances);
    }

    public Potion(@Nullable String string, StatusEffectInstance ... statusEffectInstances) {
        this.baseName = string;
        this.effects = ImmutableList.copyOf(statusEffectInstances);
    }

    public String finishTranslationKey(String string) {
        return string + (this.baseName == null ? Registries.POTION.getId(this).getPath() : this.baseName);
    }

    public List<StatusEffectInstance> getEffects() {
        return this.effects;
    }

    public boolean hasInstantEffect() {
        if (!this.effects.isEmpty()) {
            for (StatusEffectInstance statusEffectInstance : this.effects) {
                if (!statusEffectInstance.getEffectType().isInstant()) continue;
                return true;
            }
        }
        return false;
    }
}


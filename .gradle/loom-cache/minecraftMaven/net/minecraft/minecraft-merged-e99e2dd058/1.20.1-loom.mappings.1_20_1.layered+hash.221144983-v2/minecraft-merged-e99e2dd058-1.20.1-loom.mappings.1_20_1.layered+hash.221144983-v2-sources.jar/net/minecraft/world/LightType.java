/*
 * Decompiled with CFR 0.2.1 (FabricMC 53fa44c9).
 */
package net.minecraft.world;

public enum LightType {
    field_9284,
    field_9282;

}


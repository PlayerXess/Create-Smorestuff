/*
 * Decompiled with CFR 0.2.1 (FabricMC 53fa44c9).
 */
package net.minecraft.recipe;

import com.google.gson.JsonObject;
import java.util.Optional;
import java.util.stream.Stream;
import net.minecraft.inventory.Inventory;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.item.trim.ArmorTrim;
import net.minecraft.item.trim.ArmorTrimMaterial;
import net.minecraft.item.trim.ArmorTrimMaterials;
import net.minecraft.item.trim.ArmorTrimPattern;
import net.minecraft.item.trim.ArmorTrimPatterns;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.recipe.Ingredient;
import net.minecraft.recipe.Recipe;
import net.minecraft.recipe.RecipeSerializer;
import net.minecraft.recipe.SmithingRecipe;
import net.minecraft.registry.DynamicRegistryManager;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.util.Identifier;
import net.minecraft.util.JsonHelper;
import net.minecraft.world.World;

public class SmithingTrimRecipe
implements SmithingRecipe {
    private final Identifier id;
    final Ingredient template;
    final Ingredient base;
    final Ingredient addition;

    public SmithingTrimRecipe(Identifier identifier, Ingredient ingredient, Ingredient ingredient2, Ingredient ingredient3) {
        this.id = identifier;
        this.template = ingredient;
        this.base = ingredient2;
        this.addition = ingredient3;
    }

    @Override
    public boolean matches(Inventory inventory, World world) {
        return this.template.test(inventory.getStack(0)) && this.base.test(inventory.getStack(1)) && this.addition.test(inventory.getStack(2));
    }

    @Override
    public ItemStack craft(Inventory inventory, DynamicRegistryManager dynamicRegistryManager) {
        ItemStack itemStack = inventory.getStack(1);
        if (this.base.test(itemStack)) {
            Optional<RegistryEntry.Reference<ArmorTrimMaterial>> optional = ArmorTrimMaterials.get(dynamicRegistryManager, inventory.getStack(2));
            Optional<RegistryEntry.Reference<ArmorTrimPattern>> optional2 = ArmorTrimPatterns.get(dynamicRegistryManager, inventory.getStack(0));
            if (optional.isPresent() && optional2.isPresent()) {
                Optional<ArmorTrim> optional3 = ArmorTrim.getTrim(dynamicRegistryManager, itemStack);
                if (optional3.isPresent() && optional3.get().equals((RegistryEntry<ArmorTrimPattern>)optional2.get(), (RegistryEntry<ArmorTrimMaterial>)optional.get())) {
                    return ItemStack.EMPTY;
                }
                ItemStack itemStack2 = itemStack.copy();
                itemStack2.setCount(1);
                ArmorTrim armorTrim = new ArmorTrim((RegistryEntry<ArmorTrimMaterial>)optional.get(), (RegistryEntry<ArmorTrimPattern>)optional2.get());
                if (ArmorTrim.apply(dynamicRegistryManager, itemStack2, armorTrim)) {
                    return itemStack2;
                }
            }
        }
        return ItemStack.EMPTY;
    }

    @Override
    public ItemStack getOutput(DynamicRegistryManager dynamicRegistryManager) {
        Optional<RegistryEntry.Reference<ArmorTrimMaterial>> optional2;
        ItemStack itemStack = new ItemStack(Items.field_8523);
        Optional<RegistryEntry.Reference<ArmorTrimPattern>> optional = dynamicRegistryManager.get(RegistryKeys.field_42082).streamEntries().findFirst();
        if (optional.isPresent() && (optional2 = dynamicRegistryManager.get(RegistryKeys.field_42083).getEntry(ArmorTrimMaterials.field_42007)).isPresent()) {
            ArmorTrim armorTrim = new ArmorTrim((RegistryEntry<ArmorTrimMaterial>)optional2.get(), (RegistryEntry<ArmorTrimPattern>)optional.get());
            ArmorTrim.apply(dynamicRegistryManager, itemStack, armorTrim);
        }
        return itemStack;
    }

    @Override
    public boolean testTemplate(ItemStack itemStack) {
        return this.template.test(itemStack);
    }

    @Override
    public boolean testBase(ItemStack itemStack) {
        return this.base.test(itemStack);
    }

    @Override
    public boolean testAddition(ItemStack itemStack) {
        return this.addition.test(itemStack);
    }

    @Override
    public Identifier getId() {
        return this.id;
    }

    @Override
    public RecipeSerializer<?> getSerializer() {
        return RecipeSerializer.field_42028;
    }

    @Override
    public boolean isEmpty() {
        return Stream.of(this.template, this.base, this.addition).anyMatch(Ingredient::isEmpty);
    }

    public static class Serializer
    implements RecipeSerializer<SmithingTrimRecipe> {
        @Override
        public SmithingTrimRecipe read(Identifier identifier, JsonObject jsonObject) {
            Ingredient ingredient = Ingredient.fromJson(JsonHelper.getElement(jsonObject, "template"));
            Ingredient ingredient2 = Ingredient.fromJson(JsonHelper.getElement(jsonObject, "base"));
            Ingredient ingredient3 = Ingredient.fromJson(JsonHelper.getElement(jsonObject, "addition"));
            return new SmithingTrimRecipe(identifier, ingredient, ingredient2, ingredient3);
        }

        @Override
        public SmithingTrimRecipe read(Identifier identifier, PacketByteBuf packetByteBuf) {
            Ingredient ingredient = Ingredient.fromPacket(packetByteBuf);
            Ingredient ingredient2 = Ingredient.fromPacket(packetByteBuf);
            Ingredient ingredient3 = Ingredient.fromPacket(packetByteBuf);
            return new SmithingTrimRecipe(identifier, ingredient, ingredient2, ingredient3);
        }

        @Override
        public void write(PacketByteBuf packetByteBuf, SmithingTrimRecipe smithingTrimRecipe) {
            smithingTrimRecipe.template.write(packetByteBuf);
            smithingTrimRecipe.base.write(packetByteBuf);
            smithingTrimRecipe.addition.write(packetByteBuf);
        }

        @Override
        public /* synthetic */ Recipe read(Identifier identifier, PacketByteBuf packetByteBuf) {
            return this.read(identifier, packetByteBuf);
        }

        @Override
        public /* synthetic */ Recipe read(Identifier identifier, JsonObject jsonObject) {
            return this.read(identifier, jsonObject);
        }
    }
}


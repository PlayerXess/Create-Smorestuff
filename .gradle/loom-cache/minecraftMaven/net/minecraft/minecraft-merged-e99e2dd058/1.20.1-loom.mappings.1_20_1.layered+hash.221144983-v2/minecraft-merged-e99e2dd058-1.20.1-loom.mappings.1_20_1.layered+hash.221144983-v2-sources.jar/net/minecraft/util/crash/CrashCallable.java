/*
 * Decompiled with CFR 0.2.1 (FabricMC 53fa44c9).
 */
package net.minecraft.util.crash;

import java.util.concurrent.Callable;

public interface CrashCallable<V>
extends Callable<V> {
}


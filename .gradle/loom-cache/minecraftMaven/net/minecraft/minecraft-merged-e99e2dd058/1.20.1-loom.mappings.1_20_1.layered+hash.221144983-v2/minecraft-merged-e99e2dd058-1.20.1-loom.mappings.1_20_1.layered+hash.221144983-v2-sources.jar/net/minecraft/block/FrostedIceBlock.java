/*
 * Decompiled with CFR 0.2.1 (FabricMC 53fa44c9).
 */
package net.minecraft.block;

import net.minecraft.block.AbstractBlock;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.IceBlock;
import net.minecraft.item.ItemStack;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.state.StateManager;
import net.minecraft.state.property.IntProperty;
import net.minecraft.state.property.Properties;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3i;
import net.minecraft.util.math.random.Random;
import net.minecraft.world.BlockView;
import net.minecraft.world.World;

public class FrostedIceBlock
extends IceBlock {
    public static final int MAX_AGE = 3;
    public static final IntProperty AGE = Properties.AGE_3;
    private static final int NEIGHBORS_CHECKED_ON_SCHEDULED_TICK = 4;
    private static final int NEIGHBORS_CHECKED_ON_NEIGHBOR_UPDATE = 2;

    public FrostedIceBlock(AbstractBlock.Settings settings) {
        super(settings);
        this.setDefaultState((BlockState)((BlockState)this.stateManager.getDefaultState()).with(AGE, 0));
    }

    @Override
    public void randomTick(BlockState blockState, ServerWorld serverWorld, BlockPos blockPos, Random random) {
        this.scheduledTick(blockState, serverWorld, blockPos, random);
    }

    @Override
    public void scheduledTick(BlockState blockState, ServerWorld serverWorld, BlockPos blockPos, Random random) {
        if ((random.nextInt(3) == 0 || this.canMelt(serverWorld, blockPos, 4)) && serverWorld.getLightLevel(blockPos) > 11 - blockState.get(AGE) - blockState.getOpacity(serverWorld, blockPos) && this.increaseAge(blockState, serverWorld, blockPos)) {
            BlockPos.Mutable mutable = new BlockPos.Mutable();
            for (Direction direction : Direction.values()) {
                mutable.set((Vec3i)blockPos, direction);
                BlockState blockState2 = serverWorld.getBlockState(mutable);
                if (!blockState2.isOf(this) || this.increaseAge(blockState2, serverWorld, mutable)) continue;
                serverWorld.scheduleBlockTick(mutable, this, MathHelper.nextInt(random, 20, 40));
            }
            return;
        }
        serverWorld.scheduleBlockTick(blockPos, this, MathHelper.nextInt(random, 20, 40));
    }

    private boolean increaseAge(BlockState blockState, World world, BlockPos blockPos) {
        int i = blockState.get(AGE);
        if (i < 3) {
            world.setBlockState(blockPos, (BlockState)blockState.with(AGE, i + 1), 2);
            return false;
        }
        this.melt(blockState, world, blockPos);
        return true;
    }

    @Override
    public void neighborUpdate(BlockState blockState, World world, BlockPos blockPos, Block block, BlockPos blockPos2, boolean bl) {
        if (block.getDefaultState().isOf(this) && this.canMelt(world, blockPos, 2)) {
            this.melt(blockState, world, blockPos);
        }
        super.neighborUpdate(blockState, world, blockPos, block, blockPos2, bl);
    }

    private boolean canMelt(BlockView blockView, BlockPos blockPos, int i) {
        int j = 0;
        BlockPos.Mutable mutable = new BlockPos.Mutable();
        for (Direction direction : Direction.values()) {
            mutable.set((Vec3i)blockPos, direction);
            if (!blockView.getBlockState(mutable).isOf(this) || ++j < i) continue;
            return false;
        }
        return true;
    }

    @Override
    protected void appendProperties(StateManager.Builder<Block, BlockState> builder) {
        builder.add(AGE);
    }

    @Override
    public ItemStack getPickStack(BlockView blockView, BlockPos blockPos, BlockState blockState) {
        return ItemStack.EMPTY;
    }
}


/*
 * Decompiled with CFR 0.2.1 (FabricMC 53fa44c9).
 */
package net.minecraft.world.biome.source;

import net.minecraft.registry.Registerable;
import net.minecraft.registry.RegistryEntryLookup;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.util.Identifier;
import net.minecraft.world.biome.Biome;
import net.minecraft.world.biome.source.MultiNoiseBiomeSourceParameterList;

public class MultiNoiseBiomeSourceParameterLists {
    public static final RegistryKey<MultiNoiseBiomeSourceParameterList> field_42991 = MultiNoiseBiomeSourceParameterLists.of("nether");
    public static final RegistryKey<MultiNoiseBiomeSourceParameterList> field_42992 = MultiNoiseBiomeSourceParameterLists.of("overworld");

    public static void bootstrap(Registerable<MultiNoiseBiomeSourceParameterList> registerable) {
        RegistryEntryLookup<Biome> registryEntryLookup = registerable.getRegistryLookup(RegistryKeys.BIOME);
        registerable.register(field_42991, new MultiNoiseBiomeSourceParameterList(MultiNoiseBiomeSourceParameterList.Preset.NETHER, registryEntryLookup));
        registerable.register(field_42992, new MultiNoiseBiomeSourceParameterList(MultiNoiseBiomeSourceParameterList.Preset.OVERWORLD, registryEntryLookup));
    }

    private static RegistryKey<MultiNoiseBiomeSourceParameterList> of(String string) {
        return RegistryKey.of(RegistryKeys.MULTI_NOISE_BIOME_SOURCE_PARAMETER_LIST, new Identifier(string));
    }
}


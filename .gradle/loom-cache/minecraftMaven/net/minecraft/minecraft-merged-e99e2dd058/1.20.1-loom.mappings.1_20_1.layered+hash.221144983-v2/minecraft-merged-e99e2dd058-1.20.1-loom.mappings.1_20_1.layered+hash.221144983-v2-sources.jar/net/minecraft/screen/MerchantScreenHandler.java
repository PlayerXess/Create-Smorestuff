/*
 * Decompiled with CFR 0.2.1 (FabricMC 53fa44c9).
 */
package net.minecraft.screen;

import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.inventory.Inventory;
import net.minecraft.item.ItemStack;
import net.minecraft.screen.ScreenHandler;
import net.minecraft.screen.ScreenHandlerType;
import net.minecraft.screen.slot.Slot;
import net.minecraft.screen.slot.TradeOutputSlot;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.sound.SoundCategory;
import net.minecraft.village.Merchant;
import net.minecraft.village.MerchantInventory;
import net.minecraft.village.SimpleMerchant;
import net.minecraft.village.TradeOffer;
import net.minecraft.village.TradeOfferList;

public class MerchantScreenHandler
extends ScreenHandler {
    protected static final int INPUT_1_ID = 0;
    protected static final int INPUT_2_ID = 1;
    protected static final int OUTPUT_ID = 2;
    private static final int INVENTORY_START = 3;
    private static final int INVENTORY_END = 30;
    private static final int HOTBAR_START = 30;
    private static final int HOTBAR_END = 39;
    private static final int INPUT_1_X = 136;
    private static final int INPUT_2_X = 162;
    private static final int OUTPUT_X = 220;
    private static final int SLOT_Y = 37;
    private final Merchant merchant;
    private final MerchantInventory merchantInventory;
    private int levelProgress;
    private boolean leveled;
    private boolean canRefreshTrades;

    public MerchantScreenHandler(int i, PlayerInventory playerInventory) {
        this(i, playerInventory, new SimpleMerchant(playerInventory.player));
    }

    public MerchantScreenHandler(int i, PlayerInventory playerInventory, Merchant merchant) {
        super(ScreenHandlerType.field_17340, i);
        int j;
        this.merchant = merchant;
        this.merchantInventory = new MerchantInventory(merchant);
        this.addSlot(new Slot(this.merchantInventory, 0, 136, 37));
        this.addSlot(new Slot(this.merchantInventory, 1, 162, 37));
        this.addSlot(new TradeOutputSlot(playerInventory.player, merchant, this.merchantInventory, 2, 220, 37));
        for (j = 0; j < 3; ++j) {
            for (int k = 0; k < 9; ++k) {
                this.addSlot(new Slot(playerInventory, k + j * 9 + 9, 108 + k * 18, 84 + j * 18));
            }
        }
        for (j = 0; j < 9; ++j) {
            this.addSlot(new Slot(playerInventory, j, 108 + j * 18, 142));
        }
    }

    public void setLeveled(boolean bl) {
        this.leveled = bl;
    }

    @Override
    public void onContentChanged(Inventory inventory) {
        this.merchantInventory.updateOffers();
        super.onContentChanged(inventory);
    }

    public void setRecipeIndex(int i) {
        this.merchantInventory.setOfferIndex(i);
    }

    @Override
    public boolean canUse(PlayerEntity playerEntity) {
        return this.merchant.getCustomer() == playerEntity;
    }

    public int getExperience() {
        return this.merchant.getExperience();
    }

    public int getMerchantRewardedExperience() {
        return this.merchantInventory.getMerchantRewardedExperience();
    }

    public void setExperienceFromServer(int i) {
        this.merchant.setExperienceFromServer(i);
    }

    public int getLevelProgress() {
        return this.levelProgress;
    }

    public void setLevelProgress(int i) {
        this.levelProgress = i;
    }

    public void setCanRefreshTrades(boolean bl) {
        this.canRefreshTrades = bl;
    }

    public boolean canRefreshTrades() {
        return this.canRefreshTrades;
    }

    @Override
    public boolean canInsertIntoSlot(ItemStack itemStack, Slot slot) {
        return false;
    }

    @Override
    public ItemStack quickMove(PlayerEntity playerEntity, int i) {
        ItemStack itemStack = ItemStack.EMPTY;
        Slot slot = (Slot)this.slots.get(i);
        if (slot != null && slot.hasStack()) {
            ItemStack itemStack2 = slot.getStack();
            itemStack = itemStack2.copy();
            if (i == 2) {
                if (!this.insertItem(itemStack2, 3, 39, true)) {
                    return ItemStack.EMPTY;
                }
                slot.onQuickTransfer(itemStack2, itemStack);
                this.playYesSound();
            } else if (i == 0 || i == 1 ? !this.insertItem(itemStack2, 3, 39, false) : (i >= 3 && i < 30 ? !this.insertItem(itemStack2, 30, 39, false) : i >= 30 && i < 39 && !this.insertItem(itemStack2, 3, 30, false))) {
                return ItemStack.EMPTY;
            }
            if (itemStack2.isEmpty()) {
                slot.setStack(ItemStack.EMPTY);
            } else {
                slot.markDirty();
            }
            if (itemStack2.getCount() == itemStack.getCount()) {
                return ItemStack.EMPTY;
            }
            slot.onTakeItem(playerEntity, itemStack2);
        }
        return itemStack;
    }

    private void playYesSound() {
        if (!this.merchant.isClient()) {
            Entity entity = (Entity)((Object)this.merchant);
            entity.getWorld().playSound(entity.getX(), entity.getY(), entity.getZ(), this.merchant.getYesSound(), SoundCategory.field_15254, 1.0f, 1.0f, false);
        }
    }

    @Override
    public void onClosed(PlayerEntity playerEntity) {
        super.onClosed(playerEntity);
        this.merchant.setCustomer(null);
        if (this.merchant.isClient()) {
            return;
        }
        if (!playerEntity.isAlive() || playerEntity instanceof ServerPlayerEntity && ((ServerPlayerEntity)playerEntity).isDisconnected()) {
            ItemStack itemStack = this.merchantInventory.removeStack(0);
            if (!itemStack.isEmpty()) {
                playerEntity.dropItem(itemStack, false);
            }
            if (!(itemStack = this.merchantInventory.removeStack(1)).isEmpty()) {
                playerEntity.dropItem(itemStack, false);
            }
        } else if (playerEntity instanceof ServerPlayerEntity) {
            playerEntity.getInventory().offerOrDrop(this.merchantInventory.removeStack(0));
            playerEntity.getInventory().offerOrDrop(this.merchantInventory.removeStack(1));
        }
    }

    public void switchTo(int i) {
        ItemStack itemStack2;
        if (i < 0 || this.getRecipes().size() <= i) {
            return;
        }
        ItemStack itemStack = this.merchantInventory.getStack(0);
        if (!itemStack.isEmpty()) {
            if (!this.insertItem(itemStack, 3, 39, true)) {
                return;
            }
            this.merchantInventory.setStack(0, itemStack);
        }
        if (!(itemStack2 = this.merchantInventory.getStack(1)).isEmpty()) {
            if (!this.insertItem(itemStack2, 3, 39, true)) {
                return;
            }
            this.merchantInventory.setStack(1, itemStack2);
        }
        if (this.merchantInventory.getStack(0).isEmpty() && this.merchantInventory.getStack(1).isEmpty()) {
            ItemStack itemStack3 = ((TradeOffer)this.getRecipes().get(i)).getAdjustedFirstBuyItem();
            this.autofill(0, itemStack3);
            ItemStack itemStack4 = ((TradeOffer)this.getRecipes().get(i)).getSecondBuyItem();
            this.autofill(1, itemStack4);
        }
    }

    private void autofill(int i, ItemStack itemStack) {
        if (!itemStack.isEmpty()) {
            for (int j = 3; j < 39; ++j) {
                ItemStack itemStack2 = ((Slot)this.slots.get(j)).getStack();
                if (itemStack2.isEmpty() || !ItemStack.canCombine(itemStack, itemStack2)) continue;
                ItemStack itemStack3 = this.merchantInventory.getStack(i);
                int k = itemStack3.isEmpty() ? 0 : itemStack3.getCount();
                int l = Math.min(itemStack.getMaxCount() - k, itemStack2.getCount());
                ItemStack itemStack4 = itemStack2.copy();
                int m = k + l;
                itemStack2.decrement(l);
                itemStack4.setCount(m);
                this.merchantInventory.setStack(i, itemStack4);
                if (m >= itemStack.getMaxCount()) break;
            }
        }
    }

    public void setOffers(TradeOfferList tradeOfferList) {
        this.merchant.setOffersFromServer(tradeOfferList);
    }

    public TradeOfferList getRecipes() {
        return this.merchant.getOffers();
    }

    public boolean isLeveled() {
        return this.leveled;
    }
}


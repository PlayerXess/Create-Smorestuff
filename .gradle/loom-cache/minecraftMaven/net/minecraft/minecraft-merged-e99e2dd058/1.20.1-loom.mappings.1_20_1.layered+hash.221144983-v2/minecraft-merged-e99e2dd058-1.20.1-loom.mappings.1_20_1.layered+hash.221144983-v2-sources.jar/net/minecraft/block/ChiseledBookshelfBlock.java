/*
 * Decompiled with CFR 0.2.1 (FabricMC 53fa44c9).
 */
package net.minecraft.block;

import java.util.List;
import java.util.Optional;
import net.minecraft.block.AbstractBlock;
import net.minecraft.block.Block;
import net.minecraft.block.BlockRenderType;
import net.minecraft.block.BlockState;
import net.minecraft.block.BlockWithEntity;
import net.minecraft.block.HorizontalFacingBlock;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.block.entity.ChiseledBookshelfBlockEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemPlacementContext;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.registry.tag.ItemTags;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;
import net.minecraft.stat.Stats;
import net.minecraft.state.StateManager;
import net.minecraft.state.property.BooleanProperty;
import net.minecraft.state.property.Properties;
import net.minecraft.state.property.Property;
import net.minecraft.util.ActionResult;
import net.minecraft.util.BlockMirror;
import net.minecraft.util.BlockRotation;
import net.minecraft.util.Hand;
import net.minecraft.util.ItemScatterer;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec2f;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;
import net.minecraft.world.event.GameEvent;
import org.jetbrains.annotations.Nullable;

public class ChiseledBookshelfBlock
extends BlockWithEntity {
    private static final int MAX_BOOK_COUNT = 6;
    public static final int BOOK_HEIGHT = 3;
    public static final List<BooleanProperty> SLOT_OCCUPIED_PROPERTIES = List.of(Properties.SLOT_0_OCCUPIED, Properties.SLOT_1_OCCUPIED, Properties.SLOT_2_OCCUPIED, Properties.SLOT_3_OCCUPIED, Properties.SLOT_4_OCCUPIED, Properties.SLOT_5_OCCUPIED);

    public ChiseledBookshelfBlock(AbstractBlock.Settings settings) {
        super(settings);
        BlockState blockState = (BlockState)((BlockState)this.stateManager.getDefaultState()).with(HorizontalFacingBlock.FACING, Direction.field_11043);
        for (BooleanProperty booleanProperty : SLOT_OCCUPIED_PROPERTIES) {
            blockState = (BlockState)blockState.with(booleanProperty, false);
        }
        this.setDefaultState(blockState);
    }

    @Override
    public BlockRenderType getRenderType(BlockState blockState) {
        return BlockRenderType.field_11458;
    }

    @Override
    public ActionResult onUse(BlockState blockState, World world, BlockPos blockPos, PlayerEntity playerEntity, Hand hand, BlockHitResult blockHitResult) {
        BlockEntity blockEntity = world.getBlockEntity(blockPos);
        if (!(blockEntity instanceof ChiseledBookshelfBlockEntity)) {
            return ActionResult.PASS;
        }
        ChiseledBookshelfBlockEntity chiseledBookshelfBlockEntity = (ChiseledBookshelfBlockEntity)blockEntity;
        Optional<Vec2f> optional = ChiseledBookshelfBlock.getHitPos(blockHitResult, blockState.get(HorizontalFacingBlock.FACING));
        if (optional.isEmpty()) {
            return ActionResult.PASS;
        }
        int i = ChiseledBookshelfBlock.getSlotForHitPos(optional.get());
        if (((Boolean)blockState.get(SLOT_OCCUPIED_PROPERTIES.get(i))).booleanValue()) {
            ChiseledBookshelfBlock.tryRemoveBook(world, blockPos, playerEntity, chiseledBookshelfBlockEntity, i);
            return ActionResult.success(world.isClient);
        }
        ItemStack itemStack = playerEntity.getStackInHand(hand);
        if (itemStack.isIn(ItemTags.field_40109)) {
            ChiseledBookshelfBlock.tryAddBook(world, blockPos, playerEntity, chiseledBookshelfBlockEntity, itemStack, i);
            return ActionResult.success(world.isClient);
        }
        return ActionResult.CONSUME;
    }

    private static Optional<Vec2f> getHitPos(BlockHitResult blockHitResult, Direction direction) {
        Direction direction2 = blockHitResult.getSide();
        if (direction != direction2) {
            return Optional.empty();
        }
        BlockPos blockPos = blockHitResult.getBlockPos().offset(direction2);
        Vec3d vec3d = blockHitResult.getPos().subtract(blockPos.getX(), blockPos.getY(), blockPos.getZ());
        double d = vec3d.getX();
        double e = vec3d.getY();
        double f = vec3d.getZ();
        return switch (direction2) {
            default -> throw new IncompatibleClassChangeError();
            case Direction.field_11043 -> Optional.of(new Vec2f((float)(1.0 - d), (float)e));
            case Direction.field_11035 -> Optional.of(new Vec2f((float)d, (float)e));
            case Direction.field_11039 -> Optional.of(new Vec2f((float)f, (float)e));
            case Direction.field_11034 -> Optional.of(new Vec2f((float)(1.0 - f), (float)e));
            case Direction.field_11033, Direction.field_11036 -> Optional.empty();
        };
    }

    private static int getSlotForHitPos(Vec2f vec2f) {
        int i = vec2f.y >= 0.5f ? 0 : 1;
        int j = ChiseledBookshelfBlock.getColumn(vec2f.x);
        return j + i * 3;
    }

    private static int getColumn(float f) {
        float g = 0.0625f;
        float h = 0.375f;
        if (f < 0.375f) {
            return 0;
        }
        float i = 0.6875f;
        if (f < 0.6875f) {
            return 1;
        }
        return 2;
    }

    private static void tryAddBook(World world, BlockPos blockPos, PlayerEntity playerEntity, ChiseledBookshelfBlockEntity chiseledBookshelfBlockEntity, ItemStack itemStack, int i) {
        if (world.isClient) {
            return;
        }
        playerEntity.incrementStat(Stats.field_15372.getOrCreateStat(itemStack.getItem()));
        SoundEvent soundEvent = itemStack.isOf(Items.field_8598) ? SoundEvents.field_40971 : SoundEvents.field_40970;
        chiseledBookshelfBlockEntity.setStack(i, itemStack.split(1));
        world.playSound(null, blockPos, soundEvent, SoundCategory.field_15245, 1.0f, 1.0f);
        if (playerEntity.isCreative()) {
            itemStack.increment(1);
        }
        world.emitGameEvent((Entity)playerEntity, GameEvent.field_28733, blockPos);
    }

    private static void tryRemoveBook(World world, BlockPos blockPos, PlayerEntity playerEntity, ChiseledBookshelfBlockEntity chiseledBookshelfBlockEntity, int i) {
        if (world.isClient) {
            return;
        }
        ItemStack itemStack = chiseledBookshelfBlockEntity.removeStack(i, 1);
        SoundEvent soundEvent = itemStack.isOf(Items.field_8598) ? SoundEvents.field_40974 : SoundEvents.field_40973;
        world.playSound(null, blockPos, soundEvent, SoundCategory.field_15245, 1.0f, 1.0f);
        if (!playerEntity.getInventory().insertStack(itemStack)) {
            playerEntity.dropItem(itemStack, false);
        }
        world.emitGameEvent((Entity)playerEntity, GameEvent.field_28733, blockPos);
    }

    @Override
    @Nullable
    public BlockEntity createBlockEntity(BlockPos blockPos, BlockState blockState) {
        return new ChiseledBookshelfBlockEntity(blockPos, blockState);
    }

    @Override
    protected void appendProperties(StateManager.Builder<Block, BlockState> builder) {
        builder.add(HorizontalFacingBlock.FACING);
        SLOT_OCCUPIED_PROPERTIES.forEach(property -> builder.add((Property<?>)property));
    }

    @Override
    public void onStateReplaced(BlockState blockState, World world, BlockPos blockPos, BlockState blockState2, boolean bl) {
        ChiseledBookshelfBlockEntity chiseledBookshelfBlockEntity;
        if (blockState.isOf(blockState2.getBlock())) {
            return;
        }
        BlockEntity blockEntity = world.getBlockEntity(blockPos);
        if (blockEntity instanceof ChiseledBookshelfBlockEntity && !(chiseledBookshelfBlockEntity = (ChiseledBookshelfBlockEntity)blockEntity).isEmpty()) {
            for (int i = 0; i < 6; ++i) {
                ItemStack itemStack = chiseledBookshelfBlockEntity.getStack(i);
                if (itemStack.isEmpty()) continue;
                ItemScatterer.spawn(world, (double)blockPos.getX(), (double)blockPos.getY(), (double)blockPos.getZ(), itemStack);
            }
            chiseledBookshelfBlockEntity.clear();
            world.updateComparators(blockPos, this);
        }
        super.onStateReplaced(blockState, world, blockPos, blockState2, bl);
    }

    @Override
    public BlockState getPlacementState(ItemPlacementContext itemPlacementContext) {
        return (BlockState)this.getDefaultState().with(HorizontalFacingBlock.FACING, itemPlacementContext.getHorizontalPlayerFacing().getOpposite());
    }

    @Override
    public BlockState rotate(BlockState blockState, BlockRotation blockRotation) {
        return (BlockState)blockState.with(HorizontalFacingBlock.FACING, blockRotation.rotate(blockState.get(HorizontalFacingBlock.FACING)));
    }

    @Override
    public BlockState mirror(BlockState blockState, BlockMirror blockMirror) {
        return blockState.rotate(blockMirror.getRotation(blockState.get(HorizontalFacingBlock.FACING)));
    }

    @Override
    public boolean hasComparatorOutput(BlockState blockState) {
        return true;
    }

    @Override
    public int getComparatorOutput(BlockState blockState, World world, BlockPos blockPos) {
        if (world.isClient()) {
            return 0;
        }
        BlockEntity blockEntity = world.getBlockEntity(blockPos);
        if (blockEntity instanceof ChiseledBookshelfBlockEntity) {
            ChiseledBookshelfBlockEntity chiseledBookshelfBlockEntity = (ChiseledBookshelfBlockEntity)blockEntity;
            return chiseledBookshelfBlockEntity.getLastInteractedSlot() + 1;
        }
        return 0;
    }
}


/*
 * Decompiled with CFR 0.2.1 (FabricMC 53fa44c9).
 */
package net.minecraft.util.math;

import com.google.common.collect.Lists;
import java.util.List;
import net.minecraft.util.math.BlockPos;

public class GravityField {
    private final List<Point> points = Lists.newArrayList();

    public void addPoint(BlockPos blockPos, double d) {
        if (d != 0.0) {
            this.points.add(new Point(blockPos, d));
        }
    }

    public double calculate(BlockPos blockPos, double d) {
        if (d == 0.0) {
            return 0.0;
        }
        double e = 0.0;
        for (Point point : this.points) {
            e += point.getGravityFactor(blockPos);
        }
        return e * d;
    }

    static class Point {
        private final BlockPos pos;
        private final double mass;

        public Point(BlockPos blockPos, double d) {
            this.pos = blockPos;
            this.mass = d;
        }

        public double getGravityFactor(BlockPos blockPos) {
            double d = this.pos.getSquaredDistance(blockPos);
            if (d == 0.0) {
                return Double.POSITIVE_INFINITY;
            }
            return this.mass / Math.sqrt(d);
        }
    }
}


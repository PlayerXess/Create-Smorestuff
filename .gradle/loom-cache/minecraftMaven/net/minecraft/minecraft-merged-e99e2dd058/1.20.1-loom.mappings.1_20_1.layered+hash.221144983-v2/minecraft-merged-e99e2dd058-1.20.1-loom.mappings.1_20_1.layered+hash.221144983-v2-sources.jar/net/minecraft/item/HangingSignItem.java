/*
 * Decompiled with CFR 0.2.1 (FabricMC 53fa44c9).
 */
package net.minecraft.item;

import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.WallHangingSignBlock;
import net.minecraft.item.Item;
import net.minecraft.item.SignItem;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.world.WorldView;

public class HangingSignItem
extends SignItem {
    public HangingSignItem(Block block, Block block2, Item.Settings settings) {
        super(settings, block, block2, Direction.field_11036);
    }

    @Override
    protected boolean canPlaceAt(WorldView worldView, BlockState blockState, BlockPos blockPos) {
        WallHangingSignBlock wallHangingSignBlock;
        Block block = blockState.getBlock();
        if (block instanceof WallHangingSignBlock && !(wallHangingSignBlock = (WallHangingSignBlock)block).canAttachAt(blockState, worldView, blockPos)) {
            return false;
        }
        return super.canPlaceAt(worldView, blockState, blockPos);
    }
}


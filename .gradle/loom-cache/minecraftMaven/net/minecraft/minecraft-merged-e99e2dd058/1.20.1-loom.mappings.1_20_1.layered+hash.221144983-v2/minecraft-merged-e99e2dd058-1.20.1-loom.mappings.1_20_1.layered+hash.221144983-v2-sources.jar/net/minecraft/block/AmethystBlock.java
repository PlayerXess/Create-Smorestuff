/*
 * Decompiled with CFR 0.2.1 (FabricMC 53fa44c9).
 */
package net.minecraft.block;

import net.minecraft.block.AbstractBlock;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.entity.projectile.ProjectileEntity;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

public class AmethystBlock
extends Block {
    public AmethystBlock(AbstractBlock.Settings settings) {
        super(settings);
    }

    @Override
    public void onProjectileHit(World world, BlockState blockState, BlockHitResult blockHitResult, ProjectileEntity projectileEntity) {
        if (!world.isClient) {
            BlockPos blockPos = blockHitResult.getBlockPos();
            world.playSound(null, blockPos, SoundEvents.field_26982, SoundCategory.field_15245, 1.0f, 0.5f + world.random.nextFloat() * 1.2f);
            world.playSound(null, blockPos, SoundEvents.field_26980, SoundCategory.field_15245, 1.0f, 0.5f + world.random.nextFloat() * 1.2f);
        }
    }
}


/*
 * Decompiled with CFR 0.2.1 (FabricMC 53fa44c9).
 */
package net.minecraft.world.biome.source;

import com.google.common.base.Suppliers;
import com.google.common.collect.ImmutableSet;
import com.google.common.collect.Sets;
import com.mojang.datafixers.util.Pair;
import com.mojang.serialization.Codec;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.function.Supplier;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import net.minecraft.SharedConstants;
import net.minecraft.registry.Registries;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.random.Random;
import net.minecraft.world.WorldView;
import net.minecraft.world.biome.Biome;
import net.minecraft.world.biome.source.BiomeCoords;
import net.minecraft.world.biome.source.BiomeSupplier;
import net.minecraft.world.biome.source.util.MultiNoiseUtil;
import org.jetbrains.annotations.Nullable;

public abstract class BiomeSource
implements BiomeSupplier {
    public static final Codec<BiomeSource> CODEC = Registries.BIOME_SOURCE.getCodec().dispatchStable(BiomeSource::getCodec, Function.identity());
    private final Supplier<Set<RegistryEntry<Biome>>> biomes = Suppliers.memoize(() -> this.biomeStream().distinct().collect(ImmutableSet.toImmutableSet()));

    protected BiomeSource() {
    }

    protected abstract Codec<? extends BiomeSource> getCodec();

    protected abstract Stream<RegistryEntry<Biome>> biomeStream();

    public Set<RegistryEntry<Biome>> getBiomes() {
        return this.biomes.get();
    }

    public Set<RegistryEntry<Biome>> getBiomesInArea(int i, int j, int k, int l, MultiNoiseUtil.MultiNoiseSampler multiNoiseSampler) {
        int m = BiomeCoords.fromBlock(i - l);
        int n = BiomeCoords.fromBlock(j - l);
        int o = BiomeCoords.fromBlock(k - l);
        int p = BiomeCoords.fromBlock(i + l);
        int q = BiomeCoords.fromBlock(j + l);
        int r = BiomeCoords.fromBlock(k + l);
        int s = p - m + 1;
        int t = q - n + 1;
        int u = r - o + 1;
        HashSet<RegistryEntry<Biome>> set = Sets.newHashSet();
        for (int v = 0; v < u; ++v) {
            for (int w = 0; w < s; ++w) {
                for (int x = 0; x < t; ++x) {
                    int y = m + w;
                    int z = n + x;
                    int aa = o + v;
                    set.add(this.getBiome(y, z, aa, multiNoiseSampler));
                }
            }
        }
        return set;
    }

    @Nullable
    public Pair<BlockPos, RegistryEntry<Biome>> locateBiome(int i, int j, int k, int l, Predicate<RegistryEntry<Biome>> predicate, Random random, MultiNoiseUtil.MultiNoiseSampler multiNoiseSampler) {
        return this.locateBiome(i, j, k, l, 1, predicate, random, false, multiNoiseSampler);
    }

    @Nullable
    public Pair<BlockPos, RegistryEntry<Biome>> locateBiome(BlockPos blockPos, int i, int j, int k, Predicate<RegistryEntry<Biome>> predicate, MultiNoiseUtil.MultiNoiseSampler multiNoiseSampler, WorldView worldView) {
        Set set = this.getBiomes().stream().filter(predicate).collect(Collectors.toUnmodifiableSet());
        if (set.isEmpty()) {
            return null;
        }
        int l = Math.floorDiv(i, j);
        int[] is = MathHelper.stream(blockPos.getY(), worldView.getBottomY() + 1, worldView.getTopY(), k).toArray();
        for (BlockPos.Mutable mutable : BlockPos.iterateInSquare(BlockPos.ORIGIN, l, Direction.field_11034, Direction.field_11035)) {
            int m = blockPos.getX() + mutable.getX() * j;
            int n = blockPos.getZ() + mutable.getZ() * j;
            int o = BiomeCoords.fromBlock(m);
            int p = BiomeCoords.fromBlock(n);
            for (int q : is) {
                int r = BiomeCoords.fromBlock(q);
                RegistryEntry<Biome> registryEntry = this.getBiome(o, r, p, multiNoiseSampler);
                if (!set.contains(registryEntry)) continue;
                return Pair.of(new BlockPos(m, q, n), registryEntry);
            }
        }
        return null;
    }

    @Nullable
    public Pair<BlockPos, RegistryEntry<Biome>> locateBiome(int i, int j, int k, int l, int m, Predicate<RegistryEntry<Biome>> predicate, Random random, boolean bl, MultiNoiseUtil.MultiNoiseSampler multiNoiseSampler) {
        int s;
        int n = BiomeCoords.fromBlock(i);
        int o = BiomeCoords.fromBlock(k);
        int p = BiomeCoords.fromBlock(l);
        int q = BiomeCoords.fromBlock(j);
        Pair<BlockPos, RegistryEntry<Biome>> pair = null;
        int r = 0;
        for (int t = s = bl ? 0 : p; t <= p; t += m) {
            int u;
            int n2 = u = SharedConstants.DEBUG_BIOME_SOURCE ? 0 : -t;
            while (u <= t) {
                boolean bl2 = Math.abs(u) == t;
                for (int v = -t; v <= t; v += m) {
                    int x;
                    int w;
                    RegistryEntry<Biome> registryEntry;
                    if (bl) {
                        boolean bl3;
                        boolean bl4 = bl3 = Math.abs(v) == t;
                        if (!bl3 && !bl2) continue;
                    }
                    if (!predicate.test(registryEntry = this.getBiome(w = n + v, q, x = o + u, multiNoiseSampler))) continue;
                    if (pair == null || random.nextInt(r + 1) == 0) {
                        BlockPos blockPos = new BlockPos(BiomeCoords.toBlock(w), j, BiomeCoords.toBlock(x));
                        if (bl) {
                            return Pair.of(blockPos, registryEntry);
                        }
                        pair = Pair.of(blockPos, registryEntry);
                    }
                    ++r;
                }
                u += m;
            }
        }
        return pair;
    }

    @Override
    public abstract RegistryEntry<Biome> getBiome(int var1, int var2, int var3, MultiNoiseUtil.MultiNoiseSampler var4);

    public void addDebugInfo(List<String> list, BlockPos blockPos, MultiNoiseUtil.MultiNoiseSampler multiNoiseSampler) {
    }
}


/*
 * Decompiled with CFR 0.2.1 (FabricMC 53fa44c9).
 */
package net.minecraft.util.math;

import net.minecraft.util.math.GivensPair;
import org.apache.commons.lang3.tuple.Triple;
import org.joml.Math;
import org.joml.Matrix3f;
import org.joml.Matrix4f;
import org.joml.Quaternionf;
import org.joml.Vector3f;

public class MatrixUtil {
    private static final float COT_PI_OVER_8 = 3.0f + 2.0f * Math.sqrt(2.0f);
    private static final GivensPair SIN_COS_PI_OVER_8 = GivensPair.fromAngle(0.7853982f);

    private MatrixUtil() {
    }

    public static Matrix4f scale(Matrix4f matrix4f, float f) {
        return matrix4f.set(matrix4f.m00() * f, matrix4f.m01() * f, matrix4f.m02() * f, matrix4f.m03() * f, matrix4f.m10() * f, matrix4f.m11() * f, matrix4f.m12() * f, matrix4f.m13() * f, matrix4f.m20() * f, matrix4f.m21() * f, matrix4f.m22() * f, matrix4f.m23() * f, matrix4f.m30() * f, matrix4f.m31() * f, matrix4f.m32() * f, matrix4f.m33() * f);
    }

    private static GivensPair approximateGivensQuaternion(float f, float g, float h) {
        float j = g;
        float i = 2.0f * (f - h);
        if (COT_PI_OVER_8 * j * j < i * i) {
            return GivensPair.normalize(j, i);
        }
        return SIN_COS_PI_OVER_8;
    }

    private static GivensPair qrGivensQuaternion(float f, float g) {
        float h = (float)java.lang.Math.hypot(f, g);
        float i = h > 1.0E-6f ? g : 0.0f;
        float j = Math.abs(f) + Math.max(h, 1.0E-6f);
        if (f < 0.0f) {
            float k = i;
            i = j;
            j = k;
        }
        return GivensPair.normalize(i, j);
    }

    private static void conjugate(Matrix3f matrix3f, Matrix3f matrix3f2) {
        matrix3f.mul(matrix3f2);
        matrix3f2.transpose();
        matrix3f2.mul(matrix3f);
        matrix3f.set(matrix3f2);
    }

    private static void applyJacobiIteration(Matrix3f matrix3f, Matrix3f matrix3f2, Quaternionf quaternionf, Quaternionf quaternionf2) {
        Quaternionf quaternionf3;
        GivensPair givensPair;
        if (matrix3f.m01 * matrix3f.m01 + matrix3f.m10 * matrix3f.m10 > 1.0E-6f) {
            givensPair = MatrixUtil.approximateGivensQuaternion(matrix3f.m00, 0.5f * (matrix3f.m01 + matrix3f.m10), matrix3f.m11);
            quaternionf3 = givensPair.setZRotation(quaternionf);
            quaternionf2.mul(quaternionf3);
            givensPair.setRotationZ(matrix3f2);
            MatrixUtil.conjugate(matrix3f, matrix3f2);
        }
        if (matrix3f.m02 * matrix3f.m02 + matrix3f.m20 * matrix3f.m20 > 1.0E-6f) {
            givensPair = MatrixUtil.approximateGivensQuaternion(matrix3f.m00, 0.5f * (matrix3f.m02 + matrix3f.m20), matrix3f.m22).negateSin();
            quaternionf3 = givensPair.setYRotation(quaternionf);
            quaternionf2.mul(quaternionf3);
            givensPair.setRotationY(matrix3f2);
            MatrixUtil.conjugate(matrix3f, matrix3f2);
        }
        if (matrix3f.m12 * matrix3f.m12 + matrix3f.m21 * matrix3f.m21 > 1.0E-6f) {
            givensPair = MatrixUtil.approximateGivensQuaternion(matrix3f.m11, 0.5f * (matrix3f.m12 + matrix3f.m21), matrix3f.m22);
            quaternionf3 = givensPair.setXRotation(quaternionf);
            quaternionf2.mul(quaternionf3);
            givensPair.setRotationX(matrix3f2);
            MatrixUtil.conjugate(matrix3f, matrix3f2);
        }
    }

    public static Quaternionf applyJacobiIterations(Matrix3f matrix3f, int i) {
        Quaternionf quaternionf = new Quaternionf();
        Matrix3f matrix3f2 = new Matrix3f();
        Quaternionf quaternionf2 = new Quaternionf();
        for (int j = 0; j < i; ++j) {
            MatrixUtil.applyJacobiIteration(matrix3f, matrix3f2, quaternionf2, quaternionf);
        }
        quaternionf.normalize();
        return quaternionf;
    }

    public static Triple<Quaternionf, Vector3f, Quaternionf> svdDecompose(Matrix3f matrix3f) {
        Matrix3f matrix3f2 = new Matrix3f(matrix3f);
        matrix3f2.transpose();
        matrix3f2.mul(matrix3f);
        Quaternionf quaternionf = MatrixUtil.applyJacobiIterations(matrix3f2, 5);
        float f = matrix3f2.m00;
        float g = matrix3f2.m11;
        boolean bl = (double)f < 1.0E-6;
        boolean bl2 = (double)g < 1.0E-6;
        Matrix3f matrix3f3 = matrix3f2;
        Matrix3f matrix3f4 = matrix3f.rotate(quaternionf);
        Quaternionf quaternionf2 = new Quaternionf();
        Quaternionf quaternionf3 = new Quaternionf();
        GivensPair givensPair = bl ? MatrixUtil.qrGivensQuaternion(matrix3f4.m11, -matrix3f4.m10) : MatrixUtil.qrGivensQuaternion(matrix3f4.m00, matrix3f4.m01);
        Quaternionf quaternionf4 = givensPair.setZRotation(quaternionf3);
        Matrix3f matrix3f5 = givensPair.setRotationZ(matrix3f3);
        quaternionf2.mul(quaternionf4);
        matrix3f5.transpose().mul(matrix3f4);
        matrix3f3 = matrix3f4;
        givensPair = bl ? MatrixUtil.qrGivensQuaternion(matrix3f5.m22, -matrix3f5.m20) : MatrixUtil.qrGivensQuaternion(matrix3f5.m00, matrix3f5.m02);
        givensPair = givensPair.negateSin();
        Quaternionf quaternionf5 = givensPair.setYRotation(quaternionf3);
        Matrix3f matrix3f6 = givensPair.setRotationY(matrix3f3);
        quaternionf2.mul(quaternionf5);
        matrix3f6.transpose().mul(matrix3f5);
        matrix3f3 = matrix3f5;
        givensPair = bl2 ? MatrixUtil.qrGivensQuaternion(matrix3f6.m22, -matrix3f6.m21) : MatrixUtil.qrGivensQuaternion(matrix3f6.m11, matrix3f6.m12);
        Quaternionf quaternionf6 = givensPair.setXRotation(quaternionf3);
        Matrix3f matrix3f7 = givensPair.setRotationX(matrix3f3);
        quaternionf2.mul(quaternionf6);
        matrix3f7.transpose().mul(matrix3f6);
        Vector3f vector3f = new Vector3f(matrix3f7.m00, matrix3f7.m11, matrix3f7.m22);
        return Triple.of(quaternionf2, vector3f, quaternionf.conjugate());
    }
}


/*
 * Decompiled with CFR 0.2.1 (FabricMC 53fa44c9).
 */
package net.minecraft.enchantment;

import net.minecraft.enchantment.Enchantment;
import net.minecraft.enchantment.EnchantmentTarget;
import net.minecraft.entity.EquipmentSlot;

public class ChannelingEnchantment
extends Enchantment {
    public ChannelingEnchantment(Enchantment.Rarity rarity, EquipmentSlot ... equipmentSlots) {
        super(rarity, EnchantmentTarget.field_9073, equipmentSlots);
    }

    @Override
    public int getMinPower(int i) {
        return 25;
    }

    @Override
    public int getMaxPower(int i) {
        return 50;
    }
}


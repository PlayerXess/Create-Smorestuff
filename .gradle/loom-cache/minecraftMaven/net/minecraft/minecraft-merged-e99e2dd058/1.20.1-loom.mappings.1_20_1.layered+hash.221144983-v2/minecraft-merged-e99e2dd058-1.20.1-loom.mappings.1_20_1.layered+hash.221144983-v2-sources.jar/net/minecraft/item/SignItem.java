/*
 * Decompiled with CFR 0.2.1 (FabricMC 53fa44c9).
 */
package net.minecraft.item;

import net.minecraft.block.AbstractSignBlock;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.entity.SignBlockEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.VerticallyAttachableBlockItem;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.world.World;
import org.jetbrains.annotations.Nullable;

public class SignItem
extends VerticallyAttachableBlockItem {
    public SignItem(Item.Settings settings, Block block, Block block2) {
        super(block, block2, settings, Direction.field_11033);
    }

    public SignItem(Item.Settings settings, Block block, Block block2, Direction direction) {
        super(block, block2, settings, direction);
    }

    @Override
    protected boolean postPlacement(BlockPos blockPos, World world, @Nullable PlayerEntity playerEntity, ItemStack itemStack, BlockState blockState) {
        Object object;
        boolean bl = super.postPlacement(blockPos, world, playerEntity, itemStack, blockState);
        if (!world.isClient && !bl && playerEntity != null && (object = world.getBlockEntity(blockPos)) instanceof SignBlockEntity) {
            SignBlockEntity signBlockEntity = (SignBlockEntity)object;
            object = world.getBlockState(blockPos).getBlock();
            if (object instanceof AbstractSignBlock) {
                AbstractSignBlock abstractSignBlock = (AbstractSignBlock)object;
                abstractSignBlock.openEditScreen(playerEntity, signBlockEntity, true);
            }
        }
        return bl;
    }
}


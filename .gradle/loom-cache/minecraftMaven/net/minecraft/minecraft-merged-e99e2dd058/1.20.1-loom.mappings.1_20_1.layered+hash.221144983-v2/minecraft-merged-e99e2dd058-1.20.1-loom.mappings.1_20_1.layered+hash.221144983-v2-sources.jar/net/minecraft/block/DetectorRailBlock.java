/*
 * Decompiled with CFR 0.2.1 (FabricMC 53fa44c9).
 */
package net.minecraft.block;

import java.util.List;
import java.util.function.Predicate;
import net.minecraft.block.AbstractBlock;
import net.minecraft.block.AbstractRailBlock;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.RailPlacementHelper;
import net.minecraft.block.enums.RailShape;
import net.minecraft.entity.Entity;
import net.minecraft.entity.vehicle.AbstractMinecartEntity;
import net.minecraft.entity.vehicle.CommandBlockMinecartEntity;
import net.minecraft.inventory.Inventory;
import net.minecraft.predicate.entity.EntityPredicates;
import net.minecraft.screen.ScreenHandler;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.state.StateManager;
import net.minecraft.state.property.BooleanProperty;
import net.minecraft.state.property.EnumProperty;
import net.minecraft.state.property.Properties;
import net.minecraft.state.property.Property;
import net.minecraft.util.BlockMirror;
import net.minecraft.util.BlockRotation;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.random.Random;
import net.minecraft.world.BlockView;
import net.minecraft.world.World;

public class DetectorRailBlock
extends AbstractRailBlock {
    public static final EnumProperty<RailShape> SHAPE = Properties.STRAIGHT_RAIL_SHAPE;
    public static final BooleanProperty POWERED = Properties.POWERED;
    private static final int SCHEDULED_TICK_DELAY = 20;

    public DetectorRailBlock(AbstractBlock.Settings settings) {
        super(true, settings);
        this.setDefaultState((BlockState)((BlockState)((BlockState)((BlockState)this.stateManager.getDefaultState()).with(POWERED, false)).with(SHAPE, RailShape.field_12665)).with(WATERLOGGED, false));
    }

    @Override
    public boolean emitsRedstonePower(BlockState blockState) {
        return true;
    }

    @Override
    public void onEntityCollision(BlockState blockState, World world, BlockPos blockPos, Entity entity) {
        if (world.isClient) {
            return;
        }
        if (blockState.get(POWERED).booleanValue()) {
            return;
        }
        this.updatePoweredStatus(world, blockPos, blockState);
    }

    @Override
    public void scheduledTick(BlockState blockState, ServerWorld serverWorld, BlockPos blockPos, Random random) {
        if (!blockState.get(POWERED).booleanValue()) {
            return;
        }
        this.updatePoweredStatus(serverWorld, blockPos, blockState);
    }

    @Override
    public int getWeakRedstonePower(BlockState blockState, BlockView blockView, BlockPos blockPos, Direction direction) {
        return blockState.get(POWERED) != false ? 15 : 0;
    }

    @Override
    public int getStrongRedstonePower(BlockState blockState, BlockView blockView, BlockPos blockPos, Direction direction) {
        if (!blockState.get(POWERED).booleanValue()) {
            return 0;
        }
        return direction == Direction.field_11036 ? 15 : 0;
    }

    private void updatePoweredStatus(World world, BlockPos blockPos, BlockState blockState) {
        BlockState blockState2;
        if (!this.canPlaceAt(blockState, world, blockPos)) {
            return;
        }
        boolean bl = blockState.get(POWERED);
        boolean bl2 = false;
        List<AbstractMinecartEntity> list = this.getCarts(world, blockPos, AbstractMinecartEntity.class, entity -> true);
        if (!list.isEmpty()) {
            bl2 = true;
        }
        if (bl2 && !bl) {
            blockState2 = (BlockState)blockState.with(POWERED, true);
            world.setBlockState(blockPos, blockState2, 3);
            this.updateNearbyRails(world, blockPos, blockState2, true);
            world.updateNeighborsAlways(blockPos, this);
            world.updateNeighborsAlways(blockPos.down(), this);
            world.scheduleBlockRerenderIfNeeded(blockPos, blockState, blockState2);
        }
        if (!bl2 && bl) {
            blockState2 = (BlockState)blockState.with(POWERED, false);
            world.setBlockState(blockPos, blockState2, 3);
            this.updateNearbyRails(world, blockPos, blockState2, false);
            world.updateNeighborsAlways(blockPos, this);
            world.updateNeighborsAlways(blockPos.down(), this);
            world.scheduleBlockRerenderIfNeeded(blockPos, blockState, blockState2);
        }
        if (bl2) {
            world.scheduleBlockTick(blockPos, this, 20);
        }
        world.updateComparators(blockPos, this);
    }

    protected void updateNearbyRails(World world, BlockPos blockPos, BlockState blockState, boolean bl) {
        RailPlacementHelper railPlacementHelper = new RailPlacementHelper(world, blockPos, blockState);
        List<BlockPos> list = railPlacementHelper.getNeighbors();
        for (BlockPos blockPos2 : list) {
            BlockState blockState2 = world.getBlockState(blockPos2);
            world.updateNeighbor(blockState2, blockPos2, blockState2.getBlock(), blockPos, false);
        }
    }

    @Override
    public void onBlockAdded(BlockState blockState, World world, BlockPos blockPos, BlockState blockState2, boolean bl) {
        if (blockState2.isOf(blockState.getBlock())) {
            return;
        }
        BlockState blockState3 = this.updateCurves(blockState, world, blockPos, bl);
        this.updatePoweredStatus(world, blockPos, blockState3);
    }

    @Override
    public Property<RailShape> getShapeProperty() {
        return SHAPE;
    }

    @Override
    public boolean hasComparatorOutput(BlockState blockState) {
        return true;
    }

    @Override
    public int getComparatorOutput(BlockState blockState, World world, BlockPos blockPos) {
        if (blockState.get(POWERED).booleanValue()) {
            List<CommandBlockMinecartEntity> list = this.getCarts(world, blockPos, CommandBlockMinecartEntity.class, entity -> true);
            if (!list.isEmpty()) {
                return list.get(0).getCommandExecutor().getSuccessCount();
            }
            List<AbstractMinecartEntity> list2 = this.getCarts(world, blockPos, AbstractMinecartEntity.class, EntityPredicates.VALID_INVENTORIES);
            if (!list2.isEmpty()) {
                return ScreenHandler.calculateComparatorOutput((Inventory)((Object)list2.get(0)));
            }
        }
        return 0;
    }

    private <T extends AbstractMinecartEntity> List<T> getCarts(World world, BlockPos blockPos, Class<T> class_, Predicate<Entity> predicate) {
        return world.getEntitiesByClass(class_, this.getCartDetectionBox(blockPos), predicate);
    }

    private Box getCartDetectionBox(BlockPos blockPos) {
        double d = 0.2;
        return new Box((double)blockPos.getX() + 0.2, blockPos.getY(), (double)blockPos.getZ() + 0.2, (double)(blockPos.getX() + 1) - 0.2, (double)(blockPos.getY() + 1) - 0.2, (double)(blockPos.getZ() + 1) - 0.2);
    }

    @Override
    public BlockState rotate(BlockState blockState, BlockRotation blockRotation) {
        switch (blockRotation) {
            case field_11464: {
                switch (blockState.get(SHAPE)) {
                    case field_12667: {
                        return (BlockState)blockState.with(SHAPE, RailShape.field_12666);
                    }
                    case field_12666: {
                        return (BlockState)blockState.with(SHAPE, RailShape.field_12667);
                    }
                    case field_12670: {
                        return (BlockState)blockState.with(SHAPE, RailShape.field_12668);
                    }
                    case field_12668: {
                        return (BlockState)blockState.with(SHAPE, RailShape.field_12670);
                    }
                    case field_12664: {
                        return (BlockState)blockState.with(SHAPE, RailShape.field_12672);
                    }
                    case field_12671: {
                        return (BlockState)blockState.with(SHAPE, RailShape.field_12663);
                    }
                    case field_12672: {
                        return (BlockState)blockState.with(SHAPE, RailShape.field_12664);
                    }
                    case field_12663: {
                        return (BlockState)blockState.with(SHAPE, RailShape.field_12671);
                    }
                }
            }
            case field_11465: {
                switch (blockState.get(SHAPE)) {
                    case field_12665: {
                        return (BlockState)blockState.with(SHAPE, RailShape.field_12674);
                    }
                    case field_12674: {
                        return (BlockState)blockState.with(SHAPE, RailShape.field_12665);
                    }
                    case field_12667: {
                        return (BlockState)blockState.with(SHAPE, RailShape.field_12670);
                    }
                    case field_12666: {
                        return (BlockState)blockState.with(SHAPE, RailShape.field_12668);
                    }
                    case field_12670: {
                        return (BlockState)blockState.with(SHAPE, RailShape.field_12666);
                    }
                    case field_12668: {
                        return (BlockState)blockState.with(SHAPE, RailShape.field_12667);
                    }
                    case field_12664: {
                        return (BlockState)blockState.with(SHAPE, RailShape.field_12663);
                    }
                    case field_12671: {
                        return (BlockState)blockState.with(SHAPE, RailShape.field_12664);
                    }
                    case field_12672: {
                        return (BlockState)blockState.with(SHAPE, RailShape.field_12671);
                    }
                    case field_12663: {
                        return (BlockState)blockState.with(SHAPE, RailShape.field_12672);
                    }
                }
            }
            case field_11463: {
                switch (blockState.get(SHAPE)) {
                    case field_12665: {
                        return (BlockState)blockState.with(SHAPE, RailShape.field_12674);
                    }
                    case field_12674: {
                        return (BlockState)blockState.with(SHAPE, RailShape.field_12665);
                    }
                    case field_12667: {
                        return (BlockState)blockState.with(SHAPE, RailShape.field_12668);
                    }
                    case field_12666: {
                        return (BlockState)blockState.with(SHAPE, RailShape.field_12670);
                    }
                    case field_12670: {
                        return (BlockState)blockState.with(SHAPE, RailShape.field_12667);
                    }
                    case field_12668: {
                        return (BlockState)blockState.with(SHAPE, RailShape.field_12666);
                    }
                    case field_12664: {
                        return (BlockState)blockState.with(SHAPE, RailShape.field_12671);
                    }
                    case field_12671: {
                        return (BlockState)blockState.with(SHAPE, RailShape.field_12672);
                    }
                    case field_12672: {
                        return (BlockState)blockState.with(SHAPE, RailShape.field_12663);
                    }
                    case field_12663: {
                        return (BlockState)blockState.with(SHAPE, RailShape.field_12664);
                    }
                }
            }
        }
        return blockState;
    }

    @Override
    public BlockState mirror(BlockState blockState, BlockMirror blockMirror) {
        RailShape railShape = blockState.get(SHAPE);
        switch (blockMirror) {
            case field_11300: {
                switch (railShape) {
                    case field_12670: {
                        return (BlockState)blockState.with(SHAPE, RailShape.field_12668);
                    }
                    case field_12668: {
                        return (BlockState)blockState.with(SHAPE, RailShape.field_12670);
                    }
                    case field_12664: {
                        return (BlockState)blockState.with(SHAPE, RailShape.field_12663);
                    }
                    case field_12671: {
                        return (BlockState)blockState.with(SHAPE, RailShape.field_12672);
                    }
                    case field_12672: {
                        return (BlockState)blockState.with(SHAPE, RailShape.field_12671);
                    }
                    case field_12663: {
                        return (BlockState)blockState.with(SHAPE, RailShape.field_12664);
                    }
                }
                break;
            }
            case field_11301: {
                switch (railShape) {
                    case field_12667: {
                        return (BlockState)blockState.with(SHAPE, RailShape.field_12666);
                    }
                    case field_12666: {
                        return (BlockState)blockState.with(SHAPE, RailShape.field_12667);
                    }
                    case field_12664: {
                        return (BlockState)blockState.with(SHAPE, RailShape.field_12671);
                    }
                    case field_12671: {
                        return (BlockState)blockState.with(SHAPE, RailShape.field_12664);
                    }
                    case field_12672: {
                        return (BlockState)blockState.with(SHAPE, RailShape.field_12663);
                    }
                    case field_12663: {
                        return (BlockState)blockState.with(SHAPE, RailShape.field_12672);
                    }
                }
                break;
            }
        }
        return super.mirror(blockState, blockMirror);
    }

    @Override
    protected void appendProperties(StateManager.Builder<Block, BlockState> builder) {
        builder.add(SHAPE, POWERED, WATERLOGGED);
    }
}


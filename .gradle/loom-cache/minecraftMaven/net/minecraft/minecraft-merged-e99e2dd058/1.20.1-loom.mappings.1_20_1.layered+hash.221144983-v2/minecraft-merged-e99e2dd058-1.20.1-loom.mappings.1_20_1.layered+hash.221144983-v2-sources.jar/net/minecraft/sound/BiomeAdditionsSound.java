/*
 * Decompiled with CFR 0.2.1 (FabricMC 53fa44c9).
 */
package net.minecraft.sound;

import com.mojang.datafixers.kinds.Applicative;
import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.sound.SoundEvent;

public class BiomeAdditionsSound {
    public static final Codec<BiomeAdditionsSound> CODEC = RecordCodecBuilder.create(instance -> instance.group(((MapCodec)SoundEvent.ENTRY_CODEC.fieldOf("sound")).forGetter(biomeAdditionsSound -> biomeAdditionsSound.sound), ((MapCodec)Codec.DOUBLE.fieldOf("tick_chance")).forGetter(biomeAdditionsSound -> biomeAdditionsSound.chance)).apply((Applicative<BiomeAdditionsSound, ?>)instance, BiomeAdditionsSound::new));
    private final RegistryEntry<SoundEvent> sound;
    private final double chance;

    public BiomeAdditionsSound(RegistryEntry<SoundEvent> registryEntry, double d) {
        this.sound = registryEntry;
        this.chance = d;
    }

    public RegistryEntry<SoundEvent> getSound() {
        return this.sound;
    }

    public double getChance() {
        return this.chance;
    }
}


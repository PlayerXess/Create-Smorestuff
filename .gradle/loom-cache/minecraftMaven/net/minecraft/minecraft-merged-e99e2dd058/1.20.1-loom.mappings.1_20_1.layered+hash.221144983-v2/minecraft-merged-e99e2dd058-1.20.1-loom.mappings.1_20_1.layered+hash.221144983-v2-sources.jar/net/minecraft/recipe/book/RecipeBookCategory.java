/*
 * Decompiled with CFR 0.2.1 (FabricMC 53fa44c9).
 */
package net.minecraft.recipe.book;

public enum RecipeBookCategory {
    field_25763,
    field_25764,
    field_25765,
    field_25766;

}


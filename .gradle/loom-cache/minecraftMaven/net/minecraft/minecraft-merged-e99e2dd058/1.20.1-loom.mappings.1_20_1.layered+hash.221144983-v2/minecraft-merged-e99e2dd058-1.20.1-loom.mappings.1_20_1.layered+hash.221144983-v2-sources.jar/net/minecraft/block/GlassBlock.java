/*
 * Decompiled with CFR 0.2.1 (FabricMC 53fa44c9).
 */
package net.minecraft.block;

import net.minecraft.block.AbstractBlock;
import net.minecraft.block.AbstractGlassBlock;

public class GlassBlock
extends AbstractGlassBlock {
    public GlassBlock(AbstractBlock.Settings settings) {
        super(settings);
    }
}


/*
 * Decompiled with CFR 0.2.1 (FabricMC 53fa44c9).
 */
package net.minecraft.item.trim;

import java.util.Optional;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.item.trim.ArmorTrimPattern;
import net.minecraft.registry.DynamicRegistryManager;
import net.minecraft.registry.Registerable;
import net.minecraft.registry.Registries;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import net.minecraft.util.Util;

public class ArmorTrimPatterns {
    public static final RegistryKey<ArmorTrimPattern> field_42016 = ArmorTrimPatterns.of("sentry");
    public static final RegistryKey<ArmorTrimPattern> field_42017 = ArmorTrimPatterns.of("dune");
    public static final RegistryKey<ArmorTrimPattern> field_42018 = ArmorTrimPatterns.of("coast");
    public static final RegistryKey<ArmorTrimPattern> field_42019 = ArmorTrimPatterns.of("wild");
    public static final RegistryKey<ArmorTrimPattern> field_42020 = ArmorTrimPatterns.of("ward");
    public static final RegistryKey<ArmorTrimPattern> field_42021 = ArmorTrimPatterns.of("eye");
    public static final RegistryKey<ArmorTrimPattern> field_42022 = ArmorTrimPatterns.of("vex");
    public static final RegistryKey<ArmorTrimPattern> field_42023 = ArmorTrimPatterns.of("tide");
    public static final RegistryKey<ArmorTrimPattern> field_42024 = ArmorTrimPatterns.of("snout");
    public static final RegistryKey<ArmorTrimPattern> field_42025 = ArmorTrimPatterns.of("rib");
    public static final RegistryKey<ArmorTrimPattern> field_42026 = ArmorTrimPatterns.of("spire");
    public static final RegistryKey<ArmorTrimPattern> field_43221 = ArmorTrimPatterns.of("wayfinder");
    public static final RegistryKey<ArmorTrimPattern> field_43222 = ArmorTrimPatterns.of("shaper");
    public static final RegistryKey<ArmorTrimPattern> field_43223 = ArmorTrimPatterns.of("silence");
    public static final RegistryKey<ArmorTrimPattern> field_43224 = ArmorTrimPatterns.of("raiser");
    public static final RegistryKey<ArmorTrimPattern> field_43225 = ArmorTrimPatterns.of("host");

    public static void bootstrap(Registerable<ArmorTrimPattern> registerable) {
        ArmorTrimPatterns.register(registerable, Items.field_41947, field_42016);
        ArmorTrimPatterns.register(registerable, Items.field_41948, field_42017);
        ArmorTrimPatterns.register(registerable, Items.field_41949, field_42018);
        ArmorTrimPatterns.register(registerable, Items.field_41950, field_42019);
        ArmorTrimPatterns.register(registerable, Items.field_41951, field_42020);
        ArmorTrimPatterns.register(registerable, Items.field_41952, field_42021);
        ArmorTrimPatterns.register(registerable, Items.field_41953, field_42022);
        ArmorTrimPatterns.register(registerable, Items.field_41954, field_42023);
        ArmorTrimPatterns.register(registerable, Items.field_41955, field_42024);
        ArmorTrimPatterns.register(registerable, Items.field_41956, field_42025);
        ArmorTrimPatterns.register(registerable, Items.field_41957, field_42026);
        ArmorTrimPatterns.register(registerable, Items.field_43196, field_43221);
        ArmorTrimPatterns.register(registerable, Items.field_43197, field_43222);
        ArmorTrimPatterns.register(registerable, Items.field_43198, field_43223);
        ArmorTrimPatterns.register(registerable, Items.field_43199, field_43224);
        ArmorTrimPatterns.register(registerable, Items.field_43200, field_43225);
    }

    public static Optional<RegistryEntry.Reference<ArmorTrimPattern>> get(DynamicRegistryManager dynamicRegistryManager, ItemStack itemStack) {
        return dynamicRegistryManager.get(RegistryKeys.field_42082).streamEntries().filter(reference -> itemStack.itemMatches(((ArmorTrimPattern)reference.comp_349()).comp_1214())).findFirst();
    }

    private static void register(Registerable<ArmorTrimPattern> registerable, Item item, RegistryKey<ArmorTrimPattern> registryKey) {
        ArmorTrimPattern armorTrimPattern = new ArmorTrimPattern(registryKey.getValue(), Registries.ITEM.getEntry(item), Text.translatable(Util.createTranslationKey("trim_pattern", registryKey.getValue())));
        registerable.register(registryKey, armorTrimPattern);
    }

    private static RegistryKey<ArmorTrimPattern> of(String string) {
        return RegistryKey.of(RegistryKeys.field_42082, new Identifier(string));
    }
}


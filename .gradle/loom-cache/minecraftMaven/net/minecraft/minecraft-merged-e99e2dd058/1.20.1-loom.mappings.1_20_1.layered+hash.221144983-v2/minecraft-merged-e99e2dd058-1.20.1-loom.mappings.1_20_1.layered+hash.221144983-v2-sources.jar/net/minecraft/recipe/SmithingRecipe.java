/*
 * Decompiled with CFR 0.2.1 (FabricMC 53fa44c9).
 */
package net.minecraft.recipe;

import net.minecraft.block.Blocks;
import net.minecraft.inventory.Inventory;
import net.minecraft.item.ItemStack;
import net.minecraft.recipe.Recipe;
import net.minecraft.recipe.RecipeType;

public interface SmithingRecipe
extends Recipe<Inventory> {
    @Override
    default public RecipeType<?> getType() {
        return RecipeType.field_25388;
    }

    @Override
    default public boolean fits(int i, int j) {
        return i >= 3 && j >= 1;
    }

    @Override
    default public ItemStack createIcon() {
        return new ItemStack(Blocks.field_16329);
    }

    public boolean testTemplate(ItemStack var1);

    public boolean testBase(ItemStack var1);

    public boolean testAddition(ItemStack var1);
}


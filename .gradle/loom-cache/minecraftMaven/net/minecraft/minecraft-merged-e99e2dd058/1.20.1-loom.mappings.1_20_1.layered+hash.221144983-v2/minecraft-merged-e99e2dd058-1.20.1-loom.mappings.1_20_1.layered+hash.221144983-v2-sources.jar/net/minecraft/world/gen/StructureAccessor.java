/*
 * Decompiled with CFR 0.2.1 (FabricMC 53fa44c9).
 */
package net.minecraft.world.gen;

import com.google.common.collect.ImmutableList;
import it.unimi.dsi.fastutil.longs.LongIterator;
import it.unimi.dsi.fastutil.longs.LongSet;
import java.util.List;
import java.util.Map;
import java.util.function.Consumer;
import java.util.function.Predicate;
import net.minecraft.registry.DynamicRegistryManager;
import net.minecraft.registry.Registry;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.registry.tag.TagKey;
import net.minecraft.structure.StructurePiece;
import net.minecraft.structure.StructureStart;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.util.math.ChunkSectionPos;
import net.minecraft.world.ChunkRegion;
import net.minecraft.world.StructureHolder;
import net.minecraft.world.StructureLocator;
import net.minecraft.world.StructurePresence;
import net.minecraft.world.WorldAccess;
import net.minecraft.world.chunk.ChunkStatus;
import net.minecraft.world.gen.GeneratorOptions;
import net.minecraft.world.gen.structure.Structure;
import org.jetbrains.annotations.Nullable;

public class StructureAccessor {
    private final WorldAccess world;
    private final GeneratorOptions options;
    private final StructureLocator locator;

    public StructureAccessor(WorldAccess worldAccess, GeneratorOptions generatorOptions, StructureLocator structureLocator) {
        this.world = worldAccess;
        this.options = generatorOptions;
        this.locator = structureLocator;
    }

    public StructureAccessor forRegion(ChunkRegion chunkRegion) {
        if (chunkRegion.toServerWorld() != this.world) {
            throw new IllegalStateException("Using invalid structure manager (source level: " + chunkRegion.toServerWorld() + ", region: " + chunkRegion);
        }
        return new StructureAccessor(chunkRegion, this.options, this.locator);
    }

    public List<StructureStart> getStructureStarts(ChunkPos chunkPos, Predicate<Structure> predicate) {
        Map<Structure, LongSet> map = this.world.getChunk(chunkPos.x, chunkPos.z, ChunkStatus.field_16422).getStructureReferences();
        ImmutableList.Builder builder = ImmutableList.builder();
        for (Map.Entry<Structure, LongSet> entry : map.entrySet()) {
            Structure structure = entry.getKey();
            if (!predicate.test(structure)) continue;
            this.acceptStructureStarts(structure, entry.getValue(), builder::add);
        }
        return builder.build();
    }

    public List<StructureStart> getStructureStarts(ChunkSectionPos chunkSectionPos, Structure structure) {
        LongSet longSet = this.world.getChunk(chunkSectionPos.getSectionX(), chunkSectionPos.getSectionZ(), ChunkStatus.field_16422).getStructureReferences(structure);
        ImmutableList.Builder builder = ImmutableList.builder();
        this.acceptStructureStarts(structure, longSet, builder::add);
        return builder.build();
    }

    public void acceptStructureStarts(Structure structure, LongSet longSet, Consumer<StructureStart> consumer) {
        LongIterator longIterator = longSet.iterator();
        while (longIterator.hasNext()) {
            long l = (Long)longIterator.next();
            ChunkSectionPos chunkSectionPos = ChunkSectionPos.from(new ChunkPos(l), this.world.getBottomSectionCoord());
            StructureStart structureStart = this.getStructureStart(chunkSectionPos, structure, this.world.getChunk(chunkSectionPos.getSectionX(), chunkSectionPos.getSectionZ(), ChunkStatus.field_16423));
            if (structureStart == null || !structureStart.hasChildren()) continue;
            consumer.accept(structureStart);
        }
    }

    @Nullable
    public StructureStart getStructureStart(ChunkSectionPos chunkSectionPos, Structure structure, StructureHolder structureHolder) {
        return structureHolder.getStructureStart(structure);
    }

    public void setStructureStart(ChunkSectionPos chunkSectionPos, Structure structure, StructureStart structureStart, StructureHolder structureHolder) {
        structureHolder.setStructureStart(structure, structureStart);
    }

    public void addStructureReference(ChunkSectionPos chunkSectionPos, Structure structure, long l, StructureHolder structureHolder) {
        structureHolder.addStructureReference(structure, l);
    }

    public boolean shouldGenerateStructures() {
        return this.options.shouldGenerateStructures();
    }

    public StructureStart getStructureAt(BlockPos blockPos, Structure structure) {
        for (StructureStart structureStart : this.getStructureStarts(ChunkSectionPos.from(blockPos), structure)) {
            if (!structureStart.getBoundingBox().contains(blockPos)) continue;
            return structureStart;
        }
        return StructureStart.DEFAULT;
    }

    public StructureStart getStructureContaining(BlockPos blockPos, RegistryKey<Structure> registryKey) {
        Structure structure = this.getRegistryManager().get(RegistryKeys.STRUCTURE).get(registryKey);
        if (structure == null) {
            return StructureStart.DEFAULT;
        }
        return this.getStructureContaining(blockPos, structure);
    }

    public StructureStart getStructureContaining(BlockPos blockPos, TagKey<Structure> tagKey) {
        Registry<Structure> registry = this.getRegistryManager().get(RegistryKeys.STRUCTURE);
        for (StructureStart structureStart : this.getStructureStarts(new ChunkPos(blockPos), (Structure structure) -> registry.getEntry(registry.getRawId((Structure)structure)).map(reference -> reference.isIn(tagKey)).orElse(false))) {
            if (!this.structureContains(blockPos, structureStart)) continue;
            return structureStart;
        }
        return StructureStart.DEFAULT;
    }

    public StructureStart getStructureContaining(BlockPos blockPos, Structure structure) {
        for (StructureStart structureStart : this.getStructureStarts(ChunkSectionPos.from(blockPos), structure)) {
            if (!this.structureContains(blockPos, structureStart)) continue;
            return structureStart;
        }
        return StructureStart.DEFAULT;
    }

    public boolean structureContains(BlockPos blockPos, StructureStart structureStart) {
        for (StructurePiece structurePiece : structureStart.getChildren()) {
            if (!structurePiece.getBoundingBox().contains(blockPos)) continue;
            return true;
        }
        return false;
    }

    public boolean hasStructureReferences(BlockPos blockPos) {
        ChunkSectionPos chunkSectionPos = ChunkSectionPos.from(blockPos);
        return this.world.getChunk(chunkSectionPos.getSectionX(), chunkSectionPos.getSectionZ(), ChunkStatus.field_16422).hasStructureReferences();
    }

    public Map<Structure, LongSet> getStructureReferences(BlockPos blockPos) {
        ChunkSectionPos chunkSectionPos = ChunkSectionPos.from(blockPos);
        return this.world.getChunk(chunkSectionPos.getSectionX(), chunkSectionPos.getSectionZ(), ChunkStatus.field_16422).getStructureReferences();
    }

    public StructurePresence getStructurePresence(ChunkPos chunkPos, Structure structure, boolean bl) {
        return this.locator.getStructurePresence(chunkPos, structure, bl);
    }

    public void incrementReferences(StructureStart structureStart) {
        structureStart.incrementReferences();
        this.locator.incrementReferences(structureStart.getPos(), structureStart.getStructure());
    }

    public DynamicRegistryManager getRegistryManager() {
        return this.world.getRegistryManager();
    }
}


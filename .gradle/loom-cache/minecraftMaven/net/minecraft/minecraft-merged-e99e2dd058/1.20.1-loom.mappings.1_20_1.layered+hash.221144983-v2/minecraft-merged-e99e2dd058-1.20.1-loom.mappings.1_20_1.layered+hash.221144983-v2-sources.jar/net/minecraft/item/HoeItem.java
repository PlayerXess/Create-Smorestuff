/*
 * Decompiled with CFR 0.2.1 (FabricMC 53fa44c9).
 */
package net.minecraft.item;

import com.google.common.collect.ImmutableMap;
import com.google.common.collect.Maps;
import com.mojang.datafixers.util.Pair;
import java.util.Map;
import java.util.function.Consumer;
import java.util.function.Predicate;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemConvertible;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemUsageContext;
import net.minecraft.item.Items;
import net.minecraft.item.MiningToolItem;
import net.minecraft.item.ToolMaterial;
import net.minecraft.registry.tag.BlockTags;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.ActionResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.world.World;
import net.minecraft.world.event.GameEvent;

public class HoeItem
extends MiningToolItem {
    protected static final Map<Block, Pair<Predicate<ItemUsageContext>, Consumer<ItemUsageContext>>> TILLING_ACTIONS = Maps.newHashMap(ImmutableMap.of(Blocks.field_10219, Pair.of(HoeItem::canTillFarmland, HoeItem.createTillAction(Blocks.field_10362.getDefaultState())), Blocks.field_10194, Pair.of(HoeItem::canTillFarmland, HoeItem.createTillAction(Blocks.field_10362.getDefaultState())), Blocks.field_10566, Pair.of(HoeItem::canTillFarmland, HoeItem.createTillAction(Blocks.field_10362.getDefaultState())), Blocks.field_10253, Pair.of(HoeItem::canTillFarmland, HoeItem.createTillAction(Blocks.field_10566.getDefaultState())), Blocks.field_28685, Pair.of(itemUsageContext -> true, HoeItem.createTillAndDropAction(Blocks.field_10566.getDefaultState(), Items.HANGING_ROOTS))));

    public HoeItem(ToolMaterial toolMaterial, int i, float f, Item.Settings settings) {
        super(i, f, toolMaterial, BlockTags.field_33714, settings);
    }

    @Override
    public ActionResult useOnBlock(ItemUsageContext itemUsageContext) {
        BlockPos blockPos;
        World world = itemUsageContext.getWorld();
        Pair<Predicate<ItemUsageContext>, Consumer<ItemUsageContext>> pair = TILLING_ACTIONS.get(world.getBlockState(blockPos = itemUsageContext.getBlockPos()).getBlock());
        if (pair == null) {
            return ActionResult.PASS;
        }
        Predicate<ItemUsageContext> predicate = pair.getFirst();
        Consumer<ItemUsageContext> consumer = pair.getSecond();
        if (predicate.test(itemUsageContext)) {
            PlayerEntity playerEntity2 = itemUsageContext.getPlayer();
            world.playSound(playerEntity2, blockPos, SoundEvents.field_14846, SoundCategory.field_15245, 1.0f, 1.0f);
            if (!world.isClient) {
                consumer.accept(itemUsageContext);
                if (playerEntity2 != null) {
                    itemUsageContext.getStack().damage(1, playerEntity2, playerEntity -> playerEntity.sendToolBreakStatus(itemUsageContext.getHand()));
                }
            }
            return ActionResult.success(world.isClient);
        }
        return ActionResult.PASS;
    }

    public static Consumer<ItemUsageContext> createTillAction(BlockState blockState) {
        return itemUsageContext -> {
            itemUsageContext.getWorld().setBlockState(itemUsageContext.getBlockPos(), blockState, 11);
            itemUsageContext.getWorld().emitGameEvent(GameEvent.field_28733, itemUsageContext.getBlockPos(), GameEvent.Emitter.of(itemUsageContext.getPlayer(), blockState));
        };
    }

    public static Consumer<ItemUsageContext> createTillAndDropAction(BlockState blockState, ItemConvertible itemConvertible) {
        return itemUsageContext -> {
            itemUsageContext.getWorld().setBlockState(itemUsageContext.getBlockPos(), blockState, 11);
            itemUsageContext.getWorld().emitGameEvent(GameEvent.field_28733, itemUsageContext.getBlockPos(), GameEvent.Emitter.of(itemUsageContext.getPlayer(), blockState));
            Block.dropStack(itemUsageContext.getWorld(), itemUsageContext.getBlockPos(), itemUsageContext.getSide(), new ItemStack(itemConvertible));
        };
    }

    public static boolean canTillFarmland(ItemUsageContext itemUsageContext) {
        return itemUsageContext.getSide() != Direction.field_11033 && itemUsageContext.getWorld().getBlockState(itemUsageContext.getBlockPos().up()).isAir();
    }
}


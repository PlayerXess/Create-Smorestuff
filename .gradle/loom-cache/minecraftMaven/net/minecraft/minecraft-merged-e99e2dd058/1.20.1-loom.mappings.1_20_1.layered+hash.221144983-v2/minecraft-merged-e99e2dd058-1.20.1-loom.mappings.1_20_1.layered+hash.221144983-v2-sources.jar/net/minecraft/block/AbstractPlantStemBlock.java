/*
 * Decompiled with CFR 0.2.1 (FabricMC 53fa44c9).
 */
package net.minecraft.block;

import net.minecraft.block.AbstractBlock;
import net.minecraft.block.AbstractPlantPartBlock;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Fertilizable;
import net.minecraft.fluid.Fluids;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.state.StateManager;
import net.minecraft.state.property.IntProperty;
import net.minecraft.state.property.Properties;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.random.Random;
import net.minecraft.util.shape.VoxelShape;
import net.minecraft.world.World;
import net.minecraft.world.WorldAccess;
import net.minecraft.world.WorldView;

public abstract class AbstractPlantStemBlock
extends AbstractPlantPartBlock
implements Fertilizable {
    public static final IntProperty AGE = Properties.AGE_25;
    public static final int MAX_AGE = 25;
    private final double growthChance;

    protected AbstractPlantStemBlock(AbstractBlock.Settings settings, Direction direction, VoxelShape voxelShape, boolean bl, double d) {
        super(settings, direction, voxelShape, bl);
        this.growthChance = d;
        this.setDefaultState((BlockState)((BlockState)this.stateManager.getDefaultState()).with(AGE, 0));
    }

    @Override
    public BlockState getRandomGrowthState(WorldAccess worldAccess) {
        return (BlockState)this.getDefaultState().with(AGE, worldAccess.getRandom().nextInt(25));
    }

    @Override
    public boolean hasRandomTicks(BlockState blockState) {
        return blockState.get(AGE) < 25;
    }

    @Override
    public void randomTick(BlockState blockState, ServerWorld serverWorld, BlockPos blockPos, Random random) {
        BlockPos blockPos2;
        if (blockState.get(AGE) < 25 && random.nextDouble() < this.growthChance && this.chooseStemState(serverWorld.getBlockState(blockPos2 = blockPos.offset(this.growthDirection)))) {
            serverWorld.setBlockState(blockPos2, this.age(blockState, serverWorld.random));
        }
    }

    protected BlockState age(BlockState blockState, Random random) {
        return (BlockState)blockState.cycle(AGE);
    }

    public BlockState withMaxAge(BlockState blockState) {
        return (BlockState)blockState.with(AGE, 25);
    }

    public boolean hasMaxAge(BlockState blockState) {
        return blockState.get(AGE) == 25;
    }

    protected BlockState copyState(BlockState blockState, BlockState blockState2) {
        return blockState2;
    }

    @Override
    public BlockState getStateForNeighborUpdate(BlockState blockState, Direction direction, BlockState blockState2, WorldAccess worldAccess, BlockPos blockPos, BlockPos blockPos2) {
        if (direction == this.growthDirection.getOpposite() && !blockState.canPlaceAt(worldAccess, blockPos)) {
            worldAccess.scheduleBlockTick(blockPos, this, 1);
        }
        if (direction == this.growthDirection && (blockState2.isOf(this) || blockState2.isOf(this.getPlant()))) {
            return this.copyState(blockState, this.getPlant().getDefaultState());
        }
        if (this.tickWater) {
            worldAccess.scheduleFluidTick(blockPos, Fluids.WATER, Fluids.WATER.getTickRate(worldAccess));
        }
        return super.getStateForNeighborUpdate(blockState, direction, blockState2, worldAccess, blockPos, blockPos2);
    }

    @Override
    protected void appendProperties(StateManager.Builder<Block, BlockState> builder) {
        builder.add(AGE);
    }

    @Override
    public boolean isFertilizable(WorldView worldView, BlockPos blockPos, BlockState blockState, boolean bl) {
        return this.chooseStemState(worldView.getBlockState(blockPos.offset(this.growthDirection)));
    }

    @Override
    public boolean canGrow(World world, Random random, BlockPos blockPos, BlockState blockState) {
        return true;
    }

    @Override
    public void grow(ServerWorld serverWorld, Random random, BlockPos blockPos, BlockState blockState) {
        BlockPos blockPos2 = blockPos.offset(this.growthDirection);
        int i = Math.min(blockState.get(AGE) + 1, 25);
        int j = this.getGrowthLength(random);
        for (int k = 0; k < j && this.chooseStemState(serverWorld.getBlockState(blockPos2)); ++k) {
            serverWorld.setBlockState(blockPos2, (BlockState)blockState.with(AGE, i));
            blockPos2 = blockPos2.offset(this.growthDirection);
            i = Math.min(i + 1, 25);
        }
    }

    protected abstract int getGrowthLength(Random var1);

    protected abstract boolean chooseStemState(BlockState var1);

    @Override
    protected AbstractPlantStemBlock getStem() {
        return this;
    }
}


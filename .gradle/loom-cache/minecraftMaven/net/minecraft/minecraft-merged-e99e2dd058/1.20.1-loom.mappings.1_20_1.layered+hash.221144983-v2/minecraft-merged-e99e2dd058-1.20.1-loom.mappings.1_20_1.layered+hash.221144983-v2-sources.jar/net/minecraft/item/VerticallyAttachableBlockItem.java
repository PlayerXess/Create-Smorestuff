/*
 * Decompiled with CFR 0.2.1 (FabricMC 53fa44c9).
 */
package net.minecraft.item;

import java.util.Map;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.ShapeContext;
import net.minecraft.item.BlockItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemPlacementContext;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.world.World;
import net.minecraft.world.WorldView;
import org.jetbrains.annotations.Nullable;

public class VerticallyAttachableBlockItem
extends BlockItem {
    protected final Block wallBlock;
    private final Direction verticalAttachmentDirection;

    public VerticallyAttachableBlockItem(Block block, Block block2, Item.Settings settings, Direction direction) {
        super(block, settings);
        this.wallBlock = block2;
        this.verticalAttachmentDirection = direction;
    }

    protected boolean canPlaceAt(WorldView worldView, BlockState blockState, BlockPos blockPos) {
        return blockState.canPlaceAt(worldView, blockPos);
    }

    @Override
    @Nullable
    protected BlockState getPlacementState(ItemPlacementContext itemPlacementContext) {
        BlockState blockState = this.wallBlock.getPlacementState(itemPlacementContext);
        BlockState blockState2 = null;
        World worldView = itemPlacementContext.getWorld();
        BlockPos blockPos = itemPlacementContext.getBlockPos();
        for (Direction direction : itemPlacementContext.getPlacementDirections()) {
            BlockState blockState3;
            if (direction == this.verticalAttachmentDirection.getOpposite()) continue;
            BlockState blockState4 = blockState3 = direction == this.verticalAttachmentDirection ? this.getBlock().getPlacementState(itemPlacementContext) : blockState;
            if (blockState3 == null || !this.canPlaceAt(worldView, blockState3, blockPos)) continue;
            blockState2 = blockState3;
            break;
        }
        return blockState2 != null && worldView.canPlace(blockState2, blockPos, ShapeContext.absent()) ? blockState2 : null;
    }

    @Override
    public void appendBlocks(Map<Block, Item> map, Item item) {
        super.appendBlocks(map, item);
        map.put(this.wallBlock, item);
    }
}


/*
 * Decompiled with CFR 0.2.1 (FabricMC 53fa44c9).
 */
package net.minecraft.inventory;

import java.util.List;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.inventory.Inventories;
import net.minecraft.inventory.RecipeInputInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.recipe.RecipeMatcher;
import net.minecraft.screen.ScreenHandler;
import net.minecraft.util.collection.DefaultedList;

public class CraftingInventory
implements RecipeInputInventory {
    private final DefaultedList<ItemStack> stacks;
    private final int width;
    private final int height;
    private final ScreenHandler handler;

    public CraftingInventory(ScreenHandler screenHandler, int i, int j) {
        this(screenHandler, i, j, DefaultedList.ofSize(i * j, ItemStack.EMPTY));
    }

    public CraftingInventory(ScreenHandler screenHandler, int i, int j, DefaultedList<ItemStack> defaultedList) {
        this.stacks = defaultedList;
        this.handler = screenHandler;
        this.width = i;
        this.height = j;
    }

    @Override
    public int size() {
        return this.stacks.size();
    }

    @Override
    public boolean isEmpty() {
        for (ItemStack itemStack : this.stacks) {
            if (itemStack.isEmpty()) continue;
            return false;
        }
        return true;
    }

    @Override
    public ItemStack getStack(int i) {
        if (i >= this.size()) {
            return ItemStack.EMPTY;
        }
        return this.stacks.get(i);
    }

    @Override
    public ItemStack removeStack(int i) {
        return Inventories.removeStack(this.stacks, i);
    }

    @Override
    public ItemStack removeStack(int i, int j) {
        ItemStack itemStack = Inventories.splitStack(this.stacks, i, j);
        if (!itemStack.isEmpty()) {
            this.handler.onContentChanged(this);
        }
        return itemStack;
    }

    @Override
    public void setStack(int i, ItemStack itemStack) {
        this.stacks.set(i, itemStack);
        this.handler.onContentChanged(this);
    }

    @Override
    public void markDirty() {
    }

    @Override
    public boolean canPlayerUse(PlayerEntity playerEntity) {
        return true;
    }

    @Override
    public void clear() {
        this.stacks.clear();
    }

    @Override
    public int getHeight() {
        return this.height;
    }

    @Override
    public int getWidth() {
        return this.width;
    }

    @Override
    public List<ItemStack> getInputStacks() {
        return List.copyOf(this.stacks);
    }

    @Override
    public void provideRecipeInputs(RecipeMatcher recipeMatcher) {
        for (ItemStack itemStack : this.stacks) {
            recipeMatcher.addUnenchantedInput(itemStack);
        }
    }
}


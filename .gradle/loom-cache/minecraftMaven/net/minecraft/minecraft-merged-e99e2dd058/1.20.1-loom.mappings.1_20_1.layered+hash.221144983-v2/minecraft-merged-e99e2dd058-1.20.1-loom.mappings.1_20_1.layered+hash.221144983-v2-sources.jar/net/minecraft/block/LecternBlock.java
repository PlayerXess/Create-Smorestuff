/*
 * Decompiled with CFR 0.2.1 (FabricMC 53fa44c9).
 */
package net.minecraft.block;

import net.minecraft.block.AbstractBlock;
import net.minecraft.block.Block;
import net.minecraft.block.BlockRenderType;
import net.minecraft.block.BlockState;
import net.minecraft.block.BlockWithEntity;
import net.minecraft.block.HorizontalFacingBlock;
import net.minecraft.block.ShapeContext;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.block.entity.LecternBlockEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.ItemEntity;
import net.minecraft.entity.ai.pathing.NavigationType;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.BlockItem;
import net.minecraft.item.ItemPlacementContext;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.registry.tag.ItemTags;
import net.minecraft.screen.NamedScreenHandlerFactory;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.stat.Stats;
import net.minecraft.state.StateManager;
import net.minecraft.state.property.BooleanProperty;
import net.minecraft.state.property.DirectionProperty;
import net.minecraft.state.property.Properties;
import net.minecraft.util.ActionResult;
import net.minecraft.util.BlockMirror;
import net.minecraft.util.BlockRotation;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.random.Random;
import net.minecraft.util.shape.VoxelShape;
import net.minecraft.util.shape.VoxelShapes;
import net.minecraft.world.BlockView;
import net.minecraft.world.World;
import net.minecraft.world.event.GameEvent;
import org.jetbrains.annotations.Nullable;

public class LecternBlock
extends BlockWithEntity {
    public static final DirectionProperty FACING = HorizontalFacingBlock.FACING;
    public static final BooleanProperty POWERED = Properties.POWERED;
    public static final BooleanProperty HAS_BOOK = Properties.HAS_BOOK;
    public static final VoxelShape BOTTOM_SHAPE = Block.createCuboidShape(0.0, 0.0, 0.0, 16.0, 2.0, 16.0);
    public static final VoxelShape MIDDLE_SHAPE = Block.createCuboidShape(4.0, 2.0, 4.0, 12.0, 14.0, 12.0);
    public static final VoxelShape BASE_SHAPE = VoxelShapes.union(BOTTOM_SHAPE, MIDDLE_SHAPE);
    public static final VoxelShape COLLISION_SHAPE_TOP = Block.createCuboidShape(0.0, 15.0, 0.0, 16.0, 15.0, 16.0);
    public static final VoxelShape COLLISION_SHAPE = VoxelShapes.union(BASE_SHAPE, COLLISION_SHAPE_TOP);
    public static final VoxelShape WEST_SHAPE = VoxelShapes.union(Block.createCuboidShape(1.0, 10.0, 0.0, 5.333333, 14.0, 16.0), Block.createCuboidShape(5.333333, 12.0, 0.0, 9.666667, 16.0, 16.0), Block.createCuboidShape(9.666667, 14.0, 0.0, 14.0, 18.0, 16.0), BASE_SHAPE);
    public static final VoxelShape NORTH_SHAPE = VoxelShapes.union(Block.createCuboidShape(0.0, 10.0, 1.0, 16.0, 14.0, 5.333333), Block.createCuboidShape(0.0, 12.0, 5.333333, 16.0, 16.0, 9.666667), Block.createCuboidShape(0.0, 14.0, 9.666667, 16.0, 18.0, 14.0), BASE_SHAPE);
    public static final VoxelShape EAST_SHAPE = VoxelShapes.union(Block.createCuboidShape(10.666667, 10.0, 0.0, 15.0, 14.0, 16.0), Block.createCuboidShape(6.333333, 12.0, 0.0, 10.666667, 16.0, 16.0), Block.createCuboidShape(2.0, 14.0, 0.0, 6.333333, 18.0, 16.0), BASE_SHAPE);
    public static final VoxelShape SOUTH_SHAPE = VoxelShapes.union(Block.createCuboidShape(0.0, 10.0, 10.666667, 16.0, 14.0, 15.0), Block.createCuboidShape(0.0, 12.0, 6.333333, 16.0, 16.0, 10.666667), Block.createCuboidShape(0.0, 14.0, 2.0, 16.0, 18.0, 6.333333), BASE_SHAPE);
    private static final int SCHEDULED_TICK_DELAY = 2;

    public LecternBlock(AbstractBlock.Settings settings) {
        super(settings);
        this.setDefaultState((BlockState)((BlockState)((BlockState)((BlockState)this.stateManager.getDefaultState()).with(FACING, Direction.field_11043)).with(POWERED, false)).with(HAS_BOOK, false));
    }

    @Override
    public BlockRenderType getRenderType(BlockState blockState) {
        return BlockRenderType.field_11458;
    }

    @Override
    public VoxelShape getCullingShape(BlockState blockState, BlockView blockView, BlockPos blockPos) {
        return BASE_SHAPE;
    }

    @Override
    public boolean hasSidedTransparency(BlockState blockState) {
        return true;
    }

    @Override
    public BlockState getPlacementState(ItemPlacementContext itemPlacementContext) {
        NbtCompound nbtCompound;
        World world = itemPlacementContext.getWorld();
        ItemStack itemStack = itemPlacementContext.getStack();
        PlayerEntity playerEntity = itemPlacementContext.getPlayer();
        boolean bl = false;
        if (!world.isClient && playerEntity != null && playerEntity.isCreativeLevelTwoOp() && (nbtCompound = BlockItem.getBlockEntityNbt(itemStack)) != null && nbtCompound.contains("Book")) {
            bl = true;
        }
        return (BlockState)((BlockState)this.getDefaultState().with(FACING, itemPlacementContext.getHorizontalPlayerFacing().getOpposite())).with(HAS_BOOK, bl);
    }

    @Override
    public VoxelShape getCollisionShape(BlockState blockState, BlockView blockView, BlockPos blockPos, ShapeContext shapeContext) {
        return COLLISION_SHAPE;
    }

    @Override
    public VoxelShape getOutlineShape(BlockState blockState, BlockView blockView, BlockPos blockPos, ShapeContext shapeContext) {
        switch (blockState.get(FACING)) {
            case field_11043: {
                return NORTH_SHAPE;
            }
            case field_11035: {
                return SOUTH_SHAPE;
            }
            case field_11034: {
                return EAST_SHAPE;
            }
            case field_11039: {
                return WEST_SHAPE;
            }
        }
        return BASE_SHAPE;
    }

    @Override
    public BlockState rotate(BlockState blockState, BlockRotation blockRotation) {
        return (BlockState)blockState.with(FACING, blockRotation.rotate(blockState.get(FACING)));
    }

    @Override
    public BlockState mirror(BlockState blockState, BlockMirror blockMirror) {
        return blockState.rotate(blockMirror.getRotation(blockState.get(FACING)));
    }

    @Override
    protected void appendProperties(StateManager.Builder<Block, BlockState> builder) {
        builder.add(FACING, POWERED, HAS_BOOK);
    }

    @Override
    public BlockEntity createBlockEntity(BlockPos blockPos, BlockState blockState) {
        return new LecternBlockEntity(blockPos, blockState);
    }

    public static boolean putBookIfAbsent(@Nullable Entity entity, World world, BlockPos blockPos, BlockState blockState, ItemStack itemStack) {
        if (!blockState.get(HAS_BOOK).booleanValue()) {
            if (!world.isClient) {
                LecternBlock.putBook(entity, world, blockPos, blockState, itemStack);
            }
            return true;
        }
        return false;
    }

    private static void putBook(@Nullable Entity entity, World world, BlockPos blockPos, BlockState blockState, ItemStack itemStack) {
        BlockEntity blockEntity = world.getBlockEntity(blockPos);
        if (blockEntity instanceof LecternBlockEntity) {
            LecternBlockEntity lecternBlockEntity = (LecternBlockEntity)blockEntity;
            lecternBlockEntity.setBook(itemStack.split(1));
            LecternBlock.setHasBook(entity, world, blockPos, blockState, true);
            world.playSound(null, blockPos, SoundEvents.field_17482, SoundCategory.field_15245, 1.0f, 1.0f);
        }
    }

    public static void setHasBook(@Nullable Entity entity, World world, BlockPos blockPos, BlockState blockState, boolean bl) {
        BlockState blockState2 = (BlockState)((BlockState)blockState.with(POWERED, false)).with(HAS_BOOK, bl);
        world.setBlockState(blockPos, blockState2, 3);
        world.emitGameEvent(GameEvent.field_28733, blockPos, GameEvent.Emitter.of(entity, blockState2));
        LecternBlock.updateNeighborAlways(world, blockPos, blockState);
    }

    public static void setPowered(World world, BlockPos blockPos, BlockState blockState) {
        LecternBlock.setPowered(world, blockPos, blockState, true);
        world.scheduleBlockTick(blockPos, blockState.getBlock(), 2);
        world.syncWorldEvent(1043, blockPos, 0);
    }

    private static void setPowered(World world, BlockPos blockPos, BlockState blockState, boolean bl) {
        world.setBlockState(blockPos, (BlockState)blockState.with(POWERED, bl), 3);
        LecternBlock.updateNeighborAlways(world, blockPos, blockState);
    }

    private static void updateNeighborAlways(World world, BlockPos blockPos, BlockState blockState) {
        world.updateNeighborsAlways(blockPos.down(), blockState.getBlock());
    }

    @Override
    public void scheduledTick(BlockState blockState, ServerWorld serverWorld, BlockPos blockPos, Random random) {
        LecternBlock.setPowered(serverWorld, blockPos, blockState, false);
    }

    @Override
    public void onStateReplaced(BlockState blockState, World world, BlockPos blockPos, BlockState blockState2, boolean bl) {
        if (blockState.isOf(blockState2.getBlock())) {
            return;
        }
        if (blockState.get(HAS_BOOK).booleanValue()) {
            this.dropBook(blockState, world, blockPos);
        }
        if (blockState.get(POWERED).booleanValue()) {
            world.updateNeighborsAlways(blockPos.down(), this);
        }
        super.onStateReplaced(blockState, world, blockPos, blockState2, bl);
    }

    private void dropBook(BlockState blockState, World world, BlockPos blockPos) {
        BlockEntity blockEntity = world.getBlockEntity(blockPos);
        if (blockEntity instanceof LecternBlockEntity) {
            LecternBlockEntity lecternBlockEntity = (LecternBlockEntity)blockEntity;
            Direction direction = blockState.get(FACING);
            ItemStack itemStack = lecternBlockEntity.getBook().copy();
            float f = 0.25f * (float)direction.getOffsetX();
            float g = 0.25f * (float)direction.getOffsetZ();
            ItemEntity itemEntity = new ItemEntity(world, (double)blockPos.getX() + 0.5 + (double)f, blockPos.getY() + 1, (double)blockPos.getZ() + 0.5 + (double)g, itemStack);
            itemEntity.setToDefaultPickupDelay();
            world.spawnEntity(itemEntity);
            lecternBlockEntity.clear();
        }
    }

    @Override
    public boolean emitsRedstonePower(BlockState blockState) {
        return true;
    }

    @Override
    public int getWeakRedstonePower(BlockState blockState, BlockView blockView, BlockPos blockPos, Direction direction) {
        return blockState.get(POWERED) != false ? 15 : 0;
    }

    @Override
    public int getStrongRedstonePower(BlockState blockState, BlockView blockView, BlockPos blockPos, Direction direction) {
        return direction == Direction.field_11036 && blockState.get(POWERED) != false ? 15 : 0;
    }

    @Override
    public boolean hasComparatorOutput(BlockState blockState) {
        return true;
    }

    @Override
    public int getComparatorOutput(BlockState blockState, World world, BlockPos blockPos) {
        BlockEntity blockEntity;
        if (blockState.get(HAS_BOOK).booleanValue() && (blockEntity = world.getBlockEntity(blockPos)) instanceof LecternBlockEntity) {
            return ((LecternBlockEntity)blockEntity).getComparatorOutput();
        }
        return 0;
    }

    @Override
    public ActionResult onUse(BlockState blockState, World world, BlockPos blockPos, PlayerEntity playerEntity, Hand hand, BlockHitResult blockHitResult) {
        if (blockState.get(HAS_BOOK).booleanValue()) {
            if (!world.isClient) {
                this.openScreen(world, blockPos, playerEntity);
            }
            return ActionResult.success(world.isClient);
        }
        ItemStack itemStack = playerEntity.getStackInHand(hand);
        if (itemStack.isEmpty() || itemStack.isIn(ItemTags.field_21465)) {
            return ActionResult.PASS;
        }
        return ActionResult.CONSUME;
    }

    @Override
    @Nullable
    public NamedScreenHandlerFactory createScreenHandlerFactory(BlockState blockState, World world, BlockPos blockPos) {
        if (!blockState.get(HAS_BOOK).booleanValue()) {
            return null;
        }
        return super.createScreenHandlerFactory(blockState, world, blockPos);
    }

    private void openScreen(World world, BlockPos blockPos, PlayerEntity playerEntity) {
        BlockEntity blockEntity = world.getBlockEntity(blockPos);
        if (blockEntity instanceof LecternBlockEntity) {
            playerEntity.openHandledScreen((LecternBlockEntity)blockEntity);
            playerEntity.incrementStat(Stats.field_17485);
        }
    }

    @Override
    public boolean canPathfindThrough(BlockState blockState, BlockView blockView, BlockPos blockPos, NavigationType navigationType) {
        return false;
    }
}


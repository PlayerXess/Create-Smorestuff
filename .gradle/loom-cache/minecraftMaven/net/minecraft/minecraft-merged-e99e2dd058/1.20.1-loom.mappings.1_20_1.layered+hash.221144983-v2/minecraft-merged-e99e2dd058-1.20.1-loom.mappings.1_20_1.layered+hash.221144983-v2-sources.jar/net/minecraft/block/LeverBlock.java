/*
 * Decompiled with CFR 0.2.1 (FabricMC 53fa44c9).
 */
package net.minecraft.block;

import net.minecraft.block.AbstractBlock;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.ShapeContext;
import net.minecraft.block.WallMountedBlock;
import net.minecraft.block.enums.WallMountLocation;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.particle.DustParticleEffect;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.state.StateManager;
import net.minecraft.state.property.BooleanProperty;
import net.minecraft.state.property.Properties;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.random.Random;
import net.minecraft.util.shape.VoxelShape;
import net.minecraft.world.BlockView;
import net.minecraft.world.World;
import net.minecraft.world.WorldAccess;
import net.minecraft.world.event.GameEvent;

public class LeverBlock
extends WallMountedBlock {
    public static final BooleanProperty POWERED = Properties.POWERED;
    protected static final int field_31184 = 6;
    protected static final int field_31185 = 6;
    protected static final int field_31186 = 8;
    protected static final VoxelShape NORTH_WALL_SHAPE = Block.createCuboidShape(5.0, 4.0, 10.0, 11.0, 12.0, 16.0);
    protected static final VoxelShape SOUTH_WALL_SHAPE = Block.createCuboidShape(5.0, 4.0, 0.0, 11.0, 12.0, 6.0);
    protected static final VoxelShape WEST_WALL_SHAPE = Block.createCuboidShape(10.0, 4.0, 5.0, 16.0, 12.0, 11.0);
    protected static final VoxelShape EAST_WALL_SHAPE = Block.createCuboidShape(0.0, 4.0, 5.0, 6.0, 12.0, 11.0);
    protected static final VoxelShape FLOOR_Z_AXIS_SHAPE = Block.createCuboidShape(5.0, 0.0, 4.0, 11.0, 6.0, 12.0);
    protected static final VoxelShape FLOOR_X_AXIS_SHAPE = Block.createCuboidShape(4.0, 0.0, 5.0, 12.0, 6.0, 11.0);
    protected static final VoxelShape CEILING_Z_AXIS_SHAPE = Block.createCuboidShape(5.0, 10.0, 4.0, 11.0, 16.0, 12.0);
    protected static final VoxelShape CEILING_X_AXIS_SHAPE = Block.createCuboidShape(4.0, 10.0, 5.0, 12.0, 16.0, 11.0);

    public LeverBlock(AbstractBlock.Settings settings) {
        super(settings);
        this.setDefaultState((BlockState)((BlockState)((BlockState)((BlockState)this.stateManager.getDefaultState()).with(FACING, Direction.field_11043)).with(POWERED, false)).with(FACE, WallMountLocation.field_12471));
    }

    @Override
    public VoxelShape getOutlineShape(BlockState blockState, BlockView blockView, BlockPos blockPos, ShapeContext shapeContext) {
        switch ((WallMountLocation)blockState.get(FACE)) {
            case field_12475: {
                switch (blockState.get(FACING).getAxis()) {
                    case field_11048: {
                        return FLOOR_X_AXIS_SHAPE;
                    }
                }
                return FLOOR_Z_AXIS_SHAPE;
            }
            case field_12471: {
                switch (blockState.get(FACING)) {
                    case field_11034: {
                        return EAST_WALL_SHAPE;
                    }
                    case field_11039: {
                        return WEST_WALL_SHAPE;
                    }
                    case field_11035: {
                        return SOUTH_WALL_SHAPE;
                    }
                }
                return NORTH_WALL_SHAPE;
            }
        }
        switch (blockState.get(FACING).getAxis()) {
            case field_11048: {
                return CEILING_X_AXIS_SHAPE;
            }
        }
        return CEILING_Z_AXIS_SHAPE;
    }

    @Override
    public ActionResult onUse(BlockState blockState, World world, BlockPos blockPos, PlayerEntity playerEntity, Hand hand, BlockHitResult blockHitResult) {
        if (world.isClient) {
            BlockState blockState2 = (BlockState)blockState.cycle(POWERED);
            if (blockState2.get(POWERED).booleanValue()) {
                LeverBlock.spawnParticles(blockState2, world, blockPos, 1.0f);
            }
            return ActionResult.SUCCESS;
        }
        BlockState blockState2 = this.togglePower(blockState, world, blockPos);
        float f = blockState2.get(POWERED) != false ? 0.6f : 0.5f;
        world.playSound(null, blockPos, SoundEvents.field_14962, SoundCategory.field_15245, 0.3f, f);
        world.emitGameEvent((Entity)playerEntity, blockState2.get(POWERED) != false ? GameEvent.field_28174 : GameEvent.field_28175, blockPos);
        return ActionResult.CONSUME;
    }

    public BlockState togglePower(BlockState blockState, World world, BlockPos blockPos) {
        blockState = (BlockState)blockState.cycle(POWERED);
        world.setBlockState(blockPos, blockState, 3);
        this.updateNeighbors(blockState, world, blockPos);
        return blockState;
    }

    private static void spawnParticles(BlockState blockState, WorldAccess worldAccess, BlockPos blockPos, float f) {
        Direction direction = blockState.get(FACING).getOpposite();
        Direction direction2 = LeverBlock.getDirection(blockState).getOpposite();
        double d = (double)blockPos.getX() + 0.5 + 0.1 * (double)direction.getOffsetX() + 0.2 * (double)direction2.getOffsetX();
        double e = (double)blockPos.getY() + 0.5 + 0.1 * (double)direction.getOffsetY() + 0.2 * (double)direction2.getOffsetY();
        double g = (double)blockPos.getZ() + 0.5 + 0.1 * (double)direction.getOffsetZ() + 0.2 * (double)direction2.getOffsetZ();
        worldAccess.addParticle(new DustParticleEffect(DustParticleEffect.RED, f), d, e, g, 0.0, 0.0, 0.0);
    }

    @Override
    public void randomDisplayTick(BlockState blockState, World world, BlockPos blockPos, Random random) {
        if (blockState.get(POWERED).booleanValue() && random.nextFloat() < 0.25f) {
            LeverBlock.spawnParticles(blockState, world, blockPos, 0.5f);
        }
    }

    @Override
    public void onStateReplaced(BlockState blockState, World world, BlockPos blockPos, BlockState blockState2, boolean bl) {
        if (bl || blockState.isOf(blockState2.getBlock())) {
            return;
        }
        if (blockState.get(POWERED).booleanValue()) {
            this.updateNeighbors(blockState, world, blockPos);
        }
        super.onStateReplaced(blockState, world, blockPos, blockState2, bl);
    }

    @Override
    public int getWeakRedstonePower(BlockState blockState, BlockView blockView, BlockPos blockPos, Direction direction) {
        return blockState.get(POWERED) != false ? 15 : 0;
    }

    @Override
    public int getStrongRedstonePower(BlockState blockState, BlockView blockView, BlockPos blockPos, Direction direction) {
        if (blockState.get(POWERED).booleanValue() && LeverBlock.getDirection(blockState) == direction) {
            return 15;
        }
        return 0;
    }

    @Override
    public boolean emitsRedstonePower(BlockState blockState) {
        return true;
    }

    private void updateNeighbors(BlockState blockState, World world, BlockPos blockPos) {
        world.updateNeighborsAlways(blockPos, this);
        world.updateNeighborsAlways(blockPos.offset(LeverBlock.getDirection(blockState).getOpposite()), this);
    }

    @Override
    protected void appendProperties(StateManager.Builder<Block, BlockState> builder) {
        builder.add(FACE, FACING, POWERED);
    }
}


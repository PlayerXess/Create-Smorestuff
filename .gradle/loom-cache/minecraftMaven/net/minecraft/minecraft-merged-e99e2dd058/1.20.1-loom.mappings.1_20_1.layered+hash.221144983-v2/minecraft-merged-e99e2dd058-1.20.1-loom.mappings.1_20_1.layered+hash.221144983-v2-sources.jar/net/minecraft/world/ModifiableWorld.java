/*
 * Decompiled with CFR 0.2.1 (FabricMC 53fa44c9).
 */
package net.minecraft.world;

import net.minecraft.block.BlockState;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.BlockPos;
import org.jetbrains.annotations.Nullable;

public interface ModifiableWorld {
    public boolean setBlockState(BlockPos var1, BlockState var2, int var3, int var4);

    default public boolean setBlockState(BlockPos blockPos, BlockState blockState, int i) {
        return this.setBlockState(blockPos, blockState, i, 512);
    }

    public boolean removeBlock(BlockPos var1, boolean var2);

    default public boolean breakBlock(BlockPos blockPos, boolean bl) {
        return this.breakBlock(blockPos, bl, null);
    }

    default public boolean breakBlock(BlockPos blockPos, boolean bl, @Nullable Entity entity) {
        return this.breakBlock(blockPos, bl, entity, 512);
    }

    public boolean breakBlock(BlockPos var1, boolean var2, @Nullable Entity var3, int var4);

    default public boolean spawnEntity(Entity entity) {
        return false;
    }
}


/*
 * Decompiled with CFR 0.2.1 (FabricMC 53fa44c9).
 */
package net.minecraft.recipe;

import net.minecraft.inventory.RecipeInputInventory;
import net.minecraft.item.FilledMapItem;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.item.map.MapState;
import net.minecraft.recipe.Ingredient;
import net.minecraft.recipe.RecipeSerializer;
import net.minecraft.recipe.ShapedRecipe;
import net.minecraft.recipe.book.CraftingRecipeCategory;
import net.minecraft.registry.DynamicRegistryManager;
import net.minecraft.util.Identifier;
import net.minecraft.util.collection.DefaultedList;
import net.minecraft.world.World;

public class MapExtendingRecipe
extends ShapedRecipe {
    public MapExtendingRecipe(Identifier identifier, CraftingRecipeCategory craftingRecipeCategory) {
        super(identifier, "", craftingRecipeCategory, 3, 3, DefaultedList.copyOf(Ingredient.EMPTY, Ingredient.ofItems(Items.field_8407), Ingredient.ofItems(Items.field_8407), Ingredient.ofItems(Items.field_8407), Ingredient.ofItems(Items.field_8407), Ingredient.ofItems(Items.field_8204), Ingredient.ofItems(Items.field_8407), Ingredient.ofItems(Items.field_8407), Ingredient.ofItems(Items.field_8407), Ingredient.ofItems(Items.field_8407)), new ItemStack(Items.field_8895));
    }

    @Override
    public boolean matches(RecipeInputInventory recipeInputInventory, World world) {
        if (!super.matches(recipeInputInventory, world)) {
            return false;
        }
        ItemStack itemStack = MapExtendingRecipe.findFilledMap(recipeInputInventory);
        if (itemStack.isEmpty()) {
            return false;
        }
        MapState mapState = FilledMapItem.getMapState(itemStack, world);
        if (mapState == null) {
            return false;
        }
        if (mapState.hasMonumentIcon()) {
            return false;
        }
        return mapState.scale < 4;
    }

    @Override
    public ItemStack craft(RecipeInputInventory recipeInputInventory, DynamicRegistryManager dynamicRegistryManager) {
        ItemStack itemStack = MapExtendingRecipe.findFilledMap(recipeInputInventory).copyWithCount(1);
        itemStack.getOrCreateNbt().putInt("map_scale_direction", 1);
        return itemStack;
    }

    private static ItemStack findFilledMap(RecipeInputInventory recipeInputInventory) {
        for (int i = 0; i < recipeInputInventory.size(); ++i) {
            ItemStack itemStack = recipeInputInventory.getStack(i);
            if (!itemStack.isOf(Items.field_8204)) continue;
            return itemStack;
        }
        return ItemStack.EMPTY;
    }

    @Override
    public boolean isIgnoredInRecipeBook() {
        return true;
    }

    @Override
    public RecipeSerializer<?> getSerializer() {
        return RecipeSerializer.MAP_EXTENDING;
    }
}


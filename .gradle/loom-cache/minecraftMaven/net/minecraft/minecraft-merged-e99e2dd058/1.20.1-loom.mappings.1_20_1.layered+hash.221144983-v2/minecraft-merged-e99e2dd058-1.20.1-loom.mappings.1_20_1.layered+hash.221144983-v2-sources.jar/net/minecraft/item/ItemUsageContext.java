/*
 * Decompiled with CFR 0.2.1 (FabricMC 53fa44c9).
 */
package net.minecraft.item;

import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;
import org.jetbrains.annotations.Nullable;

public class ItemUsageContext {
    @Nullable
    private final PlayerEntity player;
    private final Hand hand;
    private final BlockHitResult hit;
    private final World world;
    private final ItemStack stack;

    public ItemUsageContext(PlayerEntity playerEntity, Hand hand, BlockHitResult blockHitResult) {
        this(playerEntity.getWorld(), playerEntity, hand, playerEntity.getStackInHand(hand), blockHitResult);
    }

    public ItemUsageContext(World world, @Nullable PlayerEntity playerEntity, Hand hand, ItemStack itemStack, BlockHitResult blockHitResult) {
        this.player = playerEntity;
        this.hand = hand;
        this.hit = blockHitResult;
        this.stack = itemStack;
        this.world = world;
    }

    protected final BlockHitResult getHitResult() {
        return this.hit;
    }

    public BlockPos getBlockPos() {
        return this.hit.getBlockPos();
    }

    public Direction getSide() {
        return this.hit.getSide();
    }

    public Vec3d getHitPos() {
        return this.hit.getPos();
    }

    public boolean hitsInsideBlock() {
        return this.hit.isInsideBlock();
    }

    public ItemStack getStack() {
        return this.stack;
    }

    @Nullable
    public PlayerEntity getPlayer() {
        return this.player;
    }

    public Hand getHand() {
        return this.hand;
    }

    public World getWorld() {
        return this.world;
    }

    public Direction getHorizontalPlayerFacing() {
        return this.player == null ? Direction.field_11043 : this.player.getHorizontalFacing();
    }

    public boolean shouldCancelInteraction() {
        return this.player != null && this.player.shouldCancelInteraction();
    }

    public float getPlayerYaw() {
        return this.player == null ? 0.0f : this.player.getYaw();
    }
}


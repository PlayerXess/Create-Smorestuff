/*
 * Decompiled with CFR 0.2.1 (FabricMC 53fa44c9).
 */
package net.minecraft.block;

import java.util.List;
import java.util.Optional;
import net.minecraft.block.AbstractBlock;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.Fertilizable;
import net.minecraft.block.SpreadableBlock;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.random.Random;
import net.minecraft.world.World;
import net.minecraft.world.WorldView;
import net.minecraft.world.gen.feature.ConfiguredFeature;
import net.minecraft.world.gen.feature.PlacedFeature;
import net.minecraft.world.gen.feature.RandomPatchFeatureConfig;
import net.minecraft.world.gen.feature.VegetationPlacedFeatures;

public class GrassBlock
extends SpreadableBlock
implements Fertilizable {
    public GrassBlock(AbstractBlock.Settings settings) {
        super(settings);
    }

    @Override
    public boolean isFertilizable(WorldView worldView, BlockPos blockPos, BlockState blockState, boolean bl) {
        return worldView.getBlockState(blockPos.up()).isAir();
    }

    @Override
    public boolean canGrow(World world, Random random, BlockPos blockPos, BlockState blockState) {
        return true;
    }

    @Override
    public void grow(ServerWorld serverWorld, Random random, BlockPos blockPos, BlockState blockState) {
        BlockPos blockPos2 = blockPos.up();
        BlockState blockState2 = Blocks.field_10479.getDefaultState();
        Optional<RegistryEntry.Reference<PlacedFeature>> optional = serverWorld.getRegistryManager().get(RegistryKeys.PLACED_FEATURE).getEntry(VegetationPlacedFeatures.GRASS_BONEMEAL);
        block0: for (int i = 0; i < 128; ++i) {
            RegistryEntry<PlacedFeature> registryEntry;
            BlockPos blockPos3 = blockPos2;
            for (int j = 0; j < i / 16; ++j) {
                if (!serverWorld.getBlockState((blockPos3 = blockPos3.add(random.nextInt(3) - 1, (random.nextInt(3) - 1) * random.nextInt(3) / 2, random.nextInt(3) - 1)).down()).isOf(this) || serverWorld.getBlockState(blockPos3).isFullCube(serverWorld, blockPos3)) continue block0;
            }
            BlockState blockState3 = serverWorld.getBlockState(blockPos3);
            if (blockState3.isOf(blockState2.getBlock()) && random.nextInt(10) == 0) {
                ((Fertilizable)((Object)blockState2.getBlock())).grow(serverWorld, random, blockPos3, blockState3);
            }
            if (!blockState3.isAir()) continue;
            if (random.nextInt(8) == 0) {
                List<ConfiguredFeature<?, ?>> list = serverWorld.getBiome(blockPos3).comp_349().getGenerationSettings().getFlowerFeatures();
                if (list.isEmpty()) continue;
                registryEntry = ((RandomPatchFeatureConfig)list.get(0).config()).comp_155();
            } else {
                if (!optional.isPresent()) continue;
                registryEntry = (RegistryEntry<PlacedFeature>)optional.get();
            }
            ((PlacedFeature)registryEntry.comp_349()).generateUnregistered(serverWorld, serverWorld.getChunkManager().getChunkGenerator(), random, blockPos3);
        }
    }
}


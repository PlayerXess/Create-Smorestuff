/*
 * Decompiled with CFR 0.2.1 (FabricMC 53fa44c9).
 */
package net.minecraft.util.math;

import com.mojang.datafixers.kinds.Applicative;
import com.mojang.datafixers.util.Either;
import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import io.github.fabricators_of_create.porting_lib.models.geometry.extensions.TransformationExtensions;
import java.util.Objects;
import net.minecraft.util.Util;
import net.minecraft.util.dynamic.Codecs;
import net.minecraft.util.math.MatrixUtil;
import org.apache.commons.lang3.tuple.Triple;
import org.jetbrains.annotations.Nullable;
import org.joml.Matrix3f;
import org.joml.Matrix4f;
import org.joml.Quaternionf;
import org.joml.Vector3f;

public final class AffineTransformation
implements TransformationExtensions {
    private final Matrix4f matrix;
    public static final Codec<AffineTransformation> CODEC = RecordCodecBuilder.create(instance -> instance.group(((MapCodec)Codecs.VECTOR_3F.fieldOf("translation")).forGetter(affineTransformation -> affineTransformation.translation), ((MapCodec)Codecs.ROTATION.fieldOf("left_rotation")).forGetter(affineTransformation -> affineTransformation.leftRotation), ((MapCodec)Codecs.VECTOR_3F.fieldOf("scale")).forGetter(affineTransformation -> affineTransformation.scale), ((MapCodec)Codecs.ROTATION.fieldOf("right_rotation")).forGetter(affineTransformation -> affineTransformation.rightRotation)).apply((Applicative<AffineTransformation, ?>)instance, AffineTransformation::new));
    public static final Codec<AffineTransformation> ANY_CODEC = Codec.either(CODEC, Codecs.MATRIX4F.xmap(AffineTransformation::new, AffineTransformation::getMatrix)).xmap(either -> either.map(affineTransformation -> affineTransformation, affineTransformation -> affineTransformation), Either::left);
    private boolean initialized;
    @Nullable
    private Vector3f translation;
    @Nullable
    private Quaternionf leftRotation;
    @Nullable
    private Vector3f scale;
    @Nullable
    private Quaternionf rightRotation;
    private static final AffineTransformation IDENTITY = Util.make(() -> {
        AffineTransformation affineTransformation = new AffineTransformation(new Matrix4f());
        affineTransformation.translation = new Vector3f();
        affineTransformation.leftRotation = new Quaternionf();
        affineTransformation.scale = new Vector3f(1.0f, 1.0f, 1.0f);
        affineTransformation.rightRotation = new Quaternionf();
        affineTransformation.initialized = true;
        return affineTransformation;
    });

    public AffineTransformation(@Nullable Matrix4f matrix4f) {
        this.matrix = matrix4f == null ? new Matrix4f() : matrix4f;
    }

    public AffineTransformation(@Nullable Vector3f vector3f, @Nullable Quaternionf quaternionf, @Nullable Vector3f vector3f2, @Nullable Quaternionf quaternionf2) {
        this.matrix = AffineTransformation.setup(vector3f, quaternionf, vector3f2, quaternionf2);
        this.translation = vector3f != null ? vector3f : new Vector3f();
        this.leftRotation = quaternionf != null ? quaternionf : new Quaternionf();
        this.scale = vector3f2 != null ? vector3f2 : new Vector3f(1.0f, 1.0f, 1.0f);
        this.rightRotation = quaternionf2 != null ? quaternionf2 : new Quaternionf();
        this.initialized = true;
    }

    public static AffineTransformation identity() {
        return IDENTITY;
    }

    public AffineTransformation multiply(AffineTransformation affineTransformation) {
        Matrix4f matrix4f = this.getMatrix();
        matrix4f.mul(affineTransformation.getMatrix());
        return new AffineTransformation(matrix4f);
    }

    @Nullable
    public AffineTransformation invert() {
        if (this == IDENTITY) {
            return this;
        }
        Matrix4f matrix4f = this.getMatrix().invert();
        if (matrix4f.isFinite()) {
            return new AffineTransformation(matrix4f);
        }
        return null;
    }

    private void init() {
        if (!this.initialized) {
            float f = 1.0f / this.matrix.m33();
            Triple<Quaternionf, Vector3f, Quaternionf> triple = MatrixUtil.svdDecompose(new Matrix3f(this.matrix).scale(f));
            this.translation = this.matrix.getTranslation(new Vector3f()).mul(f);
            this.leftRotation = new Quaternionf(triple.getLeft());
            this.scale = new Vector3f(triple.getMiddle());
            this.rightRotation = new Quaternionf(triple.getRight());
            this.initialized = true;
        }
    }

    private static Matrix4f setup(@Nullable Vector3f vector3f, @Nullable Quaternionf quaternionf, @Nullable Vector3f vector3f2, @Nullable Quaternionf quaternionf2) {
        Matrix4f matrix4f = new Matrix4f();
        if (vector3f != null) {
            matrix4f.translation(vector3f);
        }
        if (quaternionf != null) {
            matrix4f.rotate(quaternionf);
        }
        if (vector3f2 != null) {
            matrix4f.scale(vector3f2);
        }
        if (quaternionf2 != null) {
            matrix4f.rotate(quaternionf2);
        }
        return matrix4f;
    }

    public Matrix4f getMatrix() {
        return new Matrix4f(this.matrix);
    }

    public Vector3f getTranslation() {
        this.init();
        return new Vector3f(this.translation);
    }

    public Quaternionf getLeftRotation() {
        this.init();
        return new Quaternionf(this.leftRotation);
    }

    public Vector3f getScale() {
        this.init();
        return new Vector3f(this.scale);
    }

    public Quaternionf getRightRotation() {
        this.init();
        return new Quaternionf(this.rightRotation);
    }

    public boolean equals(Object object) {
        if (this == object) {
            return true;
        }
        if (object == null || this.getClass() != object.getClass()) {
            return false;
        }
        AffineTransformation affineTransformation = (AffineTransformation)object;
        return Objects.equals(this.matrix, affineTransformation.matrix);
    }

    public int hashCode() {
        return Objects.hash(this.matrix);
    }

    public AffineTransformation interpolate(AffineTransformation affineTransformation, float f) {
        Vector3f vector3f = this.getTranslation();
        Quaternionf quaternionf = this.getLeftRotation();
        Vector3f vector3f2 = this.getScale();
        Quaternionf quaternionf2 = this.getRightRotation();
        vector3f.lerp(affineTransformation.getTranslation(), f);
        quaternionf.slerp(affineTransformation.getLeftRotation(), f);
        vector3f2.lerp(affineTransformation.getScale(), f);
        quaternionf2.slerp(affineTransformation.getRightRotation(), f);
        return new AffineTransformation(vector3f, quaternionf, vector3f2, quaternionf2);
    }
}


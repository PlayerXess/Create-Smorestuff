/*
 * Decompiled with CFR 0.2.1 (FabricMC 53fa44c9).
 */
package net.minecraft.world;

import net.minecraft.block.AbstractRedstoneGateBlock;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.RedstoneWireBlock;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.world.BlockView;

public interface RedstoneView
extends BlockView {
    public static final Direction[] DIRECTIONS = Direction.values();

    default public int getStrongRedstonePower(BlockPos blockPos, Direction direction) {
        return this.getBlockState(blockPos).getStrongRedstonePower(this, blockPos, direction);
    }

    default public int getReceivedStrongRedstonePower(BlockPos blockPos) {
        int i = 0;
        if ((i = Math.max(i, this.getStrongRedstonePower(blockPos.down(), Direction.field_11033))) >= 15) {
            return i;
        }
        if ((i = Math.max(i, this.getStrongRedstonePower(blockPos.up(), Direction.field_11036))) >= 15) {
            return i;
        }
        if ((i = Math.max(i, this.getStrongRedstonePower(blockPos.north(), Direction.field_11043))) >= 15) {
            return i;
        }
        if ((i = Math.max(i, this.getStrongRedstonePower(blockPos.south(), Direction.field_11035))) >= 15) {
            return i;
        }
        if ((i = Math.max(i, this.getStrongRedstonePower(blockPos.west(), Direction.field_11039))) >= 15) {
            return i;
        }
        if ((i = Math.max(i, this.getStrongRedstonePower(blockPos.east(), Direction.field_11034))) >= 15) {
            return i;
        }
        return i;
    }

    default public int getEmittedRedstonePower(BlockPos blockPos, Direction direction, boolean bl) {
        BlockState blockState = this.getBlockState(blockPos);
        if (bl) {
            return AbstractRedstoneGateBlock.isRedstoneGate(blockState) ? this.getStrongRedstonePower(blockPos, direction) : 0;
        }
        if (blockState.isOf(Blocks.field_10002)) {
            return 15;
        }
        if (blockState.isOf(Blocks.field_10091)) {
            return blockState.get(RedstoneWireBlock.POWER);
        }
        if (blockState.emitsRedstonePower()) {
            return this.getStrongRedstonePower(blockPos, direction);
        }
        return 0;
    }

    default public boolean isEmittingRedstonePower(BlockPos blockPos, Direction direction) {
        return this.getEmittedRedstonePower(blockPos, direction) > 0;
    }

    default public int getEmittedRedstonePower(BlockPos blockPos, Direction direction) {
        BlockState blockState = this.getBlockState(blockPos);
        int i = blockState.getWeakRedstonePower(this, blockPos, direction);
        if (blockState.isSolidBlock(this, blockPos)) {
            return Math.max(i, this.getReceivedStrongRedstonePower(blockPos));
        }
        return i;
    }

    default public boolean isReceivingRedstonePower(BlockPos blockPos) {
        if (this.getEmittedRedstonePower(blockPos.down(), Direction.field_11033) > 0) {
            return true;
        }
        if (this.getEmittedRedstonePower(blockPos.up(), Direction.field_11036) > 0) {
            return true;
        }
        if (this.getEmittedRedstonePower(blockPos.north(), Direction.field_11043) > 0) {
            return true;
        }
        if (this.getEmittedRedstonePower(blockPos.south(), Direction.field_11035) > 0) {
            return true;
        }
        if (this.getEmittedRedstonePower(blockPos.west(), Direction.field_11039) > 0) {
            return true;
        }
        return this.getEmittedRedstonePower(blockPos.east(), Direction.field_11034) > 0;
    }

    default public int getReceivedRedstonePower(BlockPos blockPos) {
        int i = 0;
        for (Direction direction : DIRECTIONS) {
            int j = this.getEmittedRedstonePower(blockPos.offset(direction), direction);
            if (j >= 15) {
                return 15;
            }
            if (j <= i) continue;
            i = j;
        }
        return i;
    }
}


/*
 * Decompiled with CFR 0.2.1 (FabricMC 53fa44c9).
 */
package net.minecraft.item;

import java.util.Iterator;
import java.util.List;
import java.util.Optional;
import net.minecraft.client.item.TooltipContext;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Instrument;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.registry.Registries;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.registry.tag.TagKey;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvent;
import net.minecraft.stat.Stats;
import net.minecraft.text.MutableText;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.Hand;
import net.minecraft.util.Identifier;
import net.minecraft.util.TypedActionResult;
import net.minecraft.util.UseAction;
import net.minecraft.util.Util;
import net.minecraft.util.math.random.Random;
import net.minecraft.world.World;
import net.minecraft.world.event.GameEvent;
import org.jetbrains.annotations.Nullable;

public class GoatHornItem
extends Item {
    private static final String INSTRUMENT_KEY = "instrument";
    private final TagKey<Instrument> instrumentTag;

    public GoatHornItem(Item.Settings settings, TagKey<Instrument> tagKey) {
        super(settings);
        this.instrumentTag = tagKey;
    }

    @Override
    public void appendTooltip(ItemStack itemStack, @Nullable World world, List<Text> list, TooltipContext tooltipContext) {
        super.appendTooltip(itemStack, world, list, tooltipContext);
        Optional optional = this.getInstrument(itemStack).flatMap(RegistryEntry::getKey);
        if (optional.isPresent()) {
            MutableText mutableText = Text.translatable(Util.createTranslationKey(INSTRUMENT_KEY, ((RegistryKey)optional.get()).getValue()));
            list.add(mutableText.formatted(Formatting.field_1080));
        }
    }

    public static ItemStack getStackForInstrument(Item item, RegistryEntry<Instrument> registryEntry) {
        ItemStack itemStack = new ItemStack(item);
        GoatHornItem.setInstrument(itemStack, registryEntry);
        return itemStack;
    }

    public static void setRandomInstrumentFromTag(ItemStack itemStack, TagKey<Instrument> tagKey, Random random) {
        Optional optional = Registries.INSTRUMENT.getEntryList(tagKey).flatMap(named -> named.getRandom(random));
        optional.ifPresent(registryEntry -> GoatHornItem.setInstrument(itemStack, registryEntry));
    }

    private static void setInstrument(ItemStack itemStack, RegistryEntry<Instrument> registryEntry) {
        NbtCompound nbtCompound = itemStack.getOrCreateNbt();
        nbtCompound.putString(INSTRUMENT_KEY, registryEntry.getKey().orElseThrow(() -> new IllegalStateException("Invalid instrument")).getValue().toString());
    }

    @Override
    public TypedActionResult<ItemStack> use(World world, PlayerEntity playerEntity, Hand hand) {
        ItemStack itemStack = playerEntity.getStackInHand(hand);
        Optional<? extends RegistryEntry<Instrument>> optional = this.getInstrument(itemStack);
        if (optional.isPresent()) {
            Instrument instrument = optional.get().comp_349();
            playerEntity.setCurrentHand(hand);
            GoatHornItem.playSound(world, playerEntity, instrument);
            playerEntity.getItemCooldownManager().set(this, instrument.comp_773());
            playerEntity.incrementStat(Stats.field_15372.getOrCreateStat(this));
            return TypedActionResult.consume(itemStack);
        }
        return TypedActionResult.fail(itemStack);
    }

    @Override
    public int getMaxUseTime(ItemStack itemStack) {
        Optional<? extends RegistryEntry<Instrument>> optional = this.getInstrument(itemStack);
        return optional.map(registryEntry -> ((Instrument)registryEntry.comp_349()).comp_773()).orElse(0);
    }

    private Optional<? extends RegistryEntry<Instrument>> getInstrument(ItemStack itemStack) {
        Identifier identifier;
        NbtCompound nbtCompound = itemStack.getNbt();
        if (nbtCompound != null && nbtCompound.contains(INSTRUMENT_KEY, 8) && (identifier = Identifier.tryParse(nbtCompound.getString(INSTRUMENT_KEY))) != null) {
            return Registries.INSTRUMENT.getEntry(RegistryKey.of(RegistryKeys.field_41275, identifier));
        }
        Iterator<RegistryEntry<Instrument>> iterator = Registries.INSTRUMENT.iterateEntries(this.instrumentTag).iterator();
        if (iterator.hasNext()) {
            return Optional.of(iterator.next());
        }
        return Optional.empty();
    }

    @Override
    public UseAction getUseAction(ItemStack itemStack) {
        return UseAction.field_39058;
    }

    private static void playSound(World world, PlayerEntity playerEntity, Instrument instrument) {
        SoundEvent soundEvent = instrument.comp_772().comp_349();
        float f = instrument.comp_774() / 16.0f;
        world.playSoundFromEntity(playerEntity, playerEntity, soundEvent, SoundCategory.field_15247, f, 1.0f);
        world.emitGameEvent(GameEvent.field_39415, playerEntity.getPos(), GameEvent.Emitter.of(playerEntity));
    }
}


/*
 * Decompiled with CFR 0.2.1 (FabricMC 53fa44c9).
 */
package net.minecraft.world;

import com.mojang.datafixers.kinds.Applicative;
import com.mojang.serialization.Codec;
import com.mojang.serialization.DataResult;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import java.util.Optional;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.util.Identifier;
import net.minecraft.util.collection.DataPool;
import net.minecraft.util.dynamic.Codecs;
import net.minecraft.util.dynamic.Range;

public record MobSpawnerEntry(NbtCompound entity, Optional<CustomSpawnRules> customSpawnRules) {
    public static final String ENTITY_KEY = "entity";
    public static final Codec<MobSpawnerEntry> CODEC = RecordCodecBuilder.create(instance -> instance.group(((MapCodec)NbtCompound.CODEC.fieldOf(ENTITY_KEY)).forGetter(mobSpawnerEntry -> mobSpawnerEntry.entity), CustomSpawnRules.CODEC.optionalFieldOf("custom_spawn_rules").forGetter(mobSpawnerEntry -> mobSpawnerEntry.customSpawnRules)).apply((Applicative<MobSpawnerEntry, ?>)instance, MobSpawnerEntry::new));
    public static final Codec<DataPool<MobSpawnerEntry>> DATA_POOL_CODEC = DataPool.createEmptyAllowedCodec(CODEC);

    public MobSpawnerEntry() {
        this(new NbtCompound(), Optional.empty());
    }

    public MobSpawnerEntry {
        if (nbtCompound.contains("id")) {
            Identifier identifier = Identifier.tryParse(nbtCompound.getString("id"));
            if (identifier != null) {
                nbtCompound.putString("id", identifier.toString());
            } else {
                nbtCompound.remove("id");
            }
        }
    }

    public NbtCompound getNbt() {
        return this.entity;
    }

    public Optional<CustomSpawnRules> getCustomSpawnRules() {
        return this.customSpawnRules;
    }

    public record CustomSpawnRules(Range<Integer> blockLightLimit, Range<Integer> skyLightLimit) {
        private static final Range<Integer> DEFAULT = new Range<Integer>(0, 15);
        public static final Codec<CustomSpawnRules> CODEC = RecordCodecBuilder.create(instance -> instance.group(CustomSpawnRules.createLightLimitCodec("block_light_limit").forGetter(customSpawnRules -> customSpawnRules.blockLightLimit), CustomSpawnRules.createLightLimitCodec("sky_light_limit").forGetter(customSpawnRules -> customSpawnRules.skyLightLimit)).apply((Applicative<CustomSpawnRules, ?>)instance, CustomSpawnRules::new));

        private static DataResult<Range<Integer>> validate(Range<Integer> range) {
            if (!DEFAULT.contains(range)) {
                return DataResult.error(() -> "Light values must be withing range " + DEFAULT);
            }
            return DataResult.success(range);
        }

        private static MapCodec<Range<Integer>> createLightLimitCodec(String string) {
            return Codecs.validate(Range.CODEC.optionalFieldOf(string, DEFAULT), CustomSpawnRules::validate);
        }
    }
}


/*
 * Decompiled with CFR 0.2.1 (FabricMC 53fa44c9).
 */
package net.minecraft.item;

import com.mojang.logging.LogUtils;
import java.util.Optional;
import net.minecraft.block.Blocks;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemUsageContext;
import net.minecraft.item.Items;
import net.minecraft.item.Vanishable;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.nbt.NbtElement;
import net.minecraft.nbt.NbtHelper;
import net.minecraft.nbt.NbtOps;
import net.minecraft.registry.RegistryKey;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.ActionResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.GlobalPos;
import net.minecraft.world.World;
import net.minecraft.world.poi.PointOfInterestTypes;
import org.jetbrains.annotations.Nullable;
import org.slf4j.Logger;

public class CompassItem
extends Item
implements Vanishable {
    private static final Logger LOGGER = LogUtils.getLogger();
    public static final String LODESTONE_POS_KEY = "LodestonePos";
    public static final String LODESTONE_DIMENSION_KEY = "LodestoneDimension";
    public static final String LODESTONE_TRACKED_KEY = "LodestoneTracked";

    public CompassItem(Item.Settings settings) {
        super(settings);
    }

    public static boolean hasLodestone(ItemStack itemStack) {
        NbtCompound nbtCompound = itemStack.getNbt();
        return nbtCompound != null && (nbtCompound.contains(LODESTONE_DIMENSION_KEY) || nbtCompound.contains(LODESTONE_POS_KEY));
    }

    private static Optional<RegistryKey<World>> getLodestoneDimension(NbtCompound nbtCompound) {
        return World.CODEC.parse(NbtOps.INSTANCE, nbtCompound.get(LODESTONE_DIMENSION_KEY)).result();
    }

    @Nullable
    public static GlobalPos createLodestonePos(NbtCompound nbtCompound) {
        Optional<RegistryKey<World>> optional;
        boolean bl = nbtCompound.contains(LODESTONE_POS_KEY);
        boolean bl2 = nbtCompound.contains(LODESTONE_DIMENSION_KEY);
        if (bl && bl2 && (optional = CompassItem.getLodestoneDimension(nbtCompound)).isPresent()) {
            BlockPos blockPos = NbtHelper.toBlockPos(nbtCompound.getCompound(LODESTONE_POS_KEY));
            return GlobalPos.create(optional.get(), blockPos);
        }
        return null;
    }

    @Nullable
    public static GlobalPos createSpawnPos(World world) {
        return world.getDimension().comp_645() ? GlobalPos.create(world.getRegistryKey(), world.getSpawnPos()) : null;
    }

    @Override
    public boolean hasGlint(ItemStack itemStack) {
        return CompassItem.hasLodestone(itemStack) || super.hasGlint(itemStack);
    }

    @Override
    public void inventoryTick(ItemStack itemStack, World world, Entity entity, int i, boolean bl) {
        if (world.isClient) {
            return;
        }
        if (CompassItem.hasLodestone(itemStack)) {
            BlockPos blockPos;
            NbtCompound nbtCompound = itemStack.getOrCreateNbt();
            if (nbtCompound.contains(LODESTONE_TRACKED_KEY) && !nbtCompound.getBoolean(LODESTONE_TRACKED_KEY)) {
                return;
            }
            Optional<RegistryKey<World>> optional = CompassItem.getLodestoneDimension(nbtCompound);
            if (optional.isPresent() && optional.get() == world.getRegistryKey() && nbtCompound.contains(LODESTONE_POS_KEY) && (!world.isInBuildLimit(blockPos = NbtHelper.toBlockPos(nbtCompound.getCompound(LODESTONE_POS_KEY))) || !((ServerWorld)world).getPointOfInterestStorage().hasTypeAt(PointOfInterestTypes.field_39296, blockPos))) {
                nbtCompound.remove(LODESTONE_POS_KEY);
            }
        }
    }

    @Override
    public ActionResult useOnBlock(ItemUsageContext itemUsageContext) {
        BlockPos blockPos = itemUsageContext.getBlockPos();
        World world = itemUsageContext.getWorld();
        if (world.getBlockState(blockPos).isOf(Blocks.field_23261)) {
            boolean bl;
            world.playSound(null, blockPos, SoundEvents.field_23199, SoundCategory.field_15248, 1.0f, 1.0f);
            PlayerEntity playerEntity = itemUsageContext.getPlayer();
            ItemStack itemStack = itemUsageContext.getStack();
            boolean bl2 = bl = !playerEntity.getAbilities().creativeMode && itemStack.getCount() == 1;
            if (bl) {
                this.writeNbt(world.getRegistryKey(), blockPos, itemStack.getOrCreateNbt());
            } else {
                ItemStack itemStack2 = new ItemStack(Items.field_8251, 1);
                NbtCompound nbtCompound = itemStack.hasNbt() ? itemStack.getNbt().copy() : new NbtCompound();
                itemStack2.setNbt(nbtCompound);
                if (!playerEntity.getAbilities().creativeMode) {
                    itemStack.decrement(1);
                }
                this.writeNbt(world.getRegistryKey(), blockPos, nbtCompound);
                if (!playerEntity.getInventory().insertStack(itemStack2)) {
                    playerEntity.dropItem(itemStack2, false);
                }
            }
            return ActionResult.success(world.isClient);
        }
        return super.useOnBlock(itemUsageContext);
    }

    private void writeNbt(RegistryKey<World> registryKey, BlockPos blockPos, NbtCompound nbtCompound) {
        nbtCompound.put(LODESTONE_POS_KEY, NbtHelper.fromBlockPos(blockPos));
        World.CODEC.encodeStart(NbtOps.INSTANCE, registryKey).resultOrPartial(LOGGER::error).ifPresent(nbtElement -> nbtCompound.put(LODESTONE_DIMENSION_KEY, (NbtElement)nbtElement));
        nbtCompound.putBoolean(LODESTONE_TRACKED_KEY, true);
    }

    @Override
    public String getTranslationKey(ItemStack itemStack) {
        return CompassItem.hasLodestone(itemStack) ? "item.minecraft.lodestone_compass" : super.getTranslationKey(itemStack);
    }
}


/*
 * Decompiled with CFR 0.2.1 (FabricMC 53fa44c9).
 */
package net.minecraft.block;

import com.google.common.cache.CacheBuilder;
import com.google.common.cache.CacheLoader;
import com.google.common.cache.LoadingCache;
import com.google.common.collect.ImmutableMap;
import com.mojang.logging.LogUtils;
import io.github.fabricators_of_create.porting_lib.extensions.extensions.BlockExtensions;
import it.unimi.dsi.fastutil.objects.Object2ByteLinkedOpenHashMap;
import java.util.List;
import java.util.function.Function;
import java.util.function.Supplier;
import net.fabricmc.fabric.api.block.v1.FabricBlock;
import net.minecraft.SharedConstants;
import net.minecraft.block.AbstractBlock;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.LeavesBlock;
import net.minecraft.block.SideShapeType;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.client.item.TooltipContext;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.enchantment.Enchantments;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.ExperienceOrbEntity;
import net.minecraft.entity.ItemEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.mob.PiglinBrain;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.BlockItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemConvertible;
import net.minecraft.item.ItemPlacementContext;
import net.minecraft.item.ItemStack;
import net.minecraft.loot.context.LootContextParameterSet;
import net.minecraft.loot.context.LootContextParameters;
import net.minecraft.registry.Registries;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.registry.tag.BlockTags;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.BlockSoundGroup;
import net.minecraft.stat.Stats;
import net.minecraft.state.StateManager;
import net.minecraft.state.property.Property;
import net.minecraft.text.MutableText;
import net.minecraft.text.Text;
import net.minecraft.util.Util;
import net.minecraft.util.collection.IdList;
import net.minecraft.util.function.BooleanBiFunction;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.math.Vec3i;
import net.minecraft.util.math.intprovider.IntProvider;
import net.minecraft.util.math.random.Random;
import net.minecraft.util.shape.VoxelShape;
import net.minecraft.util.shape.VoxelShapes;
import net.minecraft.world.BlockView;
import net.minecraft.world.GameRules;
import net.minecraft.world.World;
import net.minecraft.world.WorldAccess;
import net.minecraft.world.WorldView;
import net.minecraft.world.biome.Biome;
import net.minecraft.world.event.GameEvent;
import net.minecraft.world.explosion.Explosion;
import org.jetbrains.annotations.Nullable;
import org.slf4j.Logger;

public class Block
extends AbstractBlock
implements ItemConvertible,
FabricBlock,
BlockExtensions,
io.github.fabricators_of_create.porting_lib.tool.extensions.BlockExtensions {
    private static final Logger LOGGER = LogUtils.getLogger();
    private final RegistryEntry.Reference<Block> registryEntry = Registries.BLOCK.createEntry(this);
    public static final IdList<BlockState> STATE_IDS = new IdList();
    private static final LoadingCache<VoxelShape, Boolean> FULL_CUBE_SHAPE_CACHE = CacheBuilder.newBuilder().maximumSize(512L).weakKeys().build(new CacheLoader<VoxelShape, Boolean>(){

        @Override
        public Boolean load(VoxelShape voxelShape) {
            return !VoxelShapes.matchesAnywhere(VoxelShapes.fullCube(), voxelShape, BooleanBiFunction.NOT_SAME);
        }

        @Override
        public /* synthetic */ Object load(Object object) throws Exception {
            return this.load((VoxelShape)object);
        }
    });
    public static final int NOTIFY_NEIGHBORS = 1;
    public static final int NOTIFY_LISTENERS = 2;
    public static final int NO_REDRAW = 4;
    public static final int REDRAW_ON_MAIN_THREAD = 8;
    public static final int FORCE_STATE = 16;
    public static final int SKIP_DROPS = 32;
    public static final int MOVED = 64;
    public static final int field_31035 = 4;
    public static final int NOTIFY_ALL = 3;
    public static final int field_31022 = 11;
    public static final float field_31023 = -1.0f;
    public static final float field_31024 = 0.0f;
    public static final int field_31025 = 512;
    protected final StateManager<Block, BlockState> stateManager;
    private BlockState defaultState;
    @Nullable
    private String translationKey;
    @Nullable
    private Item cachedItem;
    private static final int field_31026 = 2048;
    private static final ThreadLocal<Object2ByteLinkedOpenHashMap<NeighborGroup>> FACE_CULL_MAP = ThreadLocal.withInitial(() -> {
        Object2ByteLinkedOpenHashMap<NeighborGroup> object2ByteLinkedOpenHashMap = new Object2ByteLinkedOpenHashMap<NeighborGroup>(2048, 0.25f){

            @Override
            protected void rehash(int i) {
            }
        };
        object2ByteLinkedOpenHashMap.defaultReturnValue((byte)127);
        return object2ByteLinkedOpenHashMap;
    });

    public static int getRawIdFromState(@Nullable BlockState blockState) {
        if (blockState == null) {
            return 0;
        }
        int i = STATE_IDS.getRawId(blockState);
        return i == -1 ? 0 : i;
    }

    public static BlockState getStateFromRawId(int i) {
        BlockState blockState = STATE_IDS.get(i);
        return blockState == null ? Blocks.field_10124.getDefaultState() : blockState;
    }

    public static Block getBlockFromItem(@Nullable Item item) {
        if (item instanceof BlockItem) {
            return ((BlockItem)item).getBlock();
        }
        return Blocks.field_10124;
    }

    public static BlockState pushEntitiesUpBeforeBlockChange(BlockState blockState, BlockState blockState2, WorldAccess worldAccess, BlockPos blockPos) {
        VoxelShape voxelShape = VoxelShapes.combine(blockState.getCollisionShape(worldAccess, blockPos), blockState2.getCollisionShape(worldAccess, blockPos), BooleanBiFunction.ONLY_SECOND).offset(blockPos.getX(), blockPos.getY(), blockPos.getZ());
        if (voxelShape.isEmpty()) {
            return blockState2;
        }
        List<Entity> list = worldAccess.getOtherEntities(null, voxelShape.getBoundingBox());
        for (Entity entity : list) {
            double d = VoxelShapes.calculateMaxOffset(Direction.Axis.field_11052, entity.getBoundingBox().offset(0.0, 1.0, 0.0), List.of(voxelShape), -1.0);
            entity.requestTeleportOffset(0.0, 1.0 + d, 0.0);
        }
        return blockState2;
    }

    public static VoxelShape createCuboidShape(double d, double e, double f, double g, double h, double i) {
        return VoxelShapes.cuboid(d / 16.0, e / 16.0, f / 16.0, g / 16.0, h / 16.0, i / 16.0);
    }

    public static BlockState postProcessState(BlockState blockState, WorldAccess worldAccess, BlockPos blockPos) {
        BlockState blockState2 = blockState;
        BlockPos.Mutable mutable = new BlockPos.Mutable();
        for (Direction direction : DIRECTIONS) {
            mutable.set((Vec3i)blockPos, direction);
            blockState2 = blockState2.getStateForNeighborUpdate(direction, worldAccess.getBlockState(mutable), worldAccess, blockPos, mutable);
        }
        return blockState2;
    }

    public static void replace(BlockState blockState, BlockState blockState2, WorldAccess worldAccess, BlockPos blockPos, int i) {
        Block.replace(blockState, blockState2, worldAccess, blockPos, i, 512);
    }

    public static void replace(BlockState blockState, BlockState blockState2, WorldAccess worldAccess, BlockPos blockPos, int i, int j) {
        if (blockState2 != blockState) {
            if (blockState2.isAir()) {
                if (!worldAccess.isClient()) {
                    worldAccess.breakBlock(blockPos, (i & 0x20) == 0, null, j);
                }
            } else {
                worldAccess.setBlockState(blockPos, blockState2, i & 0xFFFFFFDF, j);
            }
        }
    }

    public Block(AbstractBlock.Settings settings) {
        super(settings);
        String string;
        StateManager.Builder<Block, BlockState> builder = new StateManager.Builder<Block, BlockState>(this);
        this.appendProperties(builder);
        this.stateManager = builder.build(Block::getDefaultState, BlockState::new);
        this.setDefaultState(this.stateManager.getDefaultState());
        if (SharedConstants.isDevelopment && !(string = this.getClass().getSimpleName()).endsWith("Block")) {
            LOGGER.error("Block classes should end with Block and {} doesn't.", (Object)string);
        }
    }

    public static boolean cannotConnect(BlockState blockState) {
        return blockState.getBlock() instanceof LeavesBlock || blockState.isOf(Blocks.field_10499) || blockState.isOf(Blocks.field_10147) || blockState.isOf(Blocks.field_10009) || blockState.isOf(Blocks.field_10545) || blockState.isOf(Blocks.field_10261) || blockState.isIn(BlockTags.field_21490);
    }

    public boolean hasRandomTicks(BlockState blockState) {
        return this.randomTicks;
    }

    public static boolean shouldDrawSide(BlockState blockState, BlockView blockView, BlockPos blockPos, Direction direction, BlockPos blockPos2) {
        BlockState blockState2 = blockView.getBlockState(blockPos2);
        if (blockState.isSideInvisible(blockState2, direction)) {
            return false;
        }
        if (blockState2.isOpaque()) {
            NeighborGroup neighborGroup = new NeighborGroup(blockState, blockState2, direction);
            Object2ByteLinkedOpenHashMap<NeighborGroup> object2ByteLinkedOpenHashMap = FACE_CULL_MAP.get();
            byte b = object2ByteLinkedOpenHashMap.getAndMoveToFirst(neighborGroup);
            if (b != 127) {
                return b != 0;
            }
            VoxelShape voxelShape = blockState.getCullingFace(blockView, blockPos, direction);
            if (voxelShape.isEmpty()) {
                return true;
            }
            VoxelShape voxelShape2 = blockState2.getCullingFace(blockView, blockPos2, direction.getOpposite());
            boolean bl = VoxelShapes.matchesAnywhere(voxelShape, voxelShape2, BooleanBiFunction.ONLY_FIRST);
            if (object2ByteLinkedOpenHashMap.size() == 2048) {
                object2ByteLinkedOpenHashMap.removeLastByte();
            }
            object2ByteLinkedOpenHashMap.putAndMoveToFirst(neighborGroup, (byte)(bl ? 1 : 0));
            return bl;
        }
        return true;
    }

    public static boolean hasTopRim(BlockView blockView, BlockPos blockPos) {
        return blockView.getBlockState(blockPos).isSideSolid(blockView, blockPos, Direction.field_11036, SideShapeType.field_25824);
    }

    public static boolean sideCoversSmallSquare(WorldView worldView, BlockPos blockPos, Direction direction) {
        BlockState blockState = worldView.getBlockState(blockPos);
        if (direction == Direction.field_11033 && blockState.isIn(BlockTags.field_25148)) {
            return false;
        }
        return blockState.isSideSolid(worldView, blockPos, direction, SideShapeType.field_25823);
    }

    public static boolean isFaceFullSquare(VoxelShape voxelShape, Direction direction) {
        VoxelShape voxelShape2 = voxelShape.getFace(direction);
        return Block.isShapeFullCube(voxelShape2);
    }

    public static boolean isShapeFullCube(VoxelShape voxelShape) {
        return FULL_CUBE_SHAPE_CACHE.getUnchecked(voxelShape);
    }

    public boolean isTransparent(BlockState blockState, BlockView blockView, BlockPos blockPos) {
        return !Block.isShapeFullCube(blockState.getOutlineShape(blockView, blockPos)) && blockState.getFluidState().isEmpty();
    }

    public void randomDisplayTick(BlockState blockState, World world, BlockPos blockPos, Random random) {
    }

    public void onBroken(WorldAccess worldAccess, BlockPos blockPos, BlockState blockState) {
    }

    public static List<ItemStack> getDroppedStacks(BlockState blockState, ServerWorld serverWorld, BlockPos blockPos, @Nullable BlockEntity blockEntity) {
        LootContextParameterSet.Builder builder = new LootContextParameterSet.Builder(serverWorld).add(LootContextParameters.field_24424, Vec3d.ofCenter(blockPos)).add(LootContextParameters.field_1229, ItemStack.EMPTY).addOptional(LootContextParameters.field_1228, blockEntity);
        return blockState.getDroppedStacks(builder);
    }

    public static List<ItemStack> getDroppedStacks(BlockState blockState, ServerWorld serverWorld, BlockPos blockPos, @Nullable BlockEntity blockEntity, @Nullable Entity entity, ItemStack itemStack) {
        LootContextParameterSet.Builder builder = new LootContextParameterSet.Builder(serverWorld).add(LootContextParameters.field_24424, Vec3d.ofCenter(blockPos)).add(LootContextParameters.field_1229, itemStack).addOptional(LootContextParameters.field_1226, entity).addOptional(LootContextParameters.field_1228, blockEntity);
        return blockState.getDroppedStacks(builder);
    }

    public static void dropStacks(BlockState blockState, World world, BlockPos blockPos) {
        if (world instanceof ServerWorld) {
            Block.getDroppedStacks(blockState, (ServerWorld)world, blockPos, null).forEach(itemStack -> Block.dropStack(world, blockPos, itemStack));
            blockState.onStacksDropped((ServerWorld)world, blockPos, ItemStack.EMPTY, true);
        }
    }

    public static void dropStacks(BlockState blockState, WorldAccess worldAccess, BlockPos blockPos, @Nullable BlockEntity blockEntity) {
        if (worldAccess instanceof ServerWorld) {
            Block.getDroppedStacks(blockState, (ServerWorld)worldAccess, blockPos, blockEntity).forEach(itemStack -> Block.dropStack((World)((ServerWorld)worldAccess), blockPos, itemStack));
            blockState.onStacksDropped((ServerWorld)worldAccess, blockPos, ItemStack.EMPTY, true);
        }
    }

    public static void dropStacks(BlockState blockState, World world, BlockPos blockPos, @Nullable BlockEntity blockEntity, @Nullable Entity entity, ItemStack itemStack2) {
        if (world instanceof ServerWorld) {
            Block.getDroppedStacks(blockState, (ServerWorld)world, blockPos, blockEntity, entity, itemStack2).forEach(itemStack -> Block.dropStack(world, blockPos, itemStack));
            blockState.onStacksDropped((ServerWorld)world, blockPos, itemStack2, true);
        }
    }

    public static void dropStack(World world, BlockPos blockPos, ItemStack itemStack) {
        double d = (double)EntityType.field_6052.getHeight() / 2.0;
        double e = (double)blockPos.getX() + 0.5 + MathHelper.nextDouble(world.random, -0.25, 0.25);
        double f = (double)blockPos.getY() + 0.5 + MathHelper.nextDouble(world.random, -0.25, 0.25) - d;
        double g = (double)blockPos.getZ() + 0.5 + MathHelper.nextDouble(world.random, -0.25, 0.25);
        Block.dropStack(world, () -> new ItemEntity(world, e, f, g, itemStack), itemStack);
    }

    public static void dropStack(World world, BlockPos blockPos, Direction direction, ItemStack itemStack) {
        int i = direction.getOffsetX();
        int j = direction.getOffsetY();
        int k = direction.getOffsetZ();
        double d = (double)EntityType.field_6052.getWidth() / 2.0;
        double e = (double)EntityType.field_6052.getHeight() / 2.0;
        double f = (double)blockPos.getX() + 0.5 + (i == 0 ? MathHelper.nextDouble(world.random, -0.25, 0.25) : (double)i * (0.5 + d));
        double g = (double)blockPos.getY() + 0.5 + (j == 0 ? MathHelper.nextDouble(world.random, -0.25, 0.25) : (double)j * (0.5 + e)) - e;
        double h = (double)blockPos.getZ() + 0.5 + (k == 0 ? MathHelper.nextDouble(world.random, -0.25, 0.25) : (double)k * (0.5 + d));
        double l = i == 0 ? MathHelper.nextDouble(world.random, -0.1, 0.1) : (double)i * 0.1;
        double m = j == 0 ? MathHelper.nextDouble(world.random, 0.0, 0.1) : (double)j * 0.1 + 0.1;
        double n = k == 0 ? MathHelper.nextDouble(world.random, -0.1, 0.1) : (double)k * 0.1;
        Block.dropStack(world, () -> new ItemEntity(world, f, g, h, itemStack, l, m, n), itemStack);
    }

    private static void dropStack(World world, Supplier<ItemEntity> supplier, ItemStack itemStack) {
        if (world.isClient || itemStack.isEmpty() || !world.getGameRules().getBoolean(GameRules.DO_TILE_DROPS)) {
            return;
        }
        ItemEntity itemEntity = supplier.get();
        itemEntity.setToDefaultPickupDelay();
        world.spawnEntity(itemEntity);
    }

    protected void dropExperience(ServerWorld serverWorld, BlockPos blockPos, int i) {
        if (serverWorld.getGameRules().getBoolean(GameRules.DO_TILE_DROPS)) {
            ExperienceOrbEntity.spawn(serverWorld, Vec3d.ofCenter(blockPos), i);
        }
    }

    public float getBlastResistance() {
        return this.resistance;
    }

    public void onDestroyedByExplosion(World world, BlockPos blockPos, Explosion explosion) {
    }

    public void onSteppedOn(World world, BlockPos blockPos, BlockState blockState, Entity entity) {
    }

    @Nullable
    public BlockState getPlacementState(ItemPlacementContext itemPlacementContext) {
        return this.getDefaultState();
    }

    public void afterBreak(World world, PlayerEntity playerEntity, BlockPos blockPos, BlockState blockState, @Nullable BlockEntity blockEntity, ItemStack itemStack) {
        playerEntity.incrementStat(Stats.field_15427.getOrCreateStat(this));
        playerEntity.addExhaustion(0.005f);
        Block.dropStacks(blockState, world, blockPos, blockEntity, playerEntity, itemStack);
    }

    public void onPlaced(World world, BlockPos blockPos, BlockState blockState, @Nullable LivingEntity livingEntity, ItemStack itemStack) {
    }

    public boolean canMobSpawnInside(BlockState blockState) {
        return !blockState.isSolid() && !blockState.isLiquid();
    }

    public MutableText getName() {
        return Text.translatable(this.getTranslationKey());
    }

    public String getTranslationKey() {
        if (this.translationKey == null) {
            this.translationKey = Util.createTranslationKey("block", Registries.BLOCK.getId(this));
        }
        return this.translationKey;
    }

    public void onLandedUpon(World world, BlockState blockState, BlockPos blockPos, Entity entity, float f) {
        entity.handleFallDamage(f, 1.0f, entity.getDamageSources().fall());
    }

    public void onEntityLand(BlockView blockView, Entity entity) {
        entity.setVelocity(entity.getVelocity().multiply(1.0, 0.0, 1.0));
    }

    public ItemStack getPickStack(BlockView blockView, BlockPos blockPos, BlockState blockState) {
        return new ItemStack(this);
    }

    public float getSlipperiness() {
        return this.slipperiness;
    }

    public float getVelocityMultiplier() {
        return this.velocityMultiplier;
    }

    public float getJumpVelocityMultiplier() {
        return this.jumpVelocityMultiplier;
    }

    protected void spawnBreakParticles(World world, PlayerEntity playerEntity, BlockPos blockPos, BlockState blockState) {
        world.syncWorldEvent(playerEntity, 2001, blockPos, Block.getRawIdFromState(blockState));
    }

    public void onBreak(World world, BlockPos blockPos, BlockState blockState, PlayerEntity playerEntity) {
        this.spawnBreakParticles(world, playerEntity, blockPos, blockState);
        if (blockState.isIn(BlockTags.field_23800)) {
            PiglinBrain.onGuardedBlockInteracted(playerEntity, false);
        }
        world.emitGameEvent(GameEvent.field_28165, blockPos, GameEvent.Emitter.of(playerEntity, blockState));
    }

    public void precipitationTick(BlockState blockState, World world, BlockPos blockPos, Biome.Precipitation precipitation) {
    }

    public boolean shouldDropItemsOnExplosion(Explosion explosion) {
        return true;
    }

    protected void appendProperties(StateManager.Builder<Block, BlockState> builder) {
    }

    public StateManager<Block, BlockState> getStateManager() {
        return this.stateManager;
    }

    protected final void setDefaultState(BlockState blockState) {
        this.defaultState = blockState;
    }

    public final BlockState getDefaultState() {
        return this.defaultState;
    }

    public final BlockState getStateWithProperties(BlockState blockState) {
        BlockState blockState2 = this.getDefaultState();
        for (Property<?> property : blockState.getBlock().getStateManager().getProperties()) {
            if (!blockState2.contains(property)) continue;
            blockState2 = Block.copyProperty(blockState, blockState2, property);
        }
        return blockState2;
    }

    private static <T extends Comparable<T>> BlockState copyProperty(BlockState blockState, BlockState blockState2, Property<T> property) {
        return (BlockState)blockState2.with(property, blockState.get(property));
    }

    public BlockSoundGroup getSoundGroup(BlockState blockState) {
        return this.soundGroup;
    }

    @Override
    public Item asItem() {
        if (this.cachedItem == null) {
            this.cachedItem = Item.fromBlock(this);
        }
        return this.cachedItem;
    }

    public boolean hasDynamicBounds() {
        return this.dynamicBounds;
    }

    public String toString() {
        return "Block{" + Registries.BLOCK.getId(this) + "}";
    }

    public void appendTooltip(ItemStack itemStack, @Nullable BlockView blockView, List<Text> list, TooltipContext tooltipContext) {
    }

    @Override
    protected Block asBlock() {
        return this;
    }

    protected ImmutableMap<BlockState, VoxelShape> getShapesForStates(Function<BlockState, VoxelShape> function) {
        return this.stateManager.getStates().stream().collect(ImmutableMap.toImmutableMap(Function.identity(), function));
    }

    @Deprecated
    public RegistryEntry.Reference<Block> getRegistryEntry() {
        return this.registryEntry;
    }

    protected void dropExperienceWhenMined(ServerWorld serverWorld, BlockPos blockPos, ItemStack itemStack, IntProvider intProvider) {
        int i;
        if (EnchantmentHelper.getLevel(Enchantments.field_9099, itemStack) == 0 && (i = intProvider.get(serverWorld.random)) > 0) {
            this.dropExperience(serverWorld, blockPos, i);
        }
    }

    public static final class NeighborGroup {
        private final BlockState self;
        private final BlockState other;
        private final Direction facing;

        public NeighborGroup(BlockState blockState, BlockState blockState2, Direction direction) {
            this.self = blockState;
            this.other = blockState2;
            this.facing = direction;
        }

        public boolean equals(Object object) {
            if (this == object) {
                return true;
            }
            if (!(object instanceof NeighborGroup)) {
                return false;
            }
            NeighborGroup neighborGroup = (NeighborGroup)object;
            return this.self == neighborGroup.self && this.other == neighborGroup.other && this.facing == neighborGroup.facing;
        }

        public int hashCode() {
            int i = this.self.hashCode();
            i = 31 * i + this.other.hashCode();
            i = 31 * i + this.facing.hashCode();
            return i;
        }
    }
}


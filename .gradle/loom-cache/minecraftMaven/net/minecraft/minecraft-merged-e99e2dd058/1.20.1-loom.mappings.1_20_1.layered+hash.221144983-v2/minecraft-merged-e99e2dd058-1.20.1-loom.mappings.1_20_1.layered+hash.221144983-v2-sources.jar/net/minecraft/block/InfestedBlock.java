/*
 * Decompiled with CFR 0.2.1 (FabricMC 53fa44c9).
 */
package net.minecraft.block;

import com.google.common.collect.Maps;
import java.util.Map;
import java.util.function.Supplier;
import net.minecraft.block.AbstractBlock;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.enchantment.Enchantments;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.mob.SilverfishEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.state.property.Property;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.GameRules;

public class InfestedBlock
extends Block {
    private final Block regularBlock;
    private static final Map<Block, Block> REGULAR_TO_INFESTED_BLOCK = Maps.newIdentityHashMap();
    private static final Map<BlockState, BlockState> REGULAR_TO_INFESTED_STATE = Maps.newIdentityHashMap();
    private static final Map<BlockState, BlockState> INFESTED_TO_REGULAR_STATE = Maps.newIdentityHashMap();

    public InfestedBlock(Block block, AbstractBlock.Settings settings) {
        super(settings.hardness(block.getHardness() / 2.0f).resistance(0.75f));
        this.regularBlock = block;
        REGULAR_TO_INFESTED_BLOCK.put(block, this);
    }

    public Block getRegularBlock() {
        return this.regularBlock;
    }

    public static boolean isInfestable(BlockState blockState) {
        return REGULAR_TO_INFESTED_BLOCK.containsKey(blockState.getBlock());
    }

    private void spawnSilverfish(ServerWorld serverWorld, BlockPos blockPos) {
        SilverfishEntity silverfishEntity = EntityType.field_6125.create(serverWorld);
        if (silverfishEntity != null) {
            silverfishEntity.refreshPositionAndAngles((double)blockPos.getX() + 0.5, blockPos.getY(), (double)blockPos.getZ() + 0.5, 0.0f, 0.0f);
            serverWorld.spawnEntity(silverfishEntity);
            silverfishEntity.playSpawnEffects();
        }
    }

    @Override
    public void onStacksDropped(BlockState blockState, ServerWorld serverWorld, BlockPos blockPos, ItemStack itemStack, boolean bl) {
        super.onStacksDropped(blockState, serverWorld, blockPos, itemStack, bl);
        if (serverWorld.getGameRules().getBoolean(GameRules.DO_TILE_DROPS) && EnchantmentHelper.getLevel(Enchantments.field_9099, itemStack) == 0) {
            this.spawnSilverfish(serverWorld, blockPos);
        }
    }

    public static BlockState fromRegularState(BlockState blockState) {
        return InfestedBlock.copyProperties(REGULAR_TO_INFESTED_STATE, blockState, () -> REGULAR_TO_INFESTED_BLOCK.get(blockState.getBlock()).getDefaultState());
    }

    public BlockState toRegularState(BlockState blockState) {
        return InfestedBlock.copyProperties(INFESTED_TO_REGULAR_STATE, blockState, () -> this.getRegularBlock().getDefaultState());
    }

    private static BlockState copyProperties(Map<BlockState, BlockState> map, BlockState blockState2, Supplier<BlockState> supplier) {
        return map.computeIfAbsent(blockState2, blockState -> {
            BlockState blockState2 = (BlockState)supplier.get();
            for (Property<?> property : blockState.getProperties()) {
                blockState2 = blockState2.contains(property) ? (BlockState)blockState2.with(property, blockState.get(property)) : blockState2;
            }
            return blockState2;
        });
    }
}


/*
 * Decompiled with CFR 0.2.1 (FabricMC 53fa44c9).
 */
package net.minecraft.item;

import java.util.List;
import net.minecraft.client.item.TooltipContext;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.enchantment.EnchantmentLevelEntry;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.nbt.NbtList;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import net.minecraft.world.World;
import org.jetbrains.annotations.Nullable;

public class EnchantedBookItem
extends Item {
    public static final String STORED_ENCHANTMENTS_KEY = "StoredEnchantments";

    public EnchantedBookItem(Item.Settings settings) {
        super(settings);
    }

    @Override
    public boolean hasGlint(ItemStack itemStack) {
        return true;
    }

    @Override
    public boolean isEnchantable(ItemStack itemStack) {
        return false;
    }

    public static NbtList getEnchantmentNbt(ItemStack itemStack) {
        NbtCompound nbtCompound = itemStack.getNbt();
        if (nbtCompound != null) {
            return nbtCompound.getList(STORED_ENCHANTMENTS_KEY, 10);
        }
        return new NbtList();
    }

    @Override
    public void appendTooltip(ItemStack itemStack, @Nullable World world, List<Text> list, TooltipContext tooltipContext) {
        super.appendTooltip(itemStack, world, list, tooltipContext);
        ItemStack.appendEnchantments(list, EnchantedBookItem.getEnchantmentNbt(itemStack));
    }

    public static void addEnchantment(ItemStack itemStack, EnchantmentLevelEntry enchantmentLevelEntry) {
        NbtList nbtList = EnchantedBookItem.getEnchantmentNbt(itemStack);
        boolean bl = true;
        Identifier identifier = EnchantmentHelper.getEnchantmentId(enchantmentLevelEntry.enchantment);
        for (int i = 0; i < nbtList.size(); ++i) {
            NbtCompound nbtCompound = nbtList.getCompound(i);
            Identifier identifier2 = EnchantmentHelper.getIdFromNbt(nbtCompound);
            if (identifier2 == null || !identifier2.equals(identifier)) continue;
            if (EnchantmentHelper.getLevelFromNbt(nbtCompound) < enchantmentLevelEntry.level) {
                EnchantmentHelper.writeLevelToNbt(nbtCompound, enchantmentLevelEntry.level);
            }
            bl = false;
            break;
        }
        if (bl) {
            nbtList.add(EnchantmentHelper.createNbt(identifier, enchantmentLevelEntry.level));
        }
        itemStack.getOrCreateNbt().put(STORED_ENCHANTMENTS_KEY, nbtList);
    }

    public static ItemStack forEnchantment(EnchantmentLevelEntry enchantmentLevelEntry) {
        ItemStack itemStack = new ItemStack(Items.field_8598);
        EnchantedBookItem.addEnchantment(itemStack, enchantmentLevelEntry);
        return itemStack;
    }
}


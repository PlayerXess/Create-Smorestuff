/*
 * Decompiled with CFR 0.2.1 (FabricMC 53fa44c9).
 */
package net.minecraft.block;

import it.unimi.dsi.fastutil.objects.Object2FloatMap;
import it.unimi.dsi.fastutil.objects.Object2FloatOpenHashMap;
import net.minecraft.block.AbstractBlock;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.InventoryProvider;
import net.minecraft.block.ShapeContext;
import net.minecraft.entity.Entity;
import net.minecraft.entity.ItemEntity;
import net.minecraft.entity.ai.pathing.NavigationType;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.inventory.SidedInventory;
import net.minecraft.inventory.SimpleInventory;
import net.minecraft.item.ItemConvertible;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.stat.Stats;
import net.minecraft.state.StateManager;
import net.minecraft.state.property.IntProperty;
import net.minecraft.state.property.Properties;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.Util;
import net.minecraft.util.function.BooleanBiFunction;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.math.random.Random;
import net.minecraft.util.shape.VoxelShape;
import net.minecraft.util.shape.VoxelShapes;
import net.minecraft.world.BlockView;
import net.minecraft.world.World;
import net.minecraft.world.WorldAccess;
import net.minecraft.world.event.GameEvent;
import org.jetbrains.annotations.Nullable;

public class ComposterBlock
extends Block
implements InventoryProvider {
    public static final int NUM_LEVELS = 8;
    public static final int MIN_LEVEL = 0;
    public static final int MAX_LEVEL = 7;
    public static final IntProperty LEVEL = Properties.LEVEL_8;
    public static final Object2FloatMap<ItemConvertible> ITEM_TO_LEVEL_INCREASE_CHANCE = new Object2FloatOpenHashMap<ItemConvertible>();
    private static final int field_31074 = 2;
    private static final VoxelShape RAYCAST_SHAPE = VoxelShapes.fullCube();
    private static final VoxelShape[] LEVEL_TO_COLLISION_SHAPE = Util.make(new VoxelShape[9], voxelShapes -> {
        for (int i = 0; i < 8; ++i) {
            voxelShapes[i] = VoxelShapes.combineAndSimplify(RAYCAST_SHAPE, Block.createCuboidShape(2.0, Math.max(2, 1 + i * 2), 2.0, 14.0, 16.0, 14.0), BooleanBiFunction.ONLY_FIRST);
        }
        voxelShapes[8] = voxelShapes[7];
    });

    public static void registerDefaultCompostableItems() {
        ITEM_TO_LEVEL_INCREASE_CHANCE.defaultReturnValue(-1.0f);
        float f = 0.3f;
        float g = 0.5f;
        float h = 0.65f;
        float i = 0.85f;
        float j = 1.0f;
        ComposterBlock.registerCompostableItem(0.3f, Items.JUNGLE_LEAVES);
        ComposterBlock.registerCompostableItem(0.3f, Items.OAK_LEAVES);
        ComposterBlock.registerCompostableItem(0.3f, Items.SPRUCE_LEAVES);
        ComposterBlock.registerCompostableItem(0.3f, Items.DARK_OAK_LEAVES);
        ComposterBlock.registerCompostableItem(0.3f, Items.ACACIA_LEAVES);
        ComposterBlock.registerCompostableItem(0.3f, Items.CHERRY_LEAVES);
        ComposterBlock.registerCompostableItem(0.3f, Items.BIRCH_LEAVES);
        ComposterBlock.registerCompostableItem(0.3f, Items.AZALEA_LEAVES);
        ComposterBlock.registerCompostableItem(0.3f, Items.MANGROVE_LEAVES);
        ComposterBlock.registerCompostableItem(0.3f, Items.OAK_SAPLING);
        ComposterBlock.registerCompostableItem(0.3f, Items.SPRUCE_SAPLING);
        ComposterBlock.registerCompostableItem(0.3f, Items.BIRCH_SAPLING);
        ComposterBlock.registerCompostableItem(0.3f, Items.JUNGLE_SAPLING);
        ComposterBlock.registerCompostableItem(0.3f, Items.ACACIA_SAPLING);
        ComposterBlock.registerCompostableItem(0.3f, Items.CHERRY_SAPLING);
        ComposterBlock.registerCompostableItem(0.3f, Items.DARK_OAK_SAPLING);
        ComposterBlock.registerCompostableItem(0.3f, Items.MANGROVE_PROPAGULE);
        ComposterBlock.registerCompostableItem(0.3f, Items.field_8309);
        ComposterBlock.registerCompostableItem(0.3f, Items.field_8551);
        ComposterBlock.registerCompostableItem(0.3f, Items.GRASS);
        ComposterBlock.registerCompostableItem(0.3f, Items.KELP);
        ComposterBlock.registerCompostableItem(0.3f, Items.field_8188);
        ComposterBlock.registerCompostableItem(0.3f, Items.field_8706);
        ComposterBlock.registerCompostableItem(0.3f, Items.SEAGRASS);
        ComposterBlock.registerCompostableItem(0.3f, Items.field_16998);
        ComposterBlock.registerCompostableItem(0.3f, Items.field_28659);
        ComposterBlock.registerCompostableItem(0.3f, Items.field_8317);
        ComposterBlock.registerCompostableItem(0.3f, Items.MOSS_CARPET);
        ComposterBlock.registerCompostableItem(0.3f, Items.PINK_PETALS);
        ComposterBlock.registerCompostableItem(0.3f, Items.SMALL_DRIPLEAF);
        ComposterBlock.registerCompostableItem(0.3f, Items.HANGING_ROOTS);
        ComposterBlock.registerCompostableItem(0.3f, Items.MANGROVE_ROOTS);
        ComposterBlock.registerCompostableItem(0.3f, Items.field_42711);
        ComposterBlock.registerCompostableItem(0.3f, Items.field_43195);
        ComposterBlock.registerCompostableItem(0.5f, Items.DRIED_KELP_BLOCK);
        ComposterBlock.registerCompostableItem(0.5f, Items.TALL_GRASS);
        ComposterBlock.registerCompostableItem(0.5f, Items.FLOWERING_AZALEA_LEAVES);
        ComposterBlock.registerCompostableItem(0.5f, Items.CACTUS);
        ComposterBlock.registerCompostableItem(0.5f, Items.SUGAR_CANE);
        ComposterBlock.registerCompostableItem(0.5f, Items.VINE);
        ComposterBlock.registerCompostableItem(0.5f, Items.NETHER_SPROUTS);
        ComposterBlock.registerCompostableItem(0.5f, Items.WEEPING_VINES);
        ComposterBlock.registerCompostableItem(0.5f, Items.TWISTING_VINES);
        ComposterBlock.registerCompostableItem(0.5f, Items.field_8497);
        ComposterBlock.registerCompostableItem(0.5f, Items.GLOW_LICHEN);
        ComposterBlock.registerCompostableItem(0.65f, Items.SEA_PICKLE);
        ComposterBlock.registerCompostableItem(0.65f, Items.LILY_PAD);
        ComposterBlock.registerCompostableItem(0.65f, Items.PUMPKIN);
        ComposterBlock.registerCompostableItem(0.65f, Items.CARVED_PUMPKIN);
        ComposterBlock.registerCompostableItem(0.65f, Items.MELON);
        ComposterBlock.registerCompostableItem(0.65f, Items.field_8279);
        ComposterBlock.registerCompostableItem(0.65f, Items.field_8186);
        ComposterBlock.registerCompostableItem(0.65f, Items.field_8179);
        ComposterBlock.registerCompostableItem(0.65f, Items.field_8116);
        ComposterBlock.registerCompostableItem(0.65f, Items.field_8567);
        ComposterBlock.registerCompostableItem(0.65f, Items.field_8861);
        ComposterBlock.registerCompostableItem(0.65f, Items.BROWN_MUSHROOM);
        ComposterBlock.registerCompostableItem(0.65f, Items.RED_MUSHROOM);
        ComposterBlock.registerCompostableItem(0.65f, Items.MUSHROOM_STEM);
        ComposterBlock.registerCompostableItem(0.65f, Items.CRIMSON_FUNGUS);
        ComposterBlock.registerCompostableItem(0.65f, Items.WARPED_FUNGUS);
        ComposterBlock.registerCompostableItem(0.65f, Items.field_8790);
        ComposterBlock.registerCompostableItem(0.65f, Items.CRIMSON_ROOTS);
        ComposterBlock.registerCompostableItem(0.65f, Items.WARPED_ROOTS);
        ComposterBlock.registerCompostableItem(0.65f, Items.SHROOMLIGHT);
        ComposterBlock.registerCompostableItem(0.65f, Items.DANDELION);
        ComposterBlock.registerCompostableItem(0.65f, Items.POPPY);
        ComposterBlock.registerCompostableItem(0.65f, Items.BLUE_ORCHID);
        ComposterBlock.registerCompostableItem(0.65f, Items.ALLIUM);
        ComposterBlock.registerCompostableItem(0.65f, Items.AZURE_BLUET);
        ComposterBlock.registerCompostableItem(0.65f, Items.RED_TULIP);
        ComposterBlock.registerCompostableItem(0.65f, Items.ORANGE_TULIP);
        ComposterBlock.registerCompostableItem(0.65f, Items.WHITE_TULIP);
        ComposterBlock.registerCompostableItem(0.65f, Items.PINK_TULIP);
        ComposterBlock.registerCompostableItem(0.65f, Items.OXEYE_DAISY);
        ComposterBlock.registerCompostableItem(0.65f, Items.CORNFLOWER);
        ComposterBlock.registerCompostableItem(0.65f, Items.LILY_OF_THE_VALLEY);
        ComposterBlock.registerCompostableItem(0.65f, Items.WITHER_ROSE);
        ComposterBlock.registerCompostableItem(0.65f, Items.FERN);
        ComposterBlock.registerCompostableItem(0.65f, Items.SUNFLOWER);
        ComposterBlock.registerCompostableItem(0.65f, Items.LILAC);
        ComposterBlock.registerCompostableItem(0.65f, Items.ROSE_BUSH);
        ComposterBlock.registerCompostableItem(0.65f, Items.PEONY);
        ComposterBlock.registerCompostableItem(0.65f, Items.LARGE_FERN);
        ComposterBlock.registerCompostableItem(0.65f, Items.SPORE_BLOSSOM);
        ComposterBlock.registerCompostableItem(0.65f, Items.AZALEA);
        ComposterBlock.registerCompostableItem(0.65f, Items.MOSS_BLOCK);
        ComposterBlock.registerCompostableItem(0.65f, Items.BIG_DRIPLEAF);
        ComposterBlock.registerCompostableItem(0.85f, Items.HAY_BLOCK);
        ComposterBlock.registerCompostableItem(0.85f, Items.BROWN_MUSHROOM_BLOCK);
        ComposterBlock.registerCompostableItem(0.85f, Items.RED_MUSHROOM_BLOCK);
        ComposterBlock.registerCompostableItem(0.85f, Items.NETHER_WART_BLOCK);
        ComposterBlock.registerCompostableItem(0.85f, Items.WARPED_WART_BLOCK);
        ComposterBlock.registerCompostableItem(0.85f, Items.FLOWERING_AZALEA);
        ComposterBlock.registerCompostableItem(0.85f, Items.field_8229);
        ComposterBlock.registerCompostableItem(0.85f, Items.field_8512);
        ComposterBlock.registerCompostableItem(0.85f, Items.field_8423);
        ComposterBlock.registerCompostableItem(0.85f, Items.TORCHFLOWER);
        ComposterBlock.registerCompostableItem(0.85f, Items.PITCHER_PLANT);
        ComposterBlock.registerCompostableItem(1.0f, Items.CAKE);
        ComposterBlock.registerCompostableItem(1.0f, Items.field_8741);
    }

    private static void registerCompostableItem(float f, ItemConvertible itemConvertible) {
        ITEM_TO_LEVEL_INCREASE_CHANCE.put((ItemConvertible)itemConvertible.asItem(), f);
    }

    public ComposterBlock(AbstractBlock.Settings settings) {
        super(settings);
        this.setDefaultState((BlockState)((BlockState)this.stateManager.getDefaultState()).with(LEVEL, 0));
    }

    public static void playEffects(World world, BlockPos blockPos, boolean bl) {
        BlockState blockState = world.getBlockState(blockPos);
        world.playSoundAtBlockCenter(blockPos, bl ? SoundEvents.field_17608 : SoundEvents.field_17607, SoundCategory.field_15245, 1.0f, 1.0f, false);
        double d = blockState.getOutlineShape(world, blockPos).getEndingCoord(Direction.Axis.field_11052, 0.5, 0.5) + 0.03125;
        double e = 0.13125f;
        double f = 0.7375f;
        Random random = world.getRandom();
        for (int i = 0; i < 10; ++i) {
            double g = random.nextGaussian() * 0.02;
            double h = random.nextGaussian() * 0.02;
            double j = random.nextGaussian() * 0.02;
            world.addParticle(ParticleTypes.field_17741, (double)blockPos.getX() + (double)0.13125f + (double)0.7375f * (double)random.nextFloat(), (double)blockPos.getY() + d + (double)random.nextFloat() * (1.0 - d), (double)blockPos.getZ() + (double)0.13125f + (double)0.7375f * (double)random.nextFloat(), g, h, j);
        }
    }

    @Override
    public VoxelShape getOutlineShape(BlockState blockState, BlockView blockView, BlockPos blockPos, ShapeContext shapeContext) {
        return LEVEL_TO_COLLISION_SHAPE[blockState.get(LEVEL)];
    }

    @Override
    public VoxelShape getRaycastShape(BlockState blockState, BlockView blockView, BlockPos blockPos) {
        return RAYCAST_SHAPE;
    }

    @Override
    public VoxelShape getCollisionShape(BlockState blockState, BlockView blockView, BlockPos blockPos, ShapeContext shapeContext) {
        return LEVEL_TO_COLLISION_SHAPE[0];
    }

    @Override
    public void onBlockAdded(BlockState blockState, World world, BlockPos blockPos, BlockState blockState2, boolean bl) {
        if (blockState.get(LEVEL) == 7) {
            world.scheduleBlockTick(blockPos, blockState.getBlock(), 20);
        }
    }

    @Override
    public ActionResult onUse(BlockState blockState, World world, BlockPos blockPos, PlayerEntity playerEntity, Hand hand, BlockHitResult blockHitResult) {
        int i = blockState.get(LEVEL);
        ItemStack itemStack = playerEntity.getStackInHand(hand);
        if (i < 8 && ITEM_TO_LEVEL_INCREASE_CHANCE.containsKey(itemStack.getItem())) {
            if (i < 7 && !world.isClient) {
                BlockState blockState2 = ComposterBlock.addToComposter(playerEntity, blockState, world, blockPos, itemStack);
                world.syncWorldEvent(1500, blockPos, blockState != blockState2 ? 1 : 0);
                playerEntity.incrementStat(Stats.field_15372.getOrCreateStat(itemStack.getItem()));
                if (!playerEntity.getAbilities().creativeMode) {
                    itemStack.decrement(1);
                }
            }
            return ActionResult.success(world.isClient);
        }
        if (i == 8) {
            ComposterBlock.emptyFullComposter(playerEntity, blockState, world, blockPos);
            return ActionResult.success(world.isClient);
        }
        return ActionResult.PASS;
    }

    public static BlockState compost(Entity entity, BlockState blockState, ServerWorld serverWorld, ItemStack itemStack, BlockPos blockPos) {
        int i = blockState.get(LEVEL);
        if (i < 7 && ITEM_TO_LEVEL_INCREASE_CHANCE.containsKey(itemStack.getItem())) {
            BlockState blockState2 = ComposterBlock.addToComposter(entity, blockState, serverWorld, blockPos, itemStack);
            itemStack.decrement(1);
            return blockState2;
        }
        return blockState;
    }

    public static BlockState emptyFullComposter(Entity entity, BlockState blockState, World world, BlockPos blockPos) {
        if (!world.isClient) {
            Vec3d vec3d = Vec3d.add(blockPos, 0.5, 1.01, 0.5).addRandom(world.random, 0.7f);
            ItemEntity itemEntity = new ItemEntity(world, vec3d.getX(), vec3d.getY(), vec3d.getZ(), new ItemStack(Items.field_8324));
            itemEntity.setToDefaultPickupDelay();
            world.spawnEntity(itemEntity);
        }
        BlockState blockState2 = ComposterBlock.emptyComposter(entity, blockState, world, blockPos);
        world.playSound(null, blockPos, SoundEvents.field_17606, SoundCategory.field_15245, 1.0f, 1.0f);
        return blockState2;
    }

    static BlockState emptyComposter(@Nullable Entity entity, BlockState blockState, WorldAccess worldAccess, BlockPos blockPos) {
        BlockState blockState2 = (BlockState)blockState.with(LEVEL, 0);
        worldAccess.setBlockState(blockPos, blockState2, 3);
        worldAccess.emitGameEvent(GameEvent.field_28733, blockPos, GameEvent.Emitter.of(entity, blockState2));
        return blockState2;
    }

    static BlockState addToComposter(@Nullable Entity entity, BlockState blockState, WorldAccess worldAccess, BlockPos blockPos, ItemStack itemStack) {
        int i = blockState.get(LEVEL);
        float f = ITEM_TO_LEVEL_INCREASE_CHANCE.getFloat(itemStack.getItem());
        if (i == 0 && f > 0.0f || worldAccess.getRandom().nextDouble() < (double)f) {
            int j = i + 1;
            BlockState blockState2 = (BlockState)blockState.with(LEVEL, j);
            worldAccess.setBlockState(blockPos, blockState2, 3);
            worldAccess.emitGameEvent(GameEvent.field_28733, blockPos, GameEvent.Emitter.of(entity, blockState2));
            if (j == 7) {
                worldAccess.scheduleBlockTick(blockPos, blockState.getBlock(), 20);
            }
            return blockState2;
        }
        return blockState;
    }

    @Override
    public void scheduledTick(BlockState blockState, ServerWorld serverWorld, BlockPos blockPos, Random random) {
        if (blockState.get(LEVEL) == 7) {
            serverWorld.setBlockState(blockPos, (BlockState)blockState.cycle(LEVEL), 3);
            serverWorld.playSound(null, blockPos, SoundEvents.field_17609, SoundCategory.field_15245, 1.0f, 1.0f);
        }
    }

    @Override
    public boolean hasComparatorOutput(BlockState blockState) {
        return true;
    }

    @Override
    public int getComparatorOutput(BlockState blockState, World world, BlockPos blockPos) {
        return blockState.get(LEVEL);
    }

    @Override
    protected void appendProperties(StateManager.Builder<Block, BlockState> builder) {
        builder.add(LEVEL);
    }

    @Override
    public boolean canPathfindThrough(BlockState blockState, BlockView blockView, BlockPos blockPos, NavigationType navigationType) {
        return false;
    }

    @Override
    public SidedInventory getInventory(BlockState blockState, WorldAccess worldAccess, BlockPos blockPos) {
        int i = blockState.get(LEVEL);
        if (i == 8) {
            return new FullComposterInventory(blockState, worldAccess, blockPos, new ItemStack(Items.field_8324));
        }
        if (i < 7) {
            return new ComposterInventory(blockState, worldAccess, blockPos);
        }
        return new DummyInventory();
    }

    static class FullComposterInventory
    extends SimpleInventory
    implements SidedInventory {
        private final BlockState state;
        private final WorldAccess world;
        private final BlockPos pos;
        private boolean dirty;

        public FullComposterInventory(BlockState blockState, WorldAccess worldAccess, BlockPos blockPos, ItemStack itemStack) {
            super(itemStack);
            this.state = blockState;
            this.world = worldAccess;
            this.pos = blockPos;
        }

        @Override
        public int getMaxCountPerStack() {
            return 1;
        }

        @Override
        public int[] getAvailableSlots(Direction direction) {
            int[] nArray;
            if (direction == Direction.field_11033) {
                int[] nArray2 = new int[1];
                nArray = nArray2;
                nArray2[0] = 0;
            } else {
                nArray = new int[]{};
            }
            return nArray;
        }

        @Override
        public boolean canInsert(int i, ItemStack itemStack, @Nullable Direction direction) {
            return false;
        }

        @Override
        public boolean canExtract(int i, ItemStack itemStack, Direction direction) {
            return !this.dirty && direction == Direction.field_11033 && itemStack.isOf(Items.field_8324);
        }

        @Override
        public void markDirty() {
            ComposterBlock.emptyComposter(null, this.state, this.world, this.pos);
            this.dirty = true;
        }
    }

    static class ComposterInventory
    extends SimpleInventory
    implements SidedInventory {
        private final BlockState state;
        private final WorldAccess world;
        private final BlockPos pos;
        private boolean dirty;

        public ComposterInventory(BlockState blockState, WorldAccess worldAccess, BlockPos blockPos) {
            super(1);
            this.state = blockState;
            this.world = worldAccess;
            this.pos = blockPos;
        }

        @Override
        public int getMaxCountPerStack() {
            return 1;
        }

        @Override
        public int[] getAvailableSlots(Direction direction) {
            int[] nArray;
            if (direction == Direction.field_11036) {
                int[] nArray2 = new int[1];
                nArray = nArray2;
                nArray2[0] = 0;
            } else {
                nArray = new int[]{};
            }
            return nArray;
        }

        @Override
        public boolean canInsert(int i, ItemStack itemStack, @Nullable Direction direction) {
            return !this.dirty && direction == Direction.field_11036 && ITEM_TO_LEVEL_INCREASE_CHANCE.containsKey(itemStack.getItem());
        }

        @Override
        public boolean canExtract(int i, ItemStack itemStack, Direction direction) {
            return false;
        }

        @Override
        public void markDirty() {
            ItemStack itemStack = this.getStack(0);
            if (!itemStack.isEmpty()) {
                this.dirty = true;
                BlockState blockState = ComposterBlock.addToComposter(null, this.state, this.world, this.pos, itemStack);
                this.world.syncWorldEvent(1500, this.pos, blockState != this.state ? 1 : 0);
                this.removeStack(0);
            }
        }
    }

    static class DummyInventory
    extends SimpleInventory
    implements SidedInventory {
        public DummyInventory() {
            super(0);
        }

        @Override
        public int[] getAvailableSlots(Direction direction) {
            return new int[0];
        }

        @Override
        public boolean canInsert(int i, ItemStack itemStack, @Nullable Direction direction) {
            return false;
        }

        @Override
        public boolean canExtract(int i, ItemStack itemStack, Direction direction) {
            return false;
        }
    }
}


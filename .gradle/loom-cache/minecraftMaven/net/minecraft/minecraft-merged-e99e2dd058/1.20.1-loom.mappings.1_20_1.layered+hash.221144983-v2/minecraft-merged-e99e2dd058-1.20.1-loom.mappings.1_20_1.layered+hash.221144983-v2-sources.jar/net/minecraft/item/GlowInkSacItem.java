/*
 * Decompiled with CFR 0.2.1 (FabricMC 53fa44c9).
 */
package net.minecraft.item;

import net.minecraft.block.entity.SignBlockEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.SignChangingItem;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.world.World;

public class GlowInkSacItem
extends Item
implements SignChangingItem {
    public GlowInkSacItem(Item.Settings settings) {
        super(settings);
    }

    @Override
    public boolean useOnSign(World world, SignBlockEntity signBlockEntity, boolean bl, PlayerEntity playerEntity) {
        if (signBlockEntity.changeText(signText -> signText.withGlowing(true), bl)) {
            world.playSound(null, signBlockEntity.getPos(), SoundEvents.field_28392, SoundCategory.field_15245, 1.0f, 1.0f);
            return true;
        }
        return false;
    }
}


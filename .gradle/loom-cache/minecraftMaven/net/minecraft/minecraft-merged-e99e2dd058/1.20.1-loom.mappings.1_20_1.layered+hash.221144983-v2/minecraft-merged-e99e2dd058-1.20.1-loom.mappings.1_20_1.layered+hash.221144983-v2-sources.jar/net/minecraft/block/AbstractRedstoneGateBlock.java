/*
 * Decompiled with CFR 0.2.1 (FabricMC 53fa44c9).
 */
package net.minecraft.block;

import net.minecraft.block.AbstractBlock;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.HorizontalFacingBlock;
import net.minecraft.block.RedstoneWireBlock;
import net.minecraft.block.ShapeContext;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.ItemPlacementContext;
import net.minecraft.item.ItemStack;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.state.property.BooleanProperty;
import net.minecraft.state.property.Properties;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.random.Random;
import net.minecraft.util.shape.VoxelShape;
import net.minecraft.world.BlockView;
import net.minecraft.world.RedstoneView;
import net.minecraft.world.World;
import net.minecraft.world.WorldView;
import net.minecraft.world.tick.TickPriority;

public abstract class AbstractRedstoneGateBlock
extends HorizontalFacingBlock {
    protected static final VoxelShape SHAPE = Block.createCuboidShape(0.0, 0.0, 0.0, 16.0, 2.0, 16.0);
    public static final BooleanProperty POWERED = Properties.POWERED;

    protected AbstractRedstoneGateBlock(AbstractBlock.Settings settings) {
        super(settings);
    }

    @Override
    public VoxelShape getOutlineShape(BlockState blockState, BlockView blockView, BlockPos blockPos, ShapeContext shapeContext) {
        return SHAPE;
    }

    @Override
    public boolean canPlaceAt(BlockState blockState, WorldView worldView, BlockPos blockPos) {
        return AbstractRedstoneGateBlock.hasTopRim(worldView, blockPos.down());
    }

    @Override
    public void scheduledTick(BlockState blockState, ServerWorld serverWorld, BlockPos blockPos, Random random) {
        if (this.isLocked(serverWorld, blockPos, blockState)) {
            return;
        }
        boolean bl = blockState.get(POWERED);
        boolean bl2 = this.hasPower(serverWorld, blockPos, blockState);
        if (bl && !bl2) {
            serverWorld.setBlockState(blockPos, (BlockState)blockState.with(POWERED, false), 2);
        } else if (!bl) {
            serverWorld.setBlockState(blockPos, (BlockState)blockState.with(POWERED, true), 2);
            if (!bl2) {
                serverWorld.scheduleBlockTick(blockPos, this, this.getUpdateDelayInternal(blockState), TickPriority.field_9313);
            }
        }
    }

    @Override
    public int getStrongRedstonePower(BlockState blockState, BlockView blockView, BlockPos blockPos, Direction direction) {
        return blockState.getWeakRedstonePower(blockView, blockPos, direction);
    }

    @Override
    public int getWeakRedstonePower(BlockState blockState, BlockView blockView, BlockPos blockPos, Direction direction) {
        if (!blockState.get(POWERED).booleanValue()) {
            return 0;
        }
        if (blockState.get(FACING) == direction) {
            return this.getOutputLevel(blockView, blockPos, blockState);
        }
        return 0;
    }

    @Override
    public void neighborUpdate(BlockState blockState, World world, BlockPos blockPos, Block block, BlockPos blockPos2, boolean bl) {
        if (blockState.canPlaceAt(world, blockPos)) {
            this.updatePowered(world, blockPos, blockState);
            return;
        }
        BlockEntity blockEntity = blockState.hasBlockEntity() ? world.getBlockEntity(blockPos) : null;
        AbstractRedstoneGateBlock.dropStacks(blockState, world, blockPos, blockEntity);
        world.removeBlock(blockPos, false);
        for (Direction direction : Direction.values()) {
            world.updateNeighborsAlways(blockPos.offset(direction), this);
        }
    }

    protected void updatePowered(World world, BlockPos blockPos, BlockState blockState) {
        boolean bl2;
        if (this.isLocked(world, blockPos, blockState)) {
            return;
        }
        boolean bl = blockState.get(POWERED);
        if (bl != (bl2 = this.hasPower(world, blockPos, blockState)) && !world.getBlockTickScheduler().isTicking(blockPos, this)) {
            TickPriority tickPriority = TickPriority.field_9310;
            if (this.isTargetNotAligned(world, blockPos, blockState)) {
                tickPriority = TickPriority.field_9315;
            } else if (bl) {
                tickPriority = TickPriority.field_9313;
            }
            world.scheduleBlockTick(blockPos, this, this.getUpdateDelayInternal(blockState), tickPriority);
        }
    }

    public boolean isLocked(WorldView worldView, BlockPos blockPos, BlockState blockState) {
        return false;
    }

    protected boolean hasPower(World world, BlockPos blockPos, BlockState blockState) {
        return this.getPower(world, blockPos, blockState) > 0;
    }

    protected int getPower(World world, BlockPos blockPos, BlockState blockState) {
        Direction direction = blockState.get(FACING);
        BlockPos blockPos2 = blockPos.offset(direction);
        int i = world.getEmittedRedstonePower(blockPos2, direction);
        if (i >= 15) {
            return i;
        }
        BlockState blockState2 = world.getBlockState(blockPos2);
        return Math.max(i, blockState2.isOf(Blocks.field_10091) ? blockState2.get(RedstoneWireBlock.POWER) : 0);
    }

    protected int getMaxInputLevelSides(RedstoneView redstoneView, BlockPos blockPos, BlockState blockState) {
        Direction direction = blockState.get(FACING);
        Direction direction2 = direction.rotateYClockwise();
        Direction direction3 = direction.rotateYCounterclockwise();
        boolean bl = this.getSideInputFromGatesOnly();
        return Math.max(redstoneView.getEmittedRedstonePower(blockPos.offset(direction2), direction2, bl), redstoneView.getEmittedRedstonePower(blockPos.offset(direction3), direction3, bl));
    }

    @Override
    public boolean emitsRedstonePower(BlockState blockState) {
        return true;
    }

    @Override
    public BlockState getPlacementState(ItemPlacementContext itemPlacementContext) {
        return (BlockState)this.getDefaultState().with(FACING, itemPlacementContext.getHorizontalPlayerFacing().getOpposite());
    }

    @Override
    public void onPlaced(World world, BlockPos blockPos, BlockState blockState, LivingEntity livingEntity, ItemStack itemStack) {
        if (this.hasPower(world, blockPos, blockState)) {
            world.scheduleBlockTick(blockPos, this, 1);
        }
    }

    @Override
    public void onBlockAdded(BlockState blockState, World world, BlockPos blockPos, BlockState blockState2, boolean bl) {
        this.updateTarget(world, blockPos, blockState);
    }

    @Override
    public void onStateReplaced(BlockState blockState, World world, BlockPos blockPos, BlockState blockState2, boolean bl) {
        if (bl || blockState.isOf(blockState2.getBlock())) {
            return;
        }
        super.onStateReplaced(blockState, world, blockPos, blockState2, bl);
        this.updateTarget(world, blockPos, blockState);
    }

    protected void updateTarget(World world, BlockPos blockPos, BlockState blockState) {
        Direction direction = blockState.get(FACING);
        BlockPos blockPos2 = blockPos.offset(direction.getOpposite());
        world.updateNeighbor(blockPos2, this, blockPos);
        world.updateNeighborsExcept(blockPos2, this, direction);
    }

    protected boolean getSideInputFromGatesOnly() {
        return false;
    }

    protected int getOutputLevel(BlockView blockView, BlockPos blockPos, BlockState blockState) {
        return 15;
    }

    public static boolean isRedstoneGate(BlockState blockState) {
        return blockState.getBlock() instanceof AbstractRedstoneGateBlock;
    }

    public boolean isTargetNotAligned(BlockView blockView, BlockPos blockPos, BlockState blockState) {
        Direction direction = blockState.get(FACING).getOpposite();
        BlockState blockState2 = blockView.getBlockState(blockPos.offset(direction));
        return AbstractRedstoneGateBlock.isRedstoneGate(blockState2) && blockState2.get(FACING) != direction;
    }

    protected abstract int getUpdateDelayInternal(BlockState var1);
}


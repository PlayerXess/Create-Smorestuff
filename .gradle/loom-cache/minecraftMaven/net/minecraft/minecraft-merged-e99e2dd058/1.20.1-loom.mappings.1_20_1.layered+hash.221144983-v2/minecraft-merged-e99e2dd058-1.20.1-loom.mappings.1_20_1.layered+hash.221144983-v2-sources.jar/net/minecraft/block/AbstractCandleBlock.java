/*
 * Decompiled with CFR 0.2.1 (FabricMC 53fa44c9).
 */
package net.minecraft.block;

import net.minecraft.block.AbstractBlock;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.projectile.ProjectileEntity;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.registry.tag.BlockTags;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.state.property.BooleanProperty;
import net.minecraft.state.property.Properties;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.math.random.Random;
import net.minecraft.world.World;
import net.minecraft.world.WorldAccess;
import net.minecraft.world.event.GameEvent;
import org.jetbrains.annotations.Nullable;

public abstract class AbstractCandleBlock
extends Block {
    public static final int field_30987 = 3;
    public static final BooleanProperty LIT = Properties.LIT;

    protected AbstractCandleBlock(AbstractBlock.Settings settings) {
        super(settings);
    }

    protected abstract Iterable<Vec3d> getParticleOffsets(BlockState var1);

    public static boolean isLitCandle(BlockState blockState) {
        return blockState.contains(LIT) && (blockState.isIn(BlockTags.field_26983) || blockState.isIn(BlockTags.field_26984)) && blockState.get(LIT) != false;
    }

    @Override
    public void onProjectileHit(World world, BlockState blockState, BlockHitResult blockHitResult, ProjectileEntity projectileEntity) {
        if (!world.isClient && projectileEntity.isOnFire() && this.isNotLit(blockState)) {
            AbstractCandleBlock.setLit(world, blockState, blockHitResult.getBlockPos(), true);
        }
    }

    protected boolean isNotLit(BlockState blockState) {
        return blockState.get(LIT) == false;
    }

    @Override
    public void randomDisplayTick(BlockState blockState, World world, BlockPos blockPos, Random random) {
        if (!blockState.get(LIT).booleanValue()) {
            return;
        }
        this.getParticleOffsets(blockState).forEach(vec3d -> AbstractCandleBlock.spawnCandleParticles(world, vec3d.add(blockPos.getX(), blockPos.getY(), blockPos.getZ()), random));
    }

    private static void spawnCandleParticles(World world, Vec3d vec3d, Random random) {
        float f = random.nextFloat();
        if (f < 0.3f) {
            world.addParticle(ParticleTypes.field_11251, vec3d.x, vec3d.y, vec3d.z, 0.0, 0.0, 0.0);
            if (f < 0.17f) {
                world.playSound(vec3d.x + 0.5, vec3d.y + 0.5, vec3d.z + 0.5, SoundEvents.field_26953, SoundCategory.field_15245, 1.0f + random.nextFloat(), random.nextFloat() * 0.7f + 0.3f, false);
            }
        }
        world.addParticle(ParticleTypes.field_27783, vec3d.x, vec3d.y, vec3d.z, 0.0, 0.0, 0.0);
    }

    public static void extinguish(@Nullable PlayerEntity playerEntity, BlockState blockState, WorldAccess worldAccess, BlockPos blockPos) {
        AbstractCandleBlock.setLit(worldAccess, blockState, blockPos, false);
        if (blockState.getBlock() instanceof AbstractCandleBlock) {
            ((AbstractCandleBlock)blockState.getBlock()).getParticleOffsets(blockState).forEach(vec3d -> worldAccess.addParticle(ParticleTypes.field_11251, (double)blockPos.getX() + vec3d.getX(), (double)blockPos.getY() + vec3d.getY(), (double)blockPos.getZ() + vec3d.getZ(), 0.0, 0.1f, 0.0));
        }
        worldAccess.playSound(null, blockPos, SoundEvents.field_26955, SoundCategory.field_15245, 1.0f, 1.0f);
        worldAccess.emitGameEvent((Entity)playerEntity, GameEvent.field_28733, blockPos);
    }

    private static void setLit(WorldAccess worldAccess, BlockState blockState, BlockPos blockPos, boolean bl) {
        worldAccess.setBlockState(blockPos, (BlockState)blockState.with(LIT, bl), 11);
    }
}


/*
 * Decompiled with CFR 0.2.1 (FabricMC 53fa44c9).
 */
package net.minecraft.block;

import net.minecraft.block.AbstractBlock;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.fluid.FluidState;
import net.minecraft.item.ItemPlacementContext;
import net.minecraft.registry.tag.FluidTags;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.random.Random;
import net.minecraft.world.BlockView;
import net.minecraft.world.WorldAccess;
import org.jetbrains.annotations.Nullable;

public class CoralBlockBlock
extends Block {
    private final Block deadCoralBlock;

    public CoralBlockBlock(Block block, AbstractBlock.Settings settings) {
        super(settings);
        this.deadCoralBlock = block;
    }

    @Override
    public void scheduledTick(BlockState blockState, ServerWorld serverWorld, BlockPos blockPos, Random random) {
        if (!this.isInWater(serverWorld, blockPos)) {
            serverWorld.setBlockState(blockPos, this.deadCoralBlock.getDefaultState(), 2);
        }
    }

    @Override
    public BlockState getStateForNeighborUpdate(BlockState blockState, Direction direction, BlockState blockState2, WorldAccess worldAccess, BlockPos blockPos, BlockPos blockPos2) {
        if (!this.isInWater(worldAccess, blockPos)) {
            worldAccess.scheduleBlockTick(blockPos, this, 60 + worldAccess.getRandom().nextInt(40));
        }
        return super.getStateForNeighborUpdate(blockState, direction, blockState2, worldAccess, blockPos, blockPos2);
    }

    protected boolean isInWater(BlockView blockView, BlockPos blockPos) {
        for (Direction direction : Direction.values()) {
            FluidState fluidState = blockView.getFluidState(blockPos.offset(direction));
            if (!fluidState.isIn(FluidTags.field_15517)) continue;
            return true;
        }
        return false;
    }

    @Override
    @Nullable
    public BlockState getPlacementState(ItemPlacementContext itemPlacementContext) {
        if (!this.isInWater(itemPlacementContext.getWorld(), itemPlacementContext.getBlockPos())) {
            itemPlacementContext.getWorld().scheduleBlockTick(itemPlacementContext.getBlockPos(), this, 60 + itemPlacementContext.getWorld().getRandom().nextInt(40));
        }
        return this.getDefaultState();
    }
}


/*
 * Decompiled with CFR 0.2.1 (FabricMC 53fa44c9).
 */
package net.minecraft.block;

import net.minecraft.block.AbstractBlock;
import net.minecraft.block.Block;
import net.minecraft.block.BlockSetType;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.ShapeContext;
import net.minecraft.entity.Entity;
import net.minecraft.predicate.entity.EntityPredicates;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.random.Random;
import net.minecraft.util.shape.VoxelShape;
import net.minecraft.world.BlockView;
import net.minecraft.world.World;
import net.minecraft.world.WorldAccess;
import net.minecraft.world.WorldView;
import net.minecraft.world.event.GameEvent;
import org.jetbrains.annotations.Nullable;

public abstract class AbstractPressurePlateBlock
extends Block {
    protected static final VoxelShape PRESSED_SHAPE = Block.createCuboidShape(1.0, 0.0, 1.0, 15.0, 0.5, 15.0);
    protected static final VoxelShape DEFAULT_SHAPE = Block.createCuboidShape(1.0, 0.0, 1.0, 15.0, 1.0, 15.0);
    protected static final Box BOX = new Box(0.0625, 0.0, 0.0625, 0.9375, 0.25, 0.9375);
    private final BlockSetType blockSetType;

    protected AbstractPressurePlateBlock(AbstractBlock.Settings settings, BlockSetType blockSetType) {
        super(settings.sounds(blockSetType.comp_1290()));
        this.blockSetType = blockSetType;
    }

    @Override
    public VoxelShape getOutlineShape(BlockState blockState, BlockView blockView, BlockPos blockPos, ShapeContext shapeContext) {
        return this.getRedstoneOutput(blockState) > 0 ? PRESSED_SHAPE : DEFAULT_SHAPE;
    }

    protected int getTickRate() {
        return 20;
    }

    @Override
    public boolean canMobSpawnInside(BlockState blockState) {
        return true;
    }

    @Override
    public BlockState getStateForNeighborUpdate(BlockState blockState, Direction direction, BlockState blockState2, WorldAccess worldAccess, BlockPos blockPos, BlockPos blockPos2) {
        if (direction == Direction.field_11033 && !blockState.canPlaceAt(worldAccess, blockPos)) {
            return Blocks.field_10124.getDefaultState();
        }
        return super.getStateForNeighborUpdate(blockState, direction, blockState2, worldAccess, blockPos, blockPos2);
    }

    @Override
    public boolean canPlaceAt(BlockState blockState, WorldView worldView, BlockPos blockPos) {
        BlockPos blockPos2 = blockPos.down();
        return AbstractPressurePlateBlock.hasTopRim(worldView, blockPos2) || AbstractPressurePlateBlock.sideCoversSmallSquare(worldView, blockPos2, Direction.field_11036);
    }

    @Override
    public void scheduledTick(BlockState blockState, ServerWorld serverWorld, BlockPos blockPos, Random random) {
        int i = this.getRedstoneOutput(blockState);
        if (i > 0) {
            this.updatePlateState(null, serverWorld, blockPos, blockState, i);
        }
    }

    @Override
    public void onEntityCollision(BlockState blockState, World world, BlockPos blockPos, Entity entity) {
        if (world.isClient) {
            return;
        }
        int i = this.getRedstoneOutput(blockState);
        if (i == 0) {
            this.updatePlateState(entity, world, blockPos, blockState, i);
        }
    }

    private void updatePlateState(@Nullable Entity entity, World world, BlockPos blockPos, BlockState blockState, int i) {
        boolean bl2;
        int j = this.getRedstoneOutput(world, blockPos);
        boolean bl = i > 0;
        boolean bl3 = bl2 = j > 0;
        if (i != j) {
            BlockState blockState2 = this.setRedstoneOutput(blockState, j);
            world.setBlockState(blockPos, blockState2, 2);
            this.updateNeighbors(world, blockPos);
            world.scheduleBlockRerenderIfNeeded(blockPos, blockState, blockState2);
        }
        if (!bl2 && bl) {
            world.playSound(null, blockPos, this.blockSetType.comp_1295(), SoundCategory.field_15245);
            world.emitGameEvent(entity, GameEvent.field_28175, blockPos);
        } else if (bl2 && !bl) {
            world.playSound(null, blockPos, this.blockSetType.comp_1296(), SoundCategory.field_15245);
            world.emitGameEvent(entity, GameEvent.field_28174, blockPos);
        }
        if (bl2) {
            world.scheduleBlockTick(new BlockPos(blockPos), this, this.getTickRate());
        }
    }

    @Override
    public void onStateReplaced(BlockState blockState, World world, BlockPos blockPos, BlockState blockState2, boolean bl) {
        if (bl || blockState.isOf(blockState2.getBlock())) {
            return;
        }
        if (this.getRedstoneOutput(blockState) > 0) {
            this.updateNeighbors(world, blockPos);
        }
        super.onStateReplaced(blockState, world, blockPos, blockState2, bl);
    }

    protected void updateNeighbors(World world, BlockPos blockPos) {
        world.updateNeighborsAlways(blockPos, this);
        world.updateNeighborsAlways(blockPos.down(), this);
    }

    @Override
    public int getWeakRedstonePower(BlockState blockState, BlockView blockView, BlockPos blockPos, Direction direction) {
        return this.getRedstoneOutput(blockState);
    }

    @Override
    public int getStrongRedstonePower(BlockState blockState, BlockView blockView, BlockPos blockPos, Direction direction) {
        if (direction == Direction.field_11036) {
            return this.getRedstoneOutput(blockState);
        }
        return 0;
    }

    @Override
    public boolean emitsRedstonePower(BlockState blockState) {
        return true;
    }

    protected static int getEntityCount(World world, Box box, Class<? extends Entity> class_) {
        return world.getEntitiesByClass(class_, box, EntityPredicates.EXCEPT_SPECTATOR.and(entity -> !entity.canAvoidTraps())).size();
    }

    protected abstract int getRedstoneOutput(World var1, BlockPos var2);

    protected abstract int getRedstoneOutput(BlockState var1);

    protected abstract BlockState setRedstoneOutput(BlockState var1, int var2);
}


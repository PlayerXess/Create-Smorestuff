/*
 * Decompiled with CFR 0.2.1 (FabricMC 53fa44c9).
 */
package net.minecraft.enchantment;

import com.google.common.collect.Maps;
import java.util.EnumMap;
import java.util.Map;
import net.minecraft.enchantment.EnchantmentTarget;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityGroup;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.screen.ScreenTexts;
import net.minecraft.text.MutableText;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.Util;
import org.jetbrains.annotations.Nullable;

public abstract class Enchantment {
    private final EquipmentSlot[] slotTypes;
    private final Rarity rarity;
    public final EnchantmentTarget target;
    @Nullable
    protected String translationKey;

    @Nullable
    public static Enchantment byRawId(int i) {
        return (Enchantment)Registries.ENCHANTMENT.get(i);
    }

    protected Enchantment(Rarity rarity, EnchantmentTarget enchantmentTarget, EquipmentSlot[] equipmentSlots) {
        this.rarity = rarity;
        this.target = enchantmentTarget;
        this.slotTypes = equipmentSlots;
    }

    public Map<EquipmentSlot, ItemStack> getEquipment(LivingEntity livingEntity) {
        EnumMap<EquipmentSlot, ItemStack> map = Maps.newEnumMap(EquipmentSlot.class);
        for (EquipmentSlot equipmentSlot : this.slotTypes) {
            ItemStack itemStack = livingEntity.getEquippedStack(equipmentSlot);
            if (itemStack.isEmpty()) continue;
            map.put(equipmentSlot, itemStack);
        }
        return map;
    }

    public Rarity getRarity() {
        return this.rarity;
    }

    public int getMinLevel() {
        return 1;
    }

    public int getMaxLevel() {
        return 1;
    }

    public int getMinPower(int i) {
        return 1 + i * 10;
    }

    public int getMaxPower(int i) {
        return this.getMinPower(i) + 5;
    }

    public int getProtectionAmount(int i, DamageSource damageSource) {
        return 0;
    }

    public float getAttackDamage(int i, EntityGroup entityGroup) {
        return 0.0f;
    }

    public final boolean canCombine(Enchantment enchantment) {
        return this.canAccept(enchantment) && enchantment.canAccept(this);
    }

    protected boolean canAccept(Enchantment enchantment) {
        return this != enchantment;
    }

    protected String getOrCreateTranslationKey() {
        if (this.translationKey == null) {
            this.translationKey = Util.createTranslationKey("enchantment", Registries.ENCHANTMENT.getId(this));
        }
        return this.translationKey;
    }

    public String getTranslationKey() {
        return this.getOrCreateTranslationKey();
    }

    public Text getName(int i) {
        MutableText mutableText = Text.translatable(this.getTranslationKey());
        if (this.isCursed()) {
            mutableText.formatted(Formatting.field_1061);
        } else {
            mutableText.formatted(Formatting.field_1080);
        }
        if (i != 1 || this.getMaxLevel() != 1) {
            mutableText.append(ScreenTexts.SPACE).append(Text.translatable("enchantment.level." + i));
        }
        return mutableText;
    }

    public boolean isAcceptableItem(ItemStack itemStack) {
        return this.target.isAcceptableItem(itemStack.getItem());
    }

    public void onTargetDamaged(LivingEntity livingEntity, Entity entity, int i) {
    }

    public void onUserDamaged(LivingEntity livingEntity, Entity entity, int i) {
    }

    public boolean isTreasure() {
        return false;
    }

    public boolean isCursed() {
        return false;
    }

    public boolean isAvailableForEnchantedBookOffer() {
        return true;
    }

    public boolean isAvailableForRandomSelection() {
        return true;
    }

    public static enum Rarity {
        field_9087(10),
        field_9090(5),
        field_9088(2),
        field_9091(1);

        private final int weight;

        private Rarity(int j) {
            this.weight = j;
        }

        public int getWeight() {
            return this.weight;
        }
    }
}

